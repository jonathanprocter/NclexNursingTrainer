import { Pool, PoolConfig, PoolClient } from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import { EventEmitter } from 'events';
import * as schema from '@db/schema';

export class DatabaseManager extends EventEmitter {
  private pool: Pool | null = null;
  private isInitialized = false;
  private isShuttingDown = false;
  private readonly MAX_RETRIES = 3;
  private readonly RETRY_DELAY = 1000;

  constructor(private readonly config: PoolConfig) {
    super();
  }

  async initialize(): Promise<boolean> {
    if (this.isInitialized) {
      return true;
    }

    if (this.isShuttingDown) {
      throw new Error('Cannot initialize during shutdown');
    }

    try {
      this.pool = new Pool(this.config);
      
      this.pool.on('error', (err: Error) => {
        console.error('Unexpected error on idle client:', err);
        this.emit('error', err);
      });

      this.pool.on('connect', (client: PoolClient) => {
        console.log('New client connected to the pool');
        this.emit('connect', client);
      });

      // Verify connection
      await this.verifyConnection();
      
      this.isInitialized = true;
      return true;
    } catch (error) {
      console.error('Failed to initialize database manager:', error);
      await this.cleanup();
      throw error;
    }
  }

  private async verifyConnection(): Promise<void> {
    for (let attempt = 1; attempt <= this.MAX_RETRIES; attempt++) {
      try {
        const client = await this.pool?.connect();
        if (!client) {
          throw new Error('Failed to get database client');
        }
        
        await client.query('SELECT 1');
        client.release();
        console.log('Database connection verified successfully');
        return;
      } catch (error) {
        console.error(`Database connection attempt ${attempt}/${this.MAX_RETRIES} failed:`, error);
        
        if (attempt === this.MAX_RETRIES) {
          throw error;
        }
        
        await new Promise(resolve => setTimeout(resolve, this.RETRY_DELAY * attempt));
      }
    }
  }

  getDrizzle() {
    if (!this.pool || !this.isInitialized) {
      throw new Error('Database not initialized');
    }
    return drizzle(this.pool, { schema });
  }

  async cleanup(): Promise<void> {
    if (this.isShuttingDown) {
      return;
    }

    this.isShuttingDown = true;
    console.log('Starting database manager cleanup...');

    try {
      if (this.pool) {
        await new Promise<void>((resolve, reject) => {
          const timeout = setTimeout(() => {
            reject(new Error('Pool end timeout'));
          }, 5000);

          this.pool?.end(() => {
            clearTimeout(timeout);
            resolve();
          });
        });
      }
      
      console.log('Database manager cleanup completed');
    } catch (error) {
      console.error('Error during database manager cleanup:', error);
      throw error;
    } finally {
      this.pool = null;
      this.isInitialized = false;
      this.isShuttingDown = false;
    }
  }

  isConnected(): boolean {
    return this.isInitialized && !this.isShuttingDown;
  }
}

// Create and export the singleton instance
const poolConfig: PoolConfig = {
  connectionString: process.env.DATABASE_URL,
  max: process.env.DATABASE_MAX_CONNECTIONS
    ? parseInt(process.env.DATABASE_MAX_CONNECTIONS, 10)
    : 20,
  idleTimeoutMillis: process.env.DATABASE_IDLE_TIMEOUT
    ? parseInt(process.env.DATABASE_IDLE_TIMEOUT, 10)
    : 30000,
  connectionTimeoutMillis: process.env.DATABASE_CONNECTION_TIMEOUT
    ? parseInt(process.env.DATABASE_CONNECTION_TIMEOUT, 10)
    : 5000,
  ssl: process.env.NODE_ENV === 'production'
    ? { rejectUnauthorized: false }
    : false,
  keepAlive: true,
  application_name: 'nclex_prep_app',
};

export const dbManager = new DatabaseManager(poolConfig);