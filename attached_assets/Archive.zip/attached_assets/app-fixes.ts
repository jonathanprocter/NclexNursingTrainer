// 1. First, let's update the queryClient configuration
// lib/queryClient.ts
import { QueryClient } from '@tanstack/react-query';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
      staleTime: 30000,
    },
  },
});

// 2. Create a proper types file
// types/analytics.ts
export interface DashboardData {
  overallProgress: number;
  totalQuestions: number;
  correctAnswers: number;
  lastUpdated: string;
}

export interface AnalyticsDashboardData {
  summary: {
    estimatedMastery: number;
    averageAccuracy: number;
    totalAttempts: number;
    totalCorrect: number;
    averageResponseTime: number;
    weeklyImprovement: number;
    totalStudyTime: number;
  };
  performanceTrend: Array<{
    date: string;
    accuracy: number;
    attempts: number;
  }>;
  adaptiveLearning: {
    currentLevel: number;
    recommendedTopics: string[];
    difficultyAdjustment: number;
    masteryProgress: Array<{
      topic: string;
      mastery: number;
      confidence: number;
    }>;
  };
}

// 3. Create API service for data fetching
// services/api.ts
import axios from 'axios';
import { DashboardData, AnalyticsDashboardData } from '../types/analytics';

const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

export const fetchDashboardData = async (): Promise<DashboardData> => {
  const { data } = await api.get('/dashboard/overview');
  return data;
};

export const fetchAnalytics = async (): Promise<AnalyticsDashboardData> => {
  const { data } = await api.get('/analytics/dashboard');
  return data;
};

// 4. Update the AdvancedAnalyticsDashboard component
// components/AdvancedAnalyticsDashboard/index.tsx
import { useQuery } from '@tanstack/react-query';
import { fetchAnalytics } from '../../services/api';
import { AnalyticsDashboardData } from '../../types/analytics';

export function AdvancedAnalyticsDashboard() {
  const { data, isLoading, error } = useQuery<AnalyticsDashboardData>({
    queryKey: ['analytics'],
    queryFn: fetchAnalytics,
    staleTime: 30000,
  });

  if (isLoading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-40 bg-gray-200 rounded" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (error || !data) {
    return (
      <Alert variant="destructive">
        <AlertDescription>
          Failed to load analytics data. Please try again later.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Mastery Level</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {data.summary.estimatedMastery}%
            </div>
            <Progress value={data.summary.estimatedMastery} className="mt-2" />
          </CardContent>
        </Card>
        
        {/* Add other cards similarly */}
      </div>

      {/* Performance Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Performance Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data.performanceTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis domain={[0, 100]} />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="accuracy"
                  stroke="hsl(var(--primary))"
                  name="Accuracy %"
                />
                <Line
                  type="monotone"
                  dataKey="attempts"
                  stroke="hsl(var(--secondary))"
                  name="Attempts"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// 5. Update the main Dashboard component
// pages/Dashboard.tsx
import { useQuery } from '@tanstack/react-query';
import { fetchDashboardData } from '../services/api';
import { DashboardData } from '../types/analytics';
import { AdvancedAnalyticsDashboard } from '../components/AdvancedAnalyticsDashboard';

export default function Dashboard() {
  const { data, isLoading } = useQuery<DashboardData>({
    queryKey: ['dashboard'],
    queryFn: fetchDashboardData,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <Skeleton className="h-12 w-64" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-[200px]" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">NCLEX Prep Dashboard</h1>
          <Card className="w-auto">
            <CardContent className="py-4 px-6">
              <div className="flex items-center space-x-4">
                <Avatar>
                  <AvatarFallback>U</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium">Welcome back!</p>
                  <p className="text-sm text-muted-foreground">NCLEX Candidate</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <AdvancedAnalyticsDashboard />

        {/* Progress Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Questions Attempted</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <div className="text-4xl font-bold">
                  {data?.totalQuestions || 0}
                </div>
                <div className="text-sm text-muted-foreground">
                  Total questions
                </div>
              </div>
              <div className="mt-4 text-sm text-muted-foreground">
                Correct: {data?.correctAnswers || 0}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Overall Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <div className="text-4xl font-bold">
                  {data?.overallProgress ? Math.round(data.overallProgress) : 0}%
                </div>
                <div className="text-sm text-muted-foreground">
                  Success rate
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}