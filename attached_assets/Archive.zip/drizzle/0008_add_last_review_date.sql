
ALTER TABLE user_progress
ADD COLUMN IF NOT EXISTS last_review_date timestamp with time zone;

-- Backfill with current timestamp for existing records
UPDATE user_progress 
SET last_review_date = CURRENT_TIMESTAMP 
WHERE last_review_date IS NULL;
