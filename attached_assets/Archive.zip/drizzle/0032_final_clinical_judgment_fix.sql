
-- Add column with proper type and default
ALTER TABLE flashcards 
    ADD COLUMN clinical_judgment_level clinical_judgment_level DEFAULT '2';

-- Update migration history
INSERT INTO drizzle.migration_history (version, applied_at) 
VALUES ('0032', CURRENT_TIMESTAMP);
