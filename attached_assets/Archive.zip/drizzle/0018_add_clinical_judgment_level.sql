
-- Drop existing enum if it exists
DROP TYPE IF EXISTS clinical_judgment_level CASCADE;

-- Create enum type
CREATE TYPE clinical_judgment_level AS ENUM ('1', '2', '3', '4');

-- Add column with proper enum type
ALTER TABLE flashcards ADD COLUMN IF NOT EXISTS clinical_judgment_level clinical_judgment_level;
