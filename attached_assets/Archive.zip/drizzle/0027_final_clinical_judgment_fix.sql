
-- Drop any existing type and its dependencies
DROP TYPE IF EXISTS clinical_judgment_level CASCADE;

-- Create the enum type first
CREATE TYPE clinical_judgment_level AS ENUM ('1', '2', '3', '4');

-- Drop the column if it exists
ALTER TABLE flashcards DROP COLUMN IF EXISTS clinical_judgment_level;

-- Add the column with the new enum type
ALTER TABLE flashcards ADD COLUMN clinical_judgment_level clinical_judgment_level DEFAULT '2';

-- Add migration to history table
INSERT INTO drizzle.migration_history (version, applied_at) 
VALUES ('0027', CURRENT_TIMESTAMP);
