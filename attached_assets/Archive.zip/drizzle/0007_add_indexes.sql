
-- Add indexes for frequently queried columns
CREATE INDEX IF NOT EXISTS user_progress_user_id_idx ON user_progress (user_id);
CREATE INDEX IF NOT EXISTS user_progress_question_id_idx ON user_progress (question_id);
CREATE INDEX IF NOT EXISTS questions_domain_id_idx ON questions (domain_id);
CREATE INDEX IF NOT EXISTS cognitive_metrics_user_id_idx ON cognitive_metrics (user_id);

ALTER TABLE questions
ADD CONSTRAINT fk_questions_domain 
FOREIGN KEY (domain_id) REFERENCES nclex_domains(id) ON DELETE CASCADE;

ALTER TABLE cognitive_metrics
ADD CONSTRAINT fk_cognitive_metrics_user
FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;

ALTER TABLE user_progress
ADD CONSTRAINT fk_user_progress_user
FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;
CREATE INDEX IF NOT EXISTS cognitive_metrics_session_time_idx ON cognitive_metrics (session_start_time);
CREATE INDEX IF NOT EXISTS nclex_domains_category_idx ON nclex_domains (category);
CREATE INDEX IF NOT EXISTS questions_clinical_judgment_idx ON questions (clinical_judgment_level);
