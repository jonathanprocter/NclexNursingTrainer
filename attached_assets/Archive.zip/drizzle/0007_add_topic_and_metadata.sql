-- Add topic column and update metadata structure
ALTER TABLE questions 
ADD COLUMN IF NOT EXISTS topic TEXT,
ADD COLUMN IF NOT EXISTS category TEXT;

-- Update existing rows to have a default topic and category if needed
UPDATE questions 
SET topic = domain_id::text || '_topic',
    category = 'fundamentals'
WHERE topic IS NULL;

-- Make columns NOT NULL after setting defaults
ALTER TABLE questions
ALTER COLUMN topic SET NOT NULL,
ALTER COLUMN category SET NOT NULL;

-- Create type if not exists
DO $$ BEGIN
    CREATE TYPE category AS ENUM (
        'fundamentals',
        'medical_surgical',
        'pediatric',
        'mental_health',
        'maternal',
        'leadership'
    );
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Convert category to enum type
ALTER TABLE questions 
ALTER COLUMN category TYPE category USING category::category;

-- Update metadata column to include new fields
UPDATE questions 
SET metadata = jsonb_build_object(
    'conceptualLevel', 'recall',
    'clinicalJudgmentLevel', '1',
    'cognitiveComplexity', 1
)
WHERE metadata IS NULL OR NOT (metadata ? 'conceptualLevel');

-- Create index on topic for better query performance
CREATE INDEX IF NOT EXISTS idx_questions_topic ON questions(topic);
