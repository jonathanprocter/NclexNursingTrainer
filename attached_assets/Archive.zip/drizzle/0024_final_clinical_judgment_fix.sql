-- Drop existing type if exists
DROP TYPE IF EXISTS clinical_judgment_level CASCADE;

-- Create enum type
CREATE TYPE clinical_judgment_level AS ENUM ('1', '2', '3', '4');

-- Drop column if exists
ALTER TABLE flashcards DROP COLUMN IF EXISTS clinical_judgment_level;

-- Add column with proper enum type
ALTER TABLE flashcards ADD COLUMN clinical_judgment_level clinical_judgment_level;

-- Add this migration to history
INSERT INTO drizzle.migration_history (version, applied_at) VALUES ('0024', NOW());