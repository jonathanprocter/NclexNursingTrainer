-- Migrate analytics tables to new structure

-- Drop obsolete tables if they exist
DROP TABLE IF EXISTS cognitive_metrics CASCADE;

-- Create NCLEX domains table if it doesn't exist
CREATE TABLE IF NOT EXISTS nclex_domains (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    weightage INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Update progress_tracking table
ALTER TABLE IF EXISTS progress_tracking 
    DROP COLUMN IF EXISTS content_id,
    DROP COLUMN IF EXISTS emotional_state,
    DROP COLUMN IF EXISTS cognitive_level,
    DROP COLUMN IF EXISTS ai_analysis,
    ADD COLUMN IF NOT EXISTS correct BOOLEAN NOT NULL DEFAULT false,
    ADD COLUMN IF NOT EXISTS response_time INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS time_spent INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS domain_id INTEGER REFERENCES nclex_domains(id),
    ADD COLUMN IF NOT EXISTS difficulty TEXT NOT NULL DEFAULT 'medium',
    ADD COLUMN IF NOT EXISTS performance JSONB NOT NULL DEFAULT '{"accuracy": 0, "confidenceLevel": 0, "masteryLevel": 0}'::jsonb,
    ADD COLUMN IF NOT EXISTS metadata JSONB;

-- Update user_progress table structure
ALTER TABLE IF EXISTS user_progress
    DROP COLUMN IF EXISTS question_id,
    ADD COLUMN IF NOT EXISTS domain_id INTEGER REFERENCES nclex_domains(id),
    ALTER COLUMN response_time SET DEFAULT 0,
    ALTER COLUMN learning_metrics SET NOT NULL,
    ALTER COLUMN learning_metrics SET DEFAULT '{"retentionRate": 0, "masteryLevel": 0, "predictedScore": 0, "cognitiveLoad": 0}'::jsonb;

-- Add indices for better query performance
CREATE INDEX IF NOT EXISTS idx_progress_tracking_user_timestamp 
    ON progress_tracking(user_id, timestamp DESC);

CREATE INDEX IF NOT EXISTS idx_user_progress_user_timestamp 
    ON user_progress(user_id, timestamp DESC);

CREATE INDEX IF NOT EXISTS idx_progress_tracking_domain 
    ON progress_tracking(domain_id);

CREATE INDEX IF NOT EXISTS idx_user_progress_domain 
    ON user_progress(domain_id);

-- Insert default NCLEX domains if they don't exist
INSERT INTO nclex_domains (name, description, weightage)
SELECT d.name, d.description, d.weightage
FROM (
    VALUES 
        ('management_of_care', 'Management of Care', 20),
        ('safety_infection_control', 'Safety and Infection Control', 15),
        ('health_promotion', 'Health Promotion and Maintenance', 12),
        ('psychosocial_integrity', 'Psychosocial Integrity', 12),
        ('basic_care_comfort', 'Basic Care and Comfort', 10),
        ('pharmacological_therapies', 'Pharmacological and Parenteral Therapies', 15),
        ('risk_reduction', 'Reduction of Risk Potential', 10),
        ('physiological_adaptation', 'Physiological Adaptation', 6)
) AS d(name, description, weightage)
WHERE NOT EXISTS (
    SELECT 1 FROM nclex_domains WHERE name = d.name
);