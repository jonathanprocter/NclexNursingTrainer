
DO $$ 
BEGIN
    -- First drop any existing column using this type
    ALTER TABLE IF EXISTS flashcards 
        DROP COLUMN IF EXISTS clinical_judgment_level;

    -- Then drop the type if it exists    
    DROP TYPE IF EXISTS clinical_judgment_level;
END $$;

-- Create enum type fresh
CREATE TYPE clinical_judgment_level AS ENUM ('1', '2', '3', '4');

-- Add column with proper type and default
ALTER TABLE flashcards 
    ADD COLUMN clinical_judgment_level clinical_judgment_level DEFAULT '2';

-- Update migration history
INSERT INTO drizzle.migration_history (version, applied_at) 
VALUES ('0031', CURRENT_TIMESTAMP);
