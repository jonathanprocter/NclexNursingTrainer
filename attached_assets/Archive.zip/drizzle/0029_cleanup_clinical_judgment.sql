
DO $$ 
BEGIN
    -- Drop any existing enum type and dependent objects
    DROP TYPE IF EXISTS clinical_judgment_level CASCADE;
END $$;

-- Create the enum type
CREATE TYPE clinical_judgment_level AS ENUM ('1', '2', '3', '4');

-- Ensure column exists with proper type and default
ALTER TABLE flashcards 
    DROP COLUMN IF EXISTS clinical_judgment_level CASCADE;

ALTER TABLE flashcards 
    ADD COLUMN clinical_judgment_level clinical_judgment_level DEFAULT '2';

-- Log migration
INSERT INTO drizzle.migration_history (version, applied_at) 
VALUES ('0029', CURRENT_TIMESTAMP);
