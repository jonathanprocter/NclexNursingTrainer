
-- Drop existing column if it exists
ALTER TABLE flashcards DROP COLUMN IF EXISTS clinical_judgment_level;

-- Add column with proper enum type
ALTER TABLE flashcards ADD COLUMN clinical_judgment_level clinical_judgment_level;
