-- Drop existing column and type first
DROP TYPE IF EXISTS clinical_judgment_level CASCADE;

-- Recreate the enum type
CREATE TYPE clinical_judgment_level AS ENUM ('1', '2', '3', '4');

-- Drop column if exists (to prevent conflicts)
ALTER TABLE flashcards DROP COLUMN IF EXISTS clinical_judgment_level;

-- Add column with proper enum type and make it nullable
ALTER TABLE flashcards ADD COLUMN clinical_judgment_level clinical_judgment_level;