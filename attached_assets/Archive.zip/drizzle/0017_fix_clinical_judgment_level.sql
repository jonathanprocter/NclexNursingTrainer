
-- Drop existing column and type if they exist
DROP TABLE IF EXISTS flashcards CASCADE;
DROP TYPE IF EXISTS clinical_judgment_level CASCADE;

-- Create enum type
CREATE TYPE clinical_judgment_level AS ENUM ('1', '2', '3', '4');

-- Recreate flashcards table with proper schema
CREATE TABLE flashcards (
  id SERIAL PRIMARY KEY,
  front TEXT NOT NULL,
  back TEXT NOT NULL,
  category category DEFAULT 'fundamentals',
  difficulty difficulty DEFAULT 'medium',
  explanation TEXT,
  tags TEXT[],
  hint TEXT,
  saved_for_review BOOLEAN DEFAULT false,
  clinical_judgment_level clinical_judgment_level,
  conceptual_level conceptual_level,
  rationale JSONB,
  clinical_reasoning JSONB,
  metadata JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);
