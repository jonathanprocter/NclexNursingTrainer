-- Drop existing knowledge_gaps table if it exists
DROP TABLE IF EXISTS knowledge_gaps CASCADE;

-- Create knowledge_gaps table
CREATE TABLE knowledge_gaps (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  domain nclex_domain NOT NULL,
  cognitive_level cognitive_complexity NOT NULL,
  gap_details JSONB NOT NULL DEFAULT '{"concepts": [], "recommendedContent": [], "priority": "medium"}',
  status TEXT NOT NULL DEFAULT 'identified',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Create indices for better query performance
CREATE INDEX IF NOT EXISTS knowledge_gaps_user_id_idx ON knowledge_gaps(user_id);
CREATE INDEX IF NOT EXISTS knowledge_gaps_domain_idx ON knowledge_gaps(domain);
CREATE INDEX IF NOT EXISTS knowledge_gaps_status_idx ON knowledge_gaps(status);
