
-- Add missing columns for flashcards
ALTER TABLE flashcards
ADD COLUMN IF NOT EXISTS conceptual_level text,
ADD COLUMN IF NOT EXISTS scenario text,
ADD COLUMN IF NOT EXISTS rationale jsonb,
ADD COLUMN IF NOT EXISTS clinical_reasoning jsonb;
