
DO $$ 
BEGIN
    -- Drop the column first to avoid dependency issues
    DROP COLUMN IF EXISTS clinical_judgment_level CASCADE;
    
    -- Drop the type if it exists
    IF EXISTS (SELECT 1 FROM pg_type WHERE typname = 'clinical_judgment_level') THEN
        DROP TYPE clinical_judgment_level CASCADE;
    END IF;
EXCEPTION WHEN OTHERS THEN
    -- Ignore errors if objects don't exist
END $$;

-- Create the enum type
CREATE TYPE clinical_judgment_level AS ENUM ('1', '2', '3', '4');

-- Add the column with the enum type
ALTER TABLE flashcards 
ADD COLUMN clinical_judgment_level clinical_judgment_level DEFAULT '2';

-- Update migration history
INSERT INTO drizzle.migration_history (version, applied_at) 
VALUES ('0028', CURRENT_TIMESTAMP);
