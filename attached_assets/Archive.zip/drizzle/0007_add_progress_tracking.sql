-- Create progress tracking table for analytics
CREATE TABLE IF NOT EXISTS "progress_tracking" (
  "id" serial PRIMARY KEY NOT NULL,
  "user_id" integer NOT NULL,
  "question_id" integer NOT NULL,
  "domain_id" integer,
  "correct" boolean NOT NULL,
  "response_time" integer NOT NULL,
  "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
  "performance" jsonb NOT NULL,
  "metadata" jsonb,
  CONSTRAINT "progress_tracking_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT "progress_tracking_question_id_questions_id_fk" FOREIGN KEY ("question_id") REFERENCES "questions"("id") ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT "progress_tracking_domain_id_nclex_domains_id_fk" FOREIGN KEY ("domain_id") REFERENCES "nclex_domains"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
);

-- Add indices for better query performance
CREATE INDEX IF NOT EXISTS "idx_progress_tracking_user_timestamp" ON "progress_tracking"("user_id", "timestamp" DESC);
CREATE INDEX IF NOT EXISTS "idx_progress_tracking_domain" ON "progress_tracking"("domain_id");
