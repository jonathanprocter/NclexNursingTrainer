
ALTER TABLE flashcards
ADD COLUMN IF NOT EXISTS conceptual_level text,
ADD COLUMN IF NOT EXISTS metadata jsonb,
ADD COLUMN IF NOT EXISTS rationale jsonb,
ADD COLUMN IF NOT EXISTS clinical_reasoning jsonb,
ADD COLUMN IF NOT EXISTS saved_for_review boolean DEFAULT false;
