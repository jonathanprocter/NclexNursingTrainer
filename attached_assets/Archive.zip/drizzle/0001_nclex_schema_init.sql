-- CreateEnum
CREATE TYPE "cognitive_complexity" AS ENUM ('recall', 'application', 'analysis', 'evaluation', 'synthesis');
CREATE TYPE "module_type" AS ENUM ('pharmacology_parenteral', 'analyze_cues_hypotheses', 'risk_reduction', 'clinical_judgment');
CREATE TYPE "nclex_domain" AS ENUM (
  'management_of_care',
  'safety_infection_control',
  'health_promotion',
  'psychosocial_integrity',
  'basic_care_comfort',
  'pharmacological_therapies',
  'risk_reduction',
  'physiological_adaptation',
  'clinical_judgment'
);

-- CreateTable
CREATE TABLE IF NOT EXISTS "users" (
  "id" SERIAL PRIMARY KEY,
  "email" TEXT NOT NULL UNIQUE,
  "username" TEXT NOT NULL UNIQUE,
  "password" TEXT NOT NULL,
  "current_module" module_type,
  "progress_metrics" JSONB,
  "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "learning_modules" (
  "id" SERIAL PRIMARY KEY,
  "module_type" module_type NOT NULL,
  "name" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "cognitive_level" cognitive_complexity NOT NULL,
  "content" JSONB NOT NULL,
  "prerequisites" INTEGER[],
  "estimated_duration" INTEGER,
  "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "user_progress" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "module_id" INTEGER NOT NULL REFERENCES "learning_modules"("id"),
  "cognitive_level" cognitive_complexity NOT NULL,
  "completion_status" DECIMAL NOT NULL,
  "performance_metrics" JSONB,
  "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "assessment_results" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "module_id" INTEGER NOT NULL REFERENCES "learning_modules"("id"),
  "domain" nclex_domain NOT NULL,
  "cognitive_level" cognitive_complexity NOT NULL,
  "score" DECIMAL NOT NULL,
  "details" JSONB,
  "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "learning_insights" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "module_id" INTEGER NOT NULL REFERENCES "learning_modules"("id"),
  "insight_type" TEXT NOT NULL,
  "content" JSONB NOT NULL,
  "cognitive_level" cognitive_complexity NOT NULL,
  "recommended_actions" JSONB[],
  "priority" INTEGER DEFAULT 1,
  "applied_status" BOOLEAN DEFAULT false,
  "effectiveness" DECIMAL,
  "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateIndexes
CREATE INDEX IF NOT EXISTS "user_progress_user_id_idx" ON "user_progress"("user_id");
CREATE INDEX IF NOT EXISTS "user_progress_module_id_idx" ON "user_progress"("module_id");
CREATE INDEX IF NOT EXISTS "assessment_results_user_id_idx" ON "assessment_results"("user_id");
CREATE INDEX IF NOT EXISTS "assessment_results_module_id_idx" ON "assessment_results"("module_id");
CREATE INDEX IF NOT EXISTS "learning_insights_user_id_idx" ON "learning_insights"("user_id");
CREATE INDEX IF NOT EXISTS "learning_insights_module_id_idx" ON "learning_insights"("module_id");