
-- Fix flashcards table structure
ALTER TABLE flashcards
DROP COLUMN IF EXISTS metadata;

ALTER TABLE flashcards
DROP COLUMN IF EXISTS ai_metadata;

ALTER TABLE flashcards 
ADD COLUMN IF NOT EXISTS metadata jsonb DEFAULT '{}';
