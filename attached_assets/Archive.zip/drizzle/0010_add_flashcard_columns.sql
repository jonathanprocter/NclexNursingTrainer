
-- Add conceptual_level and other missing columns
ALTER TABLE flashcards
ADD COLUMN IF NOT EXISTS conceptual_level text,
ADD COLUMN IF NOT EXISTS clinical_judgment_level text,
ADD COLUMN IF NOT EXISTS scenario text;
