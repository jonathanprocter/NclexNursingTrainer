-- Create enum for export formats
DO $$ BEGIN
    CREATE TYPE export_format AS ENUM ('markdown', 'pdf', 'docx', 'html', 'text');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Create bookmark folders table
CREATE TABLE IF NOT EXISTS bookmark_folders (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    name TEXT NOT NULL,
    description TEXT,
    parent_folder_id INTEGER REFERENCES bookmark_folders(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Create bookmarks table
CREATE TABLE IF NOT EXISTS bookmarks (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    url TEXT,
    tags TEXT[],
    ai_generated_notes JSONB,
    export_formats JSONB,
    metadata JSONB,
    folder_id INTEGER REFERENCES bookmark_folders(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Create smart notes table
CREATE TABLE IF NOT EXISTS smart_notes (
    id SERIAL PRIMARY KEY,
    bookmark_id INTEGER NOT NULL REFERENCES bookmarks(id),
    user_id INTEGER NOT NULL REFERENCES users(id),
    content JSONB NOT NULL,
    metadata JSONB,
    export_history JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_bookmarks_user_id ON bookmarks(user_id);
CREATE INDEX IF NOT EXISTS idx_bookmarks_folder_id ON bookmarks(folder_id);
CREATE INDEX IF NOT EXISTS idx_bookmark_folders_user_id ON bookmark_folders(user_id);
CREATE INDEX IF NOT EXISTS idx_bookmark_folders_parent_id ON bookmark_folders(parent_folder_id);
CREATE INDEX IF NOT EXISTS idx_smart_notes_bookmark_id ON smart_notes(bookmark_id);
CREATE INDEX IF NOT EXISTS idx_smart_notes_user_id ON smart_notes(user_id);
