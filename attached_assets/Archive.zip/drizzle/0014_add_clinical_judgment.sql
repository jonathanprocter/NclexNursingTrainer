
ALTER TABLE flashcards
ADD COLUMN IF NOT EXISTS clinical_judgment_level text;
