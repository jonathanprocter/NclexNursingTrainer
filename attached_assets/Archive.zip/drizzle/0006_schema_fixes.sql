
DO $$ 
BEGIN
    -- Create or update enums
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'difficulty') THEN
        CREATE TYPE difficulty AS ENUM ('easy', 'medium', 'hard');
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'category') THEN
        CREATE TYPE category AS ENUM (
            'fundamentals', 'medical_surgical', 'mental_health', 'clinical_judgment',
            'pharmacology', 'risk_management', 'maternal', 'pediatric'
        );
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'conceptual_level') THEN
        CREATE TYPE conceptual_level AS ENUM ('recall', 'application', 'analysis', 'synthesis', 'evaluation');
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'clinical_judgment_level') THEN
        CREATE TYPE clinical_judgment_level AS ENUM ('1', '2', '3', '4');
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'module_status') THEN
        CREATE TYPE module_status AS ENUM ('not_started', 'in_progress', 'completed');
    END IF;

    -- Add missing columns
    ALTER TABLE questions ADD COLUMN IF NOT EXISTS created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP;
    ALTER TABLE questions ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP;
    ALTER TABLE cognitive_metrics ADD COLUMN IF NOT EXISTS created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP;
    ALTER TABLE cognitive_metrics ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP;

    -- Update timestamps to be not null
    ALTER TABLE user_progress ALTER COLUMN timestamp SET NOT NULL;
    ALTER TABLE questions ALTER COLUMN created_at SET NOT NULL;
    ALTER TABLE questions ALTER COLUMN updated_at SET NOT NULL;
    ALTER TABLE cognitive_metrics ALTER COLUMN created_at SET NOT NULL;
    ALTER TABLE cognitive_metrics ALTER COLUMN updated_at SET NOT NULL;
END $$;
