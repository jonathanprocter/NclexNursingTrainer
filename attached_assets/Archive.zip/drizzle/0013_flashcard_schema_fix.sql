
-- Drop and recreate enums with correct values
DROP TYPE IF EXISTS category CASCADE;
DROP TYPE IF EXISTS difficulty CASCADE; 
DROP TYPE IF EXISTS conceptual_level CASCADE;
DROP TYPE IF EXISTS clinical_judgment_level CASCADE;

CREATE TYPE category AS ENUM ('fundamentals', 'medical_surgical', 'pediatrics', 'mental_health', 'maternal_newborn', 'community_health', 'leadership');
CREATE TYPE difficulty AS ENUM ('easy', 'medium', 'hard');
CREATE TYPE conceptual_level AS ENUM ('recall', 'application', 'analysis', 'synthesis', 'evaluation');
CREATE TYPE clinical_judgment_level AS ENUM ('1', '2', '3', '4');

-- Recreate flashcards table with correct schema
DROP TABLE IF EXISTS flashcards CASCADE;

CREATE TABLE flashcards (
  id SERIAL PRIMARY KEY,
  front TEXT NOT NULL,
  back TEXT NOT NULL,
  category category DEFAULT 'fundamentals',
  difficulty difficulty DEFAULT 'medium',
  explanation TEXT,
  tags TEXT[],
  hint TEXT,
  saved_for_review BOOLEAN DEFAULT false,
  clinical_judgment_level clinical_judgment_level,
  conceptual_level conceptual_level,
  rationale JSONB,
  clinical_reasoning JSONB,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);
