-- Drop existing tables and enums
DROP TABLE IF EXISTS user_progress CASCADE;
DROP TABLE IF EXISTS cognitive_metrics CASCADE;

-- Create required enums if they don't exist
DO $$ BEGIN
    CREATE TYPE nclex_domain AS ENUM (
        'management_of_care',
        'safety_infection_control', 
        'health_promotion',
        'psychosocial_integrity',
        'basic_care_comfort',
        'pharmacological_therapies',
        'risk_reduction',
        'physiological_adaptation'
    );
    EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- Create user_progress table with correct structure
CREATE TABLE IF NOT EXISTS user_progress (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    question_id INTEGER NOT NULL REFERENCES questions(id),
    domain nclex_domain NOT NULL,
    correct BOOLEAN NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    response_time INTEGER,
    learning_metrics JSONB,
    metadata JSONB
);

-- Create cognitive_metrics table
CREATE TABLE IF NOT EXISTS cognitive_metrics (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    session_start_time TIMESTAMP WITH TIME ZONE NOT NULL,
    fatigue_indicators JSONB,
    performance_metrics JSONB
);

-- Create indices for better query performance
CREATE INDEX IF NOT EXISTS user_progress_user_id_idx ON user_progress(user_id);
CREATE INDEX IF NOT EXISTS user_progress_question_id_idx ON user_progress(question_id);
CREATE INDEX IF NOT EXISTS user_progress_domain_idx ON user_progress(domain);
CREATE INDEX IF NOT EXISTS cognitive_metrics_user_id_idx ON cognitive_metrics(user_id);
