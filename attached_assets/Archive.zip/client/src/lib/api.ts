const API_BASE = `/api`;

export async function uploadFile(
  file: File,
  onProgress?: (progress: number) => void,
) {
  const formData = new FormData();
  formData.append("file", file);

  const response = await fetch(`${API_BASE}/upload`, {
    method: "POST",
    body: formData,
  });

  if (!response.ok) {
    throw new Error(`Upload failed: ${await response.text()}`);
  }

  const result = await response.json();
  if (onProgress) {
    onProgress(100);
  }
  return result;
}

export async function processBatch() {
  const response = await fetch(`${API_BASE}/batch-process`, {
    method: "POST",
  });

  if (!response.ok) {
    throw new Error(`Batch processing failed: ${await response.text()}`);
  }

  return response.json();
}
