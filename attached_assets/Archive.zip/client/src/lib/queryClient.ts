import { QueryClient } from "@tanstack/react-query";

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: async ({ queryKey }) => {
        const res = await fetch(queryKey[0] as string, {
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
          },
        });

        if (!res.ok) {
          const errorText = await res.text();
          // Handle 500+ errors differently as they are server issues
          if (res.status >= 500) {
            throw new Error(`Server Error (${res.status}): ${errorText}`);
          }
          // Client errors (400-499) should be handled gracefully
          throw new Error(errorText || res.statusText);
        }

        return res.json();
      },
      // Retry client errors less aggressively
      retry: (failureCount, error) => {
        if (error instanceof Error && error.message.startsWith("Server Error")) {
          return failureCount < 3;
        }
        return failureCount < 1;
      },
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
      // Cache for 30 seconds by default
      staleTime: 30000,
      // Don't refetch on window focus for better UX
      refetchOnWindowFocus: false,
    },
    mutations: {
      // Don't retry mutations as they might have side effects
      retry: false,
    },
  },
});