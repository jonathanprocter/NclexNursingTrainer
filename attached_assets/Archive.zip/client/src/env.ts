export const env = {
  DATABASE_URL:
    process.env.DATABASE_URL ||
    "postgresql://postgres:postgres@0.0.0.0:5432/nclex_db",
  NODE_ENV: process.env.NODE_ENV || "development",
  PORT: Number(process.env.PORT) || 3000,
  HOST: process.env.HOST || "0.0.0.0",
  CORS_ORIGIN: process.env.CORS_ORIGIN || "*",
  DATABASE_MAX_CONNECTIONS: Number(process.env.DATABASE_MAX_CONNECTIONS) || 10,
  DATABASE_IDLE_TIMEOUT: Number(process.env.DATABASE_IDLE_TIMEOUT) || 30000,
  RATE_LIMIT_WINDOW: Number(process.env.RATE_LIMIT_WINDOW) || 900000,
  RATE_LIMIT_MAX: Number(process.env.RATE_LIMIT_MAX) || 100,
  OPENAI_MODEL: process.env.OPENAI_MODEL || "gpt-4",
  OPENAI_MAX_TOKENS: Number(process.env.OPENAI_MAX_TOKENS) || 2000,
  OPENAI_TIMEOUT: Number(process.env.OPENAI_TIMEOUT) || 30000,
  MAX_QUESTIONS_PER_SESSION:
    Number(process.env.MAX_QUESTIONS_PER_SESSION) || 75,
  SESSION_SECRET:
    process.env.SESSION_SECRET || "your-secure-session-secret-key-here",
  WS_PROTOCOL: process.env.NODE_ENV === "production" ? "wss" : "ws",
  API_URL: process.env.API_URL || "http://0.0.0.0:3000",
} as const;
