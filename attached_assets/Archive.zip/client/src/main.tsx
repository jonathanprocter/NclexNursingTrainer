import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import App from "./App";
import "./index.css";

// Initialize React Query client with default config
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      cacheTime: 10 * 60 * 1000, // 10 minutes
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

// Get root element with type safety
const rootElement = document.getElementById("root");

if (!rootElement) {
  throw new Error(
    "Root element not found - ensure index.html contains a <div id=\"root\"></div>"
  );
}

// Create root instance
const root = createRoot(rootElement);

// Render app with strict mode and providers
root.render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
      <Toaster />
    </QueryClientProvider>
  </StrictMode>
);

// Enable HMR for development
if (import.meta.hot) {
  import.meta.hot.accept();
}