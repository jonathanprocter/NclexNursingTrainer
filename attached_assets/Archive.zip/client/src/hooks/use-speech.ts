import { useState, useCallback, useEffect } from "react";

interface UseSpeechProps {
  rate?: number;
  pitch?: number;
}

interface SpeechProps {
  question: string;
  options?: string[];
}

export function useSpeech({ rate = 1, pitch = 1 }: UseSpeechProps = {}) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [supported, setSupported] = useState(false);

  useEffect(() => {
    setSupported("speechSynthesis" in window);
  }, []);

  const stop = useCallback(() => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    }
  }, []);

  const playQuestionAndOptions = useCallback(
    ({ question, options }: SpeechProps) => {
      if (!("speechSynthesis" in window)) return;

      stop();
      setIsPlaying(true);

      const utterance = new SpeechSynthesisUtterance(question);
      utterance.rate = rate;
      utterance.pitch = pitch;

      utterance.onend = () => {
        if (options?.length) {
          const optionsText = `Options are: ${options.join(". ")}`;
          const optionsUtterance = new SpeechSynthesisUtterance(optionsText);
          optionsUtterance.rate = rate;
          optionsUtterance.pitch = pitch;
          optionsUtterance.onend = () => setIsPlaying(false);
          window.speechSynthesis.speak(optionsUtterance);
        } else {
          setIsPlaying(false);
        }
      };

      window.speechSynthesis.speak(utterance);
    },
    [rate, pitch, stop],
  );

  return {
    playQuestionAndOptions,
    stop,
    isPlaying,
    supported,
  };
}
