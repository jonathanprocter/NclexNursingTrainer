import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  Users,
  BookOpen,
  Brain,
  Activity,
  TrendingUp,
  AlertCircle,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Student {
  id: number;
  name: string;
  lastActive: string;
  averageScore: number;
  questionsAttempted: number;
  learningProgress: {
    estimatedMastery: number;
  };
  performanceTrend: number[];
  weakAreas: string[];
}

interface DomainStats {
  domain: string;
  averageScore: number;
  totalAttempts: number;
  improvement: number;
  distribution: Array<{ category: string; value: number }>;
  trendData: Array<{ date: string; score: number }>;
}

const InstructorDashboard = () => {
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const { data: students = [], isLoading: loadingStudents } = useQuery<
    Student[]
  >({
    queryKey: ["/api/instructor/students"],
  });

  const { data: domainStats = [], isLoading: loadingDomains } = useQuery<
    DomainStats[]
  >({
    queryKey: ["/api/instructor/domain-stats"],
  });

  const handleLogout = async () => {
    try {
      const response = await fetch("/api/auth/instructor/logout", {
        method: "POST",
        credentials: "include",
      });

      if (!response.ok) {
        throw new Error("Logout failed");
      }

      sessionStorage.removeItem("instructor_auth");
      toast({
        title: "Logged out",
        description: "Successfully logged out of instructor dashboard",
      });
      setLocation("/");
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to logout",
        variant: "destructive",
      });
    }
  };

  if (loadingStudents || loadingDomains) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Instructor Dashboard</h1>
        <Button variant="outline" onClick={handleLogout}>
          Logout
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Total Students</p>
                <p className="text-2xl font-bold">{students.length || 0}</p>
              </div>
              <Users className="w-8 h-8 text-primary opacity-75" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Average Performance</p>
                <p className="text-2xl font-bold">
                  {domainStats.length
                    ? Math.round(
                        domainStats.reduce(
                          (acc, d) => acc + d.averageScore,
                          0,
                        ) / domainStats.length,
                      )
                    : 0}
                  %
                </p>
              </div>
              <Activity className="w-8 h-8 text-primary opacity-75" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Total Questions Attempted</p>
                <p className="text-2xl font-bold">
                  {domainStats.reduce((acc, d) => acc + d.totalAttempts, 0)}
                </p>
              </div>
              <BookOpen className="w-8 h-8 text-primary opacity-75" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium">Overall Improvement</p>
                <p className="text-2xl font-bold">
                  {Math.round(
                    domainStats.reduce((acc, d) => acc + d.improvement, 0) /
                      (domainStats.length || 1),
                  )}
                  %
                </p>
              </div>
              <TrendingUp className="w-8 h-8 text-primary opacity-75" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="domains" className="space-y-4">
        <TabsList>
          <TabsTrigger value="domains">Domain Analysis</TabsTrigger>
          <TabsTrigger value="students">Student Progress</TabsTrigger>
        </TabsList>

        <TabsContent value="domains">
          <div className="grid gap-4 md:grid-cols-2">
            {domainStats.map((domain, index) => (
              <Card key={index} className="overflow-hidden">
                <CardHeader>
                  <CardTitle>{domain.domain}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">
                        Average Score
                      </span>
                      <span className="font-bold">{domain.averageScore}%</span>
                    </div>

                    <div className="h-[200px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={domain.trendData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" />
                          <YAxis domain={[0, 100]} />
                          <Tooltip />
                          <Line
                            type="monotone"
                            dataKey="score"
                            stroke="hsl(var(--primary))"
                            strokeWidth={2}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>

                    <div className="h-[200px] mt-4">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={domain.distribution}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="category" />
                          <YAxis />
                          <Tooltip />
                          <Bar dataKey="value" fill="hsl(var(--primary))" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>

                    <Progress value={domain.averageScore} className="mt-2" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="students">
          <div className="space-y-4">
            {students.map((student: Student) => (
              <Card key={student.id}>
                <CardHeader>
                  <CardTitle>{student.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <p className="text-sm text-muted-foreground">
                        Last active:{" "}
                        {new Date(student.lastActive).toLocaleDateString()}
                      </p>
                      <div className="text-2xl font-bold">
                        {student.averageScore}%
                      </div>
                    </div>

                    <div className="grid gap-4 md:grid-cols-3">
                      <div className="flex items-center gap-2">
                        <Brain className="w-4 h-4" />
                        <span>Questions: {student.questionsAttempted}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Activity className="w-4 h-4" />
                        <span>
                          Mastery: {student.learningProgress.estimatedMastery}%
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <TrendingUp className="w-4 h-4" />
                        <span>
                          Improvement:{" "}
                          {
                            student.performanceTrend[
                              student.performanceTrend.length - 1
                            ]
                          }
                          %
                        </span>
                      </div>
                    </div>

                    {student.weakAreas.length > 0 && (
                      <div>
                        <p className="text-sm font-medium mb-2">
                          Areas Needing Focus:
                        </p>
                        <div className="flex gap-2 flex-wrap">
                          {student.weakAreas.map((area: string, i: number) => (
                            <div
                              key={i}
                              className="px-2 py-1 bg-red-100 text-red-800 rounded-md text-sm flex items-center gap-1"
                            >
                              <AlertCircle className="w-3 h-3" />
                              {area}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <Progress value={student.averageScore} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default InstructorDashboard;
