import { useState, useEffect } from "react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "./ui/badge";
import { Alert, AlertDescription, AlertTitle } from "./ui/alert";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  CheckCircle,
  XCircle,
  Flag,
  Clock,
  ChevronLeft,
  ChevronRight,
  SkipForward,
  BookOpen,
  Brain,
  AlertCircle,
  BarChart2,
  Target,
} from "lucide-react";

interface NclexQuestion {
  id: string;
  question: string;
  answers: string[];
  correctAnswer: number;
  rationale: string;
  category: string;
  difficulty?: "easy" | "medium" | "hard";
  averageTime?: number;
  successRate?: number;
  nextReviewDate?: string;
  repetitionNumber?: number;
  easeFactor?: number;
  interval?: number;
}

interface Props {
  questions: NclexQuestion[];
  onComplete?: (
    score: number,
    flaggedQuestions: string[],
    analytics: QuizAnalytics,
  ) => void;
}

interface QuizAnalytics {
  averageTimePerQuestion: number;
  correctAnswers: number;
  incorrectAnswers: number;
  flaggedCount: number;
  timeSpentPerQuestion: number[];
  retentionScore?: number;
  learningEfficiency?: number;
}

export function NclexQuiz({ questions, onComplete }: Props) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showRationale, setShowRationale] = useState(false);
  const [score, setScore] = useState(0);
  const [questionStartTime, setQuestionStartTime] = useState(Date.now());
  const [timeSpentPerQuestion, setTimeSpentPerQuestion] = useState<number[]>(
    [],
  );
  const [flaggedQuestions, setFlaggedQuestions] = useState<Set<string>>(
    new Set(),
  );
  const [incorrectAnswers, setIncorrectAnswers] = useState<Set<number>>(
    new Set(),
  );
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const currentQuestion = questions[currentIndex];
  const progress = ((currentIndex + 1) / questions.length) * 100;
  const averageTimePerQuestion =
    timeSpentPerQuestion.length > 0
      ? Math.round(
          timeSpentPerQuestion.reduce((a, b) => a + b, 0) /
            timeSpentPerQuestion.length,
        )
      : 0;

  useEffect(() => {
    setQuestionStartTime(Date.now());
  }, [currentIndex]);

  const recordAttemptMutation = useMutation({
    mutationFn: async (data: {
      questionId: string;
      isCorrect: boolean;
      responseTime: number;
    }) => {
      const response = await fetch("/api/quiz/attempt", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        throw new Error("Failed to record attempt");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quiz/progress"] });
    },
    onError: (error) => {
      console.error("Failed to record attempt:", error);
      toast({
        title: "Error",
        description: "Failed to record your answer. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleAnswerSelect = async (answerIndex: number) => {
    if (selectedAnswer !== null) return;

    const timeSpent = Math.round((Date.now() - questionStartTime) / 1000);
    setTimeSpentPerQuestion([...timeSpentPerQuestion, timeSpent]);
    setSelectedAnswer(answerIndex);

    const isCorrect = answerIndex === currentQuestion.correctAnswer;
    if (isCorrect) {
      setScore((prev) => prev + 1);
      toast({
        title: "Correct!",
        description:
          "Great job! Review the rationale to reinforce your understanding.",
        variant: "default",
      });
    } else {
      setIncorrectAnswers((prev) => new Set(prev).add(currentIndex));
      toast({
        title: "Incorrect",
        description:
          "Take time to understand why. The rationale will help you learn.",
        variant: "destructive",
      });
    }

    // Record the attempt with spaced repetition
    try {
      await recordAttemptMutation.mutateAsync({
        questionId: currentQuestion.id,
        isCorrect,
        responseTime: timeSpent * 1000, // Convert to milliseconds
      });
    } catch (error) {
      console.error("Failed to record attempt:", error);
    }

    setShowRationale(true);
  };

  const handleNext = () => {
    if (currentIndex === questions.length - 1) {
      const analytics: QuizAnalytics = {
        averageTimePerQuestion,
        correctAnswers: score,
        incorrectAnswers: incorrectAnswers.size,
        flaggedCount: flaggedQuestions.size,
        timeSpentPerQuestion,
        retentionScore: (score / questions.length) * 100,
        learningEfficiency: calculateLearningEfficiency(
          timeSpentPerQuestion,
          score,
          questions.length,
        ),
      };
      onComplete?.(score, Array.from(flaggedQuestions), analytics);
      return;
    }

    setCurrentIndex((prev) => prev + 1);
    setSelectedAnswer(null);
    setShowRationale(false);
  };

  const calculateLearningEfficiency = (
    times: number[],
    correct: number,
    total: number,
  ): number => {
    const avgTime = times.reduce((a, b) => a + b, 0) / times.length;
    const accuracyWeight = correct / total;
    const timeWeight = Math.max(0, 1 - avgTime / 120); // Normalize time, assuming 120s is max ideal time
    return Math.round((accuracyWeight * 0.7 + timeWeight * 0.3) * 100);
  };

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
      setSelectedAnswer(null);
      setShowRationale(false);
    }
  };

  const toggleFlagQuestion = () => {
    const newFlagged = new Set(flaggedQuestions);
    if (newFlagged.has(currentQuestion.id)) {
      newFlagged.delete(currentQuestion.id);
      toast({
        title: "Question Unflagged",
        description: "Question removed from review list",
        variant: "default",
      });
    } else {
      newFlagged.add(currentQuestion.id);
      toast({
        title: "Question Flagged",
        description: "Question added to review list",
        variant: "default",
      });
    }
    setFlaggedQuestions(newFlagged);
  };

  if (!currentQuestion) return null;

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Header Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <p className="text-sm font-medium">Progress</p>
              <p className="text-2xl font-bold">{Math.round(progress)}%</p>
            </div>
            <BarChart2 className="h-8 w-8 text-primary opacity-75" />
          </div>
          {currentQuestion.interval && (
            <div className="mt-2 text-xs text-muted-foreground">
              Review interval: {currentQuestion.interval} days
            </div>
          )}
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <p className="text-sm font-medium">Score</p>
              <p className="text-2xl font-bold">
                {score}/{currentIndex + 1}
              </p>
            </div>
            <Target className="h-8 w-8 text-primary opacity-75" />
          </div>
          {currentQuestion.easeFactor && (
            <div className="mt-2 text-xs text-muted-foreground">
              Ease: {(currentQuestion.easeFactor / 100).toFixed(2)}
            </div>
          )}
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <p className="text-sm font-medium">Avg Time</p>
              <p className="text-2xl font-bold">{averageTimePerQuestion}s</p>
            </div>
            <Clock className="h-8 w-8 text-primary opacity-75" />
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <p className="text-sm font-medium">Question</p>
              <p className="text-2xl font-bold">
                {currentIndex + 1}/{questions.length}
              </p>
            </div>
            <Brain className="h-8 w-8 text-primary opacity-75" />
          </div>
          {currentQuestion.repetitionNumber !== undefined && (
            <div className="mt-2 text-xs text-muted-foreground">
              Review #{currentQuestion.repetitionNumber + 1}
            </div>
          )}
        </Card>
      </div>

      <Progress value={progress} className="h-2" />

      {/* Question Card */}
      <Card className="p-6">
        <div className="space-y-6">
          {/* Question Header */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Badge variant="outline" className="gap-1">
                <BookOpen className="h-4 w-4" />
                {currentQuestion.category}
              </Badge>
              <div className="flex items-center gap-2">
                {currentQuestion.difficulty && (
                  <Badge
                    variant="outline"
                    className={
                      currentQuestion.difficulty === "hard"
                        ? "bg-red-100 text-red-800"
                        : currentQuestion.difficulty === "medium"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-green-100 text-green-800"
                    }
                  >
                    {currentQuestion.difficulty.charAt(0).toUpperCase() +
                      currentQuestion.difficulty.slice(1)}
                  </Badge>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={toggleFlagQuestion}
                  className={
                    flaggedQuestions.has(currentQuestion.id)
                      ? "text-yellow-500"
                      : ""
                  }
                >
                  <Flag className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <h2 className="text-xl font-semibold">
              {currentQuestion.question}
            </h2>
          </div>

          {/* Answer Options */}
          <div className="space-y-3">
            {currentQuestion.answers.map((answer, index) => (
              <Button
                key={index}
                variant={
                  selectedAnswer === null
                    ? "outline"
                    : selectedAnswer === index
                      ? index === currentQuestion.correctAnswer
                        ? "default"
                        : "destructive"
                      : index === currentQuestion.correctAnswer &&
                          selectedAnswer !== null
                        ? "default"
                        : "outline"
                }
                className="w-full justify-start h-auto p-4 text-left relative"
                onClick={() => handleAnswerSelect(index)}
                disabled={selectedAnswer !== null}
              >
                <div className="flex items-start gap-3">
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border">
                    {String.fromCharCode(65 + index)}
                  </div>
                  <div>{answer}</div>
                </div>
                {selectedAnswer !== null &&
                  index === currentQuestion.correctAnswer && (
                    <CheckCircle className="absolute right-4 top-1/2 -translate-y-1/2 h-5 w-5 text-green-500" />
                  )}
                {selectedAnswer === index &&
                  index !== currentQuestion.correctAnswer && (
                    <XCircle className="absolute right-4 top-1/2 -translate-y-1/2 h-5 w-5 text-red-500" />
                  )}
              </Button>
            ))}
          </div>

          {/* Rationale Section */}
          {showRationale && (
            <div className="space-y-4">
              <Alert
                className={
                  selectedAnswer === currentQuestion.correctAnswer
                    ? "border-green-200 bg-green-50"
                    : "border-red-200 bg-red-50"
                }
              >
                <div className="flex items-center gap-2 mb-2">
                  {selectedAnswer === currentQuestion.correctAnswer ? (
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-500" />
                  )}
                  <AlertTitle>
                    {selectedAnswer === currentQuestion.correctAnswer
                      ? "Correct!"
                      : "Incorrect"}
                  </AlertTitle>
                </div>
                <AlertDescription className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <Brain className="h-4 w-4" />
                    <span>Understanding the Rationale:</span>
                  </div>
                  <p className="text-sm ml-6">{currentQuestion.rationale}</p>
                </AlertDescription>
              </Alert>

              {/* Next Review Schedule */}
              {currentQuestion.nextReviewDate && (
                <Alert>
                  <AlertTitle className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Next Review Schedule
                  </AlertTitle>
                  <AlertDescription>
                    This question will be reviewed again on{" "}
                    {new Date(
                      currentQuestion.nextReviewDate,
                    ).toLocaleDateString()}
                  </AlertDescription>
                </Alert>
              )}

              {/* Statistics */}
              {(currentQuestion.averageTime || currentQuestion.successRate) && (
                <div className="grid gap-4 grid-cols-2">
                  {currentQuestion.averageTime && (
                    <Card className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <p className="text-sm font-medium">Average Time</p>
                          <p className="text-xl font-bold">
                            {currentQuestion.averageTime}s
                          </p>
                        </div>
                        <Clock className="h-6 w-6 text-primary opacity-75" />
                      </div>
                    </Card>
                  )}
                  {currentQuestion.successRate && (
                    <Card className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <p className="text-sm font-medium">Success Rate</p>
                          <p className="text-xl font-bold">
                            {currentQuestion.successRate}%
                          </p>
                        </div>
                        <Target className="h-6 w-6 text-primary opacity-75" />
                      </div>
                    </Card>
                  )}
                </div>
              )}

              {/* Navigation Controls */}
              <div className="flex justify-between pt-4">
                <Button
                  variant="outline"
                  onClick={handlePrevious}
                  disabled={currentIndex === 0}
                  className="gap-2"
                >
                  <ChevronLeft className="h-4 w-4" />
                  Previous
                </Button>
                <Button onClick={handleNext} className="gap-2">
                  {currentIndex === questions.length - 1 ? (
                    <>
                      Finish Quiz
                      <SkipForward className="h-4 w-4" />
                    </>
                  ) : (
                    <>
                      Next
                      <ChevronRight className="h-4 w-4" />
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Time Indicator */}
      <div className="text-sm text-muted-foreground text-center">
        Time on current question:{" "}
        {Math.round((Date.now() - questionStartTime) / 1000)}s
      </div>
    </div>
  );
}
