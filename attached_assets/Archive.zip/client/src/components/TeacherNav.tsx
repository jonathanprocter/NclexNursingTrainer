import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { GraduationCap } from "lucide-react";
import { FC } from "react";

export const TeacherNav: FC = () => {
  return (
    <div className="fixed top-4 right-4 z-50">
      <Link href="/instructor">
        <Button variant="outline" className="gap-2">
          <GraduationCap className="h-4 w-4" />
          Instructor Dashboard
        </Button>
      </Link>
    </div>
  );
};
