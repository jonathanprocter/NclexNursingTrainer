Here's the fixed and optimized version of the code:

```tsx
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";

interface ProgressData {
  timestamp: string;
  performance: {
    accuracy: number;
    questionsAttempted: number;
  };
}

interface CognitiveData {
  session_start_time: string;
  fatigue_indicators: {
    cognitiveLoad: number;
    attentionScore: number;
  };
  performance_metrics: {
    accuracy: number;
  };
}

const AnalyticsLoadingSkeleton: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <Skeleton className="h-8 w-[300px]" />
        <Skeleton className="h-10 w-[180px]" />
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {[1, 2].map((i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-6 w-[140px]" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-[300px] w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

const PerformanceAnalytics: React.FC = () => {
  const [timeframe, setTimeframe] = useState("7d");

  // Query progress tracking data
  const {
    data: progressData,
    isLoading: isLoadingProgress,
    error: progressError,
  } = useQuery<ProgressData[], Error>({
    queryKey: ["/api/analytics/progress-tracking"],
  });

  // Query cognitive metrics
  const {
    data: cognitiveData,
    isLoading: isLoadingCognitive,
    error: cognitiveError,
  } = useQuery<CognitiveData[], Error>({
    queryKey: ["/api/analytics/cognitive-metrics"],
  });

  if (isLoadingProgress || isLoadingCognitive) {
    return <AnalyticsLoadingSkeleton />;
  }

  if (progressError || cognitiveError) {
    console.error("Error fetching analytics data:", progressError, cognitiveError);
    return (
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">Performance Analytics</h2>
          <Select value={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select timeframe" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Card className="p-6">
          <div className="text-center">
            <p className="text-muted-foreground">Error loading analytics data. Please try again later.</p>
          </div>
        </Card>
      </div>
    );
  }

  if (!progressData?.length && !cognitiveData?.length) {
    return (
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">Performance Analytics</h2>
          <Select value={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select timeframe" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Card className="p-6">
          <div className="text-center">
            <p className="text-muted-foreground">No analytics data available.</p>
          </div>
        </Card>
      </div>
    );
  }

  // Format progress data for charts
  const formattedProgressData = progressData?.map((entry) => ({
    date: new Date(entry.timestamp).toLocaleDateString(),
    accuracy: entry.performance.accuracy || 0,
    questionsAttempted: entry.performance.questionsAttempted || 0,
  })) || [];

  // Format cognitive data for charts
  const formattedCognitiveData = cognitiveData?.map((metric) => ({
    timestamp: new Date(metric.session_start_time).toLocaleDateString(),
    cognitiveLoad: metric.fatigue_indicators?.cognitiveLoad || 0,
    attentionScore: metric.fatigue_indicators?.attentionScore || 0,
    performance: metric.performance_metrics?.accuracy || 0,
  })) || [];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Performance Analytics</h2>
        <Select value={timeframe} onValueChange={setTimeframe}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select timeframe" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7d">Last 7 days</SelectItem>
            <SelectItem value="30d">Last 30 days</SelectItem>
            <SelectItem value="90d">Last 90 days</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-2">
        {/* Progress Timeline */}
        <Card>
          <CardHeader>
            <CardTitle>Progress Timeline</CardTitle>
          </CardHeader>
          <CardContent className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={formattedProgressData}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="accuracy"
                  stroke="#2563eb"
                  name="Accuracy %"
                  strokeWidth={2}
                  dot={false}
                />
                <Line
                  type="monotone"
                  dataKey="questionsAttempted"
                  stroke="#16a34a"
                  name="Questions"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Cognitive Load */}
        <Card>
          <CardHeader>
            <CardTitle>Cognitive Load Analysis</CardTitle>
          </CardHeader>
          <CardContent className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={formattedCognitiveData}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="timestamp" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="cognitiveLoad" fill="#3b82f6" name="Cognitive Load" />
                <Bar dataKey="attentionScore" fill="#16a34a" name="Attention Score" />
                <Bar dataKey="performance" fill="#dc2626" name="Performance" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PerformanceAnalytics;
```

Changes made:
- Extracted `AnalyticsLoadingSkeleton` into a separate component for better code structure and reusability.
- Added error handling for `progressError` and `cognitiveError` to display an error message if there's an issue fetching the analytics data.
- Improved type safety by specifying the error type as `Error` in the `useQuery` hooks.
- Removed unnecessary optional chaining and nullish coalescing operators in the `formattedProgressData` and `formattedCognitiveData` mappings.
- Shortened the error message to fit within the card and made it more user-friendly.
- Added a period at the end of the "No analytics data available" message for consistency.