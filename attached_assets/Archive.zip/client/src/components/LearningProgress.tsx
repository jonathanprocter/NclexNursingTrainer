import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Progress } from "./ui/progress";
import { Trophy, Target, Star, Lightbulb, Award } from "lucide-react";
import type { LearningProgress } from "@/types/analytics";

interface Props {
  progress: LearningProgress;
  loading?: boolean;
}

export function LearningProgressCard({ progress, loading = false }: Props) {
  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Learning Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 animate-pulse">
            {[1, 2, 3].map((i) => (
              <div key={i} className="space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4" />
                <div className="h-2 bg-gray-200 rounded" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-xl font-bold">Learning Journey</CardTitle>
        <Trophy className="h-5 w-5 text-primary" />
      </CardHeader>
      <CardContent className="space-y-6 pt-4">
        {/* Current Level and Next Milestone */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Award className="h-5 w-5 text-primary" />
              <span className="font-medium">{progress.currentLevel}</span>
            </div>
            <span className="text-sm text-muted-foreground">
              Next: {progress.nextMilestone}
            </span>
          </div>
          <Progress value={progress.progressToNext} className="h-2" />
          <p className="text-xs text-muted-foreground">
            {progress.progressToNext}% progress to next level
          </p>
        </div>

        {/* Achievements */}
        {progress.achievements.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-sm font-medium flex items-center gap-2">
              <Star className="h-4 w-4 text-yellow-500" />
              Recent Achievements
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {progress.achievements.map((achievement, index) => (
                <div
                  key={index}
                  className="text-xs bg-muted rounded-md p-2 flex items-center gap-2"
                >
                  <div className="h-2 w-2 rounded-full bg-primary" />
                  {achievement}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Recommended Actions */}
        {progress.recommendedActions.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-sm font-medium flex items-center gap-2">
              <Lightbulb className="h-4 w-4 text-yellow-500" />
              Recommended Actions
            </h3>
            <div className="space-y-2">
              {progress.recommendedActions.map((action, index) => (
                <div
                  key={index}
                  className="text-xs text-muted-foreground flex items-center gap-2"
                >
                  <Target className="h-3 w-3" />
                  {action}
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
