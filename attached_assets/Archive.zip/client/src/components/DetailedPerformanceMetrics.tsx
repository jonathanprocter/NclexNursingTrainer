import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Progress } from "../components/ui/progress";
import {
  BarChart,
  Target,
  Clock,
  TrendingUp,
  ArrowUp,
  ArrowDown,
  Minus,
} from "lucide-react";
import { type DomainProgress } from "@/types/analytics";
import {
  BarChart as RechartsBarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

interface Props {
  domainProgress: DomainProgress[];
  loading?: boolean;
}

export function DetailedPerformanceMetrics({
  domainProgress,
  loading = false,
}: Props) {
  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Detailed Performance Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 animate-pulse">
            {[1, 2, 3].map((i) => (
              <div key={i} className="space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4" />
                <div className="h-2 bg-gray-200 rounded" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const getTrendIcon = (trend?: "improving" | "declining" | "stable") => {
    switch (trend) {
      case "improving":
        return <ArrowUp className="h-4 w-4 text-green-500" />;
      case "declining":
        return <ArrowDown className="h-4 w-4 text-red-500" />;
      case "stable":
        return <Minus className="h-4 w-4 text-blue-500" />;
      default:
        return null;
    }
  };

  // Prepare data for the bar chart
  const chartData = domainProgress.map((domain) => ({
    name: domain.name,
    performance: domain.performanceScore,
    accuracy: domain.accuracy || 0,
  }));

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart className="h-5 w-5" />
          Detailed Performance Analysis
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6" key="performance-metrics-container">
          {/* Performance Chart */}
          <div className="h-[300px] mt-4" key="performance-chart">
            <ResponsiveContainer width="100%" height="100%">
              <RechartsBarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis
                  dataKey="name"
                  tick={{ fontSize: 12 }}
                  interval={0}
                  angle={-45}
                  textAnchor="end"
                  height={70}
                />
                <YAxis />
                <Tooltip />
                <Bar
                  dataKey="performance"
                  fill="hsl(var(--primary))"
                  name="Performance Score"
                />
                <Bar
                  dataKey="accuracy"
                  fill="hsl(var(--secondary))"
                  name="Accuracy"
                />
              </RechartsBarChart>
            </ResponsiveContainer>
          </div>

          {/* Detailed Metrics */}
          <div className="grid gap-4 md:grid-cols-2" key="detailed-metrics">
            {domainProgress.map((domain) => (
              <Card key={domain.id} className="p-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold">{domain.name}</h3>
                    <div className="flex items-center gap-2">
                      {getTrendIcon(domain.trend)}
                      <span className="text-sm font-medium">
                        {Math.round(domain.performanceScore)}%
                      </span>
                    </div>
                  </div>

                  <Progress value={domain.performanceScore} className="h-2" />

                  <div
                    className="grid grid-cols-2 gap-2 text-sm text-muted-foreground mt-2"
                    key={`${domain.id}-metrics`}
                  >
                    <div
                      className="flex items-center gap-1"
                      key={`${domain.id}-accuracy`}
                    >
                      <Target className="h-4 w-4" />
                      Accuracy: {Math.round(domain.accuracy || 0)}%
                    </div>
                    <div
                      className="flex items-center gap-1"
                      key={`${domain.id}-time`}
                    >
                      <Clock className="h-4 w-4" />
                      {domain.timeSpent
                        ? `${Math.round(domain.timeSpent / 60)}m`
                        : "N/A"}
                    </div>
                  </div>

                  {domain.recommendations &&
                    domain.recommendations.length > 0 && (
                      <div
                        className="mt-2"
                        key={`${domain.id}-recommendations`}
                      >
                        <p className="text-xs font-medium">Recommendations:</p>
                        <ul className="text-xs text-muted-foreground list-disc list-inside">
                          {domain.recommendations.map((rec, idx) => (
                            <li key={`${domain.id}-rec-${idx}`}>{rec}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                </div>
              </Card>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
