import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Brain, Target, Activity } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface AnalyticsDashboardData {
  overallProgress?: number;
  learningEfficiency?: number;
  questionPerformance?: number;
  domainMastery?: Array<{
    name: string;
    progress: number;
  }>;
}

export function AnalyticsDashboard() {
  const { data: analytics } = useQuery<AnalyticsDashboardData>({
    queryKey: ["/api/analytics/dashboard"],
  });

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Overall Progress
            </CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {analytics?.overallProgress ?? 0}%
            </div>
            <p className="text-xs text-muted-foreground">
              +2.5% from last week
            </p>
            <Progress
              value={analytics?.overallProgress ?? 0}
              className="mt-2"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Learning Efficiency
            </CardTitle>
            <Brain className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {analytics?.learningEfficiency ?? 0}%
            </div>
            <p className="text-xs text-muted-foreground">
              Knowledge retention rate
            </p>
            <Progress
              value={analytics?.learningEfficiency ?? 0}
              className="mt-2"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Question Performance
            </CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {analytics?.questionPerformance ?? 0}%
            </div>
            <p className="text-xs text-muted-foreground">Correct answer rate</p>
            <Progress
              value={analytics?.questionPerformance ?? 0}
              className="mt-2"
            />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Domain Mastery</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {analytics?.domainMastery?.map((domain) => (
              <div key={domain.name}>
                <div className="flex justify-between mb-2">
                  <span>{domain.name}</span>
                  <span>{domain.progress}%</span>
                </div>
                <Progress value={domain.progress} />
              </div>
            )) ?? (
              <p className="text-muted-foreground">
                Loading domain mastery data...
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default AnalyticsDashboard;
