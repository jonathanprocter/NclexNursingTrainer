import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { BookOpen, Brain, CheckCircle2, Book } from "lucide-react";

const topics = [
  {
    id: 1,
    title: "Safe and Effective Care Environment",
    progress: 65,
    subtopics: ["Management of Care", "Safety and Infection Control"],
    icon: Brain,
  },
  {
    id: 2,
    title: "Health Promotion and Maintenance",
    progress: 45,
    subtopics: ["Growth and Development", "Prevention and Early Detection"],
    icon: Book,
  },
  {
    id: 3,
    title: "Psychosocial Integrity",
    progress: 80,
    subtopics: ["Coping Mechanisms", "Mental Health Concepts"],
    icon: BookOpen,
  },
  {
    id: 4,
    title: "Physiological Integrity",
    progress: 30,
    subtopics: [
      "Basic Care and Comfort",
      "Pharmacological Therapies",
      "Reduction of Risk Potential",
      "Physiological Adaptation",
    ],
    icon: CheckCircle2,
  },
];

export function StudyGuide() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">NCLEX Study Guide</h1>
        <p className="text-muted-foreground mt-2">
          Comprehensive study materials organized by NCLEX exam categories
        </p>
      </div>

      <ScrollArea className="h-[calc(100vh-12rem)]">
        <div className="grid gap-6">
          {topics.map((topic) => (
            <Card key={topic.id}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <topic.icon className="h-5 w-5" />
                  {topic.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid gap-2">
                    {topic.subtopics.map((subtopic, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-2 hover:bg-accent rounded-md transition-colors"
                      >
                        <span>{subtopic}</span>
                        <Button variant="outline" size="sm">
                          Study
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
