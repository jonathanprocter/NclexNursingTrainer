Here's the fixed code:

```tsx
import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import {
  Brain,
  Loader2,
  AlertCircle,
  CheckCircle2,
  XCircle,
  Lightbulb,
  Maximize2,
} from "lucide-react";
import type {
  AdaptiveQuestion,
  AdaptiveMetrics,
  QuizAnalytics,
} from "@/types/quiz";

interface Props {
  userId: string;
  onComplete?: (analytics: QuizAnalytics) => void;
}

export function QuizGenerator({ userId, onComplete }: Props) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<
    Record<string, string>
  >({});
  const [showHint, setShowHint] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [startTime, setStartTime] = useState<number>(Date.now());
  const { toast } = useToast();

  // Fetch adaptive questions
  const { data: questions, isLoading } = useQuery<AdaptiveQuestion[]>({
    queryKey: [`/api/questions/adaptive/${userId}`],
  });

  // Track answer submission
  const submitAnswerMutation = useMutation({
    mutationFn: async ({
      questionId,
      answer,
      timeSpent,
    }: {
      questionId: string;
      answer: string;
      timeSpent: number;
    }) => {
      const response = await fetch("/api/questions/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          questionId,
          answer,
          timeSpent,
          metadata: {
            difficulty: questions?.[currentQuestionIndex]?.difficulty,
            domain: questions?.[currentQuestionIndex]?.category,
          },
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to submit answer");
      }

      return response.json();
    },
  });

  const handleAnswerSelect = async (questionId: string, answer: string) => {
    if (!questions?.[currentQuestionIndex]) return;

    const timeSpent = Date.now() - startTime;
    setSelectedAnswers((prev) => ({ ...prev, [questionId]: answer }));

    try {
      await submitAnswerMutation.mutateAsync({
        questionId,
        answer,
        timeSpent,
      });

      toast({
        title: "Answer Recorded",
        description:
          "Your response has been saved and will help personalize future questions.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save your answer. Please try again.",
        variant: "destructive",
      });
    }
  };

  const currentQuestion = questions?.[currentQuestionIndex];
  const progress = questions
    ? ((currentQuestionIndex + 1) / questions.length) * 100
    : 0;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center space-y-4">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
          <p className="text-muted-foreground">
            Generating personalized questions...
          </p>
        </div>
      </div>
    );
  }

  if (!questions || questions.length === 0) {
    return (
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          No questions available. Please try again later.
        </AlertDescription>
      </Alert>
    );
  }

  const QuestionView = currentQuestion && (
    <div className="space-y-6">
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex-1">
            <h3
              className={`${
                isFullScreen ? "text-2xl" : "text-xl"
              } font-medium leading-relaxed`}
            >
              {currentQuestion.content}
            </h3>
            <div className="flex items-center gap-2 mt-2">
              <Badge variant="outline">{currentQuestion.difficulty}</Badge>
              <Badge variant="secondary">{currentQuestion.category}</Badge>
            </div>
          </div>
        </div>

        {showHint && currentQuestion.explanation && (
          <Alert className="mb-4">
            <Lightbulb className="h-4 w-4" />
            <AlertDescription>
              Hint: {currentQuestion.explanation}
            </AlertDescription>
          </Alert>
        )}

        <div className="grid gap-4">
          {currentQuestion.options.map((option, index) => {
            const isSelected = selectedAnswers[currentQuestion.id] === option;
            const showFeedback =
              selectedAnswers[currentQuestion.id] !== undefined;
            const isCorrect = option === currentQuestion.correctAnswer;

            return (
              <Button
                key={index}
                variant={
                  showFeedback
                    ? isCorrect
                      ? "default"
                      : isSelected && !isCorrect
                      ? "destructive"
                      : "outline"
                    : isSelected
                    ? "default"
                    : "outline"
                }
                className="justify-start relative p-6 h-auto text-left w-full"
                onClick={() =>
                  !showFeedback &&
                  handleAnswerSelect(currentQuestion.id, option)
                }
                disabled={showFeedback}
              >
                <span className="mr-8">{option}</span>
                {showFeedback && (isCorrect || (isSelected && !isCorrect)) && (
                  <span className="absolute right-4">
                    {isCorrect ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-500" />
                    )}
                  </span>
                )}
              </Button>
            );
          })}
        </div>
      </div>

      {selectedAnswers[currentQuestion.id] && (
        <Card>
          <CardHeader>
            <CardTitle>Explanation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="bg-muted/50 p-4 rounded-lg">
                <h4 className="font-medium mb-2">Why This is Correct:</h4>
                <p className="text-muted-foreground">
                  {currentQuestion.explanation}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="sticky top-0 bg-background/95 pb-4 border-b z-10">
        <div className="flex items-center justify-between mb-4">
          <div className="text-sm text-muted-foreground">
            Question {currentQuestionIndex + 1} of {questions?.length ?? 0}
          </div>
          <div className="flex items-center gap-4">
            <Progress value={progress} className="w-32" />
            <Button
              variant="outline"
              size="icon"
              onClick={() => setIsFullScreen(true)}
            >
              <Maximize2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {isFullScreen ? (
        <Dialog open={isFullScreen} onOpenChange={setIsFullScreen}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>
                Question {currentQuestionIndex + 1} of {questions?.length ?? 0}
              </DialogTitle>
            </DialogHeader>
            <ScrollArea className="max-h-[80vh]">{QuestionView}</ScrollArea>
          </DialogContent>
        </Dialog>
      ) : (
        QuestionView
      )}

      <div className="flex justify-between items-center pt-4">
        <Button
          variant="outline"
          onClick={() =>
            setCurrentQuestionIndex((prev) => Math.max(0, prev - 1))
          }
          disabled={currentQuestionIndex === 0}
        >
          Previous
        </Button>

        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowHint(!showHint)}>
            {showHint ? "Hide" : "Show"} Hint
          </Button>

          <Button
            onClick={() => {
              if (currentQuestionIndex < (questions?.length ?? 0) - 1) {
                setCurrentQuestionIndex((prev) => prev + 1);
                setStartTime(Date.now());
              } else if (onComplete) {
                // Calculate final analytics
                const timeSpentPerQuestion = Object.values(selectedAnswers).map(
                  (answer) => {
                    const timeSpent = parseInt(answer.split(":")[1]);
                    return isNaN(timeSpent) ? 0 : timeSpent;
                  }
                );

                const analytics: QuizAnalytics = {
                  averageTimePerQuestion:
                    timeSpentPerQuestion.reduce((sum, time) => sum + time, 0) /
                      timeSpentPerQuestion.length || 0,
                  correctAnswers: Object.entries(selectedAnswers).filter(
                    ([key, value]) =>
                      value ===
                      questions?.find((q) => q.id === key)?.correctAnswer
                  ).length,
                  incorrectAnswers:
                    Object.keys(selectedAnswers).length -
                    Object.entries(selectedAnswers).filter(
                      ([key, value]) =>
                        value ===
                        questions?.find((q) => q.id === key)?.correctAnswer
                    ).length,
                  flaggedCount: 0,
                  timeSpentPerQuestion: timeSpentPerQuestion,
                };
                onComplete(analytics);
              }
            }}
            disabled={!selectedAnswers[currentQuestion?.id ?? ""]}
          >
            {currentQuestionIndex === (questions?.length ?? 0) - 1
              ? "Complete"
              : "Next"}
          </Button>
        </div>
      </div>
    </div>
  );
}
```