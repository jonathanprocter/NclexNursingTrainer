import { ProcessedFile } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  FileText,
  AlertCircle,
  CheckCircle,
  Image as ImageIcon,
  FileCode,
  FileJson,
  FileSpreadsheet,
  File,
  Loader2,
  Clock,
  Archive,
} from "lucide-react";
import { getFileType } from "@/lib/fileUtils";
import { formatFileSize } from "@/lib/fileUtils";
import React from "react";

interface FileProcessorProps {
  file: ProcessedFile;
}

const getFileIcon = (fileName: string) => {
  const extension = fileName.toLowerCase().slice(fileName.lastIndexOf("."));
  switch (extension) {
    case ".jpg":
    case ".jpeg":
    case ".png":
    case ".gif":
    case ".webp":
      return ImageIcon;
    case ".js":
    case ".ts":
    case ".jsx":
    case ".tsx":
      return FileCode;
    case ".json":
      return FileJson;
    case ".csv":
    case ".xlsx":
      return FileSpreadsheet;
    default:
      return FileText;
  }
};

const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleString();
};

const calculateCompressionRatio = (
  compressed: number,
  uncompressed: number,
) => {
  if (!uncompressed) return 0;
  const ratio = ((uncompressed - compressed) / uncompressed) * 100;
  return Math.round(ratio * 100) / 100;
};

export function FileProcessor({ file }: FileProcessorProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">
          <div className="flex items-center gap-2">
            {React.createElement(getFileIcon(file.name), {
              className: "w-4 h-4",
            })}
            {file.name}
          </div>
        </CardTitle>
        <Badge
          variant={
            file.status === "success"
              ? "default"
              : file.status === "error"
                ? "destructive"
                : "secondary"
          }
          className="transition-colors"
        >
          {file.status === "success" ? (
            <CheckCircle className="w-4 h-4 mr-1" />
          ) : file.status === "error" ? (
            <AlertCircle className="w-4 h-4 mr-1" />
          ) : (
            <Loader2 className="w-4 h-4 mr-1 animate-spin" />
          )}
          {file.status}
        </Badge>
      </CardHeader>
      <CardContent>
        <div className="text-sm text-muted-foreground space-y-2">
          {file.status === "success" ? (
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span>Size:</span>
                <span className="font-medium">{formatFileSize(file.size)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Files extracted:</span>
                <span className="font-medium">
                  {file.extractedFiles?.length || 0}
                </span>
              </div>
              {file.totalCompressedSize !== undefined &&
                file.totalUncompressedSize !== undefined && (
                  <div className="flex items-center justify-between">
                    <span>Compression ratio:</span>
                    <span className="font-medium">
                      {calculateCompressionRatio(
                        file.totalCompressedSize,
                        file.totalUncompressedSize,
                      )}
                      %
                    </span>
                  </div>
                )}
              {file.archiveComment && (
                <div className="mt-2 p-2 bg-muted rounded-md">
                  <p className="text-xs italic">{file.archiveComment}</p>
                </div>
              )}
              {file.processedAt && (
                <p className="flex items-center gap-1 mt-2 text-xs">
                  <Clock className="w-3 h-3" />
                  Processed: {formatDate(file.processedAt)}
                </p>
              )}
            </div>
          ) : file.status === "error" ? (
            <p className="text-destructive">{file.error}</p>
          ) : (
            <div className="space-y-2">
              <p>Processing file...</p>
              <Progress value={file.progress} className="transition-all" />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
