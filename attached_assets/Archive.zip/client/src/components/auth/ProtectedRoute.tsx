import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { Card } from "@/components/ui/card";

interface ProtectedRouteProps {
  children: React.ReactNode;
}

interface AuthResponse {
  isAuthenticated: boolean;
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const [, setLocation] = useLocation();

  // Force refetch on mount
  const { data: auth, isLoading } = useQuery<AuthResponse>({
    queryKey: ["/api/auth/instructor/verify"],
    retry: false,
    refetchOnMount: true,
    refetchOnWindowFocus: true,
  });

  useEffect(() => {
    // Check session storage first
    const hasAuth = sessionStorage.getItem("instructor_auth") === "true";

    if (!hasAuth) {
      setLocation("/instructor/login");
      return;
    }

    // If we have local auth but the server says we're not authenticated, redirect
    if (!isLoading && !auth?.isAuthenticated) {
      setLocation("/instructor/login");
    }
  }, [isLoading, auth, setLocation]);

  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-4">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <p className="mt-2 text-sm text-muted-foreground">
            Verifying access...
          </p>
        </Card>
      </div>
    );
  }

  // If we're not loading and not authenticated, don't render anything
  if (!auth?.isAuthenticated) {
    return null;
  }

  // If authenticated, render the protected content
  return <>{children}</>;
}
