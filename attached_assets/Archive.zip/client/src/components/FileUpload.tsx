import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Upload, X } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Card } from "@/components/ui/card";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, CheckCircle2 } from "lucide-react";

interface ProcessedFile {
  name: string;
  size: number;
  status: "processing" | "success" | "error";
  progress: number;
  error?: string;
  questions?: number;
  categories?: string[];
}

export function FileUpload() {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>(
    {},
  );
  const [processedFiles, setProcessedFiles] = useState<ProcessedFile[]>([]);
  const { toast } = useToast();

  const handleFileUpload = async (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    // Validate file types
    const invalidFiles = Array.from(files).filter(
      (file) => !file.name.toLowerCase().endsWith(".zip"),
    );

    if (invalidFiles.length > 0) {
      toast({
        title: "Invalid File Type",
        description: "Please upload only ZIP files containing NCLEX content.",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    const fileList = Array.from(files);
    const progressMap: Record<string, number> = {};
    fileList.forEach((file) => {
      progressMap[file.name] = 0;
      setProcessedFiles((prev) => [
        ...prev,
        {
          name: file.name,
          size: file.size,
          status: "processing",
          progress: 0,
        },
      ]);
    });
    setUploadProgress(progressMap);

    try {
      const uploadPromises = fileList.map(async (file) => {
        const formData = new FormData();
        formData.append("file", file);

        const response = await fetch("/api/nclex/content/upload", {
          method: "POST",
          body: formData,
        });

        if (!response.ok) {
          throw new Error(await response.text());
        }

        return await response.json();
      });

      const results = await Promise.all(uploadPromises);

      const newProcessedFiles = results.map((result, index) => {
        if (result.stats) {
          toast({
            title: `${fileList[index].name} processed successfully`,
            description: `Processed ${result.stats.processedQuestions} questions`,
          });
          return {
            name: fileList[index].name,
            size: fileList[index].size,
            status: "success" as const,
            progress: 100,
            questions: result.stats.processedQuestions,
            categories: result.stats.categories,
          };
        } else {
          toast({
            title: `${fileList[index].name} failed to process`,
            description: result.error || "Unknown error occurred",
            variant: "destructive",
          });
          return {
            name: fileList[index].name,
            size: fileList[index].size,
            status: "error" as const,
            progress: 0,
            error: result.error,
          };
        }
      });

      setProcessedFiles((prev) =>
        prev.map((file) => {
          const newFile = newProcessedFiles.find((f) => f.name === file.name);
          return newFile || file;
        }),
      );
    } catch (error) {
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to upload files",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
      setUploadProgress({});
    }
  };

  return (
    <div className="w-full space-y-4">
      <div className="p-4 border rounded-lg bg-card">
        <div className="flex gap-4">
          <input
            type="file"
            accept=".zip"
            onChange={handleFileUpload}
            className="hidden"
            id="file-upload"
            disabled={isUploading}
            multiple
          />
          <label htmlFor="file-upload" className="flex-1">
            <Button
              variant={isUploading ? "secondary" : "default"}
              disabled={isUploading}
              className="w-full transition-all duration-200 ease-in-out"
              asChild
            >
              <span className="flex items-center justify-center gap-2">
                {isUploading ? (
                  <X className="h-4 w-4 animate-pulse" />
                ) : (
                  <Upload className="h-4 w-4" />
                )}
                {isUploading ? "Uploading..." : "Upload ZIP Files"}
              </span>
            </Button>
          </label>
        </div>

        {/* Upload Progress */}
        {isUploading &&
          Object.entries(uploadProgress).map(([fileName, progress]) => (
            <div key={fileName} className="mt-4 space-y-2">
              <div className="flex justify-between text-sm text-muted-foreground">
                <span className="truncate">{fileName}</span>
                <span>{progress}%</span>
              </div>
              <Progress
                value={progress}
                className="transition-all duration-200"
              />
            </div>
          ))}
      </div>

      {/* Processed Files Section */}
      {processedFiles.length > 0 && (
        <div className="space-y-4">
          {processedFiles.map((file, index) => (
            <Card key={index} className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium">{file.name}</span>
                {file.status === "success" && (
                  <CheckCircle2 className="h-5 w-5 text-green-500" />
                )}
                {file.status === "error" && (
                  <AlertCircle className="h-5 w-5 text-red-500" />
                )}
              </div>

              {file.status === "processing" && (
                <Progress value={file.progress} className="mb-2" />
              )}

              {file.status === "error" && (
                <Alert variant="destructive">
                  <AlertTitle>Processing Error</AlertTitle>
                  <AlertDescription>{file.error}</AlertDescription>
                </Alert>
              )}

              {file.status === "success" && file.questions && (
                <Alert>
                  <AlertTitle>Processing Complete</AlertTitle>
                  <AlertDescription>
                    Successfully processed {file.questions} questions
                    {file.categories &&
                      ` across ${file.categories.length} categories`}
                  </AlertDescription>
                </Alert>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
