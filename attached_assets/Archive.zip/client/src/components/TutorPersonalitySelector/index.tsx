import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Brain, ChartBar, MessageCircle, Lightbulb } from "lucide-react";
import React from "react";

interface TutorPersonalitySelectorProps {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
}

export function TutorPersonalitySelector({
  value,
  onChange,
  disabled = false,
}: TutorPersonalitySelectorProps) {
  const handleChange = (selectedValue: string) => {
    if (!disabled) {
      onChange(selectedValue);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5" />
          Select Your Study Companion Style
        </CardTitle>
      </CardHeader>
      <CardContent>
        <RadioGroup
          value={value}
          onValueChange={handleChange}
          className="grid gap-4"
          disabled={disabled}
        >
          <div className="flex items-center space-x-2 border rounded-lg p-4">
            <RadioGroupItem value="encouraging" id="encouraging" />
            <Label htmlFor="encouraging" className="flex items-center gap-2">
              <MessageCircle className="h-4 w-4" />
              <div>
                <div className="font-medium">Encouraging Guide</div>
                <p className="text-sm text-muted-foreground">
                  Supportive and motivating approach to build confidence
                </p>
              </div>
            </Label>
          </div>

          <div className="flex items-center space-x-2 border rounded-lg p-4">
            <RadioGroupItem value="analytical" id="analytical" />
            <Label htmlFor="analytical" className="flex items-center gap-2">
              <ChartBar className="h-4 w-4" />
              <div>
                <div className="font-medium">Analytical Expert</div>
                <p className="text-sm text-muted-foreground">
                  Detail-oriented focus on clinical reasoning and evidence
                </p>
              </div>
            </Label>
          </div>

          <div className="flex items-center space-x-2 border rounded-lg p-4">
            <RadioGroupItem value="socratic" id="socratic" />
            <Label htmlFor="socratic" className="flex items-center gap-2">
              <Brain className="h-4 w-4" />
              <div>
                <div className="font-medium">Socratic Teacher</div>
                <p className="text-sm text-muted-foreground">
                  Guides through questions to develop critical thinking
                </p>
              </div>
            </Label>
          </div>

          <div className="flex items-center space-x-2 border rounded-lg p-4">
            <RadioGroupItem value="practical" id="practical" />
            <Label htmlFor="practical" className="flex items-center gap-2">
              <Lightbulb className="h-4 w-4" />
              <div>
                <div className="font-medium">Practical Mentor</div>
                <p className="text-sm text-muted-foreground">
                  Focuses on real clinical scenarios and applications
                </p>
              </div>
            </Label>
          </div>
        </RadioGroup>
      </CardContent>
    </Card>
  );
}