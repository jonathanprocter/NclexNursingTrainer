Here's the fixed and improved version of the code:

```tsx
import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Brain,
  Sparkles,
  Info,
  MessageSquare,
  ArrowRight,
  Lightbulb,
} from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";

interface VoiceResponse {
  message: string;
  action?:
    | "quiz"
    | "explain"
    | "summarize"
    | "recommend"
    | "motivate"
    | "ask_followup";
  voiceResponse: string;
  suggestedFollowUp?: string[];
  contextualHints?: string[];
  learningContext?: {
    currentTopic: string;
    masteryLevel: number;
    recentConcepts: string[];
  };
  additionalResources?: any;
}

interface ConversationMessage {
  type: "user" | "assistant";
  content: string;
  timestamp: string;
  context?: {
    topic?: string;
    concepts?: string[];
  };
}

export function VoiceStudyCompanion() {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [sessionId] = useState(() => `session_${Date.now()}`);
  const [showContext, setShowContext] = useState(false);
  const [messages, setMessages] = useState<ConversationMessage[]>([]);
  const [currentResponse, setCurrentResponse] = useState<VoiceResponse | null>(
    null
  );
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);
  const conversationRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    const initializeRecognition = () => {
      const SpeechRecognition =
        window.SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (!SpeechRecognition) {
        toast({
          title: "Browser Not Supported",
          description:
            "Speech recognition is not supported in your browser. Please try Chrome.",
          variant: "destructive",
        });
        return null;
      }

      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = true;
      recognitionInstance.interimResults = true;
      recognitionInstance.lang = "en-US";

      recognitionInstance.onstart = () => {
        setIsListening(true);
        toast({
          title: "Listening Started",
          description: "Speak clearly into your microphone",
        });
      };

      recognitionInstance.onerror = (event: SpeechRecognitionErrorEvent) => {
        console.error("Speech recognition error:", event.error);
        setIsListening(false);
        toast({
          title: "Voice Recognition Error",
          description: `Error: ${event.error}. Please check your microphone permissions.`,
          variant: "destructive",
        });
      };

      recognitionInstance.onend = () => {
        setIsListening(false);
        if (!isProcessing) {
          toast({
            title: "Listening Ended",
            description: "Click the microphone button to start listening again",
          });
        }
      };

      recognitionInstance.onresult = async (event: SpeechRecognitionEvent) => {
        try {
          const current = event.resultIndex;
          const transcript = event.results[current][0].transcript;
          setTranscript(transcript);

          if (event.results[current].isFinal) {
            await processVoiceCommand(transcript);
          }
        } catch (error) {
          console.error("Error processing recognition result:", error);
          toast({
            title: "Processing Error",
            description: "Failed to process speech. Please try again.",
            variant: "destructive",
          });
        }
      };

      return recognitionInstance;
    };

    const recognitionInstance = initializeRecognition();
    setRecognition(recognitionInstance);

    return () => {
      if (recognitionInstance) {
        recognitionInstance.stop();
      }
    };
  }, []);

  const processVoiceCommand = async (command: string) => {
    if (!command.trim()) {
      toast({
        title: "Empty Command",
        description: "Please speak your question or command clearly",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsProcessing(true);
      const response = await fetch("/api/voice-assistant/command", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          command,
          sessionId,
          context: {
            type: "voice_query",
            topic: "NCLEX preparation",
            focusAreas: ["pharmacology", "clinical analysis"],
            emotionalState: "neutral",
          },
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Server error: ${errorText}`);
      }

      const data: VoiceResponse = await response.json();
      setCurrentResponse(data);

      // Add messages to conversation
      setMessages((prev) => [
        ...prev,
        {
          type: "user",
          content: command,
          timestamp: new Date().toISOString(),
        },
        {
          type: "assistant",
          content: data.message,
          timestamp: new Date().toISOString(),
          context: {
            topic: data.learningContext?.currentTopic,
            concepts: data.learningContext?.recentConcepts,
          },
        },
      ]);

      speakResponse(data.voiceResponse);
    } catch (error) {
      console.error("Error processing voice command:", error);
      toast({
        title: "Processing Error",
        description:
          error instanceof Error
            ? error.message
            : "Failed to process your command",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const toggleListening = () => {
    if (!recognition) {
      toast({
        title: "Not Available",
        description:
          "Voice recognition is not available. Please check your browser settings.",
        variant: "destructive",
      });
      return;
    }

    if (isListening) {
      recognition.stop();
    } else {
      try {
        recognition.start();
      } catch (error) {
        console.error("Failed to start recognition:", error);
        toast({
          title: "Start Error",
          description: "Failed to start voice recognition. Please try again.",
          variant: "destructive",
        });
        setIsListening(false);
      }
    }
  };

  const speakResponse = (text: string) => {
    if (!("speechSynthesis" in window)) {
      toast({
        title: "Not Supported",
        description: "Text-to-speech is not supported in your browser",
        variant: "destructive",
      });
      return;
    }

    try {
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.pitch = 1;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = (event: SpeechSynthesisErrorEvent) => {
        console.error("Speech synthesis error:", event);
        setIsSpeaking(false);
        toast({
          title: "Speech Error",
          description: "Failed to speak the response",
          variant: "destructive",
        });
      };
      window.speechSynthesis.speak(utterance);
    } catch (error) {
      console.error("Speech synthesis error:", error);
      setIsSpeaking(false);
    }
  };

  const stopSpeaking = () => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  const handleFollowUpClick = (question: string) => {
    setTranscript(question);
    processVoiceCommand(question);
  };

  useEffect(() => {
    if (conversationRef.current) {
      conversationRef.current.scrollTop = conversationRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="h-6 w-6" />
            <span>AI Study Companion</span>
          </div>
          <div className="flex items-center gap-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setShowContext(!showContext)}
                  >
                    <Info className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Toggle learning context</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant={isListening ? "destructive" : "default"}
                    size="icon"
                    onClick={toggleListening}
                    disabled={isProcessing}
                    className="relative"
                  >
                    {isProcessing ? (
                      <Sparkles className="h-4 w-4 animate-spin" />
                    ) : isListening ? (
                      <MicOff className="h-4 w-4" />
                    ) : (
                      <Mic className="h-4 w-4" />
                    )}
                    {isListening && (
                      <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                    )}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  {isListening ? "Stop Listening" : "Start Listening"}
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription>
            Click the microphone button and speak clearly to interact with your
            AI study companion.
          </AlertDescription>
        </Alert>

        <div
          ref={conversationRef}
          className="h-[400px] overflow-y-auto space-y-4 p-4 border rounded-lg"
        >
          {messages.map((message, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`${
                message.type === "user" ? "bg-muted" : "bg-primary/5"
              } p-4 rounded-lg space-y-2`}
            >
              <div className="flex items-center justify-between">
                <span className="font-medium">
                  {message.type === "user" ? "You" : "AI Assistant"}:
                </span>
                {message.type === "assistant" && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={
                      isSpeaking
                        ? stopSpeaking
                        : () => speakResponse(message.content)
                    }
                  >
                    {isSpeaking ? (
                      <VolumeX className="h-4 w-4" />
                    ) : (
                      <Volume2 className="h-4 w-4" />
                    )}
                  </Button>
                )}
              </div>

              <p className="text-sm">{message.content}</p>

              {showContext && message.context && (
                <div className="mt-2 pt-2 border-t border-border/50">
                  <div className="flex flex-wrap gap-2">
                    {message.context.topic && (
                      <Badge variant="outline">
                        Topic: {message.context.topic}
                      </Badge>
                    )}
                    {message.context.concepts?.map((concept, idx) => (
                      <Badge key={idx} variant="secondary">
                        {concept}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          ))}

          {currentResponse?.suggestedFollowUp &&
            currentResponse.suggestedFollowUp.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-accent/10 p-4 rounded-lg space-y-2"
              >
                <div className="flex items-center gap-2 text-sm font-medium">
                  <MessageSquare className="h-4 w-4" />
                  <span>Suggested Follow-up Questions:</span>
                </div>
                <div className="space-y-2">
                  {currentResponse.suggestedFollowUp.map((question, index) => (
                    <Button
                      key={index}
                      variant="ghost"
                      className="w-full justify-start text-sm"
                      onClick={() => handleFollowUpClick(question)}
                    >
                      <ArrowRight className="h-4 w-4 mr-2" />
                      {question}
                    </Button>
                  ))}
                </div>
              </motion.div>
            )}

          {currentResponse?.contextualHints &&
            currentResponse.contextualHints.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-yellow-500/10 p-4 rounded-lg space-y-2"
              >
                <div className="flex items-center gap-2 text-sm font-medium">
                  <Lightbulb className="h-4 w-4" />
                  <span>Learning Hints:</span>
                </div>
                <ul className="space-y-1 text-sm">
                  {currentResponse.contextualHints.map((hint, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <span className="mt-1">•</span>
                      {hint}
                    </li>
                  ))}
                