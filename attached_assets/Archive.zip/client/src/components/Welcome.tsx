import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import {
  BookOpen,
  Target,
  TrendingUp,
  Calendar,
  ArrowRight,
} from "lucide-react";

// Mock data - will be replaced with actual data from the backend
const mockUserStats = {
  questionsAnswered: 245,
  totalQuestions: 500,
  categoriesCompleted: 3,
  totalCategories: 7,
  lastStudyDate: "2025-01-15",
  upcomingGoal: "Complete Pharmacology section by Jan 20",
};

const mockRecommendations = [
  {
    title: "Review Medical-Surgical Questions",
    description: "Your performance in this category is below average",
    priority: "high",
  },
  {
    title: "Take Practice Quiz",
    description: "It's been 2 days since your last quiz",
    priority: "medium",
  },
];

export function Welcome() {
  const progress =
    (mockUserStats.questionsAnswered / mockUserStats.totalQuestions) * 100;
  const categoryProgress =
    (mockUserStats.categoriesCompleted / mockUserStats.totalCategories) * 100;

  return (
    <div className="space-y-6">
      {/* Welcome Message */}
      <div>
        <h1 className="text-3xl font-bold">Welcome Back!</h1>
        <p className="text-muted-foreground mt-2">
          Continue your NCLEX preparation journey
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Overall Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>
                  {mockUserStats.questionsAnswered} questions completed
                </span>
                <span>{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              Categories Mastered
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>
                  {mockUserStats.categoriesCompleted} of{" "}
                  {mockUserStats.totalCategories} categories
                </span>
                <span>{Math.round(categoryProgress)}%</span>
              </div>
              <Progress value={categoryProgress} className="h-2" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Recommended Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockRecommendations.map((rec, index) => (
              <div key={index} className="flex items-start justify-between">
                <div>
                  <h3 className="font-medium">{rec.title}</h3>
                  <p className="text-sm text-muted-foreground">
                    {rec.description}
                  </p>
                </div>
                <Button variant="ghost" size="sm" className="shrink-0">
                  Start
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Upcoming Goal */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Upcoming Goal
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">{mockUserStats.upcomingGoal}</p>
              <p className="text-sm text-muted-foreground">
                Last studied:{" "}
                {new Date(mockUserStats.lastStudyDate).toLocaleDateString()}
              </p>
            </div>
            <Button variant="outline" size="sm">
              View Study Plan
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
