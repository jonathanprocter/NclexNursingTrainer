import { useQuery } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Skeleton } from "../components/ui/skeleton";
import { Brain, Clock, Target, TrendingUp, BookOpen } from "lucide-react";

interface Recommendation {
  questionId: number;
  domainId: number;
  difficulty: string;
  priority: number;
  reason:
    | "spaced_repetition"
    | "weak_area"
    | "topic_reinforcement"
    | "adaptive_difficulty";
  conceptualLevel: string;
  scheduledFor: string;
  metadata: {
    domainName: string;
    confidenceScore: number;
    recommendationScore: number;
    difficultyLevel: string;
    estimatedTime: number;
    adaptiveFactors: {
      domainStrength: number;
      conceptComplexity: number;
      difficultyWeight: number;
    };
  };
}

interface RecommendationsProps {
  userId: number;
}

export function QuestionRecommendations({ userId }: RecommendationsProps) {
  const {
    data: recommendations,
    isLoading,
    error,
  } = useQuery<Recommendation[]>({
    queryKey: [`/api/questions/recommended/${userId}`],
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  if (error) {
    console.error("Recommendations error:", error);
  }

  const getReasonIcon = (reason: string) => {
    switch (reason) {
      case "spaced_repetition":
        return <Clock className="h-4 w-4" />;
      case "weak_area":
        return <Target className="h-4 w-4" />;
      case "topic_reinforcement":
        return <Brain className="h-4 w-4" />;
      case "adaptive_difficulty":
        return <TrendingUp className="h-4 w-4" />;
      default:
        return <BookOpen className="h-4 w-4" />;
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case "hard":
        return "destructive";
      case "medium":
        return "secondary";
      default:
        return "outline";
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recommended Questions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recommendations?.map((rec) => (
            <Card key={rec.questionId} className="bg-card">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    {getReasonIcon(rec.reason)}
                    <span className="text-sm font-medium">
                      {rec.reason
                        .split("_")
                        .map(
                          (word) =>
                            word.charAt(0).toUpperCase() + word.slice(1),
                        )
                        .join(" ")}
                    </span>
                  </div>
                  <Badge
                    variant={getDifficultyColor(rec.metadata.difficultyLevel)}
                  >
                    {rec.metadata.difficultyLevel}
                  </Badge>
                </div>

                <div className="space-y-2 text-sm text-muted-foreground">
                  <div className="flex justify-between">
                    <span>Priority Level:</span>
                    <Badge
                      variant={rec.priority > 7 ? "destructive" : "secondary"}
                    >
                      {rec.priority}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Domain:</span>
                    <span>{rec.metadata.domainName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Confidence Score:</span>
                    <span>{rec.metadata.confidenceScore}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Estimated Time:</span>
                    <span>{rec.metadata.estimatedTime} min</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Scheduled For:</span>
                    <span>
                      {new Date(rec.scheduledFor).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Conceptual Level:</span>
                    <span>{rec.conceptualLevel.toUpperCase()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {recommendations?.length === 0 && (
            <div className="text-center text-muted-foreground py-4">
              No recommendations available at this time. Complete more questions
              to receive personalized suggestions.
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
