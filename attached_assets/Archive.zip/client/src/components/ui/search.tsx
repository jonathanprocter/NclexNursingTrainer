import * as React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Search as SearchIcon } from "lucide-react";

interface SearchBarProps {
  onSearch: (query: string, options: SearchOptions) => void;
}

export interface SearchOptions {
  caseSensitive: boolean;
  useRegex: boolean;
}

export function SearchBar({ onSearch }: SearchBarProps) {
  const [query, setQuery] = React.useState("");
  const [options, setOptions] = React.useState<SearchOptions>({
    caseSensitive: false,
    useRegex: false,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(query, options);
  };

  return (
    <form onSubmit={handleSearch} className="space-y-4">
      <div className="flex gap-2">
        <div className="flex-1">
          <Input
            type="text"
            placeholder="Search in files..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <Button type="submit" className="shrink-0">
          <SearchIcon className="h-4 w-4 mr-2" />
          Search
        </Button>
      </div>
      <div className="flex items-center space-x-8">
        <div className="flex items-center space-x-2">
          <Switch
            id="case-sensitive"
            checked={options.caseSensitive}
            onCheckedChange={(checked) =>
              setOptions((prev) => ({ ...prev, caseSensitive: checked }))
            }
          />
          <Label htmlFor="case-sensitive">Case sensitive</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            id="use-regex"
            checked={options.useRegex}
            onCheckedChange={(checked) =>
              setOptions((prev) => ({ ...prev, useRegex: checked }))
            }
          />
          <Label htmlFor="use-regex">Use regex</Label>
        </div>
      </div>
    </form>
  );
}
