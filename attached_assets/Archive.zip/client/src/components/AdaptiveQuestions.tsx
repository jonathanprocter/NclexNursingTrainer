import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";

interface Question {
  id: number;
  question: string;
  options: string[];
  explanation: string;
}

export function AdaptiveQuestions() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);

  const { data: questions, isLoading } = useQuery<Question[]>({
    queryKey: ["/api/adaptive/questions"],
    retry: 1,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-6">
        <Loader2 className="w-6 h-6 animate-spin mr-2" />
        <span>Loading questions...</span>
      </div>
    );
  }

  if (!questions || questions.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-center text-muted-foreground">
            No questions available. Complete an assessment to get started.
          </p>
        </CardContent>
      </Card>
    );
  }

  const currentQuestion = questions[currentIndex];

  return (
    <Card>
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold mb-4">
          {currentQuestion.question}
        </h3>

        <div className="space-y-2">
          {currentQuestion.options.map((option, i) => (
            <Button
              key={i}
              variant={selectedAnswer === option ? "default" : "outline"}
              className="w-full justify-start"
              onClick={() => {
                setSelectedAnswer(option);
                setShowExplanation(true);
              }}
            >
              {option}
            </Button>
          ))}
        </div>

        {showExplanation && (
          <div className="mt-4 p-4 bg-muted rounded-md">
            <p className="text-sm">{currentQuestion.explanation}</p>
            <Button
              className="mt-4"
              onClick={() => {
                if (currentIndex < questions.length - 1) {
                  setCurrentIndex((prev) => prev + 1);
                  setSelectedAnswer(null);
                  setShowExplanation(false);
                }
              }}
            >
              Next Question
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
