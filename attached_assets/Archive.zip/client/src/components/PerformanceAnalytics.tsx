import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Brain, TrendingUp, Target, Sparkles, Activity } from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  AreaChart,
  Area,
  ScatterChart,
  Scatter,
  Cell,
} from "recharts";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { z } from "zod";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

const TIME_RANGES = ["week", "month", "all"] as const;
type TimeRange = (typeof TIME_RANGES)[number];

const PerformanceDataSchema = z.object({
  performance: z.object({
    retentionRate: z.number().min(0).max(100),
    estimatedMastery: z.number().min(0).max(100),
    averageAccuracy: z.number().min(0).max(100),
    performanceTrend: z.array(
      z.object({
        date: z.string(),
        score: z.number(),
        average: z.number(),
      }),
    ),
    predictions: z.object({
      estimatedScore: z.number(),
      confidence: z.number(),
      recommendedAreas: z.array(z.string()),
      predictedWeaknesses: z.array(z.string()),
    }),
  }),
});

type PerformanceData = z.infer<typeof PerformanceDataSchema>;

export function PerformanceAnalytics() {
  const [timeRange, setTimeRange] = useState<TimeRange>("week");

  const { data, isLoading, error } = useQuery<PerformanceData>({
    queryKey: ["/api/analytics/performance", timeRange],
  });

  const performance = data?.performance;

  const getPerformanceColor = (value: number) => {
    if (value >= 80) return "text-green-600";
    if (value >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  const handleTimeRangeChange = (value: string) => {
    if (TIME_RANGES.includes(value as TimeRange)) {
      setTimeRange(value as TimeRange);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid gap-4 md:grid-cols-3">
          {[...Array(3)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-20" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error || !performance) {
    return (
      <Alert variant="destructive">
        <AlertDescription>
          Failed to load analytics data. Please try again later.
          {error instanceof Error ? `: ${error.message}` : ""}
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">
            Performance Analytics
          </h2>
          <p className="text-muted-foreground">
            Track your NCLEX preparation progress and identify areas for
            improvement
          </p>
        </div>
        <Select value={timeRange} onValueChange={handleTimeRangeChange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select time range" />
          </SelectTrigger>
          <SelectContent>
            {TIME_RANGES.map((range) => (
              <SelectItem key={range} value={range}>
                {`Last ${range === "all" ? "All Time" : range}`}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Retention Rate</p>
                <p
                  className={`text-2xl font-bold ${getPerformanceColor(performance.retentionRate)}`}
                >
                  {Math.round(performance.retentionRate)}%
                </p>
              </div>
              <Brain className="h-8 w-8 text-primary opacity-75" />
            </div>
            <Progress value={performance.retentionRate} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Mastery Level</p>
                <p
                  className={`text-2xl font-bold ${getPerformanceColor(performance.estimatedMastery)}`}
                >
                  {Math.round(performance.estimatedMastery)}%
                </p>
              </div>
              <Target className="h-8 w-8 text-primary opacity-75" />
            </div>
            <Progress value={performance.estimatedMastery} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Average Accuracy</p>
                <p
                  className={`text-2xl font-bold ${getPerformanceColor(performance.averageAccuracy)}`}
                >
                  {Math.round(performance.averageAccuracy)}%
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-primary opacity-75" />
            </div>
            <Progress value={performance.averageAccuracy} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Performance Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={performance.performanceTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="score"
                  stroke="#2563eb"
                  name="Your Score"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                />
                <Line
                  type="monotone"
                  dataKey="average"
                  stroke="#9ca3af"
                  name="Class Average"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recommended Areas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {performance.predictions.recommendedAreas.map((area, i) => (
                <Badge key={i} variant="secondary">
                  {area}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Areas Needing Improvement</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {performance.predictions.predictedWeaknesses.map((area, i) => (
                <Badge key={i} variant="outline" className="text-red-500">
                  {area}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
