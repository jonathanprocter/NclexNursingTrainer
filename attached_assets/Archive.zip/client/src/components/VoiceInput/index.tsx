import { useState, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Mic, Loader2, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";

interface VoiceInputProps {
  onTranscription: (text: string) => void;
  isDisabled?: boolean;
  className?: string;
  placeholder?: string;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onerror: (event: SpeechRecognitionErrorEvent) => void;
  onend: () => void;
  onresult: (event: SpeechRecognitionEvent) => void;
  onstart: () => void;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
  message?: string;
}

interface SpeechRecognitionEvent {
  results: SpeechRecognitionResultList;
  resultIndex: number;
}

interface SpeechRecognitionResultList {
  readonly length: number;
  item(index: number): SpeechRecognitionResult;
  [index: number]: SpeechRecognitionResult;
}

interface SpeechRecognitionResult {
  readonly length: number;
  item(index: number): SpeechRecognitionAlternative;
  [index: number]: SpeechRecognitionAlternative;
  isFinal: boolean;
}

interface SpeechRecognitionAlternative {
  transcript: string;
  confidence: number;
}

declare global {
  interface Window {
    SpeechRecognition: new () => SpeechRecognition;
    webkitSpeechRecognition: new () => SpeechRecognition;
  }
}

export function VoiceInput({
  onTranscription,
  isDisabled = false,
  className = "",
  placeholder = "Click to start speaking",
}: VoiceInputProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(
    null
  );
  const { toast } = useToast();

  useEffect(() => {
    const initializeRecognition = () => {
      if (!window.SpeechRecognition && !window.webkitSpeechRecognition) {
        setError("Speech recognition is not supported in your browser");
        return;
      }

      const SpeechRecognition =
        window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = true;
      recognitionInstance.interimResults = true;
      recognitionInstance.lang = "en-US";

      recognitionInstance.onstart = () => {
        setIsRecording(true);
        setError(null);
        toast({
          title: "Recording Started",
          description: "Listening for your voice input...",
        });
      };

      recognitionInstance.onresult = (event: SpeechRecognitionEvent) => {
        const results = Array.from(event.results);
        const transcript = results
          .map((result) => {
            const alternative = result[0] as SpeechRecognitionAlternative;
            return alternative.transcript;
          })
          .join("");

        if (results[0]?.isFinal) {
          onTranscription(transcript);
        }
      };

      recognitionInstance.onerror = (event: SpeechRecognitionErrorEvent) => {
        console.error("Speech recognition error:", event.error);
        setError(`Error: ${event.error}. Please try again.`);
        toast({
          title: "Recognition Error",
          description: `Failed to recognize speech: ${event.error}`,
          variant: "destructive",
        });
        stopRecording();
      };

      recognitionInstance.onend = () => {
        setIsRecording(false);
      };

      setRecognition(recognitionInstance);
    };

    initializeRecognition();

    return () => {
      if (recognition) {
        recognition.stop();
      }
    };
  }, [onTranscription, toast]);

  const startRecording = useCallback(() => {
    if (recognition) {
      try {
        recognition.start();
      } catch (error) {
        console.error("Failed to start recording:", error);
        setError("Failed to start recording. Please try again.");
      }
    }
  }, [recognition]);

  const stopRecording = useCallback(() => {
    if (recognition) {
      recognition.stop();
      setIsRecording(false);
    }
  }, [recognition]);

  return (
    <div className="space-y-2">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Button
        variant="outline"
        size="icon"
        className={className}
        onClick={isRecording ? stopRecording : startRecording}
        disabled={isDisabled || !recognition}
        type="button"
        aria-label={isRecording ? "Stop recording" : "Start recording"}
        title={placeholder}
      >
        {isRecording ? (
          <div className="relative">
            <Loader2 className="h-4 w-4 animate-spin" />
            <span className="absolute -top-1 -right-1 h-2 w-2 bg-red-500 rounded-full animate-pulse" />
          </div>
        ) : (
          <Mic className="h-4 w-4" />
        )}
      </Button>
    </div>
  );
}