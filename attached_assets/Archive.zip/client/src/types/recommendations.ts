import { z } from "zod";

export const recommendationSchema = z.object({
  moduleId: z.number(),
  title: z.string(),
  description: z.string(),
  priority: z.number(),
  reason: z.string(),
  status: z.enum(["not_started", "in_progress", "completed"]),
  progress: z.number().optional(),
});

export type Recommendation = z.infer<typeof recommendationSchema>;

export interface DomainPerformanceData {
  name: string;
  score: number;
  trend?: "improving" | "declining" | "stable";
  recommendations?: string[];
}

export interface LearningPathItem {
  moduleId: number;
  title: string;
  description: string;
  prerequisiteModules: number[];
  format: "text" | "video" | "interactive" | "simulation";
  estimatedDuration: number;
  difficulty: "easy" | "medium" | "hard";
  learningStyleMatch: number;
  priority: number;
}

export interface AdaptiveLearningState {
  currentModuleId?: number;
  completedModules: number[];
  domainProgress: Record<string, number>;
  learningPath: LearningPathItem[];
  lastAssessment?: Date;
}

export interface PersonalizedFeedback {
  strengths: string[];
  areasForImprovement: string[];
  suggestedResources: Array<{
    type: string;
    url: string;
    reason: string;
  }>;
  confidenceScore: number;
}
