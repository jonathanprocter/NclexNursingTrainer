import { z } from "zod";

export const adaptiveQuestionSchema = z
  .object({
    id: z.string(),
    content: z.string().min(1),
    options: z.array(z.string().min(1)).min(2),
    correctAnswer: z.string().min(1),
    explanation: z.string().min(1),
    category: z.string().min(1),
    difficulty: z.enum(["easy", "medium", "hard"]),
    averageTime: z.number().optional(),
    successRate: z.number().optional(),
    metadata: z
      .object({
        domainId: z.number(),
        conceptId: z.number().optional(),
        skillLevel: z.number().optional(),
      })
      .optional(),
  })
  .strict();

export const adaptiveMetricsSchema = z.object({
  recentAccuracy: z.number(),
  avgResponseTime: z.number(),
  recommendedDifficulty: z.enum(["easy", "medium", "hard"]),
  confidenceScore: z.number().optional(),
  masteryLevel: z.number().optional(),
});

export const adaptiveResponseSchema = z.object({
  success: z.boolean(),
  questions: z.array(adaptiveQuestionSchema),
  metrics: adaptiveMetricsSchema,
  recommendations: z
    .object({
      topics: z.array(z.string()),
      studyTips: z.array(z.string()),
      difficultyAdjustment: z.enum(["maintain", "increase", "decrease"]),
    })
    .optional(),
});

export type AdaptiveQuestion = z.infer<typeof adaptiveQuestionSchema>;
export type AdaptiveMetrics = z.infer<typeof adaptiveMetricsSchema>;
export type AdaptiveResponse = z.infer<typeof adaptiveResponseSchema>;

export interface QuizAnalytics {
  averageTimePerQuestion: number;
  correctAnswers: number;
  incorrectAnswers: number;
  flaggedCount: number;
  timeSpentPerQuestion: number[];
  domainPerformance?: Record<string, number>;
  confidenceScores?: number[];
  masteryProgress?: number;
}

export interface QuizResultsProps {
  score: number;
  totalQuestions: number;
  timeSpent: number;
  questions: AdaptiveQuestion[];
  analytics: QuizAnalytics | null;
  onRetake: () => void;
}
