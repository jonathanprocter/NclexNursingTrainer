import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MonitorPlay, Brain, Clock, Activity } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export default function AdvancedSimulation() {
  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            Advanced Clinical Simulation
          </h1>
          <p className="text-muted-foreground">
            Complex, multi-stage clinical scenarios for advanced practice
            preparation
          </p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Critical Care Scenario</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Complex multi-patient assignment in an ICU setting
            </p>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                <span>45 mins</span>
              </div>
              <div className="flex items-center gap-1">
                <Brain className="h-4 w-4" />
                <span>Expert</span>
              </div>
            </div>
            <Button className="w-full">Start Simulation</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Emergency Response</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              High-stakes emergency department scenarios
            </p>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                <span>30 mins</span>
              </div>
              <div className="flex items-center gap-1">
                <Brain className="h-4 w-4" />
                <span>Advanced</span>
              </div>
            </div>
            <Button className="w-full">Start Simulation</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Leadership Challenge</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Complex delegation and management scenarios
            </p>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                <span>60 mins</span>
              </div>
              <div className="flex items-center gap-1">
                <Brain className="h-4 w-4" />
                <span>Expert</span>
              </div>
            </div>
            <Button className="w-full">Start Simulation</Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your Simulation Stats</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">
                Critical Care Proficiency
              </span>
              <span className="text-sm text-muted-foreground">85%</span>
            </div>
            <Progress value={85} className="h-2" />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Emergency Response</span>
              <span className="text-sm text-muted-foreground">92%</span>
            </div>
            <Progress value={92} className="h-2" />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Leadership Skills</span>
              <span className="text-sm text-muted-foreground">78%</span>
            </div>
            <Progress value={78} className="h-2" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Simulations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium">Multi-Trauma Case</p>
                <p className="text-xs text-muted-foreground">
                  Completed yesterday
                </p>
              </div>
              <Button variant="outline" size="sm">
                <MonitorPlay className="h-4 w-4 mr-2" />
                Review
              </Button>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium">Code Blue Response</p>
                <p className="text-xs text-muted-foreground">
                  Completed 2 days ago
                </p>
              </div>
              <Button variant="outline" size="sm">
                <MonitorPlay className="h-4 w-4 mr-2" />
                Review
              </Button>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium">Unit Management</p>
                <p className="text-xs text-muted-foreground">
                  Completed 3 days ago
                </p>
              </div>
              <Button variant="outline" size="sm">
                <MonitorPlay className="h-4 w-4 mr-2" />
                Review
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
