import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PenTool, Clock, Activity, Brain } from "lucide-react";

export default function PracticeQuizzes() {
  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            Practice Quizzes
          </h1>
          <p className="text-muted-foreground">
            Test your knowledge with targeted practice questions
          </p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Quick Practice</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              10-15 questions focused on your current study topics
            </p>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                <span>15 mins</span>
              </div>
              <div className="flex items-center gap-1">
                <Activity className="h-4 w-4" />
                <span>Adaptive</span>
              </div>
            </div>
            <Button className="w-full">Start Quiz</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Topic Focus</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Practice questions from specific NCLEX domains
            </p>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-1">
                <Brain className="h-4 w-4" />
                <span>By Topic</span>
              </div>
              <div className="flex items-center gap-1">
                <PenTool className="h-4 w-4" />
                <span>Custom</span>
              </div>
            </div>
            <Button className="w-full">Select Topic</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Challenge Mode</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Difficult questions to test your mastery
            </p>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                <span>30 mins</span>
              </div>
              <div className="flex items-center gap-1">
                <Activity className="h-4 w-4" />
                <span>Advanced</span>
              </div>
            </div>
            <Button className="w-full">Start Challenge</Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Quiz History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium">Pharmacology Quiz</p>
                <p className="text-xs text-muted-foreground">
                  Completed yesterday
                </p>
              </div>
              <div className="text-sm font-medium">85%</div>
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium">Clinical Judgment</p>
                <p className="text-xs text-muted-foreground">
                  Completed 2 days ago
                </p>
              </div>
              <div className="text-sm font-medium">92%</div>
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium">Risk Reduction</p>
                <p className="text-xs text-muted-foreground">
                  Completed 3 days ago
                </p>
              </div>
              <div className="text-sm font-medium">78%</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
