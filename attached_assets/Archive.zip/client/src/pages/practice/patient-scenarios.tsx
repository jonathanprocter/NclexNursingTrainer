import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MonitorPlay, Clock, Brain, User } from "lucide-react";

export default function PatientScenarios() {
  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            Virtual Patient Scenarios
          </h1>
          <p className="text-muted-foreground">
            Interactive clinical scenarios to develop your critical thinking
            skills
          </p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Basic Assessment</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Practice initial patient assessments and vital signs
              interpretation
            </p>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                <span>20 mins</span>
              </div>
              <div className="flex items-center gap-1">
                <Brain className="h-4 w-4" />
                <span>Beginner</span>
              </div>
            </div>
            <Button className="w-full">Start Scenario</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Emergency Care</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Handle complex emergency situations and rapid interventions
            </p>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                <span>30 mins</span>
              </div>
              <div className="flex items-center gap-1">
                <Brain className="h-4 w-4" />
                <span>Advanced</span>
              </div>
            </div>
            <Button className="w-full">Start Scenario</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Care Planning</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Develop comprehensive care plans for long-term patient management
            </p>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                <span>45 mins</span>
              </div>
              <div className="flex items-center gap-1">
                <Brain className="h-4 w-4" />
                <span>Intermediate</span>
              </div>
            </div>
            <Button className="w-full">Start Scenario</Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Scenarios</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium">Post-Op Care Simulation</p>
                <p className="text-xs text-muted-foreground">
                  Completed yesterday
                </p>
              </div>
              <div className="text-sm font-medium text-green-600">89%</div>
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium">Respiratory Distress Case</p>
                <p className="text-xs text-muted-foreground">
                  Completed 2 days ago
                </p>
              </div>
              <div className="text-sm font-medium text-green-600">92%</div>
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium">Diabetes Management</p>
                <p className="text-xs text-muted-foreground">
                  Completed 3 days ago
                </p>
              </div>
              <div className="text-sm font-medium text-yellow-600">78%</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
