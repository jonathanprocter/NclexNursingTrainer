import { InstructorDashboard } from "@/components/instructor/InstructorDashboard";

export default function InstructorPage() {
  return <InstructorDashboard />;
}
