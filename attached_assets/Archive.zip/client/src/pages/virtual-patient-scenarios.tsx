import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  Loader2,
  Brain,
  Heart,
  Activity,
  RefreshCw,
  ChevronRight,
} from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

interface PatientScenario {
  id: number; // Changed from string to number
  difficulty: "easy" | "medium" | "hard";
  clinicalSetting: string;
  patientDetails: {
    age?: number;
    gender?: string;
    chiefComplaint?: string;
    vitalSigns?: Record<string, any>;
    history?: string[];
  };
  decisions: Array<{
    stage: string;
    options: string[];
    correctOption: string;
    rationale: string;
    followUp?: {
      observation: string;
      additionalFindings: string[];
    };
  }>;
  feedback: {
    clinical: string;
    emotional: string;
    technicalAccuracy: number;
  };
}

export default function VirtualPatientScenarios() {
  const [selectedDifficulty, setSelectedDifficulty] =
    useState<string>("medium");
  const [selectedDomain, setSelectedDomain] =
    useState<string>("medical-surgical");
  const [activeScenario, setActiveScenario] = useState<PatientScenario | null>(
    null,
  );
  const [currentStage, setCurrentStage] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const { toast } = useToast();

  const scenarioMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/scenarios/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          difficulty: selectedDifficulty,
          domain: selectedDomain,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to generate scenario");
      }

      const data = await response.json();
      if (!data.scenario) {
        throw new Error("Invalid scenario data received");
      }

      return data.scenario;
    },
    onSuccess: (data) => {
      setActiveScenario(data);
      setCurrentStage(0);
      setSelectedOption(null);
      setShowFeedback(false);
      toast({
        title: "Scenario Generated",
        description: "New virtual patient scenario is ready",
      });
    },
    onError: (error) => {
      console.error("Scenario generation error:", error);
      toast({
        title: "Error",
        description:
          error instanceof Error
            ? error.message
            : "Failed to generate scenario. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDecision = async (option: string) => {
    if (!activeScenario) return;

    const currentDecision = activeScenario.decisions[currentStage];
    const isCorrect = option === currentDecision.correctOption;
    setSelectedOption(option);
    setShowFeedback(true);

    try {
      await fetch("/api/scenarios/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          scenarioId: activeScenario.id,
          response: option,
          isCorrect,
        }),
      });

      toast({
        title: isCorrect ? "Correct Decision! 🎉" : "Incorrect Decision",
        description: "Review the feedback below to understand the rationale.",
        variant: isCorrect ? "default" : "destructive",
      });
    } catch (error) {
      console.error("Error submitting decision:", error);
      toast({
        title: "Error",
        description: "Failed to submit decision. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleNext = () => {
    if (!activeScenario) return;
    if (currentStage < activeScenario.decisions.length - 1) {
      setCurrentStage((prev) => prev + 1);
      setSelectedOption(null);
      setShowFeedback(false);
    }
  };

  const renderVitalSigns = (vitalSigns?: Record<string, any>) => {
    if (!vitalSigns) return null;

    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {Object.entries(vitalSigns).map(([key, value]) => (
          <div key={key} className="bg-muted p-3 rounded-lg">
            <div className="text-sm text-muted-foreground capitalize">
              {key.replace(/_/g, " ")}
            </div>
            <div className="text-lg font-semibold">{value}</div>
          </div>
        ))}
      </div>
    );
  };

  if (!activeScenario) {
    return (
      <div className="container mx-auto py-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-6 w-6" />
              Virtual Patient Scenarios
            </CardTitle>
            <CardDescription>
              Practice clinical decision-making with realistic patient cases
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Difficulty Level</label>
                <Select
                  value={selectedDifficulty}
                  onValueChange={setSelectedDifficulty}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select difficulty" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="easy">Easy</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="hard">Hard</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Clinical Domain</label>
                <Select
                  value={selectedDomain}
                  onValueChange={setSelectedDomain}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select domain" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="medical-surgical">
                      Medical-Surgical
                    </SelectItem>
                    <SelectItem value="pediatric">Pediatric</SelectItem>
                    <SelectItem value="psychiatric">Psychiatric</SelectItem>
                    <SelectItem value="obstetric">Obstetric</SelectItem>
                    <SelectItem value="critical-care">Critical Care</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button
              onClick={() => scenarioMutation.mutate()}
              disabled={scenarioMutation.isPending}
              className="w-full"
            >
              {scenarioMutation.isPending ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Generating Scenario...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Brain className="h-4 w-4" />
                  Generate Patient Scenario
                </div>
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const currentDecision = activeScenario.decisions[currentStage];
  const isLastStage = currentStage === activeScenario.decisions.length - 1;

  return (
    <div className="container mx-auto py-8">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Case Study</h1>
          <Button
            variant="outline"
            onClick={() => scenarioMutation.mutate()}
            disabled={scenarioMutation.isPending}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Generate New Case
          </Button>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Heart className="h-6 w-6" />
                Patient Overview
              </CardTitle>
              <Badge variant={activeScenario.difficulty as any}>
                {activeScenario.difficulty}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <h3 className="text-sm font-medium">Patient Details</h3>
                  <p className="text-muted-foreground">
                    {activeScenario.patientDetails?.age || "N/A"} year old{" "}
                    {activeScenario.patientDetails?.gender || "N/A"}
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium">Chief Complaint</h3>
                  <p className="text-muted-foreground">
                    {activeScenario.patientDetails?.chiefComplaint ||
                      "No chief complaint recorded"}
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium">Clinical Setting</h3>
                  <p className="text-muted-foreground">
                    {activeScenario.clinicalSetting}
                  </p>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium mb-2">Vital Signs</h3>
                {renderVitalSigns(activeScenario.patientDetails?.vitalSigns)}
              </div>

              <div>
                <h3 className="text-sm font-medium mb-2">Medical History</h3>
                <div className="flex flex-wrap gap-2">
                  {activeScenario.patientDetails?.history?.map(
                    (item, index) => (
                      <Badge key={index} variant="outline">
                        {item}
                      </Badge>
                    ),
                  ) || (
                    <p className="text-muted-foreground">
                      No history available
                    </p>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-6 w-6" />
              Stage {currentStage + 1}: {currentDecision.stage}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {!showFeedback ? (
                <div className="grid gap-4">
                  {currentDecision.options.map((option, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className="justify-start h-auto py-4 px-6"
                      onClick={() => handleDecision(option)}
                    >
                      <span className="font-mono mr-4">
                        {String.fromCharCode(65 + index)}.
                      </span>
                      {option}
                    </Button>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  <Alert
                    variant={
                      selectedOption === currentDecision.correctOption
                        ? "default"
                        : "destructive"
                    }
                  >
                    <AlertTitle>
                      {selectedOption === currentDecision.correctOption
                        ? "Correct Decision! 🎉"
                        : "Incorrect Decision"}
                    </AlertTitle>
                    <AlertDescription className="mt-2">
                      {currentDecision.rationale}
                    </AlertDescription>
                  </Alert>

                  {currentDecision.followUp && (
                    <Alert>
                      <AlertTitle>Follow-up Findings</AlertTitle>
                      <AlertDescription className="mt-2">
                        <p className="font-medium">
                          {currentDecision.followUp.observation}
                        </p>
                        <ul className="list-disc pl-4 mt-2 space-y-1">
                          {currentDecision.followUp.additionalFindings.map(
                            (finding, index) => (
                              <li key={index}>{finding}</li>
                            ),
                          )}
                        </ul>
                      </AlertDescription>
                    </Alert>
                  )}

                  {!isLastStage && (
                    <Button onClick={handleNext} className="w-full">
                      Continue to Next Stage
                      <ChevronRight className="h-4 w-4 ml-2" />
                    </Button>
                  )}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {currentStage === activeScenario.decisions.length - 1 &&
          showFeedback && (
            <Card>
              <CardHeader>
                <CardTitle>Case Summary and Feedback</CardTitle>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="clinical">
                    <AccordionTrigger>Clinical Reasoning</AccordionTrigger>
                    <AccordionContent>
                      {activeScenario.feedback.clinical}
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="emotional">
                    <AccordionTrigger>Communication & Empathy</AccordionTrigger>
                    <AccordionContent>
                      {activeScenario.feedback.emotional}
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>

                <Button
                  className="w-full mt-6"
                  onClick={() => scenarioMutation.mutate()}
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Start New Case
                </Button>
              </CardContent>
            </Card>
          )}
      </div>
    </div>
  );
}
