import { FlashcardGenerator } from "@/components/ui/flashcards/FlashcardGenerator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { GraduationCap } from "lucide-react";

export default function FlashcardsPage() {
  return (
    <div className="container mx-auto max-w-4xl py-8">
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <GraduationCap className="h-6 w-6 text-primary" />
            NCLEX Study Flashcards
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Generate and practice with NCLEX-style questions. Each question
            includes detailed explanations and clinical rationales to help you
            understand the concepts better.
          </p>
        </CardContent>
      </Card>

      <FlashcardGenerator
        topic="NCLEX Preparation"
        onFlashcardsGenerated={(cards) => {
          console.log("Generated cards:", cards);
        }}
      />
    </div>
  );
}
