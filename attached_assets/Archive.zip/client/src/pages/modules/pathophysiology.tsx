import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Brain,
  Heart,
  BookOpen,
  Loader2,
  MessageSquare,
  Stethoscope,
  Activity,
  CircleDot,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ExplanationContent {
  content: string;
  keyPoints?: string[];
  examples?: string[];
  relatedConcepts?: string[];
}

const MODULE_CONTENT = {
  title: "Advanced Pathophysiology",
  description:
    "Deepen your understanding of complex disease processes and their clinical manifestations",
  objectives: [
    "Analyze complex disease mechanisms",
    "Evaluate multisystem disorders",
    "Understand complications and their management",
    "Apply pathophysiology concepts to clinical scenarios",
  ],
  sections: [
    {
      title: "Disease Mechanisms",
      content:
        "Understanding the fundamental processes of disease development and progression",
      keyPoints: [
        "Cellular adaptation and injury",
        "Inflammation and healing",
        "Neoplasia and cancer biology",
        "Genetic and environmental factors",
      ],
    },
    {
      title: "System-Specific Pathology",
      content:
        "Detailed examination of pathological processes in major body systems",
      keyPoints: [
        "Cardiovascular disorders",
        "Respiratory pathologies",
        "Neurological conditions",
        "Endocrine dysfunction",
      ],
    },
    {
      title: "Clinical Applications",
      content:
        "Application of pathophysiological principles to clinical practice",
      keyPoints: [
        "Diagnostic reasoning",
        "Disease progression prediction",
        "Treatment selection considerations",
        "Complication prevention",
      ],
    },
  ],
};

export default function PathophysiologyModule() {
  const [showAIExplanation, setShowAIExplanation] = useState(false);
  const [selectedTopic, setSelectedTopic] = useState<string>("");
  const [explanationContent, setExplanationContent] =
    useState<ExplanationContent | null>(null);
  const { toast } = useToast();

  const requestAIExplanation = useMutation({
    mutationFn: async (topic: string) => {
      const response = await fetch("/api/modules/generate-explanation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic,
          context: "pathophysiology",
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to get explanation");
      }

      const data = await response.json();
      if (!data.success) {
        throw new Error(data.error || "Failed to generate explanation");
      }
      return data.data;
    },
    onSuccess: (data) => {
      setExplanationContent({
        content: data.content,
        keyPoints: data.content
          .split("\n")
          .filter((line: string) => line.startsWith("•"))
          .map((line: string) => line.substring(2)),
        examples: data.content
          .split("\n")
          .filter((line: string) => line.includes("Example:")),
        relatedConcepts: data.content
          .split("\n")
          .filter((line: string) => line.includes("Related Concepts:"))
          .flatMap((line: string) =>
            line
              .replace("Related Concepts:", "")
              .split("•")
              .map((concept: string) => concept.trim())
              .filter(Boolean),
          ),
      });
      setShowAIExplanation(true);
      toast({
        title: "AI Explanation Ready",
        description: "Your personalized explanation has been generated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description:
          error instanceof Error
            ? error.message
            : "Failed to get AI explanation",
        variant: "destructive",
      });
      setExplanationContent(null);
    },
  });

  const handleAskAI = (topic: string) => {
    setSelectedTopic(topic);
    requestAIExplanation.mutate(topic);
  };

  const formatTopicName = (topic: string) => {
    return topic
      .replace(/([a-z])([A-Z])/g, "$1 $2")
      .replace(/_/g, " ")
      .split(" ")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  const AIHelpButton = ({
    topic,
    className = "",
  }: {
    topic: string;
    className?: string;
  }) => (
    <Button
      variant="outline"
      size="sm"
      className={`flex items-center gap-2 ${className}`}
      onClick={() => handleAskAI(topic)}
      disabled={requestAIExplanation.isPending}
    >
      {requestAIExplanation.isPending && selectedTopic === topic ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <Brain className="h-4 w-4" />
      )}
      <span>Ask AI Assistant</span>
    </Button>
  );

  return (
    <ScrollArea className="h-[calc(100vh-4rem)]">
      <div className="container py-6 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-primary" />
            <h1 className="text-3xl font-bold">{MODULE_CONTENT.title}</h1>
          </div>
          <AIHelpButton topic="pathophysiology_overview" className="ml-2" />
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5" />
              Module Overview
            </CardTitle>
            <CardDescription>{MODULE_CONTENT.description}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="font-medium mb-2">Learning Objectives</h3>
                <ul className="list-disc pl-6 space-y-1">
                  {MODULE_CONTENT.objectives.map((objective, index) => (
                    <li key={index}>{objective}</li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {MODULE_CONTENT.sections.map((section, index) => (
          <Card key={index}>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {index === 0 ? (
                    <Brain className="h-5 w-5" />
                  ) : index === 1 ? (
                    <Stethoscope className="h-5 w-5" />
                  ) : (
                    <Activity className="h-5 w-5" />
                  )}
                  {section.title}
                </div>
                <AIHelpButton
                  topic={`pathophysiology_${section.title.toLowerCase().replace(/\s+/g, "_")}`}
                />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-muted-foreground">{section.content}</p>
                <div className="grid gap-4 md:grid-cols-2">
                  {section.keyPoints.map((point, pointIndex) => (
                    <div key={pointIndex} className="flex items-start gap-2">
                      <CircleDot className="h-4 w-4 mt-1 shrink-0" />
                      <p>{point}</p>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        <Dialog open={showAIExplanation} onOpenChange={setShowAIExplanation}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                {selectedTopic
                  ? formatTopicName(selectedTopic)
                  : "AI Learning Assistant"}
              </DialogTitle>
            </DialogHeader>
            {requestAIExplanation.isPending ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin" />
                <span className="ml-2">Generating explanation...</span>
              </div>
            ) : explanationContent ? (
              <ScrollArea className="h-[60vh]">
                <div className="space-y-6 pr-4">
                  <div className="prose prose-sm max-w-none dark:prose-invert">
                    {explanationContent.content.split("\n").map(
                      (paragraph, index) =>
                        paragraph.trim() && (
                          <p key={index} className="mb-4 last:mb-0">
                            {paragraph.trim()}
                          </p>
                        ),
                    )}
                  </div>
                  {explanationContent.keyPoints &&
                    explanationContent.keyPoints.length > 0 && (
                      <div className="mt-4">
                        <h4 className="font-semibold mb-2">Key Points</h4>
                        <ul className="list-disc pl-4 space-y-1">
                          {explanationContent.keyPoints.map((point, i) => (
                            <li key={i}>{point}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  {explanationContent.examples &&
                    explanationContent.examples.length > 0 && (
                      <div className="mt-4">
                        <h4 className="font-semibold mb-2">
                          Clinical Examples
                        </h4>
                        <ul className="list-disc pl-4 space-y-1">
                          {explanationContent.examples.map((example, i) => (
                            <li key={i}>{example}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  {explanationContent.relatedConcepts &&
                    explanationContent.relatedConcepts.length > 0 && (
                      <div className="mt-4">
                        <h4 className="font-semibold mb-2">Related Concepts</h4>
                        <div className="flex flex-wrap gap-2">
                          {explanationContent.relatedConcepts.map(
                            (concept, i) => (
                              <Badge
                                key={i}
                                variant="secondary"
                                className="cursor-pointer hover:bg-secondary/80"
                                onClick={() => handleAskAI(concept)}
                              >
                                {concept}
                              </Badge>
                            ),
                          )}
                        </div>
                      </div>
                    )}
                </div>
              </ScrollArea>
            ) : null}
          </DialogContent>
        </Dialog>
      </div>
    </ScrollArea>
  );
}
