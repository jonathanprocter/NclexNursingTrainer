import { useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  Brain,
  Lightbulb,
  Activity,
  ClipboardCheck,
  Stethoscope,
  Target,
  Scale,
  ArrowRight,
  CheckCircle2,
  HelpCircle,
  Loader2,
} from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

interface AIExplanationResponse {
  success: boolean;
  data: {
    title: string;
    content: string;
    context: string;
    timestamp: string;
  };
  error?: string;
}

const formatTopicName = (topic: string) => {
  return topic
    .replace(/_/g, " ")
    .split(" ")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
};

export default function ClinicalJudgmentModule() {
  const [showAIDialog, setShowAIDialog] = useState(false);
  const [currentTopic, setCurrentTopic] = useState("");
  const { toast } = useToast();

  const { data: moduleData, isLoading } = useQuery({
    queryKey: ["/api/modules/clinical-judgment"],
  });

  const generateExplanation = useMutation({
    mutationFn: async (topic: string): Promise<AIExplanationResponse> => {
      const response = await fetch("/api/modules/generate-explanation", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          topic,
          context: "clinical_judgment",
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to generate explanation");
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Explanation Generated",
        description: "AI has provided detailed insights on this topic.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description:
          error instanceof Error
            ? error.message
            : "Failed to generate explanation",
        variant: "destructive",
      });
    },
  });

  const handleAIExplanation = (topic: string) => {
    setCurrentTopic(topic);
    setShowAIDialog(true);
    generateExplanation.mutate(topic);
  };

  const AIHelpButton = ({ topic }: { topic: string }) => (
    <Button
      variant="ghost"
      size="sm"
      className="h-6 w-6 p-0 hover:bg-accent"
      onClick={() => handleAIExplanation(topic)}
      disabled={generateExplanation.isPending}
    >
      {generateExplanation.isPending && currentTopic === topic ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <HelpCircle className="h-4 w-4" />
      )}
    </Button>
  );

  const AIExplanationDialog = () => (
    <Dialog open={showAIDialog} onOpenChange={setShowAIDialog}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            {formatTopicName(currentTopic)}
          </DialogTitle>
          <DialogDescription className="mt-4">
            {generateExplanation.isPending ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin" />
                <span className="ml-2">Generating explanation...</span>
              </div>
            ) : generateExplanation.data?.success ? (
              <div className="prose prose-sm max-w-none dark:prose-invert">
                {generateExplanation.data.data.content.split("\n").map(
                  (paragraph, index) =>
                    paragraph.trim() && (
                      <p key={index} className="mb-4 last:mb-0">
                        {paragraph.trim()}
                      </p>
                    ),
                )}
              </div>
            ) : generateExplanation.error ? (
              <Alert variant="destructive">
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>
                  {generateExplanation.error instanceof Error
                    ? generateExplanation.error.message
                    : "Failed to generate explanation"}
                </AlertDescription>
              </Alert>
            ) : null}
          </DialogDescription>
        </DialogHeader>
      </DialogContent>
    </Dialog>
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-pulse">Loading module content...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Clinical Judgment</h1>
          <p className="text-muted-foreground mt-2">
            Master the art of clinical decision-making through systematic
            practice and evidence-based approaches
          </p>
        </div>
        <Progress value={60} className="w-[200px]" />
      </div>

      <Tabs defaultValue="framework" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="framework">Framework</TabsTrigger>
          <TabsTrigger value="practice">Practice</TabsTrigger>
          <TabsTrigger value="scenarios">Scenarios</TabsTrigger>
          <TabsTrigger value="assessment">Assessment</TabsTrigger>
        </TabsList>

        <TabsContent value="framework">
          <div className="grid gap-6">
            {/* Introduction Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  Understanding Clinical Judgment
                  <AIHelpButton topic="clinical_judgment_overview" />
                </CardTitle>
                <CardDescription>
                  Master the essential components of clinical reasoning and
                  decision-making
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="prose max-w-none">
                  <p>
                    Clinical judgment is the art and science of making
                    appropriate nursing decisions based on careful observation,
                    knowledge, and experience. It involves recognizing
                    significant patient changes, analyzing clinical data, and
                    taking appropriate action.
                  </p>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h3 className="font-semibold mb-2 flex items-center gap-2">
                      <Brain className="h-4 w-4" />
                      Core Components
                      <AIHelpButton topic="clinical_judgment_components" />
                    </h3>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 mt-1 text-green-500" />
                        <span>Recognition of significant patterns</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 mt-1 text-green-500" />
                        <span>Analysis of patient data</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 mt-1 text-green-500" />
                        <span>Prioritization of patient needs</span>
                      </li>
                    </ul>
                  </div>

                  <div className="p-4 bg-muted rounded-lg">
                    <h3 className="font-semibold mb-2 flex items-center gap-2">
                      <Target className="h-4 w-4" />
                      Key Skills
                      <AIHelpButton topic="clinical_judgment_skills" />
                    </h3>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 mt-1 text-green-500" />
                        <span>Critical thinking application</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 mt-1 text-green-500" />
                        <span>Evidence-based practice integration</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 mt-1 text-green-500" />
                        <span>Clinical reasoning development</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Clinical Judgment Process */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  Clinical Judgment Process
                  <AIHelpButton topic="clinical_judgment_process" />
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="recognize">
                    <AccordionTrigger>
                      <div className="flex items-center gap-2">
                        <Brain className="h-4 w-4" />
                        Phase 1: Recognize Cues
                        <AIHelpButton topic="recognize_cues" />
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="space-y-4 pt-4">
                      <div className="bg-muted p-4 rounded-lg">
                        <h4 className="font-medium mb-2">Recognition Skills</h4>
                        <ul className="space-y-2">
                          <li>Systematic assessment techniques</li>
                          <li>Pattern recognition in patient presentation</li>
                          <li>Identification of relevant clinical data</li>
                          <li>Understanding normal vs. abnormal findings</li>
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="analyze">
                    <AccordionTrigger>
                      <div className="flex items-center gap-2">
                        <Lightbulb className="h-4 w-4" />
                        Phase 2: Analyze Information
                        <AIHelpButton topic="analyze_information" />
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="space-y-4 pt-4">
                      <div className="bg-muted p-4 rounded-lg">
                        <h4 className="font-medium mb-2">Analysis Framework</h4>
                        <ul className="space-y-2">
                          <li>Data clustering and interpretation</li>
                          <li>Connecting signs and symptoms</li>
                          <li>Identifying potential causes</li>
                          <li>Evaluating risk factors</li>
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="prioritize">
                    <AccordionTrigger>
                      <div className="flex items-center gap-2">
                        <Activity className="h-4 w-4" />
                        Phase 3: Prioritize Actions
                        <AIHelpButton topic="prioritize_actions" />
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="space-y-4 pt-4">
                      <div className="bg-muted p-4 rounded-lg">
                        <h4 className="font-medium mb-2">
                          Prioritization Strategies
                        </h4>
                        <ul className="space-y-2">
                          <li>ABC (Airway, Breathing, Circulation) approach</li>
                          <li>Risk-benefit analysis</li>
                          <li>Immediate vs. long-term needs</li>
                          <li>Resource consideration</li>
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="evaluate">
                    <AccordionTrigger>
                      <div className="flex items-center gap-2">
                        <ClipboardCheck className="h-4 w-4" />
                        Phase 4: Evaluate Outcomes
                        <AIHelpButton topic="evaluate_outcomes" />
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="space-y-4 pt-4">
                      <div className="bg-muted p-4 rounded-lg">
                        <h4 className="font-medium mb-2">Evaluation Methods</h4>
                        <ul className="space-y-2">
                          <li>Outcome measurement</li>
                          <li>Response to interventions</li>
                          <li>Plan modification as needed</li>
                          <li>Documentation requirements</li>
                        </ul>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="practice">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                Interactive Learning
                <AIHelpButton topic="interactive_learning_methods" />
              </CardTitle>
              <CardDescription>
                Apply clinical judgment principles through guided practice
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <Alert>
                <AlertTitle>Practice Guidelines</AlertTitle>
                <AlertDescription>
                  Work through each scenario systematically using the clinical
                  judgment framework. Consider all available information and
                  document your reasoning process.
                </AlertDescription>
              </Alert>

              <div className="grid gap-4">
                <Button variant="outline" className="justify-start h-auto p-4">
                  <div className="flex items-center gap-4">
                    <Stethoscope className="h-5 w-5" />
                    <div className="text-left">
                      <div className="font-semibold">Patient Assessment</div>
                      <p className="text-sm text-muted-foreground">
                        Practice systematic data collection and interpretation
                      </p>
                    </div>
                  </div>
                </Button>

                <Button variant="outline" className="justify-start h-auto p-4">
                  <div className="flex items-center gap-4">
                    <Scale className="h-5 w-5" />
                    <div className="text-left">
                      <div className="font-semibold">Decision Analysis</div>
                      <p className="text-sm text-muted-foreground">
                        Evaluate clinical situations and prioritize
                        interventions
                      </p>
                    </div>
                  </div>
                </Button>

                <Button variant="outline" className="justify-start h-auto p-4">
                  <div className="flex items-center gap-4">
                    <Activity className="h-5 w-5" />
                    <div className="text-left">
                      <div className="font-semibold">Critical Thinking</div>
                      <p className="text-sm text-muted-foreground">
                        Apply reasoning skills to complex scenarios
                      </p>
                    </div>
                  </div>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="scenarios">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                Clinical Scenarios
                <AIHelpButton topic="clinical_scenarios_overview" />
              </CardTitle>
              <CardDescription>
                Apply your clinical judgment skills to real-world patient
                situations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px] pr-4">
                <div className="space-y-4">
                  {/* Scenario Cards */}
                  <div className="p-4 border rounded-lg hover:bg-accent cursor-pointer transition-colors">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold flex items-center gap-2">
                        Respiratory Distress{" "}
                        <AIHelpButton topic="scenario_respiratory_distress" />
                      </h3>
                      <Badge>Moderate</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      A 68-year-old patient with COPD presents with increased
                      work of breathing
                    </p>
                    <Button variant="outline" size="sm">
                      Start Scenario <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>

                  <div className="p-4 border rounded-lg hover:bg-accent cursor-pointer transition-colors">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold flex items-center gap-2">
                        Post-operative Assessment{" "}
                        <AIHelpButton topic="scenario_post_operative" />
                      </h3>
                      <Badge>Complex</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Evaluate a post-op patient showing signs of early
                      complications
                    </p>
                    <Button variant="outline" size="sm">
                      Start Scenario <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>

                  <div className="p-4 border rounded-lg hover:bg-accent cursor-pointer transition-colors">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold flex items-center gap-2">
                        Multiple System Assessment{" "}
                        <AIHelpButton topic="scenario_multiple_system" />
                      </h3>
                      <Badge>Advanced</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Manage a patient with multiple comorbidities showing new
                      symptoms
                    </p>
                    <Button variant="outline" size="sm">
                      Start Scenario <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="assessment">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                Knowledge Assessment
                <AIHelpButton topic="assessment_guidelines" />
              </CardTitle>
              <CardDescription>
                Evaluate your understanding of clinical judgment principles
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Alert>
                <AlertTitle>Ready to Test Your Knowledge?</AlertTitle>
                <AlertDescription>
                  This assessment will evaluate your ability to:
                  <ul className="list-disc pl-6 mt-2">
                    <li>Recognize significant clinical cues</li>
                    <li>Analyze complex patient data</li>
                    <li>Prioritize nursing interventions</li>
                    <li>Evaluate outcomes effectively</li>
                  </ul>
                </AlertDescription>
              </Alert>

              <Button className="mt-6">Begin Assessment</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <AIExplanationDialog />
    </div>
  );
}
