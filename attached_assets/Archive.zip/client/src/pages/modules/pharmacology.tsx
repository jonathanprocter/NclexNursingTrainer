import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Pill, Brain, Activity, Scale, MessagesSquare } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ProgressData {
  overallProgress: number;
  accuracyRate: string;
  masteryLevel: string;
  competencyAreas: Array<{
    area: string;
    level: number;
    status: string;
  }>;
}

interface ModuleCase {
  title: string;
  scenario: string;
  medications: string[];
}

interface ModuleContent {
  cases: ModuleCase[];
}

export default function PharmacologyModule() {
  const [activeTab, setActiveTab] = useState("overview");
  const { toast } = useToast();

  // Module content query
  const { data: moduleContent } = useQuery<ModuleContent>({
    queryKey: ["/api/modules/pharmacology/content"],
  });

  // Progress query
  const { data: progress } = useQuery<ProgressData>({
    queryKey: ["/api/modules/pharmacology/progress"],
  });

  // AI explanation mutation
  const aiExplanationMutation = useMutation({
    mutationFn: async (topic: string) => {
      const response = await fetch("/api/modules/generate-explanation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic,
          context: "Pharmacology and Medication Administration",
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to get AI explanation");
      }

      return response.json();
    },
    onSuccess: (data: any) => {
      if (data.success && data.data) {
        toast({
          title: "AI Assistant",
          description: data.data.content,
        });
      } else {
        throw new Error("Invalid response format");
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to get AI help",
        variant: "destructive",
      });
    },
  });

  const getAIHelp = async (topic: string) => {
    try {
      aiExplanationMutation.mutate(topic);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to get AI help. Please try again.",
        variant: "destructive",
      });
    }
  };

  const pharmacologyContent = {
    pharmacodynamics: {
      title: "Pharmacodynamics",
      description:
        "Understanding how drugs work in the body and their mechanisms of action",
      points: [
        "Drug-receptor interactions",
        "Therapeutic effects and side effects",
        "Factors affecting drug response",
        "Dose-response relationships",
      ],
    },
    pharmacokinetics: {
      title: "Pharmacokinetics",
      description: "Learn how drugs move through the body - ADME process",
      points: [
        "Absorption of medications",
        "Distribution in the body",
        "Drug metabolism",
        "Excretion pathways",
      ],
    },
    administration: {
      title: "Medication Administration",
      description: "Safe medication administration practices and protocols",
      points: [
        "Rights of medication administration",
        "Routes of administration",
        "Medication calculations",
        "Documentation requirements",
      ],
    },
  };

  return (
    <div className="container mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">
            Pharmacology & Parenteral Therapies
          </h1>
          <p className="text-muted-foreground mt-2">
            Master pharmacological principles and medication administration
          </p>
        </div>
        <Progress
          value={progress?.overallProgress ?? 0}
          className="w-[200px]"
        />
      </div>

      <Tabs
        defaultValue="overview"
        value={activeTab}
        onValueChange={setActiveTab}
      >
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="learn">Learn</TabsTrigger>
          <TabsTrigger value="practice">Practice</TabsTrigger>
          <TabsTrigger value="progress">Progress</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  {pharmacologyContent.pharmacodynamics.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  {pharmacologyContent.pharmacodynamics.description}
                </p>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => getAIHelp("Pharmacodynamics principles")}
                >
                  <MessagesSquare className="mr-2 h-4 w-4" />
                  Ask AI to Explain
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  {pharmacologyContent.pharmacokinetics.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  {pharmacologyContent.pharmacokinetics.description}
                </p>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => getAIHelp("ADME process in pharmacology")}
                >
                  <MessagesSquare className="mr-2 h-4 w-4" />
                  Ask AI to Explain
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Scale className="h-5 w-5" />
                  {pharmacologyContent.administration.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  {pharmacologyContent.administration.description}
                </p>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() =>
                    getAIHelp("Safe medication administration practices")
                  }
                >
                  <MessagesSquare className="mr-2 h-4 w-4" />
                  Ask AI to Explain
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="learn">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Pharmacology Fundamentals</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="prose max-w-none">
                    <h3 className="text-lg font-semibold">Core Concepts</h3>
                    <p className="text-muted-foreground">
                      Pharmacology is the study of how drugs interact with
                      living systems and produce their effects. Understanding
                      both pharmacodynamics (what drugs do to the body) and
                      pharmacokinetics (what the body does to drugs) is crucial
                      for safe medication administration.
                    </p>
                    <Button
                      variant="outline"
                      className="mt-4"
                      onClick={() => getAIHelp("Basic pharmacology concepts")}
                    >
                      <MessagesSquare className="mr-2 h-4 w-4" />
                      Explore with AI
                    </Button>
                  </div>

                  <div className="mt-6">
                    <h3 className="text-lg font-semibold mb-4">
                      Pharmacodynamics
                    </h3>
                    <ul className="space-y-2">
                      {pharmacologyContent.pharmacodynamics.points.map(
                        (point, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <span className="flex-shrink-0 mt-1">•</span>
                            <span>{point}</span>
                          </li>
                        ),
                      )}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Medication Administration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="prose max-w-none">
                    <p className="text-muted-foreground">
                      Safe medication administration requires thorough
                      understanding of the "Rights" of medication administration
                      and various administration routes.
                    </p>
                    <Button
                      variant="outline"
                      className="mt-4"
                      onClick={() =>
                        getAIHelp("Rights of medication administration")
                      }
                    >
                      <MessagesSquare className="mr-2 h-4 w-4" />
                      Learn More with AI
                    </Button>
                  </div>

                  <div className="mt-6">
                    <h3 className="text-lg font-semibold mb-4">
                      Administration Guidelines
                    </h3>
                    <ul className="space-y-2">
                      {pharmacologyContent.administration.points.map(
                        (point, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <span className="flex-shrink-0 mt-1">•</span>
                            <span>{point}</span>
                          </li>
                        ),
                      )}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="practice">
          <Card>
            <CardHeader>
              <CardTitle>Practice Cases</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {moduleContent?.cases?.map(
                  (case_: ModuleCase, index: number) => (
                    <div key={index} className="border rounded-lg p-4">
                      <h3 className="text-lg font-semibold mb-2">
                        {case_.title}
                      </h3>
                      <p className="text-muted-foreground mb-4">
                        {case_.scenario}
                      </p>
                      <div className="space-y-4">
                        <h4 className="font-medium">Medications Involved</h4>
                        <ul className="list-disc pl-6 space-y-2">
                          {case_.medications?.map(
                            (med: string, medIndex: number) => (
                              <li key={medIndex}>{med}</li>
                            ),
                          )}
                        </ul>
                        <Button
                          variant="outline"
                          onClick={() =>
                            getAIHelp(
                              `Medication case analysis: ${case_.title}`,
                            )
                          }
                        >
                          <MessagesSquare className="mr-2 h-4 w-4" />
                          Get Case Analysis
                        </Button>
                      </div>
                    </div>
                  ),
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="progress">
          <Card>
            <CardHeader>
              <CardTitle>Your Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span>Overall Progress</span>
                    <span>{progress?.overallProgress ?? 0}%</span>
                  </div>
                  <Progress value={progress?.overallProgress ?? 0} />
                </div>

                {progress?.competencyAreas && (
                  <div className="mt-6 space-y-4">
                    <h3 className="font-semibold">Competency Areas</h3>
                    {progress.competencyAreas.map((area) => (
                      <div key={area.area}>
                        <div className="flex justify-between mb-1">
                          <span>{area.area}</span>
                          <span>{Math.round(area.level * 100)}%</span>
                        </div>
                        <Progress value={area.level * 100} />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
