import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function NursingFundamentalsPage() {
  return (
    <div className="container mx-auto py-6">
      <Card>
        <CardHeader>
          <CardTitle>Nursing Fundamentals</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Comprehensive coverage of essential nursing concepts and skills.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
