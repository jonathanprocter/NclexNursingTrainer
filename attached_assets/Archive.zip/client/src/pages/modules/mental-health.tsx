import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function MentalHealthPage() {
  return (
    <div className="container mx-auto py-6">
      <Card>
        <CardHeader>
          <CardTitle>Mental Health Nursing</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            In-depth exploration of psychiatric nursing principles and
            therapeutic interventions.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
