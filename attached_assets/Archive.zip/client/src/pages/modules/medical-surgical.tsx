import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function MedicalSurgicalPage() {
  return (
    <div className="container mx-auto py-6">
      <Card>
        <CardHeader>
          <CardTitle>Medical-Surgical Nursing</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Advanced concepts in medical-surgical nursing care and
            interventions.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
