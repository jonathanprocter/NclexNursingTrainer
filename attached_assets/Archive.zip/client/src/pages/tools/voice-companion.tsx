import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mic2, Speaker, Brain, History } from "lucide-react";

export default function VoiceCompanion() {
  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            AI Voice Study Companion
          </h1>
          <p className="text-muted-foreground">
            Interactive voice-based learning assistant powered by AI
          </p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Voice Assistant</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-center p-6">
              <Button size="lg" className="rounded-full w-24 h-24">
                <Mic2 className="h-12 w-12" />
              </Button>
            </div>
            <p className="text-center text-sm text-muted-foreground">
              Tap to start speaking with your AI study companion
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Commands</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              <li className="flex items-center space-x-2">
                <Speaker className="h-4 w-4 text-muted-foreground" />
                <span>"Explain pharmacokinetics"</span>
              </li>
              <li className="flex items-center space-x-2">
                <Speaker className="h-4 w-4 text-muted-foreground" />
                <span>"Quiz me on cardiac medications"</span>
              </li>
              <li className="flex items-center space-x-2">
                <Speaker className="h-4 w-4 text-muted-foreground" />
                <span>"Summarize today's study session"</span>
              </li>
              <li className="flex items-center space-x-2">
                <Speaker className="h-4 w-4 text-muted-foreground" />
                <span>"Create a practice test"</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Conversations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium">Pathophysiology Review</p>
                <p className="text-xs text-muted-foreground">20 minutes ago</p>
              </div>
              <Button variant="outline" size="sm">
                <History className="h-4 w-4 mr-2" />
                Resume
              </Button>
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium">Medication Calculations</p>
                <p className="text-xs text-muted-foreground">2 hours ago</p>
              </div>
              <Button variant="outline" size="sm">
                <History className="h-4 w-4 mr-2" />
                Resume
              </Button>
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium">
                  Clinical Assessment Practice
                </p>
                <p className="text-xs text-muted-foreground">Yesterday</p>
              </div>
              <Button variant="outline" size="sm">
                <History className="h-4 w-4 mr-2" />
                Resume
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
