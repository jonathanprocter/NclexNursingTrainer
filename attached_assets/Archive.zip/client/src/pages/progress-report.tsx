import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import type { StudyMetrics } from "@/types/analytics";

export default function ProgressReport() {
  const {
    data: progress,
    isLoading,
    error,
  } = useQuery<StudyMetrics>({
    queryKey: ["progress-metrics"],
    queryFn: async () => {
      const res = await fetch("/api/progress/metrics", {
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
      });

      if (!res.ok) {
        throw new Error("Failed to fetch progress data");
      }

      const data = await res.json();
      if (!data || !data.performanceTrend) {
        throw new Error("Invalid progress data format");
      }

      return data;
    },
    retry: 2,
    retryDelay: 1000,
    refetchOnWindowFocus: false,
  });

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <Card>
          <CardContent className="pt-6">
            <Skeleton className="h-[300px] w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto p-6">
        <Alert variant="destructive">
          <AlertDescription>
            {error instanceof Error
              ? error.message
              : "Failed to load progress data. Please try again later."}
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  const chartData =
    progress?.performanceTrend?.map((point) => ({
      ...point,
      date: new Date(point.date).toLocaleDateString(),
    })) || [];

  return (
    <div className="container mx-auto p-6">
      <Card>
        <CardContent className="pt-6">
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Line
                type="monotone"
                dataKey="accuracy"
                stroke="#4f46e5"
                strokeWidth={2}
                dot={{ r: 4 }}
                name="Accuracy (%)"
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {progress && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
          <Card>
            <CardContent className="pt-6">
              <h3 className="font-semibold mb-2">Average Accuracy</h3>
              <p className="text-2xl">
                {progress.averageAccuracy?.toFixed(1)}%
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <h3 className="font-semibold mb-2">Questions Attempted</h3>
              <p className="text-2xl">{progress.questionsAttempted}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <h3 className="font-semibold mb-2">Study Time</h3>
              <p className="text-2xl">
                {(progress.totalTime / 3600).toFixed(1)} hours
              </p>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
