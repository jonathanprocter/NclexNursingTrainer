import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Brain } from "lucide-react";

interface Question {
  id: number;
  content: string;
  options: string[];
  difficulty: string;
  category: string;
}

export default function Practice() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const { data: questions, isLoading } = useQuery<Question[]>({
    queryKey: ["/api/questions", selectedCategory],
    enabled: !!selectedCategory,
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 w-64 bg-muted rounded"></div>
          <div className="h-4 w-full max-w-md bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold">NCLEX Practice Questions</h1>
        <p className="text-muted-foreground mt-2">
          Select a category to begin practicing questions
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {["Fundamentals", "Medical-Surgical", "Pediatric", "Mental Health"].map(
          (category) => (
            <Card
              key={category}
              className={`cursor-pointer transition-all hover:shadow-md ${
                selectedCategory === category ? "border-primary" : ""
              }`}
              onClick={() => setSelectedCategory(category)}
            >
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">
                  {category}
                </CardTitle>
                <Brain className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <Progress value={Math.random() * 100} className="h-2" />
                <p className="text-sm text-muted-foreground mt-2">
                  {Math.floor(Math.random() * 50)} questions available
                </p>
              </CardContent>
            </Card>
          ),
        )}
      </div>

      {selectedCategory && questions?.length === 0 && (
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground">
              No questions available for this category yet.
            </p>
            <Button className="mt-4" onClick={() => setSelectedCategory(null)}>
              Choose Another Category
            </Button>
          </CardContent>
        </Card>
      )}

      {selectedCategory && questions && questions.length > 0 && (
        <div className="space-y-4">
          {questions.map((question) => (
            <Card key={question.id}>
              <CardContent className="p-6">
                <p className="font-medium mb-4">{question.content}</p>
                <div className="space-y-2">
                  {question.options.map((option, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className="w-full justify-start text-left"
                    >
                      {option}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
