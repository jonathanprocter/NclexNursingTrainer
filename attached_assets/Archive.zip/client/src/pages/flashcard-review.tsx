import { VoiceFlashcardReview } from "@/components/VoiceFlashcardReview";
import { useToast } from "@/hooks/use-toast";

export default function FlashcardReviewPage() {
  const { toast } = useToast();

  const handleComplete = (results: { correct: number; total: number }) => {
    toast({
      title: "Review Complete!",
      description: `You got ${results.correct} out of ${results.total} cards correct.`,
    });
  };

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">Flashcard Review</h1>
      <div className="max-w-3xl mx-auto">
        <VoiceFlashcardReview onComplete={handleComplete} />
      </div>
    </div>
  );
}
