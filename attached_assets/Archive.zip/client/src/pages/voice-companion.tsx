import { VoiceStudyCompanion } from "@/components/VoiceStudyCompanion";

export default function VoiceCompanionPage() {
  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <header className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4">AI Voice Study Companion</h1>
          <p className="text-lg text-muted-foreground">
            Your intelligent NCLEX study partner. Ask questions, practice
            concepts, and get personalized guidance through voice interaction.
          </p>
        </header>

        <VoiceStudyCompanion />

        <div className="mt-8 p-4 bg-muted rounded-lg">
          <h2 className="text-xl font-semibold mb-4">
            Voice Command Examples:
          </h2>
          <ul className="space-y-2">
            <li>"Explain the nursing process for patient assessment"</li>
            <li>"Give me a practice question about pharmacology"</li>
            <li>"What topics should I focus on next?"</li>
            <li>"Analyze my progress in clinical judgment"</li>
            <li>"Motivate me with some study tips"</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
