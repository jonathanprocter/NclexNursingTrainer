import { useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Loader2, BookmarkPlus, FileText } from "lucide-react";
import type { Bookmark } from "@db/schema";

interface BookmarkFormData {
  title: string;
  content: string;
  url?: string;
  tags?: string[];
}

export default function BookmarksPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedBookmark, setSelectedBookmark] = useState<number | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<BookmarkFormData>();

  const { data: bookmarks, isLoading } = useQuery<Bookmark[]>({
    queryKey: ["/api/bookmarks"],
  });

  const createBookmark = useMutation({
    mutationFn: async (data: BookmarkFormData) => {
      const response = await fetch("/api/bookmarks", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify(data),
        credentials: "include",
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to create bookmark");
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bookmarks"] });
      toast({
        title: "Success",
        description: "Bookmark created with AI-generated smart notes",
      });
      reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description:
          error.message || "Failed to create bookmark and smart notes",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: BookmarkFormData) => {
    createBookmark.mutate(data);
  };

  return (
    <div className="container mx-auto py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Create New Bookmark</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  {...register("title", { required: "Title is required" })}
                  placeholder="Enter bookmark title"
                />
                {errors.title && (
                  <p className="text-sm text-red-500">{errors.title.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="content">Content</Label>
                <Textarea
                  id="content"
                  {...register("content", { required: "Content is required" })}
                  placeholder="Enter or paste content to bookmark"
                  rows={5}
                />
                {errors.content && (
                  <p className="text-sm text-red-500">
                    {errors.content.message}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="url">URL (Optional)</Label>
                <Input
                  id="url"
                  {...register("url")}
                  placeholder="Enter related URL"
                />
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={createBookmark.isPending}
              >
                {createBookmark.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating...
                  </>
                ) : (
                  <>
                    <BookmarkPlus className="mr-2 h-4 w-4" />
                    Create Bookmark
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Your Bookmarks</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin" />
              </div>
            ) : !bookmarks || bookmarks.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                No bookmarks yet. Create your first one!
              </p>
            ) : (
              <div className="space-y-4">
                {bookmarks.map((bookmark: Bookmark) => (
                  <Card
                    key={bookmark.id}
                    className="cursor-pointer hover:bg-accent/50"
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-semibold">{bookmark.title}</h3>
                          <p className="text-sm text-muted-foreground line-clamp-2">
                            {bookmark.content}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setSelectedBookmark(bookmark.id)}
                        >
                          <FileText className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
