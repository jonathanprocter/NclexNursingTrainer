import { FlashcardGenerator } from "@/components/ui/flashcards/FlashcardGenerator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { GraduationCap } from "lucide-react";
import { useState } from "react";

export default function StudyPage() {
  const [selectedDomain, setSelectedDomain] = useState("");

  const nclexDomains = {
    safe_effective_care: "Safe and Effective Care Environment",
    health_promotion: "Health Promotion and Maintenance",
    psychosocial: "Psychosocial Integrity",
    physiological: "Physiological Integrity",
  };

  return (
    <div className="container mx-auto max-w-4xl py-8">
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <GraduationCap className="h-6 w-6 text-primary" />
            NCLEX Study Session
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-4">
            Generate and practice with NCLEX-style questions. Each question
            includes detailed explanations and clinical rationales to help you
            understand the concepts better.
          </p>

          <Select value={selectedDomain} onValueChange={setSelectedDomain}>
            <SelectTrigger className="w-full mb-4">
              <SelectValue placeholder="Select NCLEX Domain" />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(nclexDomains).map(([key, value]) => (
                <SelectItem key={key} value={key}>
                  {value}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <FlashcardGenerator
        topic="NCLEX Preparation"
        domain={selectedDomain}
        onFlashcardsGenerated={(cards) => {
          console.log("Generated cards:", cards);
        }}
      />
    </div>
  );
}
