import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { QuizGenerator } from "@/components/QuizGenerator";
import { QuizSetup, type QuizSettings } from "@/components/QuizSetup";
import { QuizResults } from "@/components/QuizResults";
import { Brain, ChevronRight, Clock, Target } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import type {
  AdaptiveResponse,
  AdaptiveQuestion,
  QuizAnalytics,
} from "@/types/quiz";

// Mock user ID until auth is implemented
const MOCK_USER_ID = "demo-user";

export default function QuizPage() {
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizComplete, setQuizComplete] = useState(false);
  const [quizSettings, setQuizSettings] = useState<QuizSettings | null>(null);
  const [score, setScore] = useState(0);
  const [timeSpent, setTimeSpent] = useState(0);
  const [quizAnalytics, setQuizAnalytics] = useState<QuizAnalytics | null>(
    null,
  );
  const { toast } = useToast();

  const {
    data: adaptiveQuestions,
    isLoading: isLoadingQuestions,
    error,
  } = useQuery<AdaptiveResponse>({
    queryKey: ["/api/quiz/generate"],
    queryFn: async () => {
      const response = await fetch("/api/quiz/generate");
      if (!response.ok) {
        throw new Error("Failed to fetch quiz questions");
      }
      const data = await response.json();
      if (!data.success || !Array.isArray(data.questions)) {
        throw new Error("Invalid quiz data format");
      }
      return data;
    },
    enabled: showQuiz,
    retry: 2,
    refetchOnWindowFocus: false,
  });

  const handleStartQuiz = (settings: QuizSettings) => {
    setQuizSettings(settings);
  };

  const handleStartActualQuiz = () => {
    setShowQuiz(true);
  };

  const handleQuizComplete = async (analytics: QuizAnalytics) => {
    try {
      setQuizAnalytics(analytics);
      setScore(
        (analytics.correctAnswers /
          (analytics.correctAnswers + analytics.incorrectAnswers)) *
          100,
      );
      setTimeSpent(
        analytics.averageTimePerQuestion *
          (analytics.correctAnswers + analytics.incorrectAnswers),
      );
      setQuizComplete(true);
      setShowQuiz(false);

      toast({
        title: "Progress Saved",
        description:
          "Your quiz results have been recorded and will help personalize future questions.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save quiz progress. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleRestartQuiz = () => {
    setShowQuiz(false);
    setQuizComplete(false);
    setQuizSettings(null);
    setScore(0);
    setTimeSpent(0);
    setQuizAnalytics(null);
  };

  if (!showQuiz && !quizComplete) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="max-w-3xl mx-auto space-y-6">
          {!quizSettings ? (
            <Card>
              <CardContent className="pt-6">
                <QuizSetup onStart={handleStartQuiz} />
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              <div className="grid gap-4 md:grid-cols-3">
                <Card className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Questions</p>
                      <p className="text-2xl font-bold">
                        {adaptiveQuestions?.questions?.length ?? 5}
                      </p>
                    </div>
                    <Brain className="h-8 w-8 text-primary opacity-75" />
                  </div>
                </Card>

                <Card className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Difficulty</p>
                      <Badge
                        variant="outline"
                        className={
                          adaptiveQuestions?.metrics?.recommendedDifficulty ===
                          "hard"
                            ? "bg-red-100 text-red-800"
                            : adaptiveQuestions?.metrics
                                  ?.recommendedDifficulty === "medium"
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-green-100 text-green-800"
                        }
                      >
                        {adaptiveQuestions?.metrics?.recommendedDifficulty ??
                          "Adaptive"}
                      </Badge>
                    </div>
                    <Target className="h-8 w-8 text-primary opacity-75" />
                  </div>
                </Card>

                <Card className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Time Target</p>
                      <p className="text-2xl font-bold">
                        {Math.round(
                          (adaptiveQuestions?.metrics?.avgResponseTime ?? 60) /
                            60,
                        )}
                        m
                      </p>
                    </div>
                    <Clock className="h-8 w-8 text-primary opacity-75" />
                  </div>
                </Card>
              </div>

              <div className="flex justify-end gap-4">
                <Button variant="outline" onClick={() => setQuizSettings(null)}>
                  Back to Settings
                </Button>
                <Button
                  onClick={handleStartActualQuiz}
                  className="gap-2"
                  disabled={isLoadingQuestions}
                >
                  Start Quiz
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (quizComplete) {
    return (
      <div className="container mx-auto py-8 px-4">
        <QuizResults
          score={score}
          totalQuestions={adaptiveQuestions?.questions?.length ?? 0}
          timeSpent={timeSpent}
          questions={adaptiveQuestions?.questions ?? []}
          analytics={quizAnalytics}
          onRetake={handleRestartQuiz}
        />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <QuizGenerator userId={MOCK_USER_ID} onComplete={handleQuizComplete} />
    </div>
  );
}
