import { useQuery } from "@tanstack/react-query";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import {
  Brain,
  Target,
  TrendingUp,
  AlertCircle,
  Lightbulb,
} from "lucide-react";

interface AdaptiveQuestion {
  id: string;
  content: string;
  options: string[];
  difficulty: "easy" | "medium" | "hard";
  category: string;
  context?: string;
  explanation: string;
  correctAnswer: string;
  averageTime?: number;
  successRate?: number;
}

interface AdaptiveMetrics {
  recentAccuracy: number;
  recommendedDifficulty: "easy" | "medium" | "hard";
  avgResponseTime: number;
  masteryProgress: number;
}

interface QuizResponse {
  success: boolean;
  questions: AdaptiveQuestion[];
  metrics: AdaptiveMetrics;
  recommendations: {
    topics: string[];
    studyTips: string[];
    difficultyAdjustment?: "increase" | "decrease" | "maintain";
  };
  knowledgeGaps: Array<{
    topic: string;
    confidence: number;
    suggestedResources: string[];
  }>;
}

export default function PracticeQuizzes() {
  const [selectedAnswers, setSelectedAnswers] = useState<
    Record<string, number>
  >({});
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);

  const { data, isLoading, error, refetch } = useQuery<QuizResponse>({
    queryKey: ["/api/quiz/generate"],
    queryFn: async () => {
      try {
        const response = await fetch("/api/quiz/generate", {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            "Cache-Control": "no-cache",
          },
          credentials: "include",
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          throw new Error(
            `HTTP error! status: ${response.status} - ${errorData.message || "Unknown error"}`,
          );
        }

        const data = await response.json();
        if (!data.success) {
          throw new Error(data.message || "Failed to generate quiz");
        }

        return data;
      } catch (err) {
        console.error("Quiz generation error:", err);
        //Improved error handling to provide more specific information
        if (err instanceof Error && err.message) {
          throw new Error(err.message);
        } else {
          throw new Error(
            "Unable to load quiz. Please check your network connection and try again. If the problem persists, contact support.",
          );
        }
      }
    },
    enabled: false,
    retry: 2,
    retryDelay: 1000,
  });

  const handleAnswerSelect = (questionIndex: number, optionIndex: number) => {
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionIndex]: optionIndex,
    }));
  };

  const handleNextQuestion = () => {
    if (data?.questions && currentQuestionIndex < data.questions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex((prev) => prev - 1);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <p className="text-lg">Loading quiz questions...</p>
      </div>
    );
  }

  const currentQuestion = data?.questions?.[currentQuestionIndex];

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Practice Quizzes</CardTitle>
          <CardDescription>
            AI-powered adaptive quizzes to help you prepare for the NCLEX
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {data?.metrics && (
              <div className="grid gap-4 md:grid-cols-3 mb-6">
                <Card className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Accuracy</p>
                      <div className="flex items-center">
                        <Progress
                          value={data.metrics.recentAccuracy * 100}
                          className="w-24 mr-2"
                        />
                        <span className="text-sm">
                          {Math.round(data.metrics.recentAccuracy * 100)}%
                        </span>
                      </div>
                    </div>
                    <TrendingUp className="h-8 w-8 text-primary opacity-75" />
                  </div>
                </Card>

                <Card className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Difficulty</p>
                      <Badge
                        variant="outline"
                        className={
                          data.metrics.recommendedDifficulty === "hard"
                            ? "text-red-500"
                            : data.metrics.recommendedDifficulty === "medium"
                              ? "text-yellow-500"
                              : "text-green-500"
                        }
                      >
                        {data.metrics.recommendedDifficulty}
                      </Badge>
                    </div>
                    <Target className="h-8 w-8 text-primary opacity-75" />
                  </div>
                </Card>

                <Card className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Response Time</p>
                      <p className="text-2xl font-bold">
                        {Math.round(data.metrics.avgResponseTime)}s
                      </p>
                    </div>
                    <Brain className="h-8 w-8 text-primary opacity-75" />
                  </div>
                </Card>
              </div>
            )}

            <div>
              <Button
                onClick={() => {
                  setCurrentQuestionIndex(0);
                  setSelectedAnswers({});
                  refetch();
                }}
                className="w-full md:w-auto"
              >
                Generate New Quiz
              </Button>
            </div>

            {error && (
              <div className="p-4 text-red-500 bg-red-50 rounded flex items-center gap-2">
                <AlertCircle className="h-5 w-5" />
                <div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-2">
                      <p className="font-medium">Error loading quiz</p>
                      <p className="text-sm text-muted-foreground">
                        {error instanceof Error && error.message
                          ? error.message
                          : "Unable to load quiz. Please try again."}
                      </p>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => refetch()}
                        >
                          Try Again
                        </Button>
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() => {
                            setCurrentQuestionIndex(0);
                            setSelectedAnswers({});
                            refetch();
                          }}
                        >
                          Generate New Quiz
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentQuestion && (
              <div className="space-y-6">
                <div className="flex items-center justify-between mb-4">
                  <p className="text-sm text-muted-foreground">
                    Question {currentQuestionIndex + 1} of{" "}
                    {data?.questions?.length}
                  </p>
                  <Badge variant="outline">{currentQuestion.difficulty}</Badge>
                </div>

                <div className="p-4 border rounded-lg">
                  {currentQuestion.context && (
                    <div className="mb-4 p-3 bg-accent/10 rounded">
                      <p className="text-sm text-muted-foreground">
                        {currentQuestion.context}
                      </p>
                    </div>
                  )}
                  <p className="font-medium mb-4">{currentQuestion.content}</p>
                  <div className="space-y-2">
                    {currentQuestion.options.map((option, optIndex) => (
                      <div
                        key={optIndex}
                        className={`p-2 rounded cursor-pointer transition-colors ${
                          selectedAnswers[currentQuestionIndex] === optIndex
                            ? "bg-primary/10 border-primary"
                            : "hover:bg-accent"
                        }`}
                        onClick={() =>
                          handleAnswerSelect(currentQuestionIndex, optIndex)
                        }
                      >
                        {option}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-between mt-4">
                  <Button
                    variant="outline"
                    onClick={handlePreviousQuestion}
                    disabled={currentQuestionIndex === 0}
                  >
                    Previous Question
                  </Button>
                  <Button
                    onClick={handleNextQuestion}
                    disabled={
                      currentQuestionIndex ===
                      (data?.questions?.length || 0) - 1
                    }
                  >
                    Next Question
                  </Button>
                </div>
              </div>
            )}

            {data?.knowledgeGaps && data.knowledgeGaps.length > 0 && (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertCircle className="h-5 w-5" />
                    Knowledge Gaps Identified
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {data.knowledgeGaps.map((gap, index) => (
                      <div key={index} className="p-4 bg-accent/10 rounded-lg">
                        <h4 className="font-medium mb-2">{gap.topic}</h4>
                        <Progress
                          value={gap.confidence * 100}
                          className="mb-2"
                        />
                        <div className="text-sm text-muted-foreground">
                          <p>Suggested Resources:</p>
                          <ul className="list-disc list-inside">
                            {gap.suggestedResources.map((resource, i) => (
                              <li key={i}>{resource}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {data?.recommendations && (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Lightbulb className="h-5 w-5" />
                    Study Recommendations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {data.recommendations.studyTips.map((tip, index) => (
                      <p key={index} className="text-sm">
                        {tip}
                      </p>
                    ))}
                    {data.recommendations.difficultyAdjustment && (
                      <div className="mt-4 p-4 bg-accent/10 rounded-lg">
                        <p className="font-medium">Difficulty Adjustment:</p>
                        <p className="text-sm">
                          Based on your performance, we recommend to{" "}
                          <span className="font-medium">
                            {data.recommendations.difficultyAdjustment}
                          </span>{" "}
                          the difficulty level.
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
