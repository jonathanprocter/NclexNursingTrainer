import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";

export default function AssessmentHub() {
  const {
    data: assessments,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["domain-performance"],
    queryFn: async () => {
      try {
        const res = await fetch("/api/analytics/domain-performance");
        if (!res.ok) {
          throw new Error("Failed to load assessment data");
        }
        const data = await res.json();
        return Array.isArray(data) ? data : [];
      } catch (err) {
        console.error("Error fetching domain performance:", err);
        throw err;
      }
    },
    retry: 2,
    staleTime: 30000,
  });

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <Card>
          <CardContent className="pt-6">
            <Skeleton className="h-[300px] w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto p-6">
        <Alert variant="destructive">
          <AlertDescription>
            Failed to load assessment data. Please try again later.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  if (!assessments?.length) {
    return (
      <div className="container mx-auto p-6">
        <Alert>
          <AlertDescription>
            No assessment data available yet. Complete some assessments to see
            your performance.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">Assessment Hub</h1>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {assessments.map((domain: any, index: number) => (
          <Card key={index} className="overflow-hidden">
            <CardContent className="pt-6">
              <h3 className="text-lg font-semibold mb-2">{domain.domain}</h3>
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Score</span>
                    <span>{(domain.averageScore * 100).toFixed(1)}%</span>
                  </div>
                  <Progress value={domain.averageScore * 100} />
                </div>

                <div className="space-y-1">
                  <p className="flex justify-between">
                    <span>Status</span>
                    <span
                      className={
                        domain.status === "strong"
                          ? "text-green-500"
                          : "text-amber-500"
                      }
                    >
                      {domain.status === "strong"
                        ? "Strong"
                        : "Needs Improvement"}
                    </span>
                  </p>
                  <p className="flex justify-between">
                    <span>Attempts</span>
                    <span>{domain.attempts}</span>
                  </p>
                  <p className="flex justify-between text-sm text-muted-foreground">
                    <span>Last Attempt</span>
                    <span>
                      {new Date(domain.lastAttempted).toLocaleDateString()}
                    </span>
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
