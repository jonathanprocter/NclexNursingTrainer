import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { BrainCircuit, TrendingUp, Activity, Heart } from "lucide-react";

export default function PerformancePrediction() {
  const {
    data: prediction,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["/api/performance-prediction"],
    queryFn: async () => {
      const res = await fetch("/api/performance-prediction");
      if (!res.ok) {
        throw new Error("Failed to fetch prediction data");
      }
      return res.json();
    },
    retry: 2,
    initialData: {
      predictedScore: 0.7,
      confidence: 0.8,
      predictionFactors: {
        clinicalJudgment: 0.75,
        emotionalReadiness: 0.8,
      },
      recommendations: {
        focusAreas: [],
        suggestedResources: [],
      },
    },
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="space-y-4">
          <div className="h-8 bg-muted animate-pulse rounded" />
          <div className="h-[200px] bg-muted animate-pulse rounded" />
          <div className="h-[200px] bg-muted animate-pulse rounded" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8">
        <Card className="border-destructive">
          <CardContent className="pt-6">
            <div className="text-destructive">
              Error loading prediction data
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-8 space-y-6">
      <h1 className="text-3xl font-bold">Performance Prediction</h1>

      {/* Overall Prediction */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Overall Prediction
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            <div>
              <div className="mb-2 flex items-center justify-between">
                <span>Predicted Score</span>
                <span className="font-bold">
                  {Math.round(prediction?.predictedScore * 100)}%
                </span>
              </div>
              <Progress value={prediction?.predictedScore * 100} />
            </div>
            <div className="flex items-center gap-2">
              <span>Confidence:</span>
              <Badge variant="secondary">
                {Math.round(prediction?.confidence * 100)}%
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Clinical Judgment */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BrainCircuit className="h-5 w-5" />
            Clinical Judgment Metrics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            {prediction?.predictionFactors?.clinicalJudgment && (
              <div>
                <div className="mb-2">Clinical Judgment Score</div>
                <Progress
                  value={prediction.predictionFactors.clinicalJudgment * 100}
                  className="h-2"
                />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Emotional State */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Heart className="h-5 w-5" />
            Emotional State Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            {prediction?.predictionFactors?.emotionalReadiness && (
              <div>
                <div className="mb-2">Emotional Readiness</div>
                <Progress
                  value={prediction.predictionFactors.emotionalReadiness * 100}
                  className="h-2"
                />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[200px] rounded-md border p-4">
            <div className="space-y-4">
              {prediction?.recommendations?.focusAreas?.map(
                (area: string, i: number) => (
                  <div key={i} className="flex items-center gap-2">
                    <Badge>Focus Area</Badge>
                    <span>{area}</span>
                  </div>
                ),
              )}
              {prediction?.recommendations?.suggestedResources?.map(
                (resource: string, i: number) => (
                  <div key={i} className="flex items-center gap-2">
                    <Badge variant="secondary">Resource</Badge>
                    <span>{resource}</span>
                  </div>
                ),
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
