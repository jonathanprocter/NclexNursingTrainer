import { FileUpload } from "@/components/FileUpload";
import { ContentViewer } from "@/components/ContentViewer";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { FileUp, BookOpen, Brain } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function NclexManager() {
  return (
    <div className="container mx-auto py-8 px-4">
      <div className="space-y-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">
            Welcome to NCLEX Prep! 👋
          </h1>
          <p className="text-muted-foreground">
            Start your NCLEX journey with our comprehensive study tools
          </p>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="browse" className="space-y-6">
          <TabsList>
            <TabsTrigger value="browse" className="flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              Browse Content
            </TabsTrigger>
            <TabsTrigger value="upload" className="flex items-center gap-2">
              <FileUp className="h-4 w-4" />
              Upload Materials
            </TabsTrigger>
          </TabsList>

          <TabsContent value="browse" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Study Materials</CardTitle>
                <CardDescription>
                  Browse through your NCLEX study materials
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p>Content viewer will be displayed here</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="upload" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileUp className="h-5 w-5" />
                  Upload Study Materials
                </CardTitle>
                <CardDescription>
                  Upload your NCLEX resources here 📚
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <Alert>
                  <AlertTitle className="flex items-center gap-2">
                    <Brain className="h-4 w-4" />
                    Content Guidelines
                  </AlertTitle>
                  <AlertDescription>
                    Supported formats: PDF, Word documents (.docx), and text
                    files (.txt)
                  </AlertDescription>
                </Alert>
                <div className="p-4 text-center border-2 border-dashed rounded-lg">
                  <p>File upload component will be displayed here</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
