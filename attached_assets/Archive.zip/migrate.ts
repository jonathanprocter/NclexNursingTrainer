import { drizzle } from "drizzle-orm/neon-serverless";
import { migrate } from "drizzle-orm/neon-serverless/migrator";
import { Pool, neonConfig } from "@neondatabase/serverless";
import ws from "ws";
import * as schema from "./db/schema";

// Required for Neon serverless driver
neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL environment variable is required");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool, { schema });

async function main() {
  console.log("Starting database migrations...");

  try {
    // Run migrations
    await migrate(db, {
      migrationsFolder: "./drizzle",
      migrationsTable: "drizzle_migrations",
    });

    console.log("Migrations completed successfully");

    // Verify schema integrity by checking each table
    await Promise.all([
      db.select().from(schema.users).limit(1),
      db.select().from(schema.questions).limit(1),
      db.select().from(schema.userProgress).limit(1),
      db.select().from(schema.performanceAnalytics).limit(1),
      db.select().from(schema.nclexDomains).limit(1),
      db.select().from(schema.virtualPatientScenarios).limit(1),
      db.select().from(schema.scenarioResponses).limit(1),
    ]);

    console.log("Schema verification completed successfully");
  } catch (error) {
    console.error("Migration failed:", error);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

main().catch((err) => {
  console.error("Fatal: Migration failed:", err);
  process.exit(1);
});
