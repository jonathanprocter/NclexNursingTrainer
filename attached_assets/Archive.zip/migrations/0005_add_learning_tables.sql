CREATE TYPE "study_status" AS ENUM ('active', 'completed', 'paused', 'scheduled');

CREATE TABLE "study_paths" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "name" TEXT NOT NULL,
  "description" TEXT,
  "status" study_status DEFAULT 'active',
  "ai_generated" BOOLEAN DEFAULT false,
  "path_data" JSONB,
  "created_at" TIMESTAMP DEFAULT now() NOT NULL,
  "updated_at" TIMESTAMP DEFAULT now() NOT NULL
);

CREATE TABLE "performance_predictions" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "domain_id" INTEGER NOT NULL,
  "predicted_score" INTEGER NOT NULL,
  "confidence" INTEGER NOT NULL,
  "prediction_factors" JSONB,
  "recommendations" JSONB,
  "created_at" TIMESTAMP DEFAULT now() NOT NULL,
  "updated_at" TIMESTAMP DEFAULT now() NOT NULL
);

CREATE TABLE "study_schedules" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "week_start_date" TIMESTAMP NOT NULL,
  "schedule_data" JSONB NOT NULL,
  "ai_adjustments" JSONB,
  "created_at" TIMESTAMP DEFAULT now() NOT NULL,
  "updated_at" TIMESTAMP DEFAULT now() NOT NULL
);
