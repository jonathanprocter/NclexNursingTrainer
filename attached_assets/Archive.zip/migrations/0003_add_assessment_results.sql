-- Create assessment_results table
CREATE TABLE IF NOT EXISTS assessment_results (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    module_id INTEGER NOT NULL,
    domain TEXT NOT NULL,
    cognitive_level TEXT NOT NULL,
    score INTEGER NOT NULL,
    details JSONB NOT NULL,
    emotional_state TEXT DEFAULT NULL,
    learning_insights JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_assessment_results_user ON assessment_results(user_id);
CREATE INDEX IF NOT EXISTS idx_assessment_results_module ON assessment_results(module_id);
CREATE INDEX IF NOT EXISTS idx_assessment_results_domain ON assessment_results(domain);
CREATE INDEX IF NOT EXISTS idx_assessment_results_emotional ON assessment_results(emotional_state);