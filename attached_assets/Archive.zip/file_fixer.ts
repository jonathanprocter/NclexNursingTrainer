
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Generate a response from the OpenAI GPT-4 model
 * @param {Array<{role: string, content: string}>} messages - The conversation history/messages
 * @returns {Promise<string>} - The generated response from the model
 */
export async function generateChatResponse(
  messages: Array<{role: string, content: string}>
): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages,
      max_tokens: 1500,
      temperature: 0.7,
    });

    return response.choices[0]?.message?.content?.trim() || "";
  } catch (error) {
    console.error("Error generating response from OpenAI:", error);
    throw new Error("Failed to generate response from OpenAI.");
  }
}

/**
 * Generate a single prompt-based text response using GPT-4
 * @param {string} prompt - The prompt to generate text for
 * @returns {Promise<string>} - The generated text
 */
export async function generateText(prompt: string): Promise<string> {
  try {
    const messages = [
      { role: "system", content: "You are a helpful assistant." },
      { role: "user", content: prompt },
    ];

    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages,
      max_tokens: 1000,
      temperature: 0.7,
    });

    return response.choices[0]?.message?.content?.trim() || "";
  } catch (error) {
    console.error("Error generating text from OpenAI:", error);
    throw new Error("Failed to generate text from OpenAI.");
  }
}
