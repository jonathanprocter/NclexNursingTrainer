-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create enums first
DO $$ BEGIN
    CREATE TYPE category AS ENUM ('fundamentals', 'medical_surgical', 'pediatrics', 'mental_health', 'maternal_newborn', 'community_health', 'leadership');
    CREATE TYPE difficulty AS ENUM ('easy', 'medium', 'hard');
    CREATE TYPE conceptual_level AS ENUM ('recall', 'application', 'analysis', 'synthesis', 'evaluation');
    CREATE TYPE clinical_judgment_level AS ENUM ('1', '2', '3', '4');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Create users table first
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    learning_style JSONB
);

-- Create flashcards table first
CREATE TABLE IF NOT EXISTS flashcards (
    id SERIAL PRIMARY KEY,
    front TEXT NOT NULL,
    back TEXT NOT NULL,
    category category DEFAULT 'fundamentals',
    difficulty difficulty DEFAULT 'medium',
    explanation TEXT,
    tags TEXT[],
    hint TEXT,
    saved_for_review BOOLEAN DEFAULT false,
    clinical_judgment_level clinical_judgment_level,
    conceptual_level conceptual_level,
    rationale JSONB,
    clinical_reasoning JSONB,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create flashcard_progress table with proper foreign key
CREATE TABLE IF NOT EXISTS flashcard_progress (
    id SERIAL PRIMARY KEY,
    flashcard_id INTEGER REFERENCES flashcards(id),
    user_id INTEGER NOT NULL,
    correct BOOLEAN NOT NULL,
    confidence INTEGER NOT NULL,
    times_reviewed INTEGER DEFAULT 0,
    last_reviewed TIMESTAMP WITH TIME ZONE,
    next_review TIMESTAMP WITH TIME ZONE,
    interval INTEGER DEFAULT 0,
    ease_factor INTEGER DEFAULT 250,
    correct_streak INTEGER DEFAULT 0,
    performance_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_flashcard_progress_user_id ON flashcard_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_flashcard_progress_flashcard_id ON flashcard_progress(flashcard_id);