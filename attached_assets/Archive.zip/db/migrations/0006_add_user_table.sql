CREATE TYPE "category" AS ENUM ('fundamentals', 'medical_surgical', 'pediatrics', 'mental_health', 'maternal_newborn', 'community_health', 'leadership');
CREATE TYPE "difficulty" AS ENUM ('easy', 'medium', 'hard');
CREATE TYPE "conceptual_level" AS ENUM ('recall', 'application', 'analysis', 'synthesis', 'evaluation');
CREATE TYPE "clinical_judgment_level" AS ENUM ('1', '2', '3', '4');

-- Create users table
CREATE TABLE IF NOT EXISTS "users" (
    "id" SERIAL PRIMARY KEY,
    "username" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "hashed_password" TEXT NOT NULL,
    "is_instructor" BOOLEAN DEFAULT false,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "last_active" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "learning_progress" JSONB DEFAULT '{"completedModules": 0, "retentionRate": 0, "accuracyTrend": 0, "estimatedMastery": 0, "weakAreas": [], "strengths": []}' NOT NULL
);

-- Add foreign key constraints for flashcard_progress
ALTER TABLE IF EXISTS "flashcard_progress"
    ADD CONSTRAINT "flashcard_progress_user_id_fkey"
    FOREIGN KEY ("user_id") REFERENCES "users"("id")
    ON DELETE CASCADE;

-- Create indexes
CREATE INDEX IF NOT EXISTS "user_email_idx" ON "users"("email");
CREATE INDEX IF NOT EXISTS "user_username_idx" ON "users"("username");
