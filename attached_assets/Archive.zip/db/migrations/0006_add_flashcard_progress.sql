-- Add new columns for flashcard progress tracking
ALTER TABLE user_progress 
ADD COLUMN IF NOT EXISTS next_review_date timestamp with time zone,
ADD COLUMN IF NOT EXISTS repetition_number integer DEFAULT 0;

-- Update existing column to be not null if needed
UPDATE user_progress SET repetition_number = 0 WHERE repetition_number IS NULL;
