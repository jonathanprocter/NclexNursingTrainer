import { db } from "@db";
import {
  users,
  questions,
  userProgress,
  type InsertQuestion,
} from "@db/schema";
import { sql } from "drizzle-orm";

async function seedNCLEXQuestions() {
  try {
    console.log("Starting NCLEX questions seeding...");

    // Create test questions with proper NCLEX style content
    const sampleQuestions: InsertQuestion[] = [
      {
        domainId: 1, // Will be replaced with actual domain ID
        scenario:
          "A nurse is caring for a client who has just been admitted with acute respiratory distress. The nurse also has three other clients: one waiting for scheduled pain medication, one due for a dressing change, and one requiring assistance with ambulation. Which action should the nurse take FIRST?",
        options: [
          "A) Assess the client with respiratory distress",
          "B) Administer the scheduled pain medication",
          "C) Perform the dressing change",
          "D) Assist the client with ambulation",
        ],
        correctAnswer: "A) Assess the client with respiratory distress",
        explanation:
          "The nurse should prioritize assessing the client with respiratory distress first, as this condition can be life-threatening and requires immediate attention. The other tasks, while important, do not present immediate risks to client safety.",
        difficulty: "medium",
        conceptualLevel: "analysis",
        clinicalJudgmentLevel: "3",
        aiGenerated: false,
        conceptualBreakdown: {
          mainConcept: "Prioritization of Care",
          relatedConcepts: [
            "ABC Assessment",
            "Emergency Care",
            "Time Management",
          ],
          applicationContext: "Critical Care",
        },
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        domainId: 2,
        scenario:
          "A nurse is preparing to care for a client who requires airborne precautions. Which sequence of actions should the nurse take before entering the client's room?",
        options: [
          "A) Perform hand hygiene, put on gloves, put on N95 respirator",
          "B) Put on N95 respirator, perform fit check, perform hand hygiene",
          "C) Put on gloves, put on N95 respirator, perform hand hygiene",
          "D) Perform hand hygiene, put on N95 respirator, put on face shield",
        ],
        correctAnswer:
          "B) Put on N95 respirator, perform fit check, perform hand hygiene",
        explanation:
          "For airborne precautions, the correct sequence is to put on the N95 respirator first, perform a fit check to ensure proper seal, and then perform hand hygiene. This sequence ensures proper respiratory protection before entering the room.",
        difficulty: "medium",
        conceptualLevel: "application",
        clinicalJudgmentLevel: "2",
        aiGenerated: false,
        conceptualBreakdown: {
          mainConcept: "Infection Control",
          relatedConcepts: ["PPE", "Safety Protocols", "Disease Prevention"],
          applicationContext: "Isolation Precautions",
        },
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    // Clear existing questions
    await db.delete(questions);

    // Insert new questions
    for (const question of sampleQuestions) {
      await db.insert(questions).values(question);
    }

    console.log("Successfully seeded NCLEX questions");
  } catch (error) {
    console.error("Error seeding NCLEX questions:", error);
    throw error;
  }
}

async function seedAnalyticsData() {
  try {
    console.log("Starting analytics data seeding...");

    // Create a test user if not exists
    let testUser = await db.query.users.findFirst({
      where: sql`email = 'test@example.com'`,
    });

    if (!testUser) {
      console.log("Creating test user...");
      const insertedUsers = await db
        .insert(users)
        .values({
          email: "test@example.com",
          username: "testuser",
          password: "password123",
          createdAt: new Date(),
          learningStyle: {
            visual: 0.7,
            auditory: 0.5,
            kinesthetic: 0.3,
            reading: 0.8,
          },
        })
        .returning();
      testUser = insertedUsers[0];
    }

    // For now, we'll just log the creation of the test user
    // and skip the progress tracking until those tables are properly set up
    console.log("Test user created with ID:", testUser.id);
    console.log("Analytics seed data completed");
  } catch (error) {
    console.error("Error seeding analytics data:", error);
    throw error;
  }
}

// Run seeding
if (process.env.NODE_ENV !== "production") {
  seedNCLEXQuestions().catch(console.error);
  seedAnalyticsData().catch(console.error);
}

export { seedAnalyticsData, seedNCLEXQuestions };
