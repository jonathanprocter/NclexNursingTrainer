import fs from 'fs/promises';
import path from 'path';
import { Anthropic } from '@anthropic-ai/sdk';
import chalk from 'chalk';

// Initialize Anthropic client
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

interface FileInfo {
  path: string;
  content: string;
  priority: number;
}

class ProjectFixer {
  private readonly priorityPatterns = {
    critical: [
      /package\.json$/,
      /tsconfig\.json$/,
      /vite\.config\./,
      /index\.(ts|tsx)$/,
      /server\/.*\.(ts|js)$/,
      /\.env$/
    ],
    high: [
      /routes\//,
      /middleware\//,
      /services\//,
      /db\//,
      /config\//
    ],
    medium: [
      /components\//,
      /hooks\//,
      /utils\//,
      /types\//
    ],
    low: [
      /\.css$/,
      /\.md$/,
      /\.test\./,
      /\.spec\./
    ]
  };

  private readonly ignoredPatterns = [
    /node_modules/,
    /\.git/,
    /dist/,
    /build/,
    /\.log$/
  ];

  constructor(private readonly rootDir: string) {}

  private async getPriority(filePath: string): Promise<number> {
    const relativePath = path.relative(this.rootDir, filePath);

    if (this.priorityPatterns.critical.some(pattern => pattern.test(relativePath))) {
      return 1;
    }
    if (this.priorityPatterns.high.some(pattern => pattern.test(relativePath))) {
      return 2;
    }
    if (this.priorityPatterns.medium.some(pattern => pattern.test(relativePath))) {
      return 3;
    }
    if (this.priorityPatterns.low.some(pattern => pattern.test(relativePath))) {
      return 4;
    }
    return 5;
  }

  private shouldIgnore(filePath: string): boolean {
    return this.ignoredPatterns.some(pattern => pattern.test(filePath));
  }

  private async getAllFiles(dir: string): Promise<FileInfo[]> {
    const files: FileInfo[] = [];

    const traverse = async (currentDir: string) => {  // Changed to arrow function to preserve this context
      const entries = await fs.readdir(currentDir, { withFileTypes: true });

      for (const entry of entries) {
        const fullPath = path.join(currentDir, entry.name);

        if (entry.isDirectory()) {
          if (!this.shouldIgnore(fullPath)) {
            await traverse(fullPath);
          }
        } else {
          if (!this.shouldIgnore(fullPath)) {
            try {
              const content = await fs.readFile(fullPath, 'utf-8');
              const priority = await this.getPriority(fullPath);
              files.push({ path: fullPath, content, priority });
            } catch (error) {
              console.error(chalk.yellow(`Error reading file ${fullPath}:`, error));
            }
          }
        }
      }
    };

    await traverse(dir);
    return files.sort((a, b) => a.priority - b.priority);
  }

  private async analyzeAndFixFile(fileInfo: FileInfo): Promise<void> {
    console.log(chalk.blue(`Analyzing ${fileInfo.path}...`));

    try {
      const response = await anthropic.messages.create({
        model: 'claude-3-opus-20240229',
        max_tokens: 4000,
        messages: [{
          role: 'user',
          content: `Please analyze and fix the following ${path.extname(fileInfo.path)} file. 
          Provide fixes for any issues you find including code structure, error handling, type safety, 
          and best practices. Return only the complete fixed code without explanations.

          File path: ${fileInfo.path}

          Content:
          ${fileInfo.content}`
        }]
      });

      const fixedContent = response.content[0].text;

      if (fixedContent !== fileInfo.content) {
        await fs.writeFile(fileInfo.path, fixedContent, 'utf-8');
        console.log(chalk.green(`✓ Fixed ${fileInfo.path}`));
      } else {
        console.log(chalk.gray(`- No fixes needed for ${fileInfo.path}`));
      }
    } catch (error) {
      console.error(chalk.red(`Error processing ${fileInfo.path}:`), error);
    }
  }

  private async validateProjectStructure(): Promise<void> {
    const essentialDirs = [
      'src',
      'src/components',
      'src/hooks',
      'src/utils',
      'src/types',
      'src/services',
      'server',
      'server/routes',
      'server/middleware',
      'server/services',
      'public'
    ];

    for (const dir of essentialDirs) {
      const fullPath = path.join(this.rootDir, dir);
      try {
        await fs.access(fullPath);
      } catch {
        console.log(chalk.yellow(`Creating missing directory: ${dir}`));
        await fs.mkdir(fullPath, { recursive: true });
      }
    }
  }

  private async ensureConfigFiles(): Promise<void> {
    const configFiles = {
      'tsconfig.json': {
        content: {
          compilerOptions: {
            target: "ES2020",
            useDefineForClassFields: true,
            lib: ["ES2020", "DOM", "DOM.Iterable"],
            module: "ESNext",
            skipLibCheck: true,
            moduleResolution: "bundler",
            allowImportingTsExtensions: true,
            resolveJsonModule: true,
            isolatedModules: true,
            noEmit: true,
            jsx: "react-jsx",
            strict: true,
            noUnusedLocals: true,
            noUnusedParameters: true,
            noFallthroughCasesInSwitch: true,
            baseUrl: ".",
            paths: {
              "@/*": ["./src/*"]
            }
          },
          include: ["src"],
          references: [{ path: "./tsconfig.node.json" }]
        }
      },
      '.env.example': {
        content: `
PORT=3000
HOST=0.0.0.0
NODE_ENV=development
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/your_db
ANTHROPIC_API_KEY=your_api_key
`
      },
      'vite.config.ts': {
        content: `
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 3000,
    hmr: {
      clientPort: 443,
      protocol: 'wss'
    }
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src')
    }
  }
});
`
      }
    };

    for (const [fileName, { content }] of Object.entries(configFiles)) {
      const filePath = path.join(this.rootDir, fileName);
      try {
        await fs.access(filePath);
      } catch {
        console.log(chalk.yellow(`Creating missing config file: ${fileName}`));
        await fs.writeFile(
          filePath, 
          typeof content === 'string' ? content : JSON.stringify(content, null, 2)
        );
      }
    }
  }

  public async fix(): Promise<void> {
    console.log(chalk.cyan('Starting project analysis and fixes...'));

    // Ensure proper project structure
    await this.validateProjectStructure();
    await this.ensureConfigFiles();

    // Get and process all files
    const files = await this.getAllFiles(this.rootDir);
    console.log(chalk.cyan(`Found ${files.length} files to analyze`));

    for (const file of files) {
      await this.analyzeAndFixFile(file);
    }

    console.log(chalk.green('\nProject analysis and fixes completed!'));
  }
}

// Script execution
async function main() {
  if (!process.env.ANTHROPIC_API_KEY) {
    console.error(chalk.red('Error: ANTHROPIC_API_KEY environment variable is required'));
    process.exit(1);
  }

  const projectDir = process.cwd();
  const fixer = new ProjectFixer(projectDir);

  try {
    await fixer.fix();
  } catch (error) {
    console.error(chalk.red('Error during project fixes:'), error);
    process.exit(1);
  }
}

main();