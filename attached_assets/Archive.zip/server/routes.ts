import { fileURLToPath } from 'url';
import { dirname } from 'path';
import type { Express, Request, Response } from "express";
import express from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import MemoryStore from "memorystore";
import { db } from "@db";
import { sql } from "drizzle-orm";
import { eq, desc } from "drizzle-orm";
import { userProgress } from "@db/schema";
import authRouter from "./routes/auth";
import analyticsRouter from "./routes/analytics";
import aiRouter from "./routes/ai-routes";
import adaptiveRouter from "./routes/adaptive";
import practiceExamRouter from "./routes/practice-exam";
import studyGuideRouter from "./routes/study-guide";
import modulesRouter from "./routes/modules";
import scenariosRouter from "./routes/scenarios";
import bookmarksRouter from "./routes/bookmarks";
import { serviceIntegrator } from "./services/service-integrator";
import { log } from "./vite";
import path from "path";
import { analyticsService } from "./services/analytics.service";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

interface CustomRequest extends Request {
  session: session.Session & {
    userId?: number;
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Set up request logging middleware
  app.use((req, res, next) => {
    const start = Date.now();
    res.on("finish", () => {
      const duration = Date.now() - start;
      log(`${req.method} ${req.originalUrl} ${res.statusCode} ${duration}ms`);
    });
    next();
  });

  // Session middleware
  app.use(
    session({
      cookie: {
        maxAge: 86400000,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
      },
      store: new (MemoryStore(session))({
        checkPeriod: 86400000,
      }),
      resave: false,
      saveUninitialized: false,
      secret: process.env.SESSION_SECRET || "dev-secret-key",
      name: "nclex_prep.sid",
    }),
  );

  // Initialize services before registering routes
  log("Initializing services...");
  try {
    const servicesInitialized = await serviceIntegrator.initialize();
    if (!servicesInitialized) {
      throw new Error("Failed to initialize core services");
    }
    log("Services initialized successfully");
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    log("Failed to initialize services: " + errorMessage);
    throw new Error("Service initialization failed: " + errorMessage);
  }

  // Protected routes middleware
  const requireAuth = (req: CustomRequest, res: Response, next: () => void) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };

  // Database health check middleware
  const checkDatabase = async (_req: Request, res: Response, next: () => void) => {
    try {
      await db.execute(sql`SELECT NOW()`);
      next();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      log("Database health check error: " + errorMessage);
      return res.status(503).json({
        message: "Service temporarily unavailable",
        details: "Database connection error",
      });
    }
  };

  // Register API routes
  app.use("/api/auth", authRouter);
  app.use("/api/analytics", checkDatabase, requireAuth, analyticsRouter);
  app.use("/api/ai", checkDatabase, requireAuth, aiRouter);
  app.use("/api/practice-exam", checkDatabase, requireAuth, practiceExamRouter);
  app.use("/api/modules", checkDatabase, requireAuth, modulesRouter);
  app.use("/api/study-guide", checkDatabase, requireAuth, studyGuideRouter);
  app.use("/api/scenarios", checkDatabase, requireAuth, scenariosRouter);
  app.use("/api/bookmarks", checkDatabase, requireAuth, bookmarksRouter);
  app.use("/api/adaptive", checkDatabase, requireAuth, adaptiveRouter);

  // Analytics endpoints
  app.get("/api/analytics/advanced", checkDatabase, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).session?.userId || 1; // Fallback for testing
      const data = await analyticsService.getAdvancedAnalytics(userId);
      res.json(data);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      log("Advanced analytics error: " + errorMessage);
      res.status(500).json({
        message: errorMessage
      });
    }
  });

  // Dashboard overview endpoint
  app.get("/api/dashboard/overview", checkDatabase, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).session?.userId || 1; // Fallback for testing
      const progress = await db.query.userProgress.findMany({
        where: eq(userProgress.userId, userId),
        orderBy: [desc(userProgress.timestamp)],
        limit: 50,
      });

      const totalAnswered = progress.length;
      const correctAnswers = progress.filter(p => p.correct).length;
      const overallProgress = totalAnswered > 0 
        ? Math.round((correctAnswers / totalAnswered) * 100)
        : 0;

      res.json({
        overallProgress,
        totalQuestions: totalAnswered,
        correctAnswers,
        lastUpdated: progress[0]?.timestamp || new Date(),
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      log("Dashboard overview error: " + errorMessage);
      res.status(500).json({
        message: errorMessage
      });
    }
  });

  // Serve static files in production
  if (process.env.NODE_ENV === "production") {
    const distPath = path.resolve(__dirname, "..", "dist", "public");
    app.use("/static", express.static(distPath));
  }

  // SPA fallback
  app.get("*", (req, res, next) => {
    if (req.path.startsWith("/api")) {
      next();
    } else {
      const distPath = process.env.NODE_ENV === "production"
        ? path.resolve(__dirname, "..", "dist", "public")
        : path.resolve(__dirname, "..", "client");
      res.sendFile(path.join(distPath, "index.html"));
    }
  });

  return httpServer;
}