Here's the fixed code:

```typescript
import { Router } from "express";
import { db } from "@db";
import { flashcards, flashcardProgress, performancePredictions, knowledgeGaps } from "@db/schema";
import { Pool } from "pg";
import { Request, Response } from "express";
import { eq } from "drizzle-orm";

interface OpenAIQuestion {
  question: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
  conceptBreakdown: {
    keyPoints: string[];
    relatedConcepts: string[];
    clinicalCorrelation: string;
  };
  tags: string[];
}

interface Flashcard {
  front: string;
  back: string;
  question: string;
  options: string[];
  correct_answer: string;
  explanation: string;
  tags: string[];
  domain: string;
  difficulty: string;
}

const pool = new Pool();

function getQuestionsFromRequest(req: Request): OpenAIQuestion[] {
  console.log("Processing request body:", JSON.stringify(req.body, null, 2));

  if (req.body.rawResponse?.questions) {
    return req.body.rawResponse.questions;
  }

  if (req.body.questions) {
    return req.body.questions;
  }

  return req.body.parsedQuestions || [];
}

function convertToFlashcard(question: OpenAIQuestion, domain: string): Flashcard {
  const enhancedExplanation = `
${question.explanation}

Key Points:
${question.conceptBreakdown.keyPoints.map((point) => `• ${point}`).join("\n")}

Clinical Application:
${question.conceptBreakdown.clinicalCorrelation}

Related Concepts:
${question.conceptBreakdown.relatedConcepts.join(", ")}
  `.trim();

  return {
    front: question.question,
    back: question.correctAnswer,
    question: question.question,
    options: question.options,
    correct_answer: question.correctAnswer,
    explanation: enhancedExplanation,
    tags: question.tags,
    domain: domain,
    difficulty: "medium",
  };
}

const router = Router();

router.post("/generate", async (req: Request, res: Response) => {
  const client = await pool.connect();
  console.log("Starting flashcard generation process");

  try {
    const { domain } = req.body;
    const questions = getQuestionsFromRequest(req);
    console.log(`Found ${questions.length} questions to process`);

    if (questions.length === 0) {
      throw new Error("No questions found in the request");
    }

    const flashcards = questions.map((q) => convertToFlashcard(q, domain));
    console.log(`Created ${flashcards.length} flashcards`);

    await client.query("BEGIN");

    const insertedIds: number[] = [];

    for (const flashcard of flashcards) {
      const result = await client.query(
        `INSERT INTO flashcards (
          front, back, question, options, correct_answer,
          explanation, tags, domain, difficulty
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        RETURNING id`,
        [
          flashcard.front,
          flashcard.back,
          flashcard.question,
          flashcard.options,
          flashcard.correct_answer,
          flashcard.explanation,
          flashcard.tags,
          flashcard.domain,
          flashcard.difficulty,
        ],
      );

      insertedIds.push(result.rows[0].id);
    }

    await client.query("COMMIT");

    console.log(`Successfully saved ${insertedIds.length} flashcards`);

    res.json({
      success: true,
      message: `Successfully generated ${flashcards.length} flashcards`,
      count: flashcards.length,
      flashcards: flashcards,
      ids: insertedIds,
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Error in flashcard generation:", error);

    res.status(500).json({
      success: false,
      message: error instanceof Error ? error.message : "An unknown error occurred",
      error: error instanceof Error ? error.toString() : "Unknown error",
    });
  } finally {
    client.release();
  }
});

router.get("/", async (_req: Request, res: Response) => {
  try {
    const cards = await db.query.flashcards.findMany();
    return res.json(cards);
  } catch (error) {
    console.error("Error in GET /flashcards:", error);
    res.status(500).json({
      message: "Failed to fetch flashcards",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

// Enhanced progress endpoint with analytics integration
router.post("/progress", async (req: Request, res: Response) => {
  try {
    const { flashcardId, correct, confidence } = req.body;
    const userId = req.session?.userId || 1;

    // Get the flashcard to access its domain info
    const flashcard = await db.query.flashcards.findFirst({
      where: eq(flashcards.id, flashcardId),
    });

    if (!flashcard) {
      return res.status(404).json({ message: "Flashcard not found" });
    }

    const now = new Date();

    // Update or create progress
    const existingProgress = await db.query.flashcardProgress.findFirst({
      where: eq(flashcardProgress.flashcard_id, flashcardId),
    });

    let progress;
    if (existingProgress) {
      const [updatedProgress] = await db
        .update(flashcardProgress)
        .set({
          correct,
          confidence,
          times_reviewed: (existingProgress.times_reviewed || 0) + 1,
          last_reviewed: now,
          performance_data: {
            reviewHistory: [
              ...(existingProgress.performance_data?.reviewHistory || []),
              {
                timestamp: now.toISOString(),
                confidence,
                timeSpent: 0,
              },
            ],
            masteryLevel: correct
              ? Math.min(1, (existingProgress.performance_data?.masteryLevel || 0) + 0.1)
              : Math.max(0, (existingProgress.performance_data?.masteryLevel || 0) - 0.1),
            difficulty: confidence,
          },
          updated_at: now,
        })
        .where(eq(flashcardProgress.id, existingProgress.id))
        .returning();
      progress = updatedProgress;
    } else {
      const [newProgress] = await db
        .insert(flashcardProgress)
        .values({
          flashcard_id: flashcardId,
          user_id: userId,
          correct,
          confidence,
          times_reviewed: 1,
          last_reviewed: now,
          performance_data: {
            reviewHistory: [
              {
                timestamp: now.toISOString(),
                confidence,
                timeSpent: 0,
              },
            ],
            masteryLevel: correct ? 0.1 : 0,
            difficulty: confidence,
          },
          created_at: now,
          updated_at: now,
        })
        .returning();
      progress = newProgress;
    }

    // Update performance predictions
    const [prediction] = await db
      .insert(performancePredictions)
      .values({
        userId,
        domainId: flashcard.domain || "unknown",
        predictedScore: progress.performance_data.masteryLevel * 100,
        confidence: confidence / 5, // normalize to 0-1
        predictionFactors: {
          historicalPerformance: progress.performance_data.masteryLevel,
          studyConsistency: progress.times_reviewed / 10, // normalize based on review count
          topicMastery: correct ? 1 : 0,
          recentProgress: correct ? 0.1 : -0.1,
          comparativeFactor: 0.5, // placeholder, could be calculated based on peer performance
        },
        recommendations: {
          focusAreas: flashcard.tags || [],
          suggestedResources: [],
          timeInvestment: 30, // minutes, could be dynamic based on performance
          practiceSets: [],
        },
      })
      .returning();

    // Update knowledge gaps if performance is low
    if (confidence <= 3 || !correct) {
      await db
        .insert(knowledgeGaps)
        .values({
          userId,
          domainId: flashcard.domain || "unknown",
          gapLevel: (5 - confidence) / 5, // normalize to 0-1
          status: "active",
          analysisData: {
            conceptualGaps: flashcard.tags || [],
            misconceptions: [],
            practiceNeeded: [flashcard.domain],
            relatedTopics: flashcard.tags || [],
            impactOnPerformance: 0.5,
          },
          remediationPlan: {
            resources: [],
            exercises: [],
            targetDate: new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 1 week from now
            milestones: [
              {
                description: `Review and master ${flashcard.front}`,
                completed: false,
              },
            ],
          },
        })
        .returning();
    }

    res.json(progress);
  } catch (error) {
    console.error("Error updating flashcard progress:", error);
    res.status(500).json({
      message: "Failed to update progress",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

// Get progress for a specific flashcard
router.get("/progress/:flashcardId", async (req: Request, res: Response) => {
  try {
    const { flashcardId } = req.params;
    const userId = req.session?.userId || 1;

    const progress = await db.query.flashcardProgress.findFirst({
      where: eq(flashcardProgress.flashcard_id, parseInt(flashcardId)),
    });

    res.json(progress || null);
  } catch (error) {
    console.error("Error fetching flashcard progress:", error);
    res.status(500).json({
      message: "Failed to fetch progress",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

export default router;
```