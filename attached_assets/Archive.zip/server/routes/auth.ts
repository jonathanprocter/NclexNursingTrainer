import express from "express";
import { authService } from "../services/auth-service";
import { z } from "zod";

const router = express.Router();

const authSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

router.post("/register", async (req, res) => {
  try {
    const credentials = authSchema.parse(req.body);
    const user = await authService.register(credentials);
    req.session.userId = user.id;
    res.status(201).json({ success: true, user });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        success: false,
        errors: error.errors.map((e) => e.message),
      });
    }

    console.error("Registration failed:", error);
    res.status(500).json({ success: false, message: "Registration failed" });
  }
});

router.post("/login", async (req, res) => {
  try {
    const credentials = authSchema.parse(req.body);
    const user = await authService.login(credentials);
    req.session.userId = user.id;
    res.json({ success: true, user });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        success: false,
        errors: error.errors.map((e) => e.message),
      });
    }

    console.error("Login failed:", error);
    res.status(401).json({ success: false, message: "Invalid credentials" });
  }
});

router.post("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error("Logout failed:", err);
      return res.status(500).json({ success: false, message: "Logout failed" });
    }
    res.json({ success: true });
  });
});

router.get("/me", (req, res) => {
  const userId = req.session.userId;
  if (!userId) {
    return res.status(401).json({
      success: false,
      message: "Not authenticated",
    });
  }

  res.json({
    success: true,
    user: { id: userId },
  });
});

export default router;