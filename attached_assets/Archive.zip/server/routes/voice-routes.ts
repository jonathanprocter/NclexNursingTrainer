import { Router } from "express";
import { z } from "zod";
import {
  voiceAssistantService,
  VoiceCommandInput,
  VoiceResponse,
} from "../services/voice-assistant.service";

const router = Router();

const voiceCommandSchema = z.object({
  // Define the shape of the voice command input
  // Example:
  // command: z.string(),
  // parameters: z.record(z.string(), z.unknown()),
});

const voiceResponseSchema = z.object({
  text: z.string(),
  suggestions: z.array(z.string()).optional(),
  confidence: z.number().min(0).max(1).optional(),
  emotionalSupport: z.boolean().optional(),
  nextTopic: z.string().nullable().optional(),
});

router.post("/command", async (req, res) => {
  try {
    const result = voiceCommandSchema.safeParse(req.body);

    if (!result.success) {
      return res.status(400).json({
        error: "Invalid request format",
        details: result.error.format(),
      });
    }

    const command = result.data as VoiceCommandInput;
    const response = await voiceAssistantService.processCommand(command);

    const validatedResponse = voiceResponseSchema.safeParse(response);

    if (!validatedResponse.success) {
      console.error("Invalid response generated:", validatedResponse.error);
      return res.status(500).json({
        error: "Invalid response generated",
        details: "The voice assistant generated an invalid response",
      });
    }

    return res.status(200).json(validatedResponse.data);
  } catch (error) {
    console.error("Voice assistant error:", error);
    return res.status(500).json({
      error: "Voice processing failed",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

export default router;