import { Router } from "express";
import { rateLimit, circuitBreaker } from "../middleware/ai-middleware";
import type { Request, Response } from "express";
import {
  generateNCLEXQuestion,
  validateQuestion,
} from "../services/openai-service";
import { analyticsService } from "../services/analytics.service";
import { studyPathService } from "../services/study-path.service";
import { knowledgeGapService } from "../services/knowledge-gap.service";
import { voiceAssistantService } from "../services/voice-assistant.service";

const router = Router();

router.use(rateLimit);
router.use(circuitBreaker);

router.post("/questions/generate", async (req: Request, res: Response) => {
  try {
    const { domain, difficulty, conceptualLevel } = req.body;

    if (!domain || !difficulty || !conceptualLevel) {
      return res.status(400).json({
        error:
          "Missing required fields: domain, difficulty, and conceptualLevel are required",
      });
    }

    const question = await generateNCLEXQuestion({
      domain,
      difficulty,
      conceptualLevel,
    });

    res.json(question);
  } catch (error) {
    console.error("Error generating question:", error);
    res.status(500).json({
      error: "Failed to generate question",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

router.post("/questions/validate", async (req: Request, res: Response) => {
  try {
    const { question } = req.body;

    if (!question) {
      return res.status(400).json({ error: "Question object is required" });
    }

    const validation = await validateQuestion(question);
    res.json(validation);
  } catch (error) {
    console.error("Error validating question:", error);
    res.status(500).json({
      error: "Failed to validate question",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

router.post("/study-path", async (req: Request, res: Response) => {
  try {
    const { userId, preferences } = req.body;
    if (!userId || !preferences) {
      return res
        .status(400)
        .json({ error: "Missing required fields: userId and preferences" });
    }

    const studyPath = await studyPathService.generateStudyPath(
      userId,
      preferences,
    );
    res.json(studyPath);
  } catch (error) {
    console.error("Error generating study path:", error);
    res.status(500).json({
      error: "Failed to generate study path",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

router.get("/knowledge-gaps/:userId", async (req: Request, res: Response) => {
  try {
    const userId = parseInt(req.params.userId, 10);
    const gaps = await knowledgeGapService.analyzeGaps(userId);
    res.json(gaps);
  } catch (error) {
    console.error("Error analyzing knowledge gaps:", error);
    res.status(500).json({
      error: "Failed to analyze knowledge gaps",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

router.post("/voice-assistant/command", async (req: Request, res: Response) => {
  try {
    if (!voiceAssistantService) {
      throw new Error("Voice assistant service not initialized");
    }

    const command = req.body;
    if (!command || typeof command !== "object") {
      return res.status(400).json({ error: "Invalid command format" });
    }

    if (!command.command || typeof command.command !== "string") {
      return res.status(400).json({ error: "Command text is required" });
    }

    const response = await voiceAssistantService.processCommand(command);
    if (!response || typeof response !== "object") {
      throw new Error("Invalid response from voice assistant service");
    }

    return res.json({
      text: response.text || "",
      suggestions: Array.isArray(response.suggestions)
        ? response.suggestions
        : [],
      confidence:
        typeof response.confidence === "number" ? response.confidence : 1.0,
      emotionalSupport: Boolean(response.emotionalSupport),
    });
  } catch (error) {
    console.error("Error in voice assistant:", error);
    return res.status(500).json({
      error: "Failed to process voice command",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

router.get(
  "/predict-performance/:userId",
  async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId, 10);
      const prediction = await analyticsService.predictPerformance(userId);
      res.json(prediction);
    } catch (error) {
      console.error("Error predicting performance:", error);
      res.status(500).json({
        error: "Failed to predict performance",
        details: error instanceof Error ? error.message : "Unknown error",
      });
    }
  },
);

router.get(
  "/learning-patterns/:userId",
  async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId, 10);
      const patterns = await analyticsService.analyzeLearningPatterns(userId);
      res.json(patterns);
    } catch (error) {
      console.error("Error analyzing learning patterns:", error);
      res.status(500).json({
        error: "Failed to analyze learning patterns",
        details: error instanceof Error ? error.message : "Unknown error",
      });
    }
  },
);

export default router;