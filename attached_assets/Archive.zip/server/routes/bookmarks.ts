import { Router } from "express";
import { db } from "@db";
import { bookmarks, bookmarkFolders, users } from "@db/schema";
import { and, eq } from "drizzle-orm";
import type { Request, Response } from "express";

const router = Router();

interface Bookmark {
  userId: number;
  title: string;
  content: string;
  url: string | null;
  tags: string[];
  folderId: number | null;
  aiGeneratedNotes: {
    summary: string;
    keyPoints: string[];
    relatedConcepts: string[];
    clinicalConnections: string[];
  };
  createdAt: Date;
  updatedAt: Date;
}

// Create a new bookmark
router.post("/", async (req: Request, res: Response) => {
  try {
    const { title, content, url, tags, folderId, metadata } = req.body;
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    // Generate AI notes
    const aiNotes = await generateSmartNotes(content);

    const bookmark = await db
      .insert(bookmarks)
      .values({
        userId: req.session.userId,
        title,
        content,
        url: url || null,
        tags: tags || [],
        folderId: folderId || null,
        aiGeneratedNotes: {
          summary: aiNotes.summary,
          keyPoints: aiNotes.keyTerms,
          relatedConcepts: [],
          clinicalConnections: aiNotes.clinicalPearls,
        },
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .returning()
      .then((results) => results[0] as Bookmark);

    if (!bookmark) {
      throw new Error("Failed to create bookmark");
    }

    return res.status(201).json({ bookmark });
  } catch (error) {
    console.error("Error creating bookmark:", error);
    return res.status(500).json({ message: "Error creating bookmark" });
  }
});

// Get all bookmarks for a user
router.get("/", async (req: Request, res: Response) => {
  try {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const userBookmarks = await db.query.bookmarks.findMany({
      where: eq(bookmarks.userId, req.session.userId),
      with: {
        folder: true,
      },
    });

    return res.status(200).json(userBookmarks);
  } catch (error) {
    console.error("Error fetching bookmarks:", error);
    return res.status(500).json({ message: "Error fetching bookmarks" });
  }
});

// Export bookmark and notes in specified format
router.post("/:id/export", async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { format } = req.body;
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const bookmark = await db.query.bookmarks.findFirst({
      where: and(
        eq(bookmarks.id, parseInt(id, 10)),
        eq(bookmarks.userId, req.session.userId),
      ),
      with: {
        folder: true,
      },
    });

    if (!bookmark) {
      return res.status(404).json({ message: "Bookmark not found" });
    }

    const exportedContent = await exportContent(bookmark, format);

    return res.status(200).json({
      content: exportedContent,
      format,
    });
  } catch (error) {
    console.error("Error exporting bookmark:", error);
    return res.status(500).json({ message: "Error exporting bookmark" });
  }
});

interface SmartNotes {
  summary: string;
  detailedNotes: string;
  keyTerms: string[];
  clinicalPearls: string[];
  mnemonics: string[];
  references: string[];
}

// Helper function to generate smart notes using AI
async function generateSmartNotes(content: string): Promise<SmartNotes> {
  // TODO: Implement AI integration
  return {
    summary: "AI-generated summary here",
    detailedNotes: content,
    keyTerms: ["term1", "term2"],
    clinicalPearls: ["pearl1", "pearl2"],
    mnemonics: ["mnemonic1"],
    references: ["reference1"],
  };
}

interface ExportContent {
  title: string;
  content: string;
  notes: SmartNotes;
  metadata: Record<string, unknown>;
}

// Helper function to export content in different formats
async function exportContent(bookmark: Bookmark, format: string): Promise<string> {
  const content: ExportContent = {
    title: bookmark.title,
    content: bookmark.content,
    notes: bookmark.aiGeneratedNotes as SmartNotes,
    metadata: {},
  };

  switch (format) {
    case "markdown":
      return convertToMarkdown(content);
    case "pdf":
      return convertToPDF(content);
    case "html":
      return convertToHTML(content);
    default:
      return JSON.stringify(content);
  }
}

// Format conversion helpers
function convertToMarkdown(content: ExportContent): string {
  return `# ${content.title}\n\n${content.content}\n\n## Smart Notes\n\n${content.notes.summary}`;
}

function convertToHTML(content: ExportContent): string {
  return `<h1>${content.title}</h1><div>${content.content}</div><h2>Smart Notes</h2><div>${content.notes.summary}</div>`;
}

function convertToPDF(content: ExportContent): string {
  // TODO: Implement PDF conversion
  return JSON.stringify(content);
}

export default router;