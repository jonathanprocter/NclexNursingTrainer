import dotenv from "dotenv";
import { z } from "zod";

dotenv.config();

const configSchema = z.object({
  NODE_ENV: z
    .enum(["development", "production", "test"])
    .default("development"),
  PORT: z.preprocess((val) => Number(val as string), z.number().default(3000)),
  HOST: z.string().default("0.0.0.0"),
  DATABASE_URL: z.string().nonempty("DATABASE_URL is required"),
  DATABASE_MAX_CONNECTIONS: z.preprocess(
    (val) => Number(val as string),
    z.number().default(10)
  ),
  DATABASE_IDLE_TIMEOUT: z.preprocess(
    (val) => Number(val as string),
    z.number().default(30000)
  ),
  SESSION_SECRET: z.string().nonempty("SESSION_SECRET is required"),
  CORS_ORIGIN: z.string().default("*"),
  RATE_LIMIT_WINDOW: z.preprocess(
    (val) => Number(val as string),
    z.number().default(900000)
  ),
  RATE_LIMIT_MAX: z.preprocess(
    (val) => Number(val as string),
    z.number().default(100)
  ),
  OPENAI_API_KEY: z.string().nonempty("OPENAI_API_KEY is required"),
  OPENAI_MODEL: z.string().default("gpt-4"),
  OPENAI_MAX_TOKENS: z.preprocess(
    (val) => Number(val as string),
    z.number().default(2000)
  ),
  OPENAI_TIMEOUT: z.preprocess(
    (val) => Number(val as string),
    z.number().default(30000)
  ),
  MAX_QUESTIONS_PER_SESSION: z.preprocess(
    (val) => Number(val as string),
    z.number().default(75)
  ),
});

function validateConfig() {
  const parsed = configSchema.safeParse(process.env);

  if (!parsed.success) {
    console.error("Configuration validation failed:", parsed.error);
    process.exit(1);
  }

  return parsed.data;
}

export const config = validateConfig();