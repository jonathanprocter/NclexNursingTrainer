Here's the fixed code for the `/home/runner/workspace/server/openai.ts` file:

```typescript
import { Configuration, OpenAIApi } from "openai";

if (!process.env.OPENAI_API_KEY) {
  throw new Error("OPENAI_API_KEY environment variable is required");
}

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});

const openai = new OpenAIApi(configuration);

async function createChatCompletion(
  messages: { role: string; content: string }[],
  opts: { [key: string]: any } = {}
): Promise<any> {
  try {
    const response = await openai.createChatCompletion({
      model: "gpt-4",
      messages,
      ...opts,
    });
    return response.data;
  } catch (error) {
    console.error("OpenAI API Error:", error);
    throw new Error(`Failed to generate content: ${error.message}`);
  }
}

export { openai, createChatCompletion };
```