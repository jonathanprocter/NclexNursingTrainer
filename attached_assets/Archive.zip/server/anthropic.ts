import { Request, Response } from "express";
import Anthropic from "@anthropic-ai/sdk";

if (!process.env.ANTHROPIC_API_KEY) {
  throw new Error("ANTHROPIC_API_KEY is not set");
}

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

export interface ConceptExplanation {
  topic: string;
  content: string;
  keyPoints: string[];
  examples: string[];
  relatedConcepts: string[];
  clinicalApplications?: string[];
  commonMisconceptions?: string[];
}

export async function getConceptExplanation(concept: string, domain: string): Promise<ConceptExplanation> {
  try {
    console.log("Generating explanation for concept:", concept);
    console.log("Using domain:", domain);

    const response = await anthropic.messages.create({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: 2000,
      temperature: 0.7,
      messages: [
        {
          role: "user",
          content: `You are an expert nursing educator. Explain the following nursing concept from ${domain}: ${concept}.

        Provide a structured response with EXACTLY these sections in order:

        Basic Explanation:
        [write a thorough explanation of the concept]

        Key Points:
        • [key point 1]
        • [key point 2]
        • [key point 3]
        • [key point 4]

        Clinical Examples:
        • [example 1]
        • [example 2]

        Common Misconceptions:
        • [misconception 1]
        • [misconception 2]

        Clinical Applications:
        • [application 1]
        • [application 2]

        Related Concepts:
        • [concept 1]
        • [concept 2]

        Use bullet points (•) exactly as shown above. Do not add any other sections or change the format.`,
        },
      ],
    });

    // Handle response content
    if (!response.content || typeof response.content !== "string") {
      throw new Error("Invalid response format from Anthropic");
    }

    const content = response.content;
    console.log("Raw content:", content);

    // Parse the response content into a structured format
    const parsedExplanation = parseExplanation(content);

    return parsedExplanation;
  } catch (error) {
    console.error("Error generating concept explanation:", error);
    console.error(
      "Error details:",
      error instanceof Error ? error.stack : "Unknown error",
    );
    throw error;
  }
}

function parseExplanation(content: string): ConceptExplanation {
  const lines = content.split("\n").map((line) => line.trim());

  const explanation: ConceptExplanation = {
    topic: "",
    content: "",
    keyPoints: [],
    examples: [],
    relatedConcepts: [],
    clinicalApplications: [],
    commonMisconceptions: [],
  };

  let currentSection = "";

  for (const line of lines) {
    if (line.startsWith("Basic Explanation:")) {
      currentSection = "content";
    } else if (line.startsWith("Key Points:")) {
      currentSection = "keyPoints";
    } else if (line.startsWith("Clinical Examples:")) {
      currentSection = "examples";
    } else if (line.startsWith("Common Misconceptions:")) {
      currentSection = "commonMisconceptions";
    } else if (line.startsWith("Clinical Applications:")) {
      currentSection = "clinicalApplications";
    } else if (line.startsWith("Related Concepts:")) {
      currentSection = "relatedConcepts";
    } else if (line.startsWith("•")) {
      const value = line.slice(2).trim();
      if (currentSection && Array.isArray(explanation[currentSection])) {
        explanation[currentSection].push(value);
      }
    } else if (currentSection === "content") {
      explanation.content += line + "\n";
    }
  }

  explanation.content = explanation.content.trim();

  return explanation;
}

export async function handleConceptExplanation(req: Request, res: Response): Promise<void> {
  try {
    const { topic } = req.body as { topic?: string };

    if (!topic) {
      res.status(400).json({
        success: false,
        error: "Topic is required",
      });
      return;
    }

    console.log("Requesting explanation for topic:", topic);
    const explanation = await getConceptExplanation(
      topic,
      "Pharmacology and Parenteral Therapies",
    );

    res.json({
      success: true,
      explanation,
    });
  } catch (error) {
    console.error("Error in explanation route:", error);
    res.status(500).json({
      success: false,
      error:
        error instanceof Error
          ? error.message
          : "Failed to process explanation request",
    });
  }
}