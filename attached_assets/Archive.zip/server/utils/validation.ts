interface NCLEXValidationResult {
  isValid: boolean;
  errors: string[];
  details: {
    validationErrors: string[];
  };
}

export function validateQuestion(question: any): NCLEXValidationResult {
  const errors: string[] = [];

  if (!question.question) errors.push("Question text is required");
  if (!question.correct_answer) errors.push("Correct answer is required");
  if (!question.options || !Array.isArray(question.options))
    errors.push("Options must be an array");

  return {
    isValid: errors.length === 0,
    errors,
    details: { validationErrors: errors },
  };
}
