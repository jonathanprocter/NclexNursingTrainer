/**
 * Enhanced initialization lock with timeouts and proper cleanup
 */
export class InitializationLock {
  private isLocked = false;
  private readonly TIMEOUT = 30000; // 30 seconds timeout
  private readonly POLL_INTERVAL = 100; // 100ms polling interval
  private lockOwner: string | null = null;

  async acquire(owner: string = 'default'): Promise<void> {
    const startTime = Date.now();

    while (this.isLocked) {
      if (Date.now() - startTime > this.TIMEOUT) {
        throw new Error(`Initialization lock acquisition timed out after ${this.TIMEOUT}ms (requested by ${owner})`);
      }
      await new Promise((resolve) => setTimeout(resolve, this.POLL_INTERVAL));
    }

    this.isLocked = true;
    this.lockOwner = owner;
  }

  release(owner: string = 'default'): void {
    if (!this.isLocked) {
      console.warn(`Attempting to release an already released lock (by ${owner})`);
      return;
    }

    if (this.lockOwner !== owner) {
      console.warn(`Lock release attempted by ${owner} but is owned by ${this.lockOwner}`);
      return;
    }

    this.isLocked = false;
    this.lockOwner = null;
  }

  isAcquired(): boolean {
    return this.isLocked;
  }

  getOwner(): string | null {
    return this.lockOwner;
  }
}