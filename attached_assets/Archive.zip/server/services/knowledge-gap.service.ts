import { db } from "@db";
import { eq, desc } from "drizzle-orm";
import { userProgress } from "@db/schema";

interface KnowledgeGap {
  domain: string;
  gapScore: number;
  recommendedTopics: string[];
  suggestions: string[];
}

class KnowledgeGapService {
  async analyzeGaps(userId: number): Promise<KnowledgeGap[]> {
    try {
      const progress = await db
        .select()
        .from(userProgress)
        .where(eq(userProgress.userId, userId))
        .orderBy(desc(userProgress.timestamp))
        .limit(100);

      if (progress.length === 0) {
        return [
          {
            domain: "General Nursing",
            gapScore: 0.5,
            recommendedTopics: [
              "Fundamentals",
              "Basic Assessment",
              "Patient Safety",
            ],
            suggestions: [
              "Start with core concepts",
              "Take practice quizzes",
              "Review study materials",
            ],
          },
        ];
      }

      const questionStats = progress.reduce(
        (acc, curr) => {
          const key = curr.questionId;
          acc[key] = acc[key] || { attempts: 0, correct: 0 };
          acc[key].attempts++;
          if (curr.correct) {
            acc[key].correct++;
          }
          return acc;
        },
        {} as Record<number, { attempts: number; correct: number }>,
      );

      const gaps = Object.entries(questionStats)
        .map(([questionId, stats]) => ({
          questionId: parseInt(questionId, 10),
          gapScore: 1 - stats.correct / stats.attempts,
        }))
        .filter((gap) => gap.gapScore > 0.3)
        .sort((a, b) => b.gapScore - a.gapScore)
        .slice(0, 5);

      return gaps.map((gap) => ({
        domain: this.mapQuestionToDomain(gap.questionId),
        gapScore: Math.round(gap.gapScore * 100) / 100,
        recommendedTopics: this.getRecommendedTopics(gap.gapScore),
        suggestions: this.generateSuggestions(gap.gapScore),
      }));
    } catch (error) {
      console.error("Error analyzing knowledge gaps:", error);
      throw new Error("Failed to analyze knowledge gaps");
    }
  }

  private mapQuestionToDomain(questionId: number): string {
    const domainMap: Record<number, string> = {
      1: "Medical-Surgical Nursing",
      2: "Pharmacology",
      3: "Pediatric Nursing",
      4: "Mental Health Nursing",
      5: "Maternal-Newborn Nursing",
    };

    return domainMap[questionId] || "Fundamentals";
  }

  private getRecommendedTopics(gapScore: number): string[] {
    if (gapScore > 0.7) {
      return ["Core Concepts", "Basic Principles", "Foundational Knowledge"];
    } else if (gapScore > 0.4) {
      return ["Practice Questions", "Case Studies", "Clinical Applications"];
    } else {
      return ["Advanced Concepts", "Complex Scenarios", "Integration Practice"];
    }
  }

  private generateSuggestions(gapScore: number): string[] {
    if (gapScore > 0.7) {
      return [
        "Review basic concepts",
        "Use flashcards for key terms",
        "Watch video tutorials",
      ];
    } else if (gapScore > 0.4) {
      return [
        "Practice with sample questions",
        "Join study groups",
        "Create concept maps",
      ];
    } else {
      return [
        "Take practice exams",
        "Work on case studies",
        "Teach concepts to others",
      ];
    }
  }
}

export const knowledgeGapService = new KnowledgeGapService();