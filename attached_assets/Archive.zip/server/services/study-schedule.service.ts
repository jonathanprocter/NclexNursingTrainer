import { db } from "@db";
import { nclexDomains, userProgress } from "@db/schema";
import { eq, and, desc, sql } from "drizzle-orm";
import { spacedRepetitionService } from "./spaced-repetition.service";
import { learningAnalyticsService } from "./learning-analytics.service";

interface StudyBlock {
  startTime: string;
  duration: number;
  topic: string;
  description: string;
  priority: number;
  type: "practice" | "review" | "new_concept";
  questionCount?: number;
  domainId?: number;
}

interface DailySchedule {
  date: string;
  totalDuration: number;
  blocks: StudyBlock[];
}

interface GenerateScheduleOptions {
  userId: number;
  startDate: Date;
  daysToSchedule: number;
  dailyTarget: number; // in minutes
  preferredTimes?: string[]; // Array of preferred study times
}

export class StudyScheduleService {
  async generateSchedule({
    userId,
    startDate,
    daysToSchedule = 7,
    dailyTarget = 120, // 2 hours default
    preferredTimes = ["09:00", "14:00", "19:00"],
  }: GenerateScheduleOptions): Promise<DailySchedule[]> {
    // Get user's performance metrics
    const analytics =
      await learningAnalyticsService.getPerformanceMetrics(userId);

    // Get due questions from spaced repetition
    const dueQuestions = await spacedRepetitionService.getDueQuestions(
      userId,
      daysToSchedule * 10,
    );

    // Get domain progress
    const domainProgress = await this.getDomainProgress(userId);

    const schedule: DailySchedule[] = [];
    const currentDate = new Date(startDate);

    for (let day = 0; day < daysToSchedule; day++) {
      const dailySchedule: DailySchedule = {
        date: currentDate.toISOString().split("T")[0],
        totalDuration: 0,
        blocks: [],
      };

      // Distribute study blocks across preferred times
      for (const time of preferredTimes) {
        const durationPerBlock = Math.floor(
          dailyTarget / preferredTimes.length,
        );
        const block = await this.createStudyBlock(
          userId,
          durationPerBlock,
          domainProgress,
          dueQuestions.slice(day * 3, (day + 1) * 3),
          analytics,
        );

        if (block) {
          dailySchedule.blocks.push({
            ...block,
            startTime: `${currentDate.toISOString().split("T")[0]}T${time}`,
          });
          dailySchedule.totalDuration += block.duration;
        }
      }

      schedule.push(dailySchedule);
      currentDate.setDate(currentDate.getDate() + 1);
    }

    return schedule;
  }

  private async getDomainProgress(userId: number) {
    const progress = await db
      .select({
        domainId: nclexDomains.id,
        name: nclexDomains.name,
        totalQuestions: sql<number>`count(${userProgress.id})`,
        correctAnswers: sql<number>`sum(case when ${userProgress.correct} then 1 else 0 end)`,
      })
      .from(nclexDomains)
      .leftJoin(
        userProgress,
        and(
          eq(userProgress.userId, userId),
          eq(userProgress.questionId, nclexDomains.id),
        ),
      )
      .groupBy(nclexDomains.id, nclexDomains.name);

    return progress.map((domain) => ({
      id: domain.domainId,
      name: domain.name!,
      performance:
        domain.totalQuestions > 0
          ? domain.correctAnswers! / domain.totalQuestions
          : 0,
    }));
  }

  private async createStudyBlock(
    userId: number,
    duration: number,
    domainProgress: Array<{ id: number; name: string; performance: number }>,
    dueQuestions: any[],
    analytics: any,
  ): Promise<StudyBlock> {
    // Find weakest domain
    const weakestDomain = domainProgress.sort(
      (a, b) => a.performance - b.performance,
    )[0];

    // Determine block type based on performance and due questions
    const hasDueQuestions = dueQuestions.length > 0;
    const lowPerformance = analytics.predictedPerformance
      ? analytics.predictedPerformance < 0.7
      : false;

    let blockType: "practice" | "review" | "new_concept";
    let topic: string;
    let description: string;

    if (hasDueQuestions) {
      blockType = "review";
      topic = "Review Due Questions";
      description = `Review ${dueQuestions.length} questions due for spaced repetition`;
    } else if (lowPerformance) {
      blockType = "practice";
      topic = `Practice ${weakestDomain.name}`;
      description = `Focus on improving your understanding of ${weakestDomain.name} concepts`;
    } else {
      blockType = "new_concept";
      topic = "New Concepts";
      description = "Learn and practice new NCLEX concepts";
    }

    return {
      duration,
      topic,
      description,
      type: blockType,
      priority: hasDueQuestions ? 3 : lowPerformance ? 2 : 1,
      questionCount: hasDueQuestions
        ? dueQuestions.length
        : Math.floor(duration / 5),
      domainId: weakestDomain.id,
    };
  }
}

export const studyScheduleService = new StudyScheduleService();
