import { drizzle } from "drizzle-orm/node-postgres";
import { dbManager } from "./database-manager";
import { log } from "../vite";
import { sql } from 'drizzle-orm';

export class DatabaseService {
  private db: ReturnType<typeof drizzle> | null = null;
  private initialized = false;
  private shutdownInProgress = false;

  async initialize(): Promise<boolean> {
    if (this.initialized) {
      log("[DatabaseService] Already initialized");
      return true;
    }

    if (this.shutdownInProgress) {
      throw new Error("Cannot initialize during shutdown");
    }

    log("[DatabaseService] Initializing database service...");
    try {
      // Initialize the database manager first
      const managerInitialized = await dbManager.initialize();

      if (!managerInitialized) {
        throw new Error("Database manager initialization failed");
      }

      // Get the Drizzle instance
      this.db = dbManager.getDrizzle();

      // Verify the connection
      await this.verifyConnection();

      this.initialized = true;
      log("[DatabaseService] Database service initialized successfully");
      return true;
    } catch (error) {
      log("[DatabaseService] Failed to initialize database service: " + error);
      await this.cleanup();
      return false;
    }
  }

  private async verifyConnection(): Promise<void> {
    if (!this.db) {
      throw new Error("Database client not initialized");
    }

    try {
      // Attempt a simple query to verify the connection
      await this.db.execute(sql`SELECT 1`);
      log("[DatabaseService] Database connection verified");
    } catch (error) {
      log("[DatabaseService] Database connection verification failed: " + error);
      throw error;
    }
  }

  async cleanup(): Promise<void> {
    if (this.shutdownInProgress) {
      return;
    }

    this.shutdownInProgress = true;
    log("[DatabaseService] Starting database service cleanup...");

    try {
      await dbManager.cleanup();
      log("[DatabaseService] Database service cleanup completed");
    } catch (error) {
      log("[DatabaseService] Error during database service cleanup: " + error);
      throw error;
    } finally {
      this.db = null;
      this.initialized = false;
      this.shutdownInProgress = false;
    }
  }

  getClient(): ReturnType<typeof drizzle> {
    if (!this.db || !this.initialized) {
      throw new Error("[DatabaseService] Database client not initialized");
    }
    return this.db;
  }

  isInitialized(): boolean {
    return this.initialized;
  }
}

export const databaseService = new DatabaseService();