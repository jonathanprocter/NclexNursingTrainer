import { db } from "@db";
import { questions, userProgress } from "@db/schema";
import { eq, and, sql } from "drizzle-orm";
import { addDays } from "date-fns";

const DEFAULT_EASE = 2.5;
const MIN_EASE = 1.3;
const MAX_INTERVAL = 365; // Maximum interval of 1 year
const IDEAL_SUCCESS_RATE = 0.85;

interface ReviewSchedule {
  interval: number;
  ease: number;
  nextReviewDate: Date;
  retentionScore?: number;
}

export class SpacedRepetitionService {
  private calculateNextReview(
    quality: number,
    previousInterval: number,
    previousEase: number,
    responseTime: number,
  ): ReviewSchedule {
    // Adjust quality based on response time
    const normalizedResponseTime = Math.min(responseTime / 60000, 5); // Cap at 5 minutes
    const timeBasedQualityAdjustment = Math.max(
      -1,
      (3 - normalizedResponseTime) / 3,
    );
    const adjustedQuality = Math.max(
      0,
      Math.min(5, quality + timeBasedQualityAdjustment),
    );

    // Calculate new ease factor
    const easeChange =
      0.1 - (5 - adjustedQuality) * (0.08 + (5 - adjustedQuality) * 0.02);
    const nextEase = Math.max(MIN_EASE, previousEase + easeChange);

    // Calculate interval with progressive scheduling
    let nextInterval;
    if (adjustedQuality < 3) {
      nextInterval = 1; // Review tomorrow if quality was poor
    } else if (previousInterval === 0) {
      nextInterval = 1;
    } else if (previousInterval === 1) {
      nextInterval = 6;
    } else {
      // Apply exponential spacing with stability controls
      const optimalFactor = Math.min(2.5, nextEase);
      const rawInterval = Math.round(previousInterval * optimalFactor);

      // Apply maximum interval constraint
      nextInterval = Math.min(rawInterval, MAX_INTERVAL);

      // Add small random variation to prevent clustering
      const variation = Math.random() * 0.15 + 0.95; // 0.95-1.10
      nextInterval = Math.round(nextInterval * variation);
    }

    // Calculate retention score based on performance
    const retentionScore = (adjustedQuality / 5) * 100;

    return {
      interval: nextInterval,
      ease: nextEase,
      nextReviewDate: addDays(new Date(), nextInterval),
      retentionScore,
    };
  }

  async getDueQuestions(userId: number, limit: number = 10) {
    try {
      const now = new Date();

      // Get questions that are due for review with adaptive scheduling
      const dueQuestions = await db
        .select({
          question: {
            id: questions.id,
            domainId: questions.domainId,
            scenario: questions.scenario,
            options: questions.options,
            correctAnswer: questions.correctAnswer,
            explanation: questions.explanation,
            difficulty: questions.difficulty,
            conceptualLevel: questions.conceptualLevel,
            clinicalJudgmentLevel: questions.clinicalJudgmentLevel,
            conceptualBreakdown: questions.conceptualBreakdown,
            contentData: questions.contentData,
          },
          progress: {
            id: userProgress.id,
            correct: userProgress.correct,
            responseTime: userProgress.responseTime,
            nextReviewDate: userProgress.nextReviewDate,
            repetitionNumber: userProgress.repetitionNumber,
            easeFactor: userProgress.easeFactor,
            interval: userProgress.interval,
            learningMetrics: userProgress.learningMetrics,
          },
        })
        .from(questions)
        .leftJoin(
          userProgress,
          and(
            eq(userProgress.questionId, questions.id),
            eq(userProgress.userId, userId),
          ),
        )
        .where(
          sql`${userProgress.nextReviewDate} IS NULL OR ${userProgress.nextReviewDate} <= ${now.toISOString()}::timestamptz`,
        )
        .limit(limit);

      // Sort questions by priority score
      return dueQuestions.sort((a, b) => {
        const getReviewPriority = (question: (typeof dueQuestions)[0]) => {
          const progress = question.progress;
          if (!progress) return 1; // New questions get high priority

          // Calculate priority based on multiple factors
          const daysOverdue = progress.nextReviewDate
            ? Math.max(
                0,
                (now.getTime() - new Date(progress.nextReviewDate).getTime()) /
                  (1000 * 60 * 60 * 24),
              )
            : 0;
          const performanceScore =
            progress.learningMetrics?.confidenceLevel || 0;
          const repetitionBonus =
            Math.max(0, 3 - (progress.repetitionNumber || 0)) / 3;

          return (
            daysOverdue * 0.4 +
            (1 - performanceScore) * 0.4 +
            repetitionBonus * 0.2
          );
        };

        return getReviewPriority(b) - getReviewPriority(a);
      });
    } catch (error) {
      console.error("Error fetching due questions:", error);
      throw new Error("Failed to fetch due questions");
    }
  }

  async recordAttempt(
    userId: number,
    questionId: number,
    isCorrect: boolean,
    responseTime: number,
  ) {
    try {
      // Get previous review data
      const lastReview = await db
        .select()
        .from(userProgress)
        .where(
          and(
            eq(userProgress.userId, userId),
            eq(userProgress.questionId, questionId),
          ),
        )
        .orderBy(sql`${userProgress.timestamp} DESC`)
        .limit(1)
        .then((results) => results[0]);

      // Calculate quality score (0-5) based on correctness and response time
      const baseQuality = isCorrect
        ? 5
        : Math.min(2, Math.max(0, 3 * (45000 / responseTime)));

      const currentDate = new Date();
      const schedule = this.calculateNextReview(
        baseQuality,
        lastReview?.interval || 0,
        lastReview?.easeFactor ? lastReview.easeFactor / 100 : DEFAULT_EASE,
        responseTime,
      );

      // Record the attempt with enhanced learning metrics
      await db.insert(userProgress).values({
        userId,
        questionId,
        correct: isCorrect,
        responseTime,
        nextReviewDate: schedule.nextReviewDate,
        repetitionNumber: (lastReview?.repetitionNumber || 0) + 1,
        easeFactor: Math.round(schedule.ease * 100),
        interval: schedule.interval,
        timestamp: currentDate,
        learningMetrics: {
          confidenceLevel: isCorrect ? 1 : 0,
          difficultyRating: 5 - baseQuality,
          clinicalJudgmentScore: baseQuality,
          conceptualUnderstanding: baseQuality / 5,
          cognitiveLoadIndex: responseTime / 60000, // Convert to minutes
          reviewHistory: [
            {
              date: currentDate.toISOString(),
              performance: baseQuality,
              timeToAnswer: responseTime,
            },
          ],
        },
      });

      return {
        ...schedule,
        retentionScore: schedule.retentionScore,
      };
    } catch (error) {
      console.error("Error recording attempt:", error);
      throw error;
    }
  }
  async getReviewStats(userId: number) {
    try {
      const stats = await db
        .select({
          totalReviews: sql<number>`COUNT(*)`,
          correctReviews: sql<number>`SUM(CASE WHEN ${userProgress.correct} THEN 1 ELSE 0 END)`,
          averageResponseTime: sql<number>`AVG(${userProgress.responseTime})`,
          retentionRate: sql<number>`
            AVG(CASE 
              WHEN ${userProgress.repetitionNumber} > 1 
              AND ${userProgress.correct} = true 
              THEN 1 
              ELSE 0 
            END)
          `,
        })
        .from(userProgress)
        .where(eq(userProgress.userId, userId))
        .then((results) => results[0]);

      if (!stats) {
        return {
          totalReviews: 0,
          correctReviews: 0,
          averageResponseTime: 0,
          accuracy: 0,
          retentionRate: 0,
        };
      }

      const {
        totalReviews,
        correctReviews,
        averageResponseTime,
        retentionRate,
      } = stats;
      return {
        totalReviews,
        correctReviews,
        averageResponseTime,
        accuracy: totalReviews > 0 ? (correctReviews! / totalReviews) * 100 : 0,
        retentionRate: retentionRate ? retentionRate * 100 : 0,
      };
    } catch (error) {
      console.error("Error fetching review stats:", error);
      throw new Error("Failed to fetch review statistics");
    }
  }
}

export const spacedRepetitionService = new SpacedRepetitionService();
