import { EventEmitter } from "events";
import { databaseService } from "./database-service";
import { analyticsService } from "./analytics.service";
import { aiLearningService } from "./ai-learning.service";
import { log } from "../vite";

interface ServiceState {
  name: string;
  initialized: boolean;
  lastError?: Error;
  retryCount: number;
  dependencies?: string[];
}

export class ServiceIntegrator extends EventEmitter {
  private services: Map<string, ServiceState> = new Map();
  private readonly MAX_RETRIES = 3;
  private readonly RETRY_DELAY = 1000;
  private isInitializing = false;
  private initializationTimeout: NodeJS.Timeout | null = null;
  private readonly TIMEOUT_MS = 30000;
  private static instance: ServiceIntegrator;

  // Make constructor private to enforce singleton
  private constructor() {
    super();
    this.setupServices();
    this.setupErrorHandlers();
  }

  public static getInstance(): ServiceIntegrator {
    if (!ServiceIntegrator.instance) {
      ServiceIntegrator.instance = new ServiceIntegrator();
    }
    return ServiceIntegrator.instance;
  }

  private setupServices() {
    // Define services with their dependencies
    this.services.set("database", {
      name: "Database",
      initialized: false,
      retryCount: 0,
      dependencies: [],
    });

    this.services.set("analytics", {
      name: "Analytics",
      initialized: false,
      retryCount: 0,
      dependencies: ["database"],
    });

    this.services.set("aiLearning", {
      name: "AI Learning",
      initialized: false,
      retryCount: 0,
      dependencies: ["database", "analytics"],
    });
  }

  private setupErrorHandlers() {
    process.on("unhandledRejection", (error) => {
      log("[ServiceIntegrator] Unhandled rejection: " + error);
      if (this.isInitializing) {
        this.handleInitializationFailure(error);
      }
    });
  }

  private async checkDependencies(serviceName: string): Promise<boolean> {
    const service = this.services.get(serviceName);
    if (!service?.dependencies) return true;

    for (const dep of service.dependencies) {
      if (!this.services.get(dep)?.initialized) {
        log(`[ServiceIntegrator] Service ${serviceName} is waiting for dependency: ${dep}`);
        return false;
      }
    }
    return true;
  }

  async initialize(): Promise<boolean> {
    if (this.isInitializing) {
      log("[ServiceIntegrator] Service initialization already in progress...");
      return false;
    }

    this.isInitializing = true;
    log("[ServiceIntegrator] Starting service integration...");

    try {
      this.initializationTimeout = setTimeout(() => {
        this.handleInitializationTimeout();
      }, this.TIMEOUT_MS);

      // Initialize services in dependency order
      const serviceOrder = this.getInitializationOrder();
      for (const serviceName of serviceOrder) {
        log(`[ServiceIntegrator] Initializing ${serviceName} service...`);

        // Check dependencies before initializing
        if (!await this.checkDependencies(serviceName)) {
          throw new Error(`Dependencies not met for service: ${serviceName}`);
        }

        const initialized = await this.initializeService(serviceName);
        if (!initialized) {
          throw new Error(`Failed to initialize service: ${serviceName}`);
        }
      }

      if (this.initializationTimeout) {
        clearTimeout(this.initializationTimeout);
        this.initializationTimeout = null;
      }

      log("[ServiceIntegrator] Services integrated successfully");
      return true;
    } catch (error) {
      log("[ServiceIntegrator] Service integration failed: " + error);
      await this.handleInitializationFailure(error);
      return false;
    } finally {
      this.isInitializing = false;
    }
  }

  private async initializeService(serviceName: string): Promise<boolean> {
    const service = this.services.get(serviceName);
    if (!service) return false;

    // If service is already initialized, return early
    if (service.initialized) {
      log(`[ServiceIntegrator] ${service.name} already initialized`);
      return true;
    }

    for (let attempt = 1; attempt <= this.MAX_RETRIES; attempt++) {
      try {
        let success = false;
        switch (serviceName) {
          case "database":
            success = await databaseService.initialize();
            break;
          case "analytics":
            success = await analyticsService.initialize();
            break;
          case "aiLearning":
            success = await aiLearningService.initialize();
            break;
        }

        if (success) {
          this.updateServiceState(serviceName, true);
          log(`[ServiceIntegrator] ${service.name} service initialized successfully`);
          return true;
        }
      } catch (error) {
        log(`[ServiceIntegrator] ${service.name} initialization attempt ${attempt} failed: ${error}`);
        if (attempt === this.MAX_RETRIES) {
          this.updateServiceState(serviceName, false, error as Error);
          break;
        }
        await new Promise(resolve => setTimeout(resolve, this.RETRY_DELAY * attempt));
      }
    }
    return false;
  }

  private async handleInitializationTimeout() {
    log("[ServiceIntegrator] Service initialization timed out");
    await this.cleanup();
    this.emit("initializationTimeout");
  }

  private async handleInitializationFailure(error: unknown) {
    log("[ServiceIntegrator] Handling initialization failure: " + error);
    await this.cleanup();
    this.emit("initializationFailed", error);
  }

  async cleanup(): Promise<void> {
    log("[ServiceIntegrator] Starting service cleanup...");

    if (this.initializationTimeout) {
      clearTimeout(this.initializationTimeout);
      this.initializationTimeout = null;
    }

    try {
      // Get services in reverse initialization order
      const cleanupOrder = this.getInitializationOrder().reverse();

      // Cleanup each service that was initialized
      for (const serviceName of cleanupOrder) {
        if (this.services.get(serviceName)?.initialized) {
          log(`[ServiceIntegrator] Cleaning up ${serviceName} service...`);
          try {
            switch (serviceName) {
              case "aiLearning":
                await aiLearningService.cleanup();
                break;
              case "analytics":
                await analyticsService.cleanup();
                break;
              case "database":
                await databaseService.cleanup();
                break;
            }
          } catch (error) {
            log(`[ServiceIntegrator] Error cleaning up ${serviceName}: ${error}`);
          }
        }
      }
    } catch (error) {
      log("[ServiceIntegrator] Error during cleanup: " + error);
      throw error;
    } finally {
      // Reset service states
      this.services.forEach((service) => {
        service.initialized = false;
        service.retryCount = 0;
        service.lastError = undefined;
      });
    }

    log("[ServiceIntegrator] Service cleanup completed");
  }

  private updateServiceState(serviceName: string, initialized: boolean, error?: Error) {
    const service = this.services.get(serviceName);
    if (service) {
      service.initialized = initialized;
      service.lastError = error;
      if (!initialized) {
        service.retryCount++;
      }
      this.emit("serviceStateChanged", { serviceName, state: service });
    }
  }

  getServiceStates(): Record<string, any> {
    return Array.from(this.services.entries()).reduce((acc, [name, state]) => {
      acc[name] = {
        initialized: state.initialized,
        retryCount: state.retryCount,
        hasError: !!state.lastError,
        error: state.lastError?.message,
        dependencies: state.dependencies,
      };
      return acc;
    }, {} as Record<string, any>);
  }

  isServiceInitialized(serviceName: string): boolean {
    return this.services.get(serviceName)?.initialized || false;
  }

  private getInitializationOrder(): string[] {
    const visited = new Set<string>();
    const visiting = new Set<string>();
    const order: string[] = [];

    const visit = (serviceName: string) => {
      if (visiting.has(serviceName)) {
        throw new Error(`Circular dependency detected for service: ${serviceName}`);
      }
      if (visited.has(serviceName)) return;

      const service = this.services.get(serviceName);
      if (!service) return;

      visiting.add(serviceName);

      // Process dependencies first
      if (service.dependencies) {
        for (const dep of service.dependencies) {
          visit(dep);
        }
      }

      visiting.delete(serviceName);
      visited.add(serviceName);
      order.push(serviceName);
    };

    // Convert Map to array before iteration to fix TypeScript compatibility
    Array.from(this.services.keys()).forEach(serviceName => {
      if (!visited.has(serviceName)) {
        visit(serviceName);
      }
    });

    return order;
  }
}

// Export singleton instance
export const serviceIntegrator = ServiceIntegrator.getInstance();