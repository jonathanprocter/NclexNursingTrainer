Here's the fixed code:

```typescript
import { EventEmitter } from "events";

interface TimerState {
  totalTime: number;
  remainingTime: number;
  questionStartTime: number;
  isRunning: boolean;
  questionTimes: Map<number, number>;
}

interface TimerUpdateEvent {
  remainingTime: number;
  formattedTime: string;
}

interface QuestionTimeRecordedEvent {
  questionId: number;
  timeSpent: number;
  formattedTime: string;
}

export class ExamTimerService extends EventEmitter {
  private state: TimerState;
  private timer: NodeJS.Timeout | null = null;
  private readonly updateInterval = 1000; // 1 second

  constructor(totalTimeInMinutes = 300) {
    // Default 5 hours for NCLEX
    super();
    this.state = {
      totalTime: totalTimeInMinutes * 60, // Convert to seconds
      remainingTime: totalTimeInMinutes * 60,
      questionStartTime: Date.now(),
      isRunning: false,
      questionTimes: new Map(),
    };
  }

  start(): void {
    if (this.state.isRunning) return;

    this.state.isRunning = true;
    this.state.questionStartTime = Date.now();

    this.timer = setInterval(() => {
      this.state.remainingTime--;

      this.emit("timerUpdate", {
        remainingTime: this.state.remainingTime,
        formattedTime: this.formatTime(this.state.remainingTime),
      } as TimerUpdateEvent);

      if (this.state.remainingTime <= 0) {
        this.stop();
        this.emit("timeUp");
      }
    }, this.updateInterval);
  }

  stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    this.state.isRunning = false;
  }

  pause(): void {
    this.stop();
    this.emit("timerPaused", {
      remainingTime: this.state.remainingTime,
      formattedTime: this.formatTime(this.state.remainingTime),
    } as TimerUpdateEvent);
  }

  resume(): void {
    this.start();
    this.emit("timerResumed", {
      remainingTime: this.state.remainingTime,
      formattedTime: this.formatTime(this.state.remainingTime),
    } as TimerUpdateEvent);
  }

  recordQuestionTime(questionId: number): void {
    const timeSpent = Math.floor(
      (Date.now() - this.state.questionStartTime) / 1000
    );
    this.state.questionTimes.set(questionId, timeSpent);
    this.state.questionStartTime = Date.now();

    this.emit("questionTimeRecorded", {
      questionId,
      timeSpent,
      formattedTime: this.formatTime(timeSpent),
    } as QuestionTimeRecordedEvent);
  }

  getQuestionAnalytics(): {
    averageTime: number;
    fastestTime: number;
    slowestTime: number;
    timesByQuestion: Map<number, number>;
  } {
    const times = Array.from(this.state.questionTimes.values());

    if (times.length === 0) {
      return {
        averageTime: 0,
        fastestTime: 0,
        slowestTime: 0,
        timesByQuestion: new Map(),
      };
    }

    return {
      averageTime: Math.floor(times.reduce((a, b) => a + b, 0) / times.length),
      fastestTime: Math.min(...times),
      slowestTime: Math.max(...times),
      timesByQuestion: new Map(this.state.questionTimes),
    };
  }

  getRemainingTime(): { seconds: number; formatted: string } {
    return {
      seconds: this.state.remainingTime,
      formatted: this.formatTime(this.state.remainingTime),
    };
  }

  private formatTime(seconds: number): string {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;

    return `${hours.toString().padStart(2, "0")}:${minutes
      .toString()
      .padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`;
  }
}
```