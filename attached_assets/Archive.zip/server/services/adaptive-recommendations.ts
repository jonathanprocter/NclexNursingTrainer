import { db } from "@db";
import { userProgress, questions, nclexDomains, users, userModuleProgress } from "@db/schema";
import { eq, desc, sql } from "drizzle-orm";

interface PerformanceMetrics {
  domainPerformance: Record<string, number>;
  conceptualUnderstanding: Record<string, number>;
  responseTimeAverage: number;
  confidenceScores: Record<string, number>;
  strugglingConcepts: string[];
  learningStyleEffectiveness: {
    [key: string]: number;
  };
}

interface RecommendationCriteria {
  priorityLevel: number;
  domainId: number;
  conceptLevel: string;
  reason: string;
  learningStyleMatch: number;
  recommendedFormat: "text" | "video" | "interactive" | "simulation";
}

export async function generateAdaptiveRecommendations(
  userId: number,
): Promise<RecommendationCriteria[]> {
  try {
    // Get user profile for learning style preferences
    const [user] = await db
      .select({
        learningStyle: users.learningStyle,
        currentLevel: users.currentLevel,
      })
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);

    if (!user) throw new Error("User not found");

    // Get user's module progress
    const moduleProgress = await db.query.userModuleProgress.findMany({
      where: eq(userModuleProgress.userId, userId),
      with: {
        module: {
          with: {
            domain: true,
          },
        },
      },
    });

    // Analyze recent performance
    const recentProgress = await db.query.userProgress.findMany({
      limit: 100,
      where: eq(userProgress.userId, userId),
      orderBy: [desc(userProgress.timestamp)],
      with: {
        question: {
          with: {
            domain: true,
          },
        },
      },
    });

    // Calculate comprehensive performance metrics
    const metrics = calculatePerformanceMetrics(
      recentProgress,
      user.learningStyle,
    );

    // Generate recommendations based on performance and learning style
    const recommendations: RecommendationCriteria[] = [];

    // Identify struggling domains (below 70% success rate)
    for (const [domainId, performance] of Object.entries(
      metrics.domainPerformance,
    )) {
      if (performance < 0.7) {
        const learningStyleMatch = calculateLearningStyleMatch(
          user.learningStyle,
          metrics.learningStyleEffectiveness,
        );

        recommendations.push({
          priorityLevel: calculatePriorityLevel(
            performance,
            metrics.confidenceScores[domainId] || 0,
          ),
          domainId: parseInt(domainId),
          conceptLevel: determineAppropriateConceptLevel(
            metrics,
            parseInt(domainId),
          ),
          reason: generateDetailedReason(
            performance,
            metrics,
            domainId,
            user.learningStyle,
          ),
          learningStyleMatch,
          recommendedFormat: determineOptimalFormat(user.learningStyle),
        });
      }
    }

    // Address conceptual gaps with targeted recommendations
    for (const concept of metrics.strugglingConcepts) {
      const relatedDomain = await findDomainForConcept(concept);
      if (relatedDomain) {
        recommendations.push({
          priorityLevel: 2,
          domainId: relatedDomain,
          conceptLevel: "application",
          reason: `Additional practice needed for concept: ${concept}`,
          learningStyleMatch: 0.8,
          recommendedFormat: determineOptimalFormat(user.learningStyle),
        });
      }
    }

    // Sort recommendations by priority and learning style match
    return recommendations.sort(
      (a, b) =>
        b.priorityLevel * b.learningStyleMatch -
        a.priorityLevel * a.learningStyleMatch,
    );
  } catch (error) {
    console.error("Error generating adaptive recommendations:", error);
    throw error;
  }
}

function calculatePerformanceMetrics(
  progress: (typeof userProgress & { question?: { domain?: { id: number } } })[],
  learningStyle: Record<string, number> | null,
): PerformanceMetrics {
  const metrics: PerformanceMetrics = {
    domainPerformance: {},
    conceptualUnderstanding: {},
    responseTimeAverage: 0,
    confidenceScores: {},
    strugglingConcepts: [],
    learningStyleEffectiveness: {
      visual: 0,
      auditory: 0,
      kinesthetic: 0,
      reading: 0,
    },
  };

  // Calculate domain performance
  progress.forEach((entry) => {
    if (!entry.question?.domain?.id) return;

    const domainId = entry.question.domain.id.toString();
    if (!metrics.domainPerformance[domainId]) {
      metrics.domainPerformance[domainId] = 0;
      metrics.confidenceScores[domainId] = 0;
    }

    metrics.domainPerformance[domainId] += entry.correct ? 1 : 0;

    // Track learning style effectiveness
    if (entry.learningMetrics?.confidenceLevel) {
      const format = entry.question.content?.format || "reading";
      metrics.learningStyleEffectiveness[format as keyof typeof metrics.learningStyleEffectiveness] += entry.correct ? 1 : 0;
    }
  });

  // Normalize domain performance and learning style effectiveness
  Object.keys(metrics.domainPerformance).forEach((domainId) => {
    const total = progress.filter(
      (p) => p.question?.domain?.id?.toString() === domainId,
    ).length;
    metrics.domainPerformance[domainId] /= total || 1;
  });

  Object.keys(metrics.learningStyleEffectiveness).forEach((style) => {
    const totalForStyle = progress.filter(
      (p) => p.question?.content?.format === style,
    ).length;
    metrics.learningStyleEffectiveness[style as keyof typeof metrics.learningStyleEffectiveness] /= totalForStyle || 1;
  });

  // Calculate average response time
  metrics.responseTimeAverage =
    progress.reduce((acc, curr) => acc + (curr.responseTime || 0), 0) /
    progress.length;

  // Identify struggling concepts
  metrics.strugglingConcepts = progress
    .filter((entry) => !entry.correct && entry.learningMetrics?.struggleAreas)
    .flatMap((entry) => entry.learningMetrics!.struggleAreas)
    .filter((concept, index, self) => self.indexOf(concept) === index);

  return metrics;
}

function calculatePriorityLevel(
  performance: number,
  confidence: number,
): number {
  // Lower performance and lower confidence = higher priority
  return Math.round((1 - performance) * 5 + (1 - confidence) * 3);
}

function calculateLearningStyleMatch(
  userStyle: Record<string, number> | null,
  effectiveness: Record<string, number>,
): number {
  if (!userStyle) {
    return 0.5; // Default match score if no learning style is set
  }

  let match = 0;
  let totalWeight = 0;

  Object.entries(userStyle).forEach(([style, preference]) => {
    match += preference * (effectiveness[style] || 0);
    totalWeight += preference;
  });

  return totalWeight > 0 ? match / totalWeight : 0.5;
}

function determineOptimalFormat(
  learningStyle: Record<string, number> | null,
): "text" | "video" | "interactive" | "simulation" {
  if (!learningStyle) {
    return "text";
  }

  const stylePreferences = Object.entries(learningStyle).sort(
    ([, a], [, b]) => b - a,
  );

  // Map learning styles to content formats
  const primaryStyle = stylePreferences[0][0];
  const primaryScore = stylePreferences[0][1];

  // Strongly prefer formats that match the user's dominant learning style
  if (primaryScore >= 0.7) {
    switch (primaryStyle) {
      case "visual":
        return "video";
      case "kinesthetic":
        return "simulation";
      case "auditory":
        return "interactive";
      default:
        return "text";
    }
  }

  // For mixed learning styles, use a weighted approach
  const scores = {
    video: learningStyle.visual || 0,
    simulation: learningStyle.kinesthetic || 0,
    interactive: learningStyle.auditory || 0,
    text: learningStyle.reading || 0,
  };

  return Object.entries(scores).sort(([, a], [, b]) => b - a)[0][0] as
    | "text"
    | "video"
    | "interactive"
    | "simulation";
}

function generateDetailedReason(
  performance: number,
  metrics: PerformanceMetrics,
  domainId: string,
  learningStyle: Record<string, number> | null,
): string {
  const performancePercent = Math.round(performance * 100);
  const avgResponseTime = Math.round(metrics.responseTimeAverage / 1000);

  let reason = `Performance below target in this domain (${performancePercent}%).`;

  if (metrics.confidenceScores[domainId] < 0.6) {
    reason += ` Low confidence level detected.`;
  }

  if (avgResponseTime > 60) {
    reason += ` Response time indicates need for concept reinforcement.`;
  }

  // Add learning style-based recommendation
  if (learningStyle) {
    const optimalFormat = determineOptimalFormat(learningStyle);
    const formatMap = {
      video: "visual content",
      simulation: "hands-on practice",
      interactive: "interactive exercises",
      text: "comprehensive reading materials",
    };
    reason += ` Recommended format: ${formatMap[optimalFormat]} based on your learning style preferences.`;
  }

  return reason;
}

function determineAppropriateConceptLevel(
  metrics: PerformanceMetrics,
  domainId: number,
): string {
  const performance = metrics.domainPerformance[domainId.toString()] || 0;

  if (performance < 0.4) return "recall";
  if (performance < 0.6) return "application";
  if (performance < 0.8) return "analysis";
  return "synthesis";
}

async function findDomainForConcept(concept: string): Promise<number | null> {
  const domain = await db.query.nclexDomains.findFirst({
    where: sql`${nclexDomains.subTopics} @> ARRAY[${concept}]`,
  });

  return domain?.id || null;
}

export async function generateLearningPath(userId: number): Promise<Array<{ recommendation: RecommendationCriteria; suggestedModules: any[] }>> {
  try {
    const recommendations = await generateAdaptiveRecommendations(userId);
    return recommendations.map((rec) => ({
      recommendation: rec,
      suggestedModules: [],
    }));
  } catch (error) {
    console.error("Error generating learning path:", error);
    throw error;
  }
}