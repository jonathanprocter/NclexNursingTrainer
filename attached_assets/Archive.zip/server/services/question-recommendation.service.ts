import { db } from "@db";
import {
  questions,
  userProgress,
  nclexDomains,
  questionRecommendations,
} from "@db/schema";
import { eq, and, desc, sql, not, asc } from "drizzle-orm";
import { learningAnalyticsService } from "./learning-analytics.service";
import type { Question } from "@db/schema";

interface RecommendationMetadata {
  domainName: string;
  confidenceScore: number;
  recommendationScore: number;
  difficultyLevel: string;
  estimatedTime: number;
  adaptiveFactors: {
    domainStrength: number;
    conceptComplexity: number;
    difficultyWeight: number;
  };
}

interface QuestionRecommendation {
  questionId: number;
  domainId: number | null;
  difficulty: string;
  priority: number;
  reason: string;
  conceptualLevel: string;
  scheduledFor: string;
  metadata: RecommendationMetadata;
}

export class QuestionRecommendationService {
  async getRecommendedQuestions(
    userId: number,
    count: number = 10,
  ): Promise<QuestionRecommendation[]> {
    // Get user's performance data
    const recentProgress = await db
      .select({
        correct: userProgress.correct,
        timestamp: userProgress.timestamp,
        responseTime: userProgress.responseTime,
        learningMetrics: userProgress.learningMetrics,
        questionId: userProgress.questionId,
      })
      .from(userProgress)
      .where(eq(userProgress.userId, userId))
      .orderBy(desc(userProgress.timestamp))
      .limit(20);

    // Get available questions excluding recently attempted ones
    const answeredQuestionIds = recentProgress.map((p) => p.questionId);
    const availableQuestions = await db
      .select({
        question: questions,
        domain: nclexDomains,
      })
      .from(questions)
      .leftJoin(nclexDomains, eq(questions.domainId, nclexDomains.id))
      .where(
        answeredQuestionIds.length > 0
          ? not(sql`${questions.id} IN ${answeredQuestionIds}`)
          : undefined,
      );

    // Calculate domain performance
    const domainPerformance = this.calculateDomainPerformance(
      recentProgress,
      availableQuestions,
    );

    // Get user's learning patterns
    const learningPatterns =
      await learningAnalyticsService.analyzeLearningPatterns(userId);

    // Score and prioritize questions
    const scoredQuestions = this.scoreQuestions(
      availableQuestions,
      domainPerformance,
      learningPatterns,
    );

    // Sort by score and return top N recommendations
    return scoredQuestions
      .sort((a, b) => b.priority - a.priority)
      .slice(0, count);
  }

  private calculateDomainPerformance(
    progress: any[],
    questions: any[],
  ): Record<number, { correct: number; total: number }> {
    return progress.reduce(
      (acc: Record<number, { correct: number; total: number }>, curr) => {
        const question = questions.find(
          (q) => q.question.id === curr.questionId,
        );
        if (question?.question.domainId) {
          if (!acc[question.question.domainId]) {
            acc[question.question.domainId] = { correct: 0, total: 0 };
          }
          acc[question.question.domainId].total++;
          if (curr.correct) {
            acc[question.question.domainId].correct++;
          }
        }
        return acc;
      },
      {},
    );
  }

  private scoreQuestions(
    questions: any[],
    domainPerformance: Record<number, { correct: number; total: number }>,
    learningPatterns: any,
  ): QuestionRecommendation[] {
    return questions.map((question) => {
      const domainId = question.question.domainId;
      const domainPerf = domainPerformance[domainId || 0] || {
        correct: 0,
        total: 0,
      };
      const domainScore =
        domainPerf.total > 0 ? domainPerf.correct / domainPerf.total : 0.5;

      // Calculate difficulty score
      const difficultyScore =
        question.question.difficulty === "hard"
          ? 3
          : question.question.difficulty === "medium"
            ? 2
            : 1;

      // Calculate conceptual level score
      const conceptualScore =
        question.question.conceptualLevel === "analysis"
          ? 3
          : question.question.conceptualLevel === "application"
            ? 2
            : 1;

      // Adjust based on learning style
      const styleMatch = this.calculateStyleMatch(
        question.question.conceptualLevel,
        learningPatterns.learningStyle,
      );

      // Calculate cognitive load appropriateness
      const cognitiveLoadMatch = Math.abs(
        learningPatterns.cognitiveLoadIndex - difficultyScore / 3,
      );

      // Calculate final priority score (0-10 scale)
      const priorityScore = this.calculatePriorityScore(
        domainScore,
        difficultyScore,
        conceptualScore,
        styleMatch,
        cognitiveLoadMatch,
      );

      // Determine recommendation reason
      const reason = this.determineRecommendationReason(
        domainScore,
        learningPatterns.retentionMetrics.applicationRate,
      );

      // Calculate review date based on spaced repetition
      const reviewDate = new Date();
      reviewDate.setDate(
        reviewDate.getDate() + Math.ceil(domainScore * 7 + difficultyScore),
      );

      return {
        questionId: question.question.id,
        domainId: question.question.domainId,
        difficulty: question.question.difficulty,
        priority: priorityScore,
        reason,
        conceptualLevel: question.question.conceptualLevel,
        scheduledFor: reviewDate.toISOString(),
        metadata: {
          domainName: question.domain?.name || "General",
          confidenceScore: Math.round(domainScore * 100),
          recommendationScore: priorityScore,
          difficultyLevel: question.question.difficulty,
          estimatedTime: difficultyScore * 5,
          adaptiveFactors: {
            domainStrength: domainScore,
            conceptComplexity: conceptualScore / 3,
            difficultyWeight: difficultyScore / 3,
          },
        },
      };
    });
  }

  private calculateStyleMatch(
    conceptualLevel: string,
    learningStyle: { visual: number; practical: number; theoretical: number },
  ): number {
    switch (conceptualLevel) {
      case "recall":
        return learningStyle.visual;
      case "application":
        return learningStyle.practical;
      case "analysis":
        return learningStyle.theoretical;
      default:
        return 0.5;
    }
  }

  private calculatePriorityScore(
    domainScore: number,
    difficultyScore: number,
    conceptualScore: number,
    styleMatch: number,
    cognitiveLoadMatch: number,
  ): number {
    // Weighted combination of factors
    const weights = {
      domainPerformance: 0.3,
      difficulty: 0.2,
      conceptual: 0.2,
      styleMatch: 0.2,
      cognitiveLoad: 0.1,
    };

    const rawScore =
      (1 - domainScore) * weights.domainPerformance +
      (difficultyScore / 3) * weights.difficulty +
      (conceptualScore / 3) * weights.conceptual +
      styleMatch * weights.styleMatch +
      (1 - cognitiveLoadMatch) * weights.cognitiveLoad;

    // Convert to 1-10 scale
    return Math.round(rawScore * 10);
  }

  private determineRecommendationReason(
    domainScore: number,
    applicationRate: number,
  ): string {
    if (domainScore < 0.6) return "weak_area";
    if (applicationRate < 0.7) return "topic_reinforcement";
    return "spaced_repetition";
  }
}

export const questionRecommendationService =
  new QuestionRecommendationService();
