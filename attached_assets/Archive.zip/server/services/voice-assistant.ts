import { type ChatRequest } from "../types/chat";
import { aiLearningService } from "../services/ai-learning.service";
import { analyticsService } from "../services/analytics.service";
import { studyCompanionService } from "../services/study-companion.service";

interface VoiceCommandContext {
  studentId: number;
  currentTopic?: string;
  lastAction?: string;
  learningState?: {
    confidenceLevel: number;
    focusLevel: number;
    currentStreak: number;
  };
}

interface VoiceCommandResponse {
  message: string;
  action?: string;
  data?: any;
  recommendations?: {
    topics: string[];
    resources: string[];
    nextSteps: string[];
  };
}

/**
 * Process voice commands for the study buddy with enhanced analytics integration
 */
export async function processVoiceCommand(
  command: string,
  studentId: number,
  context: VoiceCommandContext,
): Promise<VoiceCommandResponse> {
  try {
    // Get user's learning analytics for personalized responses
    const userAnalytics = await analyticsService.getUserAnalytics(studentId);
    const learningPatterns = await analyticsService.getStudyPatterns(studentId);

    // Normalize command to lowercase for easier matching
    const normalizedCommand = command.toLowerCase();

    // Enhanced command processing with analytics integration
    if (normalizedCommand.includes("start study session")) {
      const studyPath = await aiLearningService.generateStudyPath(studentId, {
        timeframe: "immediate",
        focusAreas: [context.currentTopic || "general"],
        difficulty: "adaptive",
        studyPatterns: learningPatterns,
      });

      // Get personalized recommendations
      const recommendations = await studyCompanionService.processVoiceCommand(
        studentId,
        command,
        {
          ...context,
          analytics: userAnalytics,
          studyPath,
        },
      );

      return {
        message:
          "Starting a personalized study session. Here's what I recommend based on your learning patterns:",
        action: "START_SESSION",
        data: studyPath,
        recommendations: {
          topics: userAnalytics.areasForImprovement,
          resources: recommendations.additionalResources || [],
          nextSteps: recommendations.suggestions || [],
        },
      };
    }

    if (normalizedCommand.includes("give me a practice question")) {
      // Generate question based on user's performance analytics
      const questionResponse = await aiLearningService.generatePracticeQuestion(
        studentId,
        {
          topic: context.currentTopic,
          difficulty: "adaptive",
          performance: userAnalytics.overallProgress,
          learningPatterns,
        },
      );

      return {
        message:
          "Here's a practice question tailored to your current learning level",
        action: "SHOW_QUESTION",
        data: questionResponse,
        recommendations: {
          topics: questionResponse.relatedTopics || [],
          resources: questionResponse.studyResources || [],
          nextSteps: questionResponse.followUpQuestions || [],
        },
      };
    }

    if (normalizedCommand.includes("analyze my progress")) {
      const gaps = await analyticsService.identifyKnowledgeGaps(studentId);

      return {
        message:
          "Here's an analysis of your current progress and recommendations:",
        action: "SHOW_ANALYSIS",
        data: {
          gaps,
          patterns: learningPatterns,
          analytics: userAnalytics,
        },
        recommendations: {
          topics: gaps.map((g) => g.domainName),
          resources: gaps.flatMap((g) => g.recommendedActions),
          nextSteps: [
            "Focus on identified weak areas",
            "Review related content",
            "Take practice tests in these domains",
          ],
        },
      };
    }

    // Default response with personalized recommendations
    const defaultResponse = await studyCompanionService.processVoiceCommand(
      studentId,
      command,
      {
        ...context,
        analytics: userAnalytics,
      },
    );

    return {
      message: defaultResponse.message,
      action: defaultResponse.action,
      data: defaultResponse.additionalResources,
      recommendations: {
        topics: userAnalytics.areasForImprovement,
        resources: defaultResponse.additionalResources || [],
        nextSteps: defaultResponse.suggestions || [],
      },
    };
  } catch (error) {
    console.error("Error processing voice command:", error);
    throw error;
  }
}
