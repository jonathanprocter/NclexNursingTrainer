Here's the fixed version of the code:

```typescript
import { db } from "@db";
import { userProgress } from "@db/schema";
import { sql } from "drizzle-orm";

interface LearningMetrics {
  currentDifficulty: string;
  performanceLevel: number;
  accuracyRate: number;
  completionRate: number;
  averageResponseTime: number;
}

class AnalyticsService {
  async getLearningMetrics(userId: number): Promise<LearningMetrics> {
    const defaultMetrics: LearningMetrics = {
      currentDifficulty: "beginner",
      performanceLevel: 0.5,
      accuracyRate: 0,
      completionRate: 0,
      averageResponseTime: 0,
    };

    try {
      const performanceData = await db
        .select({
          correct: sql<number>`COUNT(*) FILTER (WHERE ${userProgress.correct})::float / NULLIF(COUNT(*), 0)`,
          avgResponseTime: sql<number>`AVG(${userProgress.responseTime})`,
        })
        .from(userProgress)
        .where(sql`user_id = ${userId}`)
        .execute();

      if (performanceData.length === 0) {
        return defaultMetrics;
      }

      const accuracy = performanceData[0]?.correct ?? 0;

      let currentDifficulty: string;
      if (accuracy < 0.6) {
        currentDifficulty = "beginner";
      } else if (accuracy > 0.8) {
        currentDifficulty = "advanced";
      } else {
        currentDifficulty = "intermediate";
      }

      const performanceLevel = Math.min(Math.max(accuracy, 0), 1);

      return {
        currentDifficulty,
        performanceLevel,
        accuracyRate: accuracy * 100,
        averageResponseTime: performanceData[0]?.avgResponseTime ?? 0,
        completionRate: accuracy * 100,
      };
    } catch (error) {
      console.error("Error getting learning metrics:", error);
      return defaultMetrics;
    }
  }
}

export const analyticsService = new AnalyticsService();
```