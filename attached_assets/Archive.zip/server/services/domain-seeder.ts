Here's the fixed and improved version of the `domain-seeder.ts` file:

```typescript
import { db } from "@db";
import { nclexDomains } from "@db/schema";
import { eq } from "drizzle-orm";

interface NclexDomain {
  name: string;
  description: string;
  category: string;
  subTopics: string[];
  weightage: number;
  clinicalJudgmentLevel: string;
}

// NCLEX Domains based on the official exam blueprint
const MAIN_NCLEX_DOMAINS: NclexDomain[] = [
  {
    name: "Safe and Effective Care Environment",
    description: "Management of Care and Safety and Infection Control",
    category: "fundamentals",
    subTopics: [
      "Management of Care",
      "Safety and Infection Control",
      "Delegation",
      "Legal Rights",
      "Ethics",
    ],
    weightage: 30,
    clinicalJudgmentLevel: "3",
  },
  {
    name: "Health Promotion and Maintenance",
    description: "Growth and Development Through the Life Span",
    category: "health_promotion",
    subTopics: [
      "Prevention",
      "Early Detection",
      "Health Screening",
      "Lifestyle Choices",
      "Self-Care",
    ],
    weightage: 17,
    clinicalJudgmentLevel: "2",
  },
  {
    name: "Psychosocial Integrity",
    description: "Coping, Adaptation, and Mental Health",
    category: "mental_health",
    subTopics: [
      "Coping Mechanisms",
      "Mental Health Concepts",
      "Crisis Intervention",
      "Cultural Awareness",
      "Support Systems",
    ],
    weightage: 15,
    clinicalJudgmentLevel: "2",
  },
  {
    name: "Physiological Integrity",
    description: "Basic Care, Pharmacology, and Complex Care Management",
    category: "physiological",
    subTopics: [
      "Basic Care and Comfort",
      "Pharmacological Therapies",
      "Reduction of Risk",
      "Physiological Adaptation",
      "Complex Care",
    ],
    weightage: 38,
    clinicalJudgmentLevel: "3",
  },
];

export async function seedNCLEXDomains(): Promise<{ success: boolean; message: string }> {
  try {
    console.log("Starting NCLEX domains seeding...");

    // Update or insert main domains
    for (const domain of MAIN_NCLEX_DOMAINS) {
      const existingDomain = await db
        .select()
        .from(nclexDomains)
        .where(eq(nclexDomains.name, domain.name))
        .limit(1);

      if (existingDomain.length > 0) {
        await db
          .update(nclexDomains)
          .set({
            description: domain.description,
            weightage: domain.weightage,
            subTopics: domain.subTopics,
            clinicalJudgmentLevel: domain.clinicalJudgmentLevel,
          })
          .where(eq(nclexDomains.name, domain.name));
      } else {
        await db.insert(nclexDomains).values({
          name: domain.name,
          description: domain.description,
          category: domain.category,
          subTopics: domain.subTopics,
          weightage: domain.weightage,
          clinicalJudgmentLevel: domain.clinicalJudgmentLevel,
          performanceScore: 0,
        });
      }
    }

    console.log("NCLEX domains seeded successfully");
    return { success: true, message: "Domains seeded successfully" };
  } catch (error) {
    console.error("Error seeding NCLEX domains:", error);
    return { success: false, message: "Failed to seed domains" };
  }
}
```