Here's the fixed and optimized code:

```typescript
import {
  readFile,
  readdir,
  mkdir,
  writeFile,
  rm,
  stat,
  open,
  copyFile,
} from "fs/promises";
import { createReadStream, createWriteStream } from "fs";
import { join, normalize, relative, extname, sep, dirname } from "path";
import { randomUUID } from "crypto";
import * as unzipper from "unzipper";
import { lookup } from "mime-types";
import { logger } from "./logging";
import type {
  difficultyEnum,
  categoryEnum,
  conceptualLevelEnum,
  clinicalJudgmentLevelEnum,
} from "@db/schema";

// Type definitions
export interface NclexDomain {
  name: string;
  description?: string;
  category: (typeof categoryEnum.enumValues)[number];
  subTopics?: string[];
  weightage?: number;
  clinicalJudgmentLevel?: (typeof clinicalJudgmentLevelEnum.enumValues)[number];
  performanceScore?: number;
}

export interface NclexQuestion {
  scenario: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
  difficulty: (typeof difficultyEnum.enumValues)[number];
  conceptualLevel: (typeof conceptualLevelEnum.enumValues)[number];
  clinicalJudgmentLevel: (typeof clinicalJudgmentLevelEnum.enumValues)[number];
  conceptualBreakdown: {
    mainConcept: string;
    relatedConcepts: string[];
    applicationContext: string;
  };
  domain: string;
}

export interface NclexContent {
  questions: NclexQuestion[];
  domains: NclexDomain[];
  metadata: {
    version: string;
    processedAt: string;
    totalFiles: number;
  };
}

export interface ProcessResult {
  originalName: string;
  extractedFiles: ExtractedFile[];
  totalFiles: number;
  processedAt: string;
  archiveComment?: string;
  totalCompressedSize: number;
  totalUncompressedSize: number;
  nclexContent?: NclexContent;
}

export interface BatchProcessingStatus {
  totalFiles: number;
  processedFiles: number;
  currentFile: string;
  errors: Array<{
    file: string;
    error: string;
  }>;
  status: "processing" | "completed" | "error";
}

// Helper interfaces
interface ZipEntry extends unzipper.Entry {
  path: string;
  type: string;
  vars: {
    uncompressedSize: number;
    compressedSize: number;
    signature?: number;
    versionsNeededToExtract: number;
    flags: number;
    compressionMethod: number;
    lastModifiedTime: number;
    fileNameLength: number;
    extraFieldLength: number;
  };
  autodrain(): void;
  buffer(): Promise<Buffer>;
  method: number;
  compressedSize: number;
}

interface ExtractedFile {
  name: string;
  path: string;
  content: string;
  size: number;
  metadata: {
    lastModified: string;
    createdAt: string;
    mimeType: string;
    encoding: string;
    extension: string;
    path: string;
    compressionMethod?: string;
    compressedSize?: number;
    crc32?: string;
    comment?: string;
  };
  parsedContent?: NclexQuestion[] | NclexDomain[] | null;
}

// Constants
const MAX_TOTAL_SIZE = 5 * 1024 * 1024 * 1024; // 5GB
const MAX_PATH_LENGTH = 255;
const MAX_FILE_SIZE = 500 * 1024 * 1024; // 500MB
const ALLOWED_TEXT_EXTENSIONS = [
  ".txt",
  ".md",
  ".json",
  ".xml",
  ".csv",
  ".html",
  ".css",
  ".js",
  ".ts",
  ".jsx",
  ".tsx",
  ".yml",
  ".yaml",
  ".conf",
  ".config",
  ".ini",
  ".log",
];

const ALLOWED_NCLEX_EXTENSIONS = [
  ".txt",
  ".json",
  ".md",
  ".xml",
  ".tsx",
  ".ts",
  ".js",
  ".jsx",
  ".csv",
];
const NCLEX_CONTENT_PATTERNS = [
  /question.*\.(json|md|xml|csv)$/i,
  /q[0-9]+.*\.(json|md|xml|csv)$/i,
  /exam.*\.(json|md|xml|csv)$/i,
  /test.*\.(json|md|xml|csv)$/i,
  /nclex.*\.(json|md|xml|csv)$/i,
  /prep.*\.(json|md|xml|csv)$/i,
  /.*\.tsx?$/i,
  /.*\.jsx?$/i,
  /content\/.*\.(json|md|xml|csv)$/i,
  /data\/.*\.(json|md|xml|csv)$/i,
  /questions\/.*\.(json|md|xml|csv)$/i,
];

// Helper functions
async function validateZipHeader(filePath: string): Promise<boolean> {
  const fileHandle = await open(filePath, "r");
  try {
    const buffer = Buffer.alloc(4);
    await fileHandle.read(buffer, 0, 4, 0);
    return (
      buffer[0] === 0x50 &&
      buffer[1] === 0x4b &&
      buffer[2] === 0x03 &&
      buffer[3] === 0x04
    );
  } finally {
    await fileHandle.close();
  }
}

async function validateZipEntry(
  entry: ZipEntry,
  workDir: string,
  extractedFiles: Set<string>,
): Promise<{ isValid: boolean; error?: string }> {
  const fileName = entry.path;
  const type = entry.type;
  const size = entry.vars.uncompressedSize;

  if (type === "Directory" || !fileName || fileName === "") {
    return { isValid: false };
  }

  const normalizedPath = normalize(join(workDir, fileName))
    .split(sep)
    .join("/");
  const normalizedWorkDir = normalize(workDir).split(sep).join("/");

  if (!normalizedPath.startsWith(normalizedWorkDir)) {
    return { isValid: false, error: "Path traversal attempt detected" };
  }

  if (!(await validateNclexContent(fileName))) {
    return { isValid: false, error: "Invalid content type" };
  }

  if (fileName.length > MAX_PATH_LENGTH) {
    return { isValid: false, error: "Path too long" };
  }

  if (size > MAX_FILE_SIZE) {
    return { isValid: false, error: "File too large" };
  }

  if (extractedFiles.has(fileName)) {
    return { isValid: false, error: "Duplicate file" };
  }

  return { isValid: true };
}

async function extractFileMetadata(
  filePath: string,
  fileName: string,
  relativePath: string,
  zipEntry?: ZipEntry,
): Promise<ExtractedFile["metadata"]> {
  const stats = await stat(filePath);
  const extension = extname(fileName).toLowerCase();

  const metadata: ExtractedFile["metadata"] = {
    lastModified: stats.mtime.toISOString(),
    createdAt: stats.birthtime.toISOString(),
    mimeType: lookup(fileName) || "application/octet-stream",
    encoding: ALLOWED_TEXT_EXTENSIONS.includes(extension) ? "utf-8" : "base64",
    extension,
    path: relativePath,
  };

  if (zipEntry) {
    metadata.compressionMethod = zipEntry.method === 0 ? "Stored" : "Deflated";
    metadata.compressedSize = zipEntry.compressedSize;
    metadata.crc32 = zipEntry.crc32?.toString(16).padStart(8, "0");
    metadata.comment = zipEntry.comment;
  }

  return metadata;
}

async function validateNclexContent(fileName: string): Promise<boolean> {
  const ext = extname(fileName).toLowerCase();
  return (
    ALLOWED_NCLEX_EXTENSIONS.includes(ext) &&
    NCLEX_CONTENT_PATTERNS.some((pattern) => pattern.test(fileName))
  );
}

async function parseNclexContent(
  content: string,
  fileName: string,
): Promise<NclexQuestion[] | NclexDomain[] | null> {
  try {
    if (fileName.match(/\.(json)$/i)) {
      const parsed = JSON.parse(content);

      if (fileName.includes("domain") || fileName.includes("category")) {
        const domains = Array.isArray(parsed) ? parsed : [parsed];
        return domains.map((d: any) => ({
          name: d.name,
          description: d.description,
          category: d.category || "fundamentals",
          subTopics: d.subTopics || d.topics || [],
          weightage: d.weightage || d.weight || 0,
          clinicalJudgmentLevel: d.clinicalJudgmentLevel || "1",
          performanceScore: 0,
        }));
      }

      const questions = Array.isArray(parsed) ? parsed : [parsed];
      return questions.map((q: any) => ({
        scenario: q.scenario || q.question || q.stem || "",
        options: q.options || q.answers || q.choices || [],
        correctAnswer: q.correctAnswer || q.answer || "",
        explanation: q.explanation || q.rationale || "",
        difficulty: q.difficulty || "medium",
        conceptualLevel: q.conceptualLevel || "application",
        clinicalJudgmentLevel: q.clinicalJudgmentLevel || "1",
        domain: q.domain || q.category || "Fundamentals",
        conceptualBreakdown: {
          mainConcept: q.mainConcept || q.concept || "",
          relatedConcepts: q.relatedConcepts || [],
          applicationContext: q.applicationContext || q.context || "",
        },
      }));
    }

    if (fileName.match(/\.(csv)$/i)) {
      const lines = content
        .split("\n")
        .map((line) => line.trim())
        .filter(Boolean);
      const headers = lines[0]
        .toLowerCase()
        .split(",")
        .map((h) => h.trim());

      if (lines.length < 2) return null;

      return lines.slice(1).map((line) => {
        const values = line.split(",").map((v) => v.trim());
        const entry: Record<string, any> = {};
        headers.forEach((header, index) => {
          entry[header] = values[index] || "";
        });

        return {
          scenario: entry.scenario || entry.question || "",
          options: entry.options ? entry.options.split("|") : [],
          correctAnswer: entry.correctanswer || entry.answer || "",
          explanation: entry.explanation || entry.rationale || "",
          difficulty: entry.difficulty || "medium",
          conceptualLevel: entry.conceptuallevel || "application",
          clinicalJudgmentLevel: entry.clinicaljudgmentlevel || "1",
          domain: entry.domain || entry.category || "Fundamentals",
          conceptualBreakdown: {
            mainConcept: entry.mainconcept || "",
            relatedConcepts: entry.relatedconcepts
              ? entry.relatedconcepts.split("|")
              : [],
            applicationContext: entry.applicationcontext || "",
          },
        };
      });
    }

    return null;
  } catch (error) {
    logger.error("Content parsing failed:", error);
    return null;
  }
}

async function structureNclexContent(
  extractedFiles: ExtractedFile[],
): Promise<NclexContent> {
  const questions: NclexQuestion[] = [];
  const domainSet = new Map<string, NclexDomain>();

  for (const file of extractedFiles) {
    if (!file.parsedContent) continue;

    const parsedContent = Array.isArray(file.parsedContent)
      ? file.parsedContent
      : [file.parsedContent];

    for (const item of parsedContent) {
      if ("scenario" in item) {
        const question = item as NclexQuestion;
        if (!domainSet.has(question.domain)) {
          domainSet.set(question.domain, {
            name: question.domain,
            category: "fundamentals",
            subTopics: [],
            weightage: 0,
            clinicalJudgmentLevel: "1",
            performanceScore: 0,
          });
        }
        questions.push(question);
      } else if ("name" in item) {
        const domain = item as NclexDomain;
        domainSet.set(domain.name, domain);
      }
    }
  }

  return {
    questions,
    domains: Array.from(domainSet.values()),
    metadata: {
      version: "1.0",
      processedAt: new Date().toISOString(),
      totalFiles: extractedFiles.length,
    },
  };
}

async function processZipFile(
  filePath: string,
  originalName: string,
): Promise<ProcessResult> {
  const tmpDir = join(process.cwd(), "tmp");
  await mkdir(tmpDir, { recursive: true });
  const workDir = join(tmpDir, randomUUID());
  await mkdir(workDir, { recursive: true });

  let totalCompressedSize = 0;
  let totalUncompressedSize = 0;
  let archiveComment: string | undefined;

  try {
    const isValidZip = await validateZipHeader(filePath);
    if (!isValidZip) {
      throw new Error("Invalid ZIP file format");
    }

    const extractedFiles = new Set<string>();
    const validFiles: ExtractedFile[] = [];

    await new Promise<void>((resolve, reject) => {
      createReadStream(filePath)
        .pipe(unzipper.Parse())
        .on("entry", async (entry: ZipEntry) => {
          try {
            const validationResult = await validateZipEntry(
              entry,
              workDir,
              extractedFiles,
            );
            if (!validationResult.isValid) {
              entry.autodrain();
              return;
            }

            totalCompressedSize += entry.compressedSize;
            totalUncompressedSize += entry.vars.uncompressedSize;

            if (totalUncompressedSize > MAX_TOTAL_SIZE) {
              entry.autodrain();
              reject(new Error("Total extracted size exceeds limit"));
              return;
            }

            extractedFiles.add(entry.path);

            const entryPath = normalize(entry.path);
            const targetPath = join(workDir, entryPath);
            await mkdir(dirname(targetPath), { recursive: true });

            const writeStream = createWriteStream(targetPath);
            entry.pipe(writeStream);

            await new Promise((res, rej) => {
              writeStream.on("finish", res);
              writeStream.on("error", rej);
            });

            const content = await readFile(targetPath, "utf-8");
            const parsedContent = await parseNclexContent(content, entry.path);

            validFiles.push({
              name: entry.path,
              path: relative(workDir, targetPath),
              