import { db } from "@db";
import { userProgress, nclexDomains, questions } from "@db/schema";
import { eq, desc, and, sql } from "drizzle-orm";
import OpenAI from "openai";
// Added NGN_DOMAINS constant -  Assume this is fetched from db/nclex-domains.ts
const NGN_DOMAINS = {
  Domain1: {
    category: "Category A",
    subTopics: ["Subtopic X", "Subtopic Y"],
    clinicalJudgmentLevels: ["Application", "Analysis"],
  },
  Domain2: {
    category: "Category B",
    subTopics: ["Subtopic Z"],
    clinicalJudgmentLevels: ["Application"],
  },
  // ... more domains
};

interface GeneratedQuestion {
  question: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
  domain: string;
  difficulty: "easy" | "medium" | "hard";
  clinicalJudgmentLevel: string;
}

interface QuestionGenerationParams {
  userId: number;
  focusArea?: string;
  difficulty?: "easy" | "medium" | "hard";
  count?: number;
}

interface PerformanceMetrics {
  recentAccuracy: number;
  averageResponseTime: number;
  consistencyScore: number;
  topicMastery: number;
}

class QuestionGenerationService {
  private openai: OpenAI;
  private readonly MASTERY_THRESHOLD = 0.85;
  private readonly DIFFICULTY_THRESHOLDS = {
    easy: { lower: 0, upper: 0.4 },
    medium: { lower: 0.4, upper: 0.7 },
    hard: { lower: 0.7, upper: 1.0 },
  };

  constructor() {
    if (!process.env.OPENAI_API_KEY) {
      throw new Error("OpenAI API key is required");
    }
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
  }

  async generateQuestions(
    params: QuestionGenerationParams,
  ): Promise<GeneratedQuestion[]> {
    try {
      const performanceMetrics = await this.calculatePerformanceMetrics(
        params.userId,
      );
      const adaptiveDifficulty =
        params.difficulty ||
        this.calculateAdaptiveDifficulty(performanceMetrics);

      // Get user's recent performance and emotional state
      const recentProgress = await db.query.userProgress.findMany({
        where: eq(userProgress.userId, params.userId),
        orderBy: [desc(userProgress.timestamp)],
        limit: 5,
      });

      // Get domain focus areas considering spaced repetition
      const domains = await this.getOptimalDomains(
        params.userId,
        params.focusArea,
      );

      const questions: GeneratedQuestion[] = [];
      for (const domain of domains) {
        const prompt = await this.generatePrompt(
          domain,
          adaptiveDifficulty,
          performanceMetrics,
        );

        const completion = await this.openai.chat.completions.create({
          model: "gpt-4o",
          messages: [
            { role: "system", content: prompt.systemMessage },
            { role: "user", content: prompt.userMessage },
          ],
          temperature: 0.7,
          response_format: { type: "json_object" },
        });

        const generatedQuestion = this.parseResponse(
          completion.choices[0].message.content,
        );
        if (generatedQuestion) {
          questions.push({
            ...generatedQuestion,
            domain: domain.name,
            difficulty: adaptiveDifficulty,
            clinicalJudgmentLevel: this.adjustClinicalJudgmentLevel(
              domain.clinicalJudgmentLevel || "application",
              performanceMetrics,
            ),
          });
        }
      }

      await this.updateUserProgress(params.userId, performanceMetrics);
      return questions;
    } catch (error) {
      console.error("Error generating questions:", error);
      throw new Error("Failed to generate questions");
    }
  }

  private async calculatePerformanceMetrics(
    userId: number,
  ): Promise<PerformanceMetrics> {
    const recentProgress = await db.query.userProgress.findMany({
      where: eq(userProgress.userId, userId),
      orderBy: [desc(userProgress.timestamp)],
      limit: 20,
    });

    const recentAccuracy =
      recentProgress.filter((p) => p.correct).length /
      Math.max(1, recentProgress.length);
    const averageResponseTime =
      recentProgress.reduce((acc, curr) => acc + (curr.responseTime || 0), 0) /
      Math.max(1, recentProgress.length);
    const consistencyScore = this.calculateConsistencyScore(recentProgress);
    const topicMastery = await this.calculateTopicMastery(userId);

    return {
      recentAccuracy,
      averageResponseTime,
      consistencyScore,
      topicMastery,
    };
  }

  private calculateConsistencyScore(progress: any[]): number {
    if (progress.length < 2) return 1;

    let streaks = 0;
    for (let i = 1; i < progress.length; i++) {
      if (progress[i].correct === progress[i - 1].correct) {
        streaks++;
      }
    }

    return streaks / (progress.length - 1);
  }

  private async calculateTopicMastery(userId: number): Promise<number> {
    const domainProgress = await db.query.userProgress.findMany({
      where: eq(userProgress.userId, userId),
      with: {
        domain: true,
      },
    });

    const domainScores = new Map<number, { correct: number; total: number }>();

    domainProgress.forEach((progress) => {
      if (!progress.domain) return;

      const current = domainScores.get(progress.domain.id) || {
        correct: 0,
        total: 0,
      };
      domainScores.set(progress.domain.id, {
        correct: current.correct + (progress.correct ? 1 : 0),
        total: current.total + 1,
      });
    });

    const masteryScores = Array.from(domainScores.values()).map((score) =>
      score.total > 0 ? score.correct / score.total : 0,
    );

    return (
      masteryScores.reduce((acc, score) => acc + score, 0) /
      Math.max(1, masteryScores.length)
    );
  }

  private calculateAdaptiveDifficulty(
    metrics: PerformanceMetrics,
  ): "easy" | "medium" | "hard" {
    const performanceScore =
      metrics.recentAccuracy * 0.4 +
      metrics.consistencyScore * 0.3 +
      metrics.topicMastery * 0.3;

    if (performanceScore <= this.DIFFICULTY_THRESHOLDS.easy.upper)
      return "easy";
    if (performanceScore <= this.DIFFICULTY_THRESHOLDS.medium.upper)
      return "medium";
    return "hard";
  }

  private async getOptimalDomains(
    userId: number,
    focusArea?: string,
  ): Promise<(typeof nclexDomains.$inferSelect)[]> {
    // Get domains considering spaced repetition intervals
    const now = new Date();
    const spacedRepetitionData = await db.query.userProgress.findMany({
      where: eq(userProgress.userId, userId),
      with: {
        domain: true,
      },
      orderBy: [desc(userProgress.lastReviewDate)],
    });

    const domainDueDates = new Map<number, Date>();
    spacedRepetitionData.forEach((progress) => {
      if (!progress.domain) return;
      if (!domainDueDates.has(progress.domain.id)) {
        const interval = this.calculateReviewInterval(
          progress.strengthLevel || 0,
        );
        const dueDate = new Date(progress.lastReviewDate || now);
        dueDate.setDate(dueDate.getDate() + interval);
        domainDueDates.set(progress.domain.id, dueDate);
      }
    });

    // Query domains that are due for review
    const domains = await db.query.nclexDomains.findMany({
      where: focusArea ? eq(nclexDomains.category, focusArea) : undefined,
      limit: 3,
    });

    return domains.filter((domain) => {
      const dueDate = domainDueDates.get(domain.id) || now;
      return dueDate <= now;
    });
  }

  private calculateReviewInterval(strengthLevel: number): number {
    // Implement spaced repetition intervals (in days)
    const intervals = [1, 3, 7, 14, 30, 60];
    return intervals[Math.min(strengthLevel, intervals.length - 1)];
  }

  private adjustClinicalJudgmentLevel(
    baseLevel: string,
    metrics: PerformanceMetrics,
  ): string {
    const levels = ["recall", "application", "analysis", "synthesis"];
    const currentIndex = levels.indexOf(baseLevel);

    if (
      metrics.topicMastery > this.MASTERY_THRESHOLD &&
      currentIndex < levels.length - 1
    ) {
      return levels[currentIndex + 1];
    }

    return baseLevel;
  }

  private async generatePrompt(
    domain: typeof nclexDomains.$inferSelect,
    difficulty: string,
    metrics: PerformanceMetrics,
  ): Promise<{ systemMessage: string; userMessage: string }> {
    const adaptiveInstructions = this.getAdaptiveInstructions(metrics);
    const domainInfo = NGN_DOMAINS[domain.name];

    return {
      systemMessage:
        "You are an expert NCLEX question writer with deep knowledge of nursing concepts and clinical scenarios.",
      userMessage: `Generate an NCLEX-style question for the following nursing domain:
Topic: ${domain.name}
Category: ${domainInfo?.category || domain.name}
Sub-topics: ${domainInfo?.subTopics?.join(", ") || ""}
Clinical Judgment Level: ${domainInfo?.clinicalJudgmentLevels?.join(", ") || domain.clinicalJudgmentLevel || "application"}
Difficulty: ${difficulty}

${adaptiveInstructions}
`,
    };
  }

  private getAdaptiveInstructions(metrics: PerformanceMetrics): string {
    let instructions = [];

    if (metrics.recentAccuracy < 0.6) {
      instructions.push("Break down complex concepts into simpler components.");
    }

    if (metrics.averageResponseTime > 120) {
      instructions.push(
        "Focus on clear, concise scenarios that test core concepts.",
      );
    }

    return instructions.join("\n");
  }

  private parseResponse(response: string): GeneratedQuestion | null {
    try {
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (!jsonMatch) return null;

      const parsedResponse = JSON.parse(jsonMatch[0]);
      return {
        question: parsedResponse.question,
        options: parsedResponse.options,
        correctAnswer: parsedResponse.correctAnswer,
        explanation: parsedResponse.explanation,
        domain: "",
        difficulty: "medium",
        clinicalJudgmentLevel: "application",
      };
    } catch (error) {
      console.error("Error parsing AI response:", error);
      return null;
    }
  }

  private async updateUserProgress(
    userId: number,
    metrics: PerformanceMetrics,
  ): Promise<void> {
    try {
      // Update user's learning metrics
      await db
        .update(userProgress)
        .set({
          lastMetrics: {
            accuracy: metrics.recentAccuracy,
            responseTime: metrics.averageResponseTime,
            consistencyScore: metrics.consistencyScore,
            topicMastery: metrics.topicMastery,
          },
          lastUpdated: new Date(),
        })
        .where(eq(userProgress.userId, userId));
    } catch (error) {
      console.error("Error updating user progress:", error);
    }
  }
}

function generateQuestion(topic: string | null) {
  if (!topic) {
    throw new Error("Topic cannot be null");
  }
  return db.query.questions.findFirst({
    where: eq(questions.topic, topic),
  });
}

export const questionGenerationService = new QuestionGenerationService();
