import { db } from "@db";
import { questions, nclexDomains } from "@db/schema";
import { eq } from "drizzle-orm";

export interface NCLEXValidationResult {
  isValid: boolean;
  category: string;
  details: Record<string, any>;
  recommendations: string[];
}

export interface ValidationDetails {
  checkName: string;
  metrics?: Record<string, number>;
  error?: string;
}

export interface SystemHealthMetrics {
  responseTime: number;
  errorRate: number;
  resourceUsage: {
    cpu: number;
    memory: number;
    disk: number;
  };
}

export class ValidationService {
  private initialized: boolean = false;

  async initialize(): Promise<boolean> {
    try {
      if (this.initialized) {
        return true;
      }

      const maxRetries = 3;
      let lastError: Error | null = null;

      for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
          await this.checkSystemHealth();
          this.initialized = true;
          return true;
        } catch (error) {
          lastError = error;
          if (attempt === maxRetries) break;
          await new Promise((resolve) => setTimeout(resolve, attempt * 1000));
        }
      }

      if (lastError) {
        console.error(
          `Failed to initialize ValidationService after ${maxRetries} attempts:`,
          {
            error: lastError.message,
            stack: lastError.stack,
            timestamp: new Date().toISOString(),
          },
        );
        return false;
      }

      this.initialized = true;
      return true;
    } catch (error) {
      console.error("Failed to initialize ValidationService:", {
        error: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString(),
        service: "ValidationService",
        method: "initialize",
      });
      return false;
    }
  }

  async validateNCLEXContent(
    contentId: number,
  ): Promise<NCLEXValidationResult> {
    try {
      if (!this.initialized && !(await this.initialize())) {
        return {
          isValid: false,
          category: "System Error",
          details: { error: "Validation service not initialized" },
          recommendations: ["Check system health and try again"],
        };
      }

      const question = await db.query.questions.findFirst({
        where: eq(questions.id, contentId),
      });

      if (!question) {
        return {
          isValid: false,
          category: "Not Found",
          details: { error: `Question with id ${contentId} not found` },
          recommendations: [],
        };
      }

      const validationResult: NCLEXValidationResult = {
        isValid: true,
        category: "Standard Question",
        details: {},
        recommendations: [],
      };

      // Validate content structure
      if (!question.options || question.options.length < 2) {
        validationResult.isValid = false;
        validationResult.details.optionsError =
          "Question must have at least 2 options";
      }

      if (!question.correct_answer) {
        validationResult.isValid = false;
        validationResult.details.answerError =
          "Question must have a correct answer";
      }

      if (!question.conceptualBreakdown) {
        validationResult.recommendations.push(
          "Add conceptual breakdown for better learning outcomes",
        );
      }

      return validationResult;
    } catch (error) {
      console.error("Error validating NCLEX content:", error);
      return {
        isValid: false,
        category: "Error",
        details: { error: "Validation failed" },
        recommendations: ["System error occurred, please try again"],
      };
    }
  }

  async checkSystemHealth(): Promise<boolean> {
    try {
      if (!this.initialized && !(await this.initialize())) {
        return false;
      }

      const metrics: SystemHealthMetrics = {
        responseTime: await this.measureResponseTime(),
        errorRate: await this.calculateErrorRate(),
        resourceUsage: await this.getResourceUsage(),
      };

      return this.evaluateMetrics(metrics);
    } catch (error) {
      console.error("Error checking system health:", error);
      return false;
    }
  }

  private async measureResponseTime(): Promise<number> {
    try {
      const start = process.hrtime();
      await db.query.questions.findFirst();
      const [seconds, nanoseconds] = process.hrtime(start);
      return seconds * 1000 + nanoseconds / 1000000; // Convert to milliseconds
    } catch (error) {
      console.error("Error measuring response time:", error);
      return -1;
    }
  }

  private async calculateErrorRate(): Promise<number> {
    try {
      const recentQuestions = await db.query.questions.findMany({
        limit: 100,
      });

      if (recentQuestions.length === 0) return 0;
      const invalidQuestions = recentQuestions.filter(
        (q) => !q.correctAnswer || !q.options,
      ).length;
      return invalidQuestions / recentQuestions.length;
    } catch (error) {
      console.error("Error calculating error rate:", error);
      return 1; // Indicate high error rate on failure
    }
  }

  private async getResourceUsage(): Promise<{
    cpu: number;
    memory: number;
    disk: number;
  }> {
    try {
      return {
        cpu: process.cpuUsage().user / 1000000, // Convert to milliseconds
        memory: process.memoryUsage().heapUsed / 1024 / 1024, // Convert to MB
        disk: 0, // Placeholder for actual disk usage monitoring
      };
    } catch (error) {
      console.error("Error getting resource usage:", error);
      return { cpu: -1, memory: -1, disk: -1 };
    }
  }

  private evaluateMetrics(metrics: SystemHealthMetrics): boolean {
    const thresholds = {
      responseTime: 1000, // 1 second
      errorRate: 0.1, // 10%
      cpuUsage: 80, // 80%
      memoryUsage: 512, // 512MB
    };

    return (
      metrics.responseTime < thresholds.responseTime &&
      metrics.errorRate < thresholds.errorRate &&
      metrics.resourceUsage.cpu < thresholds.cpuUsage &&
      metrics.resourceUsage.memory < thresholds.memoryUsage
    );
  }
}

// Export singleton instance
export const validationService = new ValidationService();
