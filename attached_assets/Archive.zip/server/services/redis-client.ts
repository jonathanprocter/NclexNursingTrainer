import { createClient, type RedisClientType } from "redis";

let redisClient: RedisClientType | null = null;

export async function initializeRedisClient() {
  try {
    if (!process.env.UPSTASH_REDIS_URL) {
      console.log("Redis URL not provided, running without cache");
      return null;
    }

    console.log("Initializing Redis client...");

    // Format Redis URL properly
    const redisUrl = process.env.UPSTASH_REDIS_URL?.includes("://")
      ? process.env.UPSTASH_REDIS_URL
      : `redis://${process.env.UPSTASH_REDIS_URL?.replace(/^\/\//, "")}`;

    // Create client with strict configuration
    redisClient = createClient({
      url: redisUrl,
      socket: {
        tls: true,
        reconnectStrategy: (attempts) => {
          const maxRetryMs = 3000;
          const exponential = Math.min(attempts * 100, maxRetryMs);
          return exponential;
        },
      },
    });

    // Add error handling
    redisClient.on("error", (err) => {
      console.error("Redis Client Error:", err);
    });

    // Add connection success logging
    redisClient.on("connect", () => {
      console.log("Redis client connected successfully");
    });

    // Attempt connection
    console.log("Attempting to connect to Redis...");
    await redisClient.connect();

    return redisClient;
  } catch (error) {
    console.error("Failed to create Redis client:", error);
    return null;
  }
}

export function getRedisClient() {
  return redisClient;
}
