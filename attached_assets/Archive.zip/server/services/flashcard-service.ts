import { db } from "@db";
import type { SelectFlashcard } from "@db/schema";
import { flashcards } from "@db/schema";
import { eq } from "drizzle-orm";

class FlashcardService {
  async createFlashcard(
    question: string,
    userId: number,
    domain: string,
  ): Promise<SelectFlashcard> {
    const [flashcard] = await db
      .insert(flashcards)
      .values({
        question,
        userId,
        domain,
        lastReviewed: new Date(),
        nextReview: new Date(),
        correctCount: 0,
        incorrectCount: 0,
      })
      .returning();

    return flashcard;
  }

  async getFlashcards(userId: number): Promise<SelectFlashcard[]> {
    return db.query.flashcards.findMany({
      where: eq(flashcards.userId, userId),
      orderBy: [flashcards.nextReview],
    });
  }

  async getDueFlashcards(
    userId: number,
    limit = 10,
  ): Promise<SelectFlashcard[]> {
    const now = new Date();
    return db.query.flashcards.findMany({
      where: eq(flashcards.userId, userId).and(
        flashcards.nextReview.lte(now),
      ),
      orderBy: [flashcards.nextReview],
      limit,
    });
  }

  async recordFlashcardReview(
    userId: number,
    flashcardId: number,
    isCorrect: boolean,
    confidence: number,
  ): Promise<void> {
    const flashcard = await db.query.flashcards.findFirst({
      where: eq(flashcards.id, flashcardId),
    });

    if (!flashcard || flashcard.userId !== userId) {
      throw new Error("Flashcard not found or unauthorized");
    }

    const nextReview = this.calculateNextReview(confidence, isCorrect);

    await db
      .update(flashcards)
      .set({
        lastReviewed: new Date(),
        nextReview,
        correctCount: flashcard.correctCount + (isCorrect ? 1 : 0),
        incorrectCount: flashcard.incorrectCount + (isCorrect ? 0 : 1),
      })
      .where(eq(flashcards.id, flashcardId));
  }

  private calculateNextReview(confidence: number, isCorrect: boolean): Date {
    const now = new Date();
    const baseInterval = isCorrect ? 24 : 4; // hours
    const multiplier = Math.max(0.5, Math.min(2, confidence));
    const hoursToAdd = baseInterval * multiplier;

    return new Date(now.getTime() + hoursToAdd * 60 * 60 * 1000);
  }
}

export const flashcardService = new FlashcardService();