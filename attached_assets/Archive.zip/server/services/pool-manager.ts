import pg from "pg";
import { log } from "../vite";

class PoolManager {
  private pool: pg.Pool | null = null;
  private readonly MAX_CONNECTIONS = 20;
  private readonly CONNECTION_TIMEOUT = 10000;
  private readonly QUERY_TIMEOUT = 5000;
  private readonly SHUTDOWN_TIMEOUT = 10000;
  private isShuttingDown = false;
  private retryAttempts = 3;
  private retryDelay = 1000;

  async executeQuery<T>(
    queryFn: (client: pg.PoolClient) => Promise<T>,
  ): Promise<T> {
    if (this.isShuttingDown) {
      throw new Error("Cannot execute query during shutdown");
    }

    if (!this.pool) {
      await this.initialize();
    }

    if (!this.pool) {
      throw new Error("Pool failed to initialize");
    }

    let client: pg.PoolClient | null = null;
    let attempt = 0;
    let lastError: Error | null = null;

    while (attempt < this.retryAttempts) {
      try {
        // Get client from pool
        client = await this.pool.connect();

        // Execute query with timeout
        const result = await Promise.race([
          queryFn(client),
          new Promise((_, reject) =>
            setTimeout(
              () => reject(new Error("Query timeout")),
              this.QUERY_TIMEOUT,
            ),
          ),
        ]);

        return result;
      } catch (error) {
        lastError = error as Error;
        attempt++;

        if (attempt === this.retryAttempts) {
          break;
        }

        log(`Query attempt ${attempt} failed, retrying...`);
        await new Promise((resolve) =>
          setTimeout(resolve, this.retryDelay * attempt),
        );
      } finally {
        if (client) {
          client.release();
        }
      }
    }

    throw new Error(
      `Query failed after ${this.retryAttempts} attempts: ${lastError?.message}`,
    );
  }

  private async initialize() {
    if (this.pool || this.isShuttingDown) return;

    if (!process.env.DATABASE_URL) {
      throw new Error("DATABASE_URL environment variable is not set");
    }

    this.pool = new pg.Pool({
      connectionString: process.env.DATABASE_URL,
      max: this.MAX_CONNECTIONS,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: this.CONNECTION_TIMEOUT,
      ssl:
        process.env.NODE_ENV === "production"
          ? {
              rejectUnauthorized: false,
            }
          : undefined,
    });

    this.pool.on("error", (err) => {
      if (this.isShuttingDown) return;
      log("Unexpected error on idle client", err);
    });

    this.pool.on("connect", () => {
      log("New database connection established");
    });

    try {
      // Test connection
      await this.executeQuery(async (client) => {
        const result = await client.query("SELECT NOW()");
        return result.rows[0];
      });
    } catch (error) {
      this.pool = null;
      throw error;
    }
  }

  async cleanup(): Promise<void> {
    if (!this.pool) return;

    this.isShuttingDown = true;
    log("Cleaning up database connection pool...");

    try {
      // Wait for pool end with timeout
      const cleanup = Promise.race([
        this.pool.end(),
        new Promise((_, reject) =>
          setTimeout(
            () => reject(new Error("Pool shutdown timeout")),
            this.SHUTDOWN_TIMEOUT,
          ),
        ),
      ]);

      await cleanup;
      log("Database connection pool closed successfully");
    } catch (error) {
      log("Error during pool cleanup:", error);
      throw error;
    } finally {
      this.pool = null;
      this.isShuttingDown = false;
    }
  }

  getStatus(): boolean {
    return this.pool !== null && !this.isShuttingDown;
  }
}

export const poolManager = new PoolManager();
