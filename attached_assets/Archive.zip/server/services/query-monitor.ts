import { EventEmitter } from "events";
import { log } from "../vite";

interface QueryMetrics {
  queryId: string;
  duration: number;
  timestamp: Date;
  sql?: string;
}

class QueryMonitor extends EventEmitter {
  private metrics: Map<string, QueryMetrics> = new Map();
  private readonly SLOW_QUERY_THRESHOLD = 1000; // 1 second
  private isEnabled = false;

  constructor() {
    super();
    this.setupCleanupInterval();
  }

  private setupCleanupInterval() {
    // Clean up old metrics every hour
    setInterval(
      () => {
        const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
        for (const [queryId, metrics] of this.metrics) {
          if (metrics.timestamp < oneHourAgo) {
            this.metrics.delete(queryId);
          }
        }
      },
      60 * 60 * 1000,
    ); // Run every hour
  }

  enable() {
    this.isEnabled = true;
    log("Query monitor enabled");
  }

  disable() {
    this.isEnabled = false;
    log("Query monitor disabled");
  }

  reset() {
    this.metrics.clear();
    this.isEnabled = false;
    log("Query monitor reset");
  }

  trackQuery(queryId: string, duration: number, sql?: string) {
    if (!this.isEnabled) return;

    const metrics: QueryMetrics = {
      queryId,
      duration,
      timestamp: new Date(),
      sql,
    };

    this.metrics.set(queryId, metrics);

    if (duration > this.SLOW_QUERY_THRESHOLD) {
      this.emit("slowQuery", {
        queryId,
        duration,
        sql,
      });
    }
  }

  recordError(queryId: string, error: Error) {
    if (!this.isEnabled) return;

    this.emit("queryError", {
      queryId,
      error,
      timestamp: new Date(),
    });
  }

  getMetrics(queryId?: string): QueryMetrics | Map<string, QueryMetrics> {
    if (queryId) {
      return (
        this.metrics.get(queryId) || {
          queryId,
          duration: 0,
          timestamp: new Date(),
        }
      );
    }
    return new Map(this.metrics);
  }

  getAverageQueryTime(): number {
    if (this.metrics.size === 0) return 0;

    const totalDuration = Array.from(this.metrics.values()).reduce(
      (sum, metrics) => sum + metrics.duration,
      0,
    );

    return totalDuration / this.metrics.size;
  }
}

export const queryMonitor = new QueryMonitor();
