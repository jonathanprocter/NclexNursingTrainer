```typescript
import { type Question, type UserProgress } from "@db/schema";

interface CATMetrics {
  questionId: number;
  difficulty: number;
  discriminationIndex: number;
  timeSpent: number;
  correctness: boolean;
  confidence?: number;
  abilityEstimate: number;
  standardError: number;
}

export class ComputerizedAdaptiveTestService {
  private readonly minDifficulty = -3;
  private readonly maxDifficulty = 3;
  private readonly targetProbability = 0.5;
  private readonly confidenceInterval = 0.95;
  private readonly minimumInformationThreshold = 0.1;

  public calculateNextQuestionDifficulty(
    userResponses: CATMetrics[],
    currentAbility: number,
  ): number {
    if (userResponses.length === 0) {
      return 0; // Start with medium difficulty
    }

    // Calculate information function for different difficulty levels
    const difficultyLevels = Array.from(
      { length: 61 },
      (_, i) => this.minDifficulty + i * 0.1,
    );

    // Find difficulty level that maximizes information
    let maxInfo = 0;
    let optimalDifficulty = currentAbility;

    for (const difficulty of difficultyLevels) {
      const info = this.calculateInformationAt(difficulty, currentAbility);
      if (info > maxInfo) {
        maxInfo = info;
        optimalDifficulty = difficulty;
      }
    }

    // Apply confidence interval adjustment
    const adjustedDifficulty = this.adjustDifficultyWithConfidence(
      optimalDifficulty,
      userResponses.length,
    );

    return Math.max(
      this.minDifficulty,
      Math.min(this.maxDifficulty, adjustedDifficulty),
    );
  }

  private calculateInformationAt(difficulty: number, ability: number): number {
    const p = this.calculateProbability(ability - difficulty);
    return p * (1 - p); // Fisher information for dichotomous model
  }

  private calculateProbability(diff: number): number {
    return 1 / (1 + Math.exp(-1.7 * diff));
  }

  public updateAbilityEstimate(
    responses: CATMetrics[],
    currentAbility: number,
    currentSE: number,
  ): { abilityEstimate: number; standardError: number } {
    if (responses.length === 0) {
      return { abilityEstimate: currentAbility, standardError: currentSE };
    }

    let ability = currentAbility;
    let standardError = currentSE;
    const iterations = 10;
    const lastResponse = responses[responses.length - 1];

    // Newton-Raphson iteration for ability estimation
    for (let i = 0; i < iterations; i++) {
      let numerator = 0;
      let denominator = 0;

      for (const resp of responses) {
        const p = this.calculateProbability(ability - resp.difficulty);
        numerator += resp.correctness ? 1 - p : -p;
        denominator += p * (1 - p);
      }

      if (denominator === 0) {
        break;
      }

      // Update ability estimate
      ability += numerator / denominator;

      // Update standard error
      standardError = Math.sqrt(1 / denominator);
    }

    // Bound the ability estimate
    ability = Math.max(
      this.minDifficulty,
      Math.min(this.maxDifficulty, ability),
    );

    return { abilityEstimate: ability, standardError };
  }

  public evaluateStoppingCriteria(
    responses: CATMetrics[],
    minimumQuestions = 75,
    maximumQuestions = 145,
    currentStandardError = 1.0,
  ): boolean {
    if (responses.length < minimumQuestions) {
      return false;
    }
    if (responses.length >= maximumQuestions) {
      return true;
    }

    // Check if standard error is below threshold
    if (currentStandardError < 0.3) {
      return true;
    }

    // Check if ability estimate has stabilized
    const recentResponses = responses.slice(-5);
    if (recentResponses.length >= 5) {
      const abilityVariance = this.calculateAbilityVariance(recentResponses);
      if (abilityVariance < 0.1) {
        return true;
      }
    }

    // Check if information gain is minimal
    const lastResponse = responses[responses.length - 1];
    const information = this.calculateInformationAt(
      lastResponse.difficulty,
      lastResponse.abilityEstimate,
    );

    return information < this.minimumInformationThreshold;
  }

  private calculateAbilityVariance(responses: CATMetrics[]): number {
    if (responses.length < 2) {
      return 1;
    }

    const abilities = responses.map((r) => r.abilityEstimate);
    const mean = abilities.reduce((sum, a) => sum + a, 0) / abilities.length;

    return (
      abilities.reduce((sum, a) => sum + Math.pow(a - mean, 2), 0) /
      (abilities.length - 1)
    );
  }

  public mapDifficultyToLevel(difficulty: number): "easy" | "medium" | "hard" {
    if (difficulty <= -1) {
      return "easy";
    }
    if (difficulty >= 1) {
      return "hard";
    }
    return "medium";
  }

  public generateFeedback(responses: CATMetrics[]): {
    strengths: string[];
    weaknesses: string[];
    recommendedFocus: string[];
  } {
    // Group responses by difficulty ranges
    const performanceByDifficulty = new Map<number, number>();
    for (const r of responses) {
      const difficulty = Math.round(r.difficulty);
      const current = performanceByDifficulty.get(difficulty) || 0;
      performanceByDifficulty.set(
        difficulty,
        current + (r.correctness ? 1 : 0),
      );
    }

    // Identify strengths and weaknesses
    const strengths: string[] = [];
    const weaknesses: string[] = [];
    const recommendedFocus: string[] = [];

    for (const [difficulty, correct] of performanceByDifficulty.entries()) {
      const total = responses.filter(
        (r) => Math.round(r.difficulty) === difficulty,
      ).length;
      const percentage = (correct / total) * 100;

      if (percentage >= 80) {
        strengths.push(`Strong performance at difficulty level ${difficulty}`);
      } else if (percentage <= 50) {
        weaknesses.push(`Needs improvement at difficulty level ${difficulty}`);
        recommendedFocus.push(
          `Focus on questions at difficulty level ${difficulty}`,
        );
      }
    }

    return {
      strengths,
      weaknesses,
      recommendedFocus,
    };
  }

  private adjustDifficultyWithConfidence(
    ability: number,
    responseCount: number,
  ): number {
    // Add confidence interval based on number of responses
    const confidenceAdjustment =
      (1 - this.confidenceInterval) / Math.sqrt(responseCount + 1);
    return ability * (1 + confidenceAdjustment);
  }
}
```