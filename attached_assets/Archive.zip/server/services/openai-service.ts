import OpenAI from "openai";

if (!process.env.OPENAI_API_KEY) {
  throw new Error("OpenAI API key is required");
}

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

interface QuestionGenerationParams {
  domain: string;
  difficulty: "easy" | "medium" | "hard";
  conceptualLevel: "recall" | "application" | "analysis";
  previousQuestions?: string[];
}

export async function generateNCLEXQuestion(params: QuestionGenerationParams) {
  try {
    const prompt = `Generate one NCLEX-style question for the ${params.domain} domain with the following criteria:
    - Difficulty level: ${params.difficulty}
    - Cognitive level: ${params.conceptualLevel}
    - Format: Multiple choice with 4 options
    - Include: Question stem, all options (A through D), correct answer, and detailed explanation
    - Focus on clinical judgment and patient safety
    - Use current evidence-based practice

    Format the response as a JSON object with the following structure:
    {
      "question": "...",
      "options": ["A) ...", "B) ...", "C) ...", "D) ..."],
      "correctAnswer": "A", // just the letter
      "explanation": "...",
      "domain": "${params.domain}",
      "difficulty": "${params.difficulty}",
      "conceptualLevel": "${params.conceptualLevel}"
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content:
            "You are an expert NCLEX question writer with deep knowledge of nursing concepts and clinical judgment.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      temperature: 0.7,
      max_tokens: 1000,
    });

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error("No response from OpenAI");
    }

    return JSON.parse(content);
  } catch (error) {
    console.error("Error generating NCLEX question:", error);
    throw error;
  }
}

export async function validateQuestion(question: any) {
  try {
    const prompt = `Review this NCLEX question for accuracy, clarity, and alignment with current nursing standards:

    ${JSON.stringify(question, null, 2)}

    Analyze and respond with a JSON object:
    {
      "isValid": boolean,
      "issues": string[],
      "suggestions": string[]
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content:
            "You are an expert NCLEX reviewer who validates questions for accuracy and educational value.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      temperature: 0.3,
      max_tokens: 500,
    });

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error("No response from OpenAI");
    }

    return JSON.parse(content);
  } catch (error) {
    console.error("Error validating question:", error);
    throw error;
  }
}
