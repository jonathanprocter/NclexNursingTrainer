import { db } from "@db";
import { eq, desc } from "drizzle-orm";
import { userProgress, nclexDomains } from "@db/schema";
import { serviceMonitor } from "../lib/ai-service-monitor";
import { analyticsService } from "./analytics.service";
import OpenAI from "openai";
import Anthropic from "@anthropic-ai/sdk";
import { log } from "../vite";

interface AdaptivePath {
  recommendedPath: {
    currentDomainFocus: string[];
    suggestedDifficulty: "easy" | "medium" | "hard";
    estimatedTimeMinutes: number;
    studyPlan: {
      shortTerm: string[];
      longTerm: string[];
    };
  };
}

export class AILearningService {
  private openai: OpenAI | null = null;
  private anthropic: Anthropic | null = null;
  private readonly MAX_RETRIES = 3;
  private readonly RETRY_DELAY = 1000;
  protected initialized = false;
  private cleanupInProgress = false;
  private activeProvider: "openai" | "anthropic" | null = null;
  private static instance: AILearningService;

  private constructor() {
    log("[AILearningService] Constructor called");
  }

  public static getInstance(): AILearningService {
    if (!AILearningService.instance) {
      AILearningService.instance = new AILearningService();
    }
    return AILearningService.instance;
  }

  public async initialize(): Promise<boolean> {
    try {
      log("[AILearningService] Starting initialization");

      if (this.initialized) {
        log("[AILearningService] Already initialized");
        return true;
      }

      // Initialize AI providers with retry logic
      const initializeProvider = async (provider: "anthropic" | "openai"): Promise<boolean> => {
        let attempts = 0;
        while (attempts < this.MAX_RETRIES) {
          try {
            if (provider === "anthropic" && process.env.ANTHROPIC_API_KEY) {
              this.anthropic = new Anthropic({
                apiKey: process.env.ANTHROPIC_API_KEY,
              });
              log("[AILearningService] Anthropic initialized successfully");
              this.activeProvider = "anthropic";
              serviceMonitor.updateStatus("anthropic", true);
              return true;
            } else if (provider === "openai" && process.env.OPENAI_API_KEY) {
              this.openai = new OpenAI({
                apiKey: process.env.OPENAI_API_KEY,
              });
              log("[AILearningService] OpenAI initialized successfully");
              this.activeProvider = "openai";
              serviceMonitor.updateStatus("openai", true);
              return true;
            }
            log(`[AILearningService] No API key found for ${provider}`);
            return false;
          } catch (error) {
            attempts++;
            log(`[AILearningService] ${provider} initialization attempt ${attempts} failed: ${error}`);
            if (attempts === this.MAX_RETRIES) break;
            await new Promise((resolve) => setTimeout(resolve, this.RETRY_DELAY * attempts));
          }
        }
        return false;
      };

      // Try Anthropic first, then fall back to OpenAI
      if (await initializeProvider("anthropic")) {
        serviceMonitor.updateStatus("anthropic", true);
      } else if (await initializeProvider("openai")) {
        serviceMonitor.updateStatus("openai", true);
      } else {
        log("[AILearningService] No AI providers could be initialized");
        serviceMonitor.updateStatus("openai", false);
        return false;
      }

      this.initialized = true;
      log("[AILearningService] Successfully initialized AI service");
      return true;
    } catch (error) {
      log("[AILearningService] Failed to initialize AI services: " + error);
      this.initialized = false;
      serviceMonitor.updateStatus(this.activeProvider || "openai", false);
      return false;
    }
  }

  public async cleanup(): Promise<void> {
    if (!this.initialized || this.cleanupInProgress) {
      return;
    }

    try {
      this.cleanupInProgress = true;
      log("[AILearningService] Starting cleanup...");

      // Update service monitor status
      if (this.activeProvider) {
        serviceMonitor.updateStatus(this.activeProvider, false);
      }

      // Reset AI clients
      this.openai = null;
      this.anthropic = null;
      this.activeProvider = null;

      log("[AILearningService] Cleanup completed");
    } catch (error) {
      log("[AILearningService] Cleanup error: " + error);
      throw error;
    } finally {
      this.initialized = false;
      this.cleanupInProgress = false;
    }
  }

  public async generateAdaptivePath(userId: number): Promise<AdaptivePath> {
    try {
      // Get user's recent performance
      const recentProgress = await db.query.userProgress.findMany({
        where: eq(userProgress.userId, userId),
        orderBy: [desc(userProgress.timestamp)],
        limit: 10,
      });

      // Calculate recommended difficulty based on recent performance
      const correctAnswers = recentProgress.filter((p) => p.correct).length;
      const averageScore = (correctAnswers / recentProgress.length) * 100 || 0;

      const suggestedDifficulty: "easy" | "medium" | "hard" =
        averageScore > 80 ? "hard" : averageScore > 60 ? "medium" : "easy";

      // Get domains for focus
      const domainResults = await db.query.nclexDomains.findMany({
        limit: 3,
      });

      return {
        recommendedPath: {
          currentDomainFocus: domainResults.map((d) => d.name),
          suggestedDifficulty,
          estimatedTimeMinutes: this.calculateStudyTime(averageScore),
          studyPlan: {
            shortTerm: this.generateShortTermGoals(correctAnswers, recentProgress.length),
            longTerm: this.generateLongTermGoals(averageScore),
          },
        },
      };
    } catch (error) {
      log("[AILearningService] Error generating adaptive path: " + error);
      return {
        recommendedPath: {
          currentDomainFocus: ["Patient Care Management"],
          suggestedDifficulty: "medium",
          estimatedTimeMinutes: 30,
          studyPlan: {
            shortTerm: ["Review basics"],
            longTerm: ["Master core concepts"],
          },
        },
      };
    }
  }

  private calculateStudyTime(score: number): number {
    return Math.max(30, Math.round((1 - score / 100) * 120));
  }

  private generateShortTermGoals(correct: number, total: number): string[] {
    const accuracy = total === 0 ? 0 : (correct / total) * 100;
    if (accuracy < 60) {
      return [
        "Review fundamental concepts",
        "Focus on basic question types",
        "Practice time management",
      ];
    } else if (accuracy < 80) {
      return [
        "Practice complex scenarios",
        "Review recent weak areas",
        "Improve answer speed",
      ];
    } else {
      return [
        "Challenge with advanced questions",
        "Focus on time optimization",
        "Master test strategies",
      ];
    }
  }

  private generateLongTermGoals(score: number): string[] {
    if (score < 60) {
      return [
        "Build strong foundation",
        "Master core concepts",
        "Develop test-taking confidence",
      ];
    } else if (score < 80) {
      return [
        "Improve clinical reasoning",
        "Enhance critical thinking",
        "Perfect time management",
      ];
    } else {
      return [
        "Master advanced concepts",
        "Perfect test strategies",
        "Maintain high performance",
      ];
    }
  }
}

export const aiLearningService = AILearningService.getInstance();