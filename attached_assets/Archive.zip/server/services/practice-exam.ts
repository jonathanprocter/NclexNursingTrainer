import { db } from "@db";
import { questions } from "@db/schema";
import { eq, sql, and, not, inArray } from "drizzle-orm";
import * as crypto from 'crypto';
import { ComputerizedAdaptiveTestService } from './cat-service';

interface ExamConfig {
  duration: number;
  questionCount: number;
  difficultyDistribution: {
    easy: number;
    medium: number;
    hard: number;
  };
  userId: number;
  mode?: 'standard' | 'cat';
  adaptiveParams?: {
    initialAbility: number;
    targetStandardError: number;
    maxQuestions: number;
    minQuestions: number;
  };
}

interface FormattedQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: string;
  explanation?: string;
  difficulty?: string;
  tags?: string[];
}

interface ExamSession {
  id: string;
  userId: number;
  startTime: Date;
  questions: FormattedQuestion[];
  currentQuestionIndex: number;
  answers: Record<number, {
    answer: string;
    timeSpent: number;
    correct?: boolean;
    confidence?: number;
  }>;
  timeRemaining: number;
  completed: boolean;
  bookmarkedQuestions: Set<number>;
  mode: 'standard' | 'cat';
  catMetrics?: CATMetrics[];
  abilityEstimate?: number;
  standardError?: number;
  totalQuestions: number;
}

interface CATMetrics {
  questionId: number;
  difficulty: number;
  discriminationIndex: number;
  timeSpent: number;
  correctness: boolean;
  confidence?: number;
  abilityEstimate: number;
  standardError: number;
}

export class PracticeExamService {
  private activeExams: Map<string, ExamSession> = new Map();
  private catService: ComputerizedAdaptiveTestService;

  constructor() {
    this.catService = new ComputerizedAdaptiveTestService();
  }

  private readonly DEFAULT_CONFIG: ExamConfig = {
    duration: 360,
    questionCount: 75,
    difficultyDistribution: {
      easy: 0.33,
      medium: 0.34,
      hard: 0.33
    },
    userId: 0,
    mode: 'standard',
    adaptiveParams: {
      initialAbility: 0,
      targetStandardError: 0.3,
      maxQuestions: 145,
      minQuestions: 75
    }
  };

  private formatQuestion(question: any): FormattedQuestion {
    if (!question.scenario || !question.options || !question.correctAnswer) {
      throw new Error('Invalid question format: missing required fields');
    }

    return {
      id: question.id,
      question: question.scenario,
      options: question.options,
      correctAnswer: question.correct_answer,
      explanation: question.explanation,
      difficulty: question.difficulty,
      tags: question.metadata?.tags || []
    };
  }

  private async generateExamQuestions(config: ExamConfig): Promise<FormattedQuestion[]> {
    try {
      if (config.mode === 'cat') {
        const initialQuestions = await db.select()
          .from(questions)
          .where(and(
            eq(questions.difficulty, 'medium'),
            sql`${questions.scenario} IS NOT NULL`,
            sql`${questions.correct_answer} IS NOT NULL`,
            sql`array_length(${questions.options}, 1) > 0`
          ))
          .limit(1);

        if (!initialQuestions.length) {
          throw new Error('No suitable questions available for CAT');
        }

        return initialQuestions.map(q => this.formatQuestion(q));
      }

      const questionCounts = {
        easy: Math.floor(config.questionCount * config.difficultyDistribution.easy),
        medium: Math.floor(config.questionCount * config.difficultyDistribution.medium),
        hard: Math.floor(config.questionCount * config.difficultyDistribution.hard)
      };

      const [easyQuestions, mediumQuestions, hardQuestions] = await Promise.all([
        db.select()
          .from(questions)
          .where(and(
            eq(questions.difficulty, 'easy'),
            sql`${questions.scenario} IS NOT NULL`,
            sql`${questions.correct_answer} IS NOT NULL`,
            sql`array_length(${questions.options}, 1) > 0`
          ))
          .limit(questionCounts.easy),
        db.select()
          .from(questions)
          .where(and(
            eq(questions.difficulty, 'medium'),
            sql`${questions.scenario} IS NOT NULL`,
            sql`${questions.correct_answer} IS NOT NULL`,
            sql`array_length(${questions.options}, 1) > 0`
          ))
          .limit(questionCounts.medium),
        db.select()
          .from(questions)
          .where(and(
            eq(questions.difficulty, 'hard'),
            sql`${questions.scenario} IS NOT NULL`,
            sql`${questions.correct_answer} IS NOT NULL`,
            sql`array_length(${questions.options}, 1) > 0`
          ))
          .limit(questionCounts.hard)
      ]);

      const selectedQuestions = [
        ...easyQuestions,
        ...mediumQuestions,
        ...hardQuestions
      ];

      if (selectedQuestions.length < config.questionCount) {
        console.warn(`Warning: Only found ${selectedQuestions.length} valid questions`);
      }

      return this.shuffleArray(selectedQuestions.map(q => this.formatQuestion(q)));
    } catch (error) {
      console.error('Error generating exam questions:', error);
      throw new Error('Failed to generate exam questions');
    }
  }

  private shuffleArray<T>(array: T[]): T[] {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  }

  async createExam(config: Partial<ExamConfig> = {}): Promise<ExamSession> {
    try {
      const examConfig = {
        ...this.DEFAULT_CONFIG,
        ...config,
        questionCount: config.mode === 'cat' ?
          config.adaptiveParams?.maxQuestions || 145 : 75
      };

      const initialQuestions = await this.generateExamQuestions(examConfig);

      if (initialQuestions.length === 0) {
        throw new Error('No questions available for exam');
      }

      const examSession: ExamSession = {
        id: crypto.randomUUID(),
        userId: examConfig.userId,
        startTime: new Date(),
        questions: initialQuestions,
        currentQuestionIndex: 0,
        answers: {},
        timeRemaining: examConfig.duration * 60,
        completed: false,
        bookmarkedQuestions: new Set(),
        mode: examConfig.mode || 'standard',
        catMetrics: examConfig.mode === 'cat' ? [] : undefined,
        abilityEstimate: examConfig.mode === 'cat' ?
          examConfig.adaptiveParams?.initialAbility : undefined,
        standardError: examConfig.mode === 'cat' ? 1.0 : undefined,
        totalQuestions: examConfig.mode === 'cat' ?
          examConfig.adaptiveParams?.maxQuestions || 145 : 75
      };

      this.activeExams.set(examSession.id, examSession);
      return examSession;

    } catch (error) {
      console.error('Error creating practice exam:', error);
      throw new Error('Failed to create practice exam');
    }
  }

  async submitAnswer(
    examId: string,
    answer: string,
    timeSpent: number,
    confidence?: number
  ): Promise<{
    completed: boolean;
    nextQuestion: FormattedQuestion | null;
    timeRemaining: number;
    abilityEstimate?: number;
    standardError?: number;
  }> {
    const exam = this.activeExams.get(examId);
    if (!exam) {
      throw new Error('Exam not found');
    }

    const currentQuestion = exam.questions[exam.currentQuestionIndex];
    const isCorrect = currentQuestion.correctAnswer === answer;

    exam.answers[exam.currentQuestionIndex] = {
      answer,
      timeSpent,
      correct: isCorrect,
      confidence
    };

    if (exam.mode === 'cat') {
      const currentMetrics: CATMetrics = {
        questionId: currentQuestion.id,
        difficulty: this.getDifficultyValue(currentQuestion.difficulty || 'medium'),
        discriminationIndex: 1.0,
        timeSpent,
        correctness: isCorrect,
        confidence,
        abilityEstimate: exam.abilityEstimate || 0,
        standardError: exam.standardError || 1.0
      };

      exam.catMetrics?.push(currentMetrics);

      const updatedEstimates = this.catService.updateAbilityEstimate(
        exam.catMetrics || [],
        exam.abilityEstimate || 0,
        exam.standardError || 1.0
      );

      exam.abilityEstimate = updatedEstimates.abilityEstimate;
      exam.standardError = updatedEstimates.standardError;

      const nextQuestion = await this.getNextCATQuestion(exam);
      if (nextQuestion) {
        exam.questions.push(nextQuestion);
      }
    }

    exam.currentQuestionIndex++;
    exam.timeRemaining = Math.max(0, exam.timeRemaining - timeSpent);

    const isComplete =
      exam.mode === 'standard'
        ? exam.currentQuestionIndex >= exam.questions.length
        : exam.completed;

    if (isComplete || exam.timeRemaining <= 0) {
      exam.completed = true;
      return {
        completed: true,
        nextQuestion: null,
        timeRemaining: exam.timeRemaining,
        abilityEstimate: exam.abilityEstimate,
        standardError: exam.standardError
      };
    }

    return {
      completed: false,
      nextQuestion: exam.questions[exam.currentQuestionIndex],
      timeRemaining: exam.timeRemaining,
      abilityEstimate: exam.abilityEstimate,
      standardError: exam.standardError
    };
  }

  private getDifficultyValue(difficulty: string): number {
    switch (difficulty) {
      case 'easy': return -1;
      case 'medium': return 0;
      case 'hard': return 1;
      default: return 0;
    }
  }

  private async getNextCATQuestion(exam: ExamSession): Promise<FormattedQuestion | null> {
    if (!exam.catMetrics || !exam.abilityEstimate) return null;

    const targetDifficulty = this.catService.calculateNextQuestionDifficulty(
      exam.catMetrics,
      exam.abilityEstimate
    );

    const usedQuestionIds = exam.questions.map(q => q.id);
    const difficultyLevel = this.catService.mapDifficultyToLevel(targetDifficulty);

    return db.select()
      .from(questions)
      .where(and(
        eq(questions.difficulty, difficultyLevel),
        not(inArray(questions.id, usedQuestionIds))
      ))
      .limit(1)
      .then(nextQuestions => {
        if (nextQuestions.length === 0) {
          return db.select()
            .from(questions)
            .where(not(inArray(questions.id, usedQuestionIds)))
            .limit(1)
            .then(fallbackQuestions =>
              fallbackQuestions[0] ? this.formatQuestion(fallbackQuestions[0]) : null
            );
        }
        return nextQuestions[0] ? this.formatQuestion(nextQuestions[0]) : null;
      });
  }

  getExamStatus(examId: string): ExamSession | null {
    return this.activeExams.get(examId) || null;
  }

  getCurrentQuestion(examId: string): FormattedQuestion | null {
    const exam = this.activeExams.get(examId);
    if (!exam || exam.completed) return null;
    return exam.questions[exam.currentQuestionIndex];
  }

  toggleBookmark(examId: string, questionIndex: number): boolean {
    const exam = this.activeExams.get(examId);
    if (!exam) throw new Error('Exam not found');

    if (exam.bookmarkedQuestions.has(questionIndex)) {
      exam.bookmarkedQuestions.delete(questionIndex);
      return false;
    } else {
      exam.bookmarkedQuestions.add(questionIndex);
      return true;
    }
  }

  getBookmarkedQuestions(examId: string): FormattedQuestion[] {
    const exam = this.activeExams.get(examId);
    if (!exam) throw new Error('Exam not found');
    return Array.from(exam.bookmarkedQuestions).map(index => exam.questions[index]);
  }

  async completeExam(examId: string) {
    const exam = this.activeExams.get(examId);
    if (!exam) throw new Error('Exam not found');

    const totalTimeSpent = Object.values(exam.answers)
      .reduce((total, { timeSpent }) => total + timeSpent, 0);

    const questionResults = exam.questions.map((q, idx) => {
      const answer = exam.answers[idx];
      return {
        id: q.id,
        question: q.question,
        correctAnswer: q.correctAnswer,
        explanation: q.explanation,
        difficulty: q.difficulty,
        userAnswer: answer?.answer || '',
        timeSpent: answer?.timeSpent || 0,
        isCorrect: answer?.correct || false,
        confidence: answer?.confidence,
        isBookmarked: exam.bookmarkedQuestions.has(idx),
        options: q.options
      };
    });

    const correctAnswers = questionResults.filter(q => q.isCorrect).length;
    const score = (correctAnswers / questionResults.length) * 100;

    const difficultyPerformance = this.calculateDifficultyPerformance(questionResults);

    const catAnalytics = exam.mode === 'cat' && exam.catMetrics ? {
      adaptiveProgress: exam.catMetrics.map((metric, index) => ({
        questionNumber: index + 1,
        difficulty: metric.difficulty,
        timeSpent: metric.timeSpent,
        correctness: metric.correctness,
        confidence: metric.confidence,
        abilityEstimate: metric.abilityEstimate,
        standardError: metric.standardError
      })),
      finalAbilityEstimate: exam.abilityEstimate,
      finalStandardError: exam.standardError,
      consistencyMetrics: {
        averageTimePerQuestion: totalTimeSpent / exam.catMetrics.length,
        performanceStability: this.calculatePerformanceStability(exam.catMetrics)
      }
    } : undefined;

    this.activeExams.delete(examId);

    return {
      score,
      totalQuestions: exam.questions.length,
      correctAnswers,
      totalTimeSpent,
      averageTimePerQuestion: totalTimeSpent / exam.questions.length,
      questions: questionResults,
      difficultyPerformance,
      areasForImprovement: this.calculateAreasForImprovement(difficultyPerformance),
      bookmarkedQuestions: Array.from(exam.bookmarkedQuestions).map(idx => questionResults[idx]),
      timeAnalysis: {
        totalTime: totalTimeSpent,
        averageTimePerQuestion: totalTimeSpent / exam.questions.length,
        timeByDifficulty: difficultyPerformance
      },
      catAnalytics,
      passingLikelihood: this.calculatePassingLikelihood(
        exam.abilityEstimate || 0,
        exam.standardError || 1.0,
        score
      )
    };
  }

  private calculateDifficultyPerformance(results: any[]) {
    return this.calculatePerformanceMetrics(results, 'difficulty');
  }

  private calculatePerformanceMetrics(results: any[], field: string) {
    return results.reduce((acc: any, q) => {
      const key = q[field] || 'uncategorized';
      if (!acc[key]) {
        acc[key] = { total: 0, correct: 0, timeSpent: 0 };
      }
      acc[key].total++;
      if (q.isCorrect) acc[key].correct++;
      acc[key].timeSpent += q.timeSpent;
      return acc;
    }, {});
  }

  private calculateAreasForImprovement(performance: Record<string, { total: number; correct: number; timeSpent: number }>) {
    return Object.entries(performance)
      .map(([type, data]) => ({
        type,
        accuracy: (data.correct / data.total) * 100,
        averageTime: data.timeSpent / data.total
      }))
      .sort((a, b) => a.accuracy - b.accuracy)
      .slice(0, 3);
  }

  private calculatePerformanceStability(metrics: CATMetrics[]): number {
    if (metrics.length < 5) return 0;
    const last5Correct = metrics.slice(-5).filter(m => m.correctness).length;
    return last5Correct / 5;
  }

  private calculatePassingLikelihood(abilityEstimate: number, standardError: number, score: number): number {
    const passingThreshold = 0.5;
    const z = (abilityEstimate - passingThreshold) / standardError;
    const likelihood = 0.5 * (1 + this.erf(z / Math.sqrt(2)));
    return Math.min(Math.max(likelihood * 100, 0), 100);
  }

  private erf(x: number): number {
    const sign = Math.sign(x);
    x = Math.abs(x);
    const a1 = 0.254829592;
    const a2 = -0.284496736;
    const a3 = 1.421413741;
    const a4 = -1.453152027;
    const a5 = 1.061405429;
    const p = 0.3275911;
    const t = 1 / (1 + p * x);
    const y = 1 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);
    return sign * y;
  }
}

export const practiceExamService = new PracticeExamService();