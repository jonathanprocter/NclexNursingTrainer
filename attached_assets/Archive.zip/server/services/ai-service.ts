Here's the fixed code for the `/home/runner/workspace/server/services/ai-service.ts` file:

```typescript
import OpenAI from "openai";
import { db } from "@db";
import { questions, userProgress } from "@db/schema";
import { eq, desc } from "drizzle-orm";
import { serviceMonitor } from "./ai-service-monitor";
import { InitializationLock } from "../utils/initialization-lock";

const initLock = new InitializationLock();

export class NCLEXAIService {
  private openai?: OpenAI;
  private isInitialized = false;
  private readonly INIT_TIMEOUT = 30000;
  private readonly MAX_RETRIES = 3;
  private readonly fallbackEnabled = true;

  private async initializeFallback(): Promise<boolean> {
    console.log("Initializing in fallback mode...");
    this.isInitialized = true;
    serviceMonitor.updateStatus("openai", true);
    return true;
  }

  constructor() {
    this.setupErrorHandlers();
  }

  private setupErrorHandlers() {
    process.on("unhandledRejection", (error) => {
      console.error("Unhandled promise rejection in AI service:", error);
      serviceMonitor.updateStatus("openai", false);
    });
  }

  async initialize(): Promise<boolean> {
    try {
      if (this.isInitialized) return true;

      await initLock.acquire();

      if (!process.env.OPENAI_API_KEY) {
        console.warn("OPENAI_API_KEY not found, initializing in fallback mode");
        return this.fallbackEnabled ? await this.initializeFallback() : false;
      }

      console.log("Starting AI service initialization...");

      this.openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY,
      });

      // Test connection
      await this.openai.chat.completions.create({
        model: "gpt-4",
        messages: [{ role: "user", content: "Connection test" }],
        max_tokens: 5,
      });

      this.isInitialized = true;
      serviceMonitor.updateStatus("openai", true);
      console.log("OpenAI service initialized successfully");
      return true;
    } catch (error) {
      console.error("AI service initialization failed:", error);
      serviceMonitor.updateStatus("openai", false);
      return false;
    } finally {
      await initLock.release();
    }
  }

  async generatePersonalizedQuestion(
    userId: number,
    domain: string,
    difficulty: string,
  ): Promise<Question | null> {
    if (!this.isInitialized) {
      await this.initialize();
    }

    if (!this.openai) {
      throw new Error("OpenAI service not initialized");
    }

    try {
      // Get user's performance data
      const progress = await db.query.userProgress.findMany({
        where: eq(userProgress.userId, userId),
        orderBy: [desc(userProgress.timestamp)],
        limit: 50,
      });

      // Analyze weak areas
      const weakAreas = this.analyzeWeakAreas(progress);

      const prompt = `Generate an NCLEX-style question focusing on ${weakAreas.join(", ")} within the ${domain} domain.
      Difficulty level: ${difficulty}

      Create a scenario that:
      1. Tests clinical judgment
      2. Incorporates ${weakAreas[0]} concepts
      3. Requires critical thinking

      Format as JSON:
      {
        "scenario": "detailed clinical scenario",
        "options": ["four detailed answer options"],
        "correctAnswer": "correct option",
        "explanation": "detailed rationale",
        "conceptualBreakdown": {
          "keyPoints": ["key learning points"],
          "relatedConcepts": ["related topics"]
        }
      }`;

      const response = await this.openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content:
              "You are an expert NCLEX question writer specializing in clinical judgment scenarios.",
          },
          { role: "user", content: prompt },
        ],
        temperature: 0.7,
        response_format: { type: "json_object" },
      });

      if (!response.choices[0]?.message?.content) {
        throw new Error("No content in OpenAI response");
      }

      const questionData = JSON.parse(response.choices[0].message.content);

      // Store the generated question
      const [savedQuestion] = await db
        .insert(questions)
        .values({
          scenario: questionData.scenario,
          options: questionData.options,
          correctAnswer: questionData.correctAnswer,
          explanation: questionData.explanation,
          domainId: domain,
          difficulty: difficulty,
          conceptualLevel: "analysis",
          metadata: {
            conceptualBreakdown: questionData.conceptualBreakdown,
            targetedWeakAreas: weakAreas,
            generationPrompt: prompt,
          },
        })
        .returning();

      return {
        ...savedQuestion,
        id: savedQuestion.id,
      };
    } catch (error) {
      console.error("Error generating personalized question:", error);
      throw new Error(
        `Failed to generate question: ${error instanceof Error ? error.message : "Unknown error"}`,
      );
    }
  }

  private analyzeWeakAreas(progress: userProgress[]): string[] {
    // Group performance by domain
    const domainPerformance = progress.reduce(
      (acc, attempt) => {
        const domain = attempt.domain;
        if (!acc[domain]) {
          acc[domain] = { correct: 0, total: 0 };
        }
        acc[domain].total++;
        if (attempt.correct) {
          acc[domain].correct++;
        }
        return acc;
      },
      {} as Record<string, { correct: number; total: number }>,
    );

    // Find domains with < 70% accuracy
    const weakAreas = Object.entries(domainPerformance)
      .filter(([_, stats]) => stats.correct / stats.total < 0.7)
      .map(([domain]) => domain)
      .slice(0, 3);

    return weakAreas.length > 0 ? weakAreas : ["Patient Care Management"];
  }
}

export const aiService = new NCLEXAIService();
```

The main changes made to the code are:

1. Added `await` when releasing the `initLock` in the `finally` block of the `initialize` method to ensure proper asynchronous behavior.
2. Updated the `generatePersonalizedQuestion` method to return a `Promise<Question | null>` for better type safety.
3. Fixed the `analyzeWeakAreas` method to accept `userProgress[]` as the parameter type instead of `any[]`.

These changes improve code structure, error handling, and type safety while following best practices for TypeScript.