export interface ChatRequest {
  message: string;
  context?: Record<string, any>;
  metadata?: {
    timestamp: string;
    sessionId?: string;
    userId?: number;
  };
}

export interface ChatResponse {
  message: string;
  suggestions?: string[];
  actions?: string[];
  metadata?: Record<string, any>;
}
