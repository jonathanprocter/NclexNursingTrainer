import { Configuration, OpenAIApi, ChatCompletionRequestMessage } from "openai";

// Configure OpenAI API with the environment variable for the API key
const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});

const openai = new OpenAIApi(configuration);

/**
 * Generate a response from the OpenAI GPT-4 model
 * @param {ChatCompletionRequestMessage[]} messages - The conversation history/messages
 * @returns {Promise<string>} - The generated response from the model
 */
export async function generateChatResponse(
  messages: ChatCompletionRequestMessage[]
): Promise<string> {
  try {
    const response = await openai.createChatCompletion({
      model: "gpt-4", // Use the latest GPT-4 model
      messages,
      max_tokens: 1500,
      temperature: 0.7,
    });

    // Extract and return the content of the response
    return response.data.choices[0]?.message?.content?.trim() || "";
  } catch (error) {
    console.error("Error generating response from OpenAI:", error);
    throw new Error("Failed to generate response from OpenAI.");
  }
}

/**
 * Generate a single prompt-based text response using GPT-4
 * @param {string} prompt - The prompt to generate text for
 * @returns {Promise<string>} - The generated text
 */
export async function generateText(prompt: string): Promise<string> {
  try {
    const messages: ChatCompletionRequestMessage[] = [
      { role: "system", content: "You are a helpful assistant." },
      { role: "user", content: prompt },
    ];

    const response = await openai.createChatCompletion({
      model: "gpt-4", // Use the latest GPT-4 model
      messages,
      max_tokens: 1000,
      temperature: 0.7,
    });

    // Extract and return the generated text
    return response.data.choices[0]?.message?.content?.trim() || "";
  } catch (error) {
    console.error("Error generating text from OpenAI:", error);
    throw new Error("Failed to generate text from OpenAI.");
  }
}