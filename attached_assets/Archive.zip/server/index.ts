import express from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { serviceIntegrator } from "./services/service-integrator";
import { InitializationLock } from "./utils/initialization-lock";
import { EventEmitter } from "events";
import { exec } from "child_process";

// Increase max listeners to handle multiple error events
EventEmitter.defaultMaxListeners = 15;

const initLock = new InitializationLock();
const PORT = 5000;

// Singleton flag to prevent multiple initializations
let isInitialized = false;

function killProcessOnPort(port: number): Promise<void> {
  return new Promise((resolve, reject) => {
    exec(`lsof -i :${port} -t | xargs kill -9`, (err) => {
      if (err) {
        // If no process found or other error, just resolve
        resolve();
      } else {
        log(`Terminated existing process on port ${port}`);
        resolve();
      }
    });
  });
}

async function initializeApp() {
  if (isInitialized) {
    log("App is already initialized.");
    return null;
  }

  const app = express();

  // Basic middleware setup
  app.use(express.json());
  app.use(express.urlencoded({ extended: false }));

  // Enhanced request logging middleware
  app.use((req, res, next) => {
    const start = Date.now();
    const path = req.path;
    let capturedJsonResponse: Record<string, any> | undefined = undefined;

    const originalResJson = res.json;
    res.json = function (bodyJson, ...args) {
      capturedJsonResponse = bodyJson;
      return originalResJson.apply(res, [bodyJson, ...args]);
    };

    res.on("finish", () => {
      const duration = Date.now() - start;
      if (path.startsWith("/api")) {
        let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
        if (capturedJsonResponse) {
          logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
        }
        if (logLine.length > 80) {
          logLine = logLine.slice(0, 79) + "…";
        }
        log(logLine);
      }
    });

    next();
  });

  isInitialized = true;
  return app;
}

async function startServer() {
  try {
    log('Starting server initialization...');
    await initLock.acquire('server-startup');

    try {
      // Validate environment variables
      const requiredEnvVars = ["DATABASE_URL"];
      requiredEnvVars.forEach((key) => {
        if (!process.env[key]) {
          throw new Error(`Missing environment variable: ${key}`);
        }
      });

      // Try to kill any existing process on our port
      await killProcessOnPort(PORT);

      // Initialize services
      log('Initializing services...');
      const servicesInitialized = await serviceIntegrator.initialize();
      if (!servicesInitialized) {
        throw new Error('Failed to initialize core services');
      }
      log('Services initialized successfully');

      const app = await initializeApp();
      if (!app) {
        throw new Error('Failed to initialize application');
      }

      const server = await registerRoutes(app);
      log('Routes registered successfully');

      if (process.env.NODE_ENV === "development") {
        await setupVite(app, server);
        log('Vite development server setup complete');
      }

      // Enhanced error handling for port conflicts
      return new Promise((resolve, reject) => {
        server.on("error", (error: any) => {
          if (error.code === "EADDRINUSE") {
            log(`Error: Port ${PORT} is already in use`);
            reject(new Error(`Port ${PORT} is already in use. Please free up the port and try again.`));
          } else {
            log(`Server error: ${error.message}`);
            reject(error);
          }
        });

        server.listen(PORT, "0.0.0.0", () => {
          log(`Server running on http://0.0.0.0:${PORT}`);
          resolve(server);
        });
      });

    } finally {
      initLock.release('server-startup');
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    log(`Failed to start server: ${errorMessage}`);
    initLock.release('server-startup');
    throw error;
  }
}

// Process-level error handlers
process.on("unhandledRejection", (reason, promise) => {
  log(`Unhandled Rejection at: ${promise}\nReason: ${reason}`);
});

process.on("uncaughtException", (error) => {
  log(`Uncaught Exception: ${error.message}`);
  // Give time for logging before exit
  setTimeout(() => process.exit(1), 1000);
});

// Graceful shutdown handlers
process.on("SIGTERM", async () => {
  log("Received SIGTERM signal. Starting graceful shutdown...");
  await serviceIntegrator.cleanup();
  process.exit(0);
});

process.on("SIGINT", async () => {
  log("Received SIGINT signal. Starting graceful shutdown...");
  await serviceIntegrator.cleanup();
  process.exit(0);
});

// Start server with enhanced error handling
startServer().catch((error) => {
  log(`Fatal error during startup: ${error.message}`);
  process.exit(1);
});

export default startServer;