import { Request, Response, NextFunction } from "express";
import { serviceMonitor } from "../services/ai-service-monitor";

interface RateLimitWindow {
  timestamp: number;
  count: number;
}

const rateLimits: Map<string, RateLimitWindow> = new Map();
const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute
const RATE_LIMIT_MAX_REQUESTS = 30; // 30 requests per minute

export const rateLimit = (req: Request, res: Response, next: NextFunction) => {
  const clientId = req.ip || "anonymous";
  const now = Date.now();
  const windowData = rateLimits.get(clientId) || { timestamp: now, count: 0 };

  // Reset window if it's expired
  if (now - windowData.timestamp > RATE_LIMIT_WINDOW) {
    windowData.timestamp = now;
    windowData.count = 0;
  }

  // Check rate limit
  if (windowData.count >= RATE_LIMIT_MAX_REQUESTS) {
    return res.status(429).json({
      error: "Rate limit exceeded",
      message: "Too many requests, please try again later",
      resetIn: RATE_LIMIT_WINDOW - (now - windowData.timestamp),
    });
  }

  // Update rate limit counter
  windowData.count++;
  rateLimits.set(clientId, windowData);

  next();
};

export const circuitBreaker = (
  req: Request,
  res: Response,
  next: NextFunction,
) => {
  const status = serviceMonitor.getStatus();

  // Check if service is experiencing issues
  if (status.consecutiveErrors >= 5) {
    return res.status(503).json({
      error: "Service Temporarily Unavailable",
      message:
        "The AI service is currently experiencing issues, please try again later",
      status: {
        consecutiveErrors: status.consecutiveErrors,
        lastCheck: status.lastCheck,
        averageResponseTime: status.averageResponseTime,
      },
    });
  }

  next();
};

// Clean up old rate limit entries periodically
setInterval(() => {
  const now = Date.now();
  for (const [clientId, windowData] of rateLimits.entries()) {
    if (now - windowData.timestamp > RATE_LIMIT_WINDOW) {
      rateLimits.delete(clientId);
    }
  }
}, RATE_LIMIT_WINDOW);