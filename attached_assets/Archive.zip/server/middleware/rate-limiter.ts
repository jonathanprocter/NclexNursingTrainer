import { Request, Response, NextFunction } from "express";
import { config } from "../config";
import { log } from "../services/logging";

class RateLimiter {
  private requests = new Map<string, number[]>();

  constructor(
    private windowMs: number,
    private maxRequests: number,
  ) {}

  public middleware(req: Request, res: Response, next: NextFunction): void {
    const ip = req.ip;
    const now = Date.now();

    if (!this.requests.has(ip)) {
      this.requests.set(ip, [now]);
      next();
      return;
    }

    const requests = this.requests.get(ip)!;
    const windowStart = now - this.windowMs;
    const recentRequests = requests.filter((time) => time > windowStart);

    if (recentRequests.length >= this.maxRequests) {
      log.warn("Rate limit exceeded", { ip });
      res.status(429).json({ error: "Too many requests" });
      return;
    }

    recentRequests.push(now);
    this.requests.set(ip, recentRequests);
    next();
  }
}

export const apiLimiter = new RateLimiter(
  config.RATE_LIMIT_WINDOW,
  config.RATE_LIMIT_MAX,
);