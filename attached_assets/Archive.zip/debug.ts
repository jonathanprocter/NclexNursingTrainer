import fs from "fs";
import path from "path";
import ts from "typescript";

function validateFile(filePath: string) {
  try {
    const content = fs.readFileSync(filePath, "utf8");
    ts.transpileModule(content, { compilerOptions: { module: ts.ModuleKind.CommonJS } });
    console.log(`✓ Validated: ${filePath}`);
  } catch (error) {
    console.error(`✗ Error in ${filePath}:`, error.message);
  }
}

function scanDirectory(directory: string) {
  try {
    const files = fs.readdirSync(directory);
    files.forEach((file) => {
      const fullPath = path.join(directory, file);
      if (fs.statSync(fullPath).isDirectory()) {
        scanDirectory(fullPath);
      } else if (fullPath.endsWith(".ts") || fullPath.endsWith(".tsx")) {
        validateFile(fullPath);
      }
    });
  } catch (error) {
    console.error(`Error scanning directory ${directory}:`, error.message);
  }
}

console.log("Starting TypeScript file validation...");
scanDirectory("./client/src");
scanDirectory("./server");
scanDirectory("./db");
console.log("Validation complete.");
