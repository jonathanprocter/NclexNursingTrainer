import { db } from "@db";
import { eq, and, desc } from "drizzle-orm";
import {
  users,
  studySessions,
  learningContent,
  progressTracking,
  aiRecommendations,
  type User,
  type ProgressTracking,
  type StudySession,
  type InsertProgressTracking,
  emotionalStateEnum,
  cognitiveComplexityEnum,
  performanceAnalytics,
} from "@db/schema";

interface EmotionalMetrics {
  stressLevel: number;
  confidence: number;
  engagementScore: number;
  adaptiveRecommendations: string[];
  currentState: typeof emotionalStateEnum;
  lastAssessment: Date;
}

interface PerformanceMetrics {
  accuracy: number;
  speed: number;
  comprehension: number;
  retentionScore: number;
  cognitiveLevel: typeof cognitiveComplexityEnum;
}

interface AIRecommendation {
  nextTopics: string[];
  adjustedDifficulty: string;
  personalizedStrategies: string[];
}

interface ProgressMetrics {
  emotionalMetrics: EmotionalMetrics;
  performanceMetrics: PerformanceMetrics;
  aiRecommendations: AIRecommendation;
}

export class ProgressTrackingService {
  async trackProgress(userId: number): Promise<ProgressMetrics> {
    const user = await this.getUserProfile(userId);
    const currentSession = await this.getCurrentOrCreateSession(userId);
    const emotionalMetrics = await this.analyzeEmotionalState(userId);
    const performanceMetrics = await this.calculatePerformanceMetrics(userId);
    const aiRecommendations = await this.generateAIRecommendations(
      userId,
      emotionalMetrics,
      performanceMetrics,
    );

    // Update user's emotional metrics
    await db
      .update(users)
      .set({
        emotionalMetrics: {
          stressLevel: emotionalMetrics.stressLevel,
          confidence: emotionalMetrics.confidence,
          engagementScore: emotionalMetrics.engagementScore,
          lastAssessment: new Date(),
          adaptiveRecommendations: emotionalMetrics.adaptiveRecommendations,
        },
      })
      .where(eq(users.id, userId));

    // Record progress with emotional context
    const progressRecord: InsertProgressTracking = {
      userId,
      contentId: parseInt(currentSession.id.toString()),
      emotionalState: emotionalMetrics.currentState,
      cognitiveLevel: performanceMetrics.cognitiveLevel,
      performance: {
        accuracy: performanceMetrics.accuracy,
        timeSpent: performanceMetrics.speed,
        emotionalResponse: "normal",
        comprehensionScore: performanceMetrics.comprehension,
      },
      aiAnalysis: {
        learningPatterns: this.analyzeLearningPatterns(performanceMetrics),
        recommendedAdjustments: aiRecommendations.personalizedStrategies,
        nextStepPredictions: this.predictNextSteps(
          performanceMetrics,
          emotionalMetrics,
        ),
      },
    };

    await db.insert(progressTracking).values(progressRecord);

    return {
      emotionalMetrics,
      performanceMetrics,
      aiRecommendations,
    };
  }

  async trackProgressSimple(userId: number) {
    const progress = await db.query.performanceAnalytics.findFirst({
      where: eq(performanceAnalytics.userId, userId),
    });

    return {
      userId,
      progress: progress?.score || 0,
      performance: {
        accuracy: progress?.accuracy || 0,
        speed: progress?.completionTime || 0,
        consistency: progress?.consistency || 0,
      },
      lastUpdated: progress?.updatedAt || new Date(),
    };
  }

  private async getUserProfile(userId: number): Promise<User> {
    const user = await db.query.users.findFirst({
      where: eq(users.id, userId),
    });
    if (!user) throw new Error("User not found");
    return user;
  }

  private async getCurrentOrCreateSession(
    userId: number,
  ): Promise<StudySession> {
    const activeSession = await db.query.studySessions.findFirst({
      where: and(
        eq(studySessions.userId, userId),
        eq(studySessions.endTime, null),
      ),
    });

    if (activeSession) return activeSession;

    const [newSession] = await db
      .insert(studySessions)
      .values({
        userId,
        startTime: new Date(),
        emotionalStates: {
          preSession: emotionalStateEnum.focused,
          postSession: null,
          stressIndicators: [],
        },
      })
      .returning();

    return newSession;
  }

  private async analyzeEmotionalState(
    userId: number,
  ): Promise<EmotionalMetrics> {
    const recentProgress = await db
      .select()
      .from(progressTracking)
      .where(eq(progressTracking.userId, userId))
      .orderBy(desc(progressTracking.timestamp))
      .limit(5);

    // Analyze emotional patterns and stress indicators
    const emotionalPatterns = recentProgress.map(
      (p) => p.emotionalState as typeof emotionalStateEnum,
    );
    const stressLevel = this.calculateStressLevel(emotionalPatterns);
    const confidence = this.calculateConfidence(recentProgress);
    const engagementScore = this.calculateEngagement(recentProgress);
    const currentState = this.determineCurrentEmotionalState(emotionalPatterns);

    return {
      stressLevel,
      confidence,
      engagementScore,
      adaptiveRecommendations: this.generateEmotionalRecommendations(
        stressLevel,
        confidence,
      ),
      currentState,
      lastAssessment: new Date(),
    };
  }

  private async calculatePerformanceMetrics(
    userId: number,
  ): Promise<PerformanceMetrics> {
    const recentProgress = await db
      .select()
      .from(progressTracking)
      .where(eq(progressTracking.userId, userId))
      .orderBy(desc(progressTracking.timestamp))
      .limit(10);

    const performance = recentProgress.map((p) => ({
      accuracy: p.performance.accuracy,
      speed: p.performance.timeSpent,
      comprehension: p.performance.comprehensionScore,
      retentionScore: 0,
      cognitiveLevel: p.cognitiveLevel as typeof cognitiveComplexityEnum,
    }));

    return {
      accuracy: this.calculateAverageAccuracy(performance),
      speed: this.calculateAverageSpeed(performance),
      comprehension: this.calculateComprehension(performance),
      retentionScore: this.calculateRetention(performance),
      cognitiveLevel: this.determineCognitiveLevel(performance),
    };
  }

  private async generateAIRecommendations(
    userId: number,
    emotionalMetrics: EmotionalMetrics,
    performanceMetrics: PerformanceMetrics,
  ): Promise<AIRecommendation> {
    // Generate personalized recommendations
    const recommendations = {
      nextTopics: this.determineNextTopics(performanceMetrics),
      adjustedDifficulty: this.adjustDifficulty(
        performanceMetrics,
        emotionalMetrics,
      ),
      personalizedStrategies: this.generateStrategies(
        emotionalMetrics,
        performanceMetrics,
      ),
    };

    // Record AI recommendations
    await db.insert(aiRecommendations).values({
      userId,
      contentId: 1, // Default content ID
      recommendationType: "adaptive_learning",
      recommendation: recommendations,
      emotionalContext: emotionalMetrics.currentState,
      cognitiveContext: performanceMetrics.cognitiveLevel,
      effectiveness: null,
      createdAt: new Date(),
    });

    return recommendations;
  }

  // Helper methods for emotional analysis
  private calculateStressLevel(
    emotionalPatterns: Array<typeof emotionalStateEnum>,
  ): number {
    const stressIndicators = emotionalPatterns.filter(
      (state) =>
        state === emotionalStateEnum.anxious ||
        state === emotionalStateEnum.overwhelmed,
    ).length;
    return (stressIndicators / emotionalPatterns.length) * 100;
  }

  private calculateConfidence(progress: ProgressTracking[]): number {
    if (!progress.length) return 0;
    return (
      progress.reduce((acc, p) => acc + (p.performance?.accuracy || 0), 0) /
      progress.length
    );
  }

  private calculateEngagement(progress: ProgressTracking[]): number {
    if (!progress.length) return 50;
    return (
      progress.reduce(
        (acc, p) => acc + (p.performance?.comprehensionScore || 0),
        0,
      ) / progress.length
    );
  }

  private generateEmotionalRecommendations(
    stressLevel: number,
    confidence: number,
  ): string[] {
    const recommendations: string[] = [];
    if (stressLevel > 70) recommendations.push("Take a short break");
    if (confidence < 50) recommendations.push("Review fundamental concepts");
    return recommendations;
  }

  private determineCurrentEmotionalState(
    emotionalPatterns: Array<typeof emotionalStateEnum>,
  ): typeof emotionalStateEnum {
    if (!emotionalPatterns.length) return emotionalStateEnum.focused;

    const counts = new Map<typeof emotionalStateEnum, number>();
    emotionalPatterns.forEach((state) => {
      counts.set(state, (counts.get(state) || 0) + 1);
    });

    let currentState = emotionalStateEnum.focused;
    let maxCount = 0;

    counts.forEach((count, state) => {
      if (count > maxCount) {
        maxCount = count;
        currentState = state;
      }
    });

    return currentState;
  }

  // Helper methods for performance analysis
  private calculateAverageAccuracy(performance: PerformanceMetrics[]): number {
    if (!performance.length) return 0;
    return (
      performance.reduce((acc, p) => acc + p.accuracy, 0) / performance.length
    );
  }

  private calculateAverageSpeed(performance: PerformanceMetrics[]): number {
    if (!performance.length) return 0;
    return (
      performance.reduce((acc, p) => acc + p.speed, 0) / performance.length
    );
  }

  private calculateComprehension(performance: PerformanceMetrics[]): number {
    if (!performance.length) return 0;
    return (
      performance.reduce((acc, p) => acc + p.comprehension, 0) /
      performance.length
    );
  }

  private calculateRetention(performance: PerformanceMetrics[]): number {
    if (!performance.length) return 0;
    return (
      performance.reduce((acc, p) => acc + p.retentionScore, 0) /
      performance.length
    );
  }

  private determineCognitiveLevel(
    performance: PerformanceMetrics[],
  ): typeof cognitiveComplexityEnum {
    const avgAccuracy = this.calculateAverageAccuracy(performance);
    if (avgAccuracy >= 90) return cognitiveComplexityEnum.synthesis;
    if (avgAccuracy >= 80) return cognitiveComplexityEnum.evaluation;
    if (avgAccuracy >= 70) return cognitiveComplexityEnum.analysis;
    if (avgAccuracy >= 60) return cognitiveComplexityEnum.application;
    return cognitiveComplexityEnum.recall;
  }

  // AI recommendation helper methods
  private determineNextTopics(performance: PerformanceMetrics): string[] {
    return ["Advanced Clinical Judgment", "Complex Patient Care"];
  }

  private adjustDifficulty(
    performance: PerformanceMetrics,
    emotional: EmotionalMetrics,
  ): string {
    const avgPerformance =
      (performance.accuracy + performance.comprehension) / 2;
    const stressAdjustment = emotional.stressLevel > 70 ? -1 : 0;

    if (avgPerformance >= 85) return "challenging";
    if (avgPerformance >= 70) return "moderate";
    return "supportive";
  }

  private generateStrategies(
    emotional: EmotionalMetrics,
    performance: PerformanceMetrics,
  ): string[] {
    const strategies: string[] = [];

    if (emotional.stressLevel > 70) {
      strategies.push("Implement stress-reduction techniques");
      strategies.push("Break content into smaller chunks");
    }

    if (performance.accuracy < 70) {
      strategies.push("Focus on foundational concepts");
      strategies.push("Increase practice frequency");
    }

    return strategies;
  }

  private analyzeLearningPatterns(performance: PerformanceMetrics): any[] {
    return [
      {
        pattern: "initial",
        metrics: {
          accuracy: performance.accuracy,
          speed: performance.speed,
          comprehension: performance.comprehension,
        },
      },
    ];
  }

  private predictNextSteps(
    performance: PerformanceMetrics,
    emotional: EmotionalMetrics,
  ): any[] {
    return [
      {
        type: "recommendation",
        cognitiveLevel: performance.cognitiveLevel,
        emotionalState: emotional.currentState,
        suggestedPath: this.determineNextTopics(performance),
      },
    ];
  }
}

export const progressTrackingService = new ProgressTrackingService();
