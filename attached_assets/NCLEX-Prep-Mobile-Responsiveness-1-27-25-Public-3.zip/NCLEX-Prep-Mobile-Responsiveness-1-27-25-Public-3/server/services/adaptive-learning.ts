import { AdaptiveLearningService } from "./ai-learning.service";

// Re-export the consolidated service
export { AdaptiveLearningService } from "./ai-learning.service";
export const createAdaptiveLearningService = (userId: number): AdaptiveLearningService => {
  return new AdaptiveLearningService(userId);
};