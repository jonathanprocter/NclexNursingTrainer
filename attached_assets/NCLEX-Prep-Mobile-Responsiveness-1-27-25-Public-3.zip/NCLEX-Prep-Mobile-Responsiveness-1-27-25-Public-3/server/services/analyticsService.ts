import { db } from "@db";
import { eq, desc } from "drizzle-orm";
import { userProgress } from "@db/schema";

interface MoodAnalytics {
  moodScores: number[];
  focusLevels: number[];
  studyEfficiency: number;
  recommendations: string[];
}

interface StudyMetrics {
  totalStudyTime: number;
  totalQuestions: number;
  averageScore: number;
  performanceTrend: number[];
  strengths: string[];
  weaknesses: string[];
  recommendations: string[];
  streak: number;
  lastActive: string;
}

class AnalyticsService {
  async getMoodAnalytics(userId: number): Promise<MoodAnalytics | null> {
    try {
      const data = await db
        .select()
        .from(userProgress)
        .where(eq(userProgress.userId, userId))
        .orderBy(desc(userProgress.timestamp));

      const moodScores = data.map((d) => d.learningMetrics?.cognitiveLoad || 0);
      const focusLevels = data.map((d) => d.learningMetrics?.masteryLevel || 0);
      const studyEfficiency =
        data.reduce(
          (acc, d) => acc + (d.learningMetrics?.retentionRate || 0),
          0,
        ) / data.length || 0;

      return {
        moodScores,
        focusLevels,
        studyEfficiency,
        recommendations: [],
      };
    } catch (error) {
      console.error("Error getting mood analytics:", error);
      return null;
    }
  }

  async getStudyMetrics(userId: number): Promise<StudyMetrics | null> {
    try {
      const progress = await db
        .select()
        .from(userProgress)
        .where(eq(userProgress.userId, userId));

      if (progress.length === 0) {
        return null;
      }

      const totalStudyTime = progress.reduce(
        (acc, p) => acc + (p.timeSpent || 0),
        0,
      );
      const totalQuestions = progress.length;
      const averageScore =
        (progress.filter((p) => p.correct).length / totalQuestions) * 100;

      return {
        totalStudyTime,
        totalQuestions,
        averageScore,
        performanceTrend: [],
        strengths: [],
        weaknesses: [],
        recommendations: [],
        streak: 0,
        lastActive: new Date().toISOString(),
      };
    } catch (error) {
      console.error("Error getting study metrics:", error);
      return null;
    }
  }
}

export default new AnalyticsService();