import { db } from "@db";
import { eq } from "drizzle-orm";
import { desc } from "drizzle-orm";
import { userProgress } from "@db/schema";

interface StudyPreferences {
  targetScore: number;
  availableTime: number;
  focusAreas?: string[];
  learningStyle?: string;
}

interface StudyModule {
  id: string;
  name: string;
  duration: number;
  priority: "high" | "medium" | "low";
  type: string;
}

interface StudyPath {
  modules: StudyModule[];
  estimatedCompletionTime: number;
  recommendedSchedule: {
    date: string;
    modules: string[];
  }[];
}

class StudyPathService {
  async generateStudyPath(
    userId: number,
    preferences: StudyPreferences,
  ): Promise<StudyPath> {
    try {
      // Get user progress data
      const progress = await db
        .select()
        .from(userProgress)
        .where(eq(userProgress.userId, userId))
        .orderBy(desc(userProgress.timestamp))
        .limit(30);

      // Calculate priority areas based on performance
      const priorityAreas = this.calculatePriorityAreas(progress);

      // Generate study modules
      const modules = this.generateStudyModules(
        preferences.availableTime,
        priorityAreas,
        preferences.focusAreas,
      );

      // Create recommended schedule
      const schedule = this.createSchedule(modules, preferences.availableTime);

      return {
        modules,
        estimatedCompletionTime: modules.reduce(
          (acc, m) => acc + m.duration,
          0,
        ),
        recommendedSchedule: schedule,
      };
    } catch (error) {
      console.error("Error generating study path:", error);
      throw new Error("Failed to generate study path");
    }
  }

  private calculatePriorityAreas(
    progress: (typeof userProgress.$inferSelect)[],
  ): string[] {
    const areaScores: Record<string, { correct: number; total: number }> = {};

    progress.forEach((p) => {
      const domain = `Domain_${p.questionId}`; // Map question ID to domain
      if (!areaScores[domain]) {
        areaScores[domain] = { correct: 0, total: 0 };
      }
      areaScores[domain].total++;
      if (p.correct) {
        areaScores[domain].correct++;
      }
    });

    return Object.entries(areaScores)
      .map(([domain, stats]) => ({
        domain,
        proficiency: stats.correct / stats.total,
      }))
      .sort((a, b) => a.proficiency - b.proficiency)
      .slice(0, 3)
      .map((a) => a.domain);
  }

  private generateStudyModules(
    availableTime: number,
    priorityAreas: string[],
    focusAreas?: string[],
  ): StudyModule[] {
    const modules: StudyModule[] = [];
    let remainingTime = availableTime;

    // Add high-priority modules for weak areas
    priorityAreas.forEach((area) => {
      if (remainingTime >= 45) {
        modules.push({
          id: `${area}-${Date.now()}`,
          name: `${area} Review`,
          duration: 45,
          priority: "high",
          type: "review",
        });
        remainingTime -= 45;
      }
    });

    // Add medium-priority practice modules
    if (remainingTime >= 30) {
      modules.push({
        id: `practice-${Date.now()}`,
        name: "Practice Questions",
        duration: 30,
        priority: "medium",
        type: "practice",
      });
      remainingTime -= 30;
    }

    // Add low-priority supplemental modules
    if (remainingTime >= 20) {
      modules.push({
        id: `supplemental-${Date.now()}`,
        name: "Supplemental Material",
        duration: 20,
        priority: "low",
        type: "supplement",
      });
    }

    return modules;
  }

  private createSchedule(modules: StudyModule[], availableTime: number) {
    const schedule = [];
    const today = new Date();
    let currentDate = today;
    let dailyModules: string[] = [];
    let dailyTime = 0;

    modules.forEach((module) => {
      if (dailyTime + module.duration > availableTime) {
        schedule.push({
          date: currentDate.toISOString().split("T")[0],
          modules: [...dailyModules],
        });
        currentDate = new Date(currentDate.getTime() + 24 * 60 * 60 * 1000);
        dailyModules = [];
        dailyTime = 0;
      }
      dailyModules.push(module.id);
      dailyTime += module.duration;
    });

    if (dailyModules.length > 0) {
      schedule.push({
        date: currentDate.toISOString().split("T")[0],
        modules: dailyModules,
      });
    }

    return schedule;
  }
}

export const studyPathService = new StudyPathService();
