import { db } from "@db";
import { eq, desc } from "drizzle-orm";
import { userProgress } from "@db/schema";
import { log } from "../vite";

interface StudyMetrics {
  totalQuestions: number;
  correctAnswers: number;
  accuracy: number;
  averageResponseTime: number;
  lastActive: string;
}

interface AnalyticsData {
  overallProgress: number;
  recentPerformance: number;
  domainPerformance: Array<{
    domain: string;
    accuracy: number;
    totalAttempts: number;
    status: "strong" | "needs_improvement";
  }>;
  learningTrend: "improving" | "declining" | "stable";
}

type UserProgressType = typeof userProgress.$inferSelect;

export class AnalyticsService {
  private initialized = false;
  private cleanupInProgress = false;

  async initialize(): Promise<boolean> {
    try {
      if (this.initialized) {
        log("[AnalyticsService] Already initialized");
        return true;
      }

      log("[AnalyticsService] Verifying database connection...");
      await db.query.userProgress.findMany({
        limit: 1,
        orderBy: [desc(userProgress.timestamp)],
      });

      this.initialized = true;
      log("[AnalyticsService] Successfully initialized");
      return true;
    } catch (error) {
      log("[AnalyticsService] Failed to initialize: " + (error instanceof Error ? error.message : String(error)));
      this.initialized = false;
      return false;
    }
  }

  async cleanup(): Promise<void> {
    if (!this.initialized || this.cleanupInProgress) {
      return;
    }

    try {
      this.cleanupInProgress = true;
      log("[AnalyticsService] Starting cleanup...");
      this.initialized = false;
      log("[AnalyticsService] Cleanup completed");
    } catch (error) {
      log("[AnalyticsService] Cleanup error: " + (error instanceof Error ? error.message : String(error)));
      throw error;
    } finally {
      this.cleanupInProgress = false;
    }
  }

  async getStudyPatterns(userId: number) {
    try {
      const progress = await db.query.userProgress.findMany({
        where: eq(userProgress.userId, userId),
        orderBy: [desc(userProgress.timestamp)],
      });

      const patterns = {
        accuracy: this.calculateOverallProgress(progress),
        trend: this.calculateLearningTrend(progress),
        lastActive: progress[0]?.timestamp || new Date(),
      };

      return patterns;
    } catch (error) {
      log("[AnalyticsService] Error getting study patterns: " + (error instanceof Error ? error.message : String(error)));
      throw error;
    }
  }

  private generateRecommendations(result: UserProgressType): string[] {
    const recommendations = [];
    if (!result.correct) {
      recommendations.push(
        "Review core concepts",
        "Practice additional questions",
        "Study related clinical scenarios"
      );
    }
    return recommendations;
  }

  private calculateOverallProgress(progress: UserProgressType[]): number {
    if (!progress.length) return 0;
    return (progress.filter((p) => p.correct).length / progress.length) * 100;
  }

  private calculateLearningTrend(progress: UserProgressType[]): "improving" | "declining" | "stable" {
    if (progress.length < 2) return "stable";

    const scores = progress.map(p => p.correct ? 1 : 0);
    let trend = 0;

    for (let i = 1; i < scores.length; i++) {
      trend += scores[i] - scores[i - 1];
    }

    return trend > 0 ? "improving" : trend < 0 ? "declining" : "stable";
  }

  async getAdvancedAnalytics(userId: number): Promise<AnalyticsData> {
    try {
      const progress = await db.query.userProgress.findMany({
        where: eq(userProgress.userId, userId),
        orderBy: [desc(userProgress.timestamp)],
        limit: 50,
      });

      if (!progress.length) {
        return {
          overallProgress: 0,
          recentPerformance: 0,
          domainPerformance: [],
          learningTrend: "stable",
        };
      }

      const recentProgress = progress.slice(0, 10);
      const totalAnswered = progress.length;
      const correctAnswers = progress.filter(p => p.correct).length;
      const overallProgress = totalAnswered > 0 
        ? (correctAnswers / totalAnswered) * 100
        : 0;

      return {
        overallProgress,
        recentPerformance: this.calculateOverallProgress(recentProgress),
        domainPerformance: [
          {
            domain: "General",
            accuracy: overallProgress,
            totalAttempts: totalAnswered,
            status: overallProgress >= 70 ? "strong" : "needs_improvement"
          }
        ],
        learningTrend: this.calculateLearningTrend(recentProgress),
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      log("[AnalyticsService] Error getting advanced analytics: " + errorMessage);
      throw new Error("Failed to generate advanced analytics");
    }
  }

  async getStudyMetrics(userId: number): Promise<StudyMetrics> {
    try {
      const progress = await db.query.userProgress.findMany({
        where: eq(userProgress.userId, userId),
        orderBy: [desc(userProgress.timestamp)],
      });

      if (!progress || progress.length === 0) {
        return {
          totalQuestions: 0,
          correctAnswers: 0,
          accuracy: 0,
          averageResponseTime: 0,
          lastActive: new Date().toISOString(),
        };
      }

      const totalQuestions = progress.length;
      const correctAnswers = progress.filter((p) => p.correct).length;
      const accuracy = (correctAnswers / totalQuestions) * 100;
      const averageResponseTime =
        progress.reduce((acc, p) => acc + p.responseTime, 0) / totalQuestions;

      return {
        totalQuestions,
        correctAnswers,
        accuracy,
        averageResponseTime,
        lastActive: progress[0].timestamp?.toISOString() || new Date().toISOString(),
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      log("[AnalyticsService] Error getting study metrics: " + errorMessage);
      throw new Error("Failed to fetch study metrics");
    }
  }

  async getUserAnalytics(userId: number) {
    try {
      const progress = await db.query.userProgress.findMany({
        where: eq(userProgress.userId, userId),
        orderBy: [desc(userProgress.timestamp)],
        with: {
          question: {
            with: {
              domain: true,
            },
          },
        },
      });

      if (!progress.length) {
        return {
          areasForImprovement: [],
          overallProgress: 0,
          lastActive: new Date(),
        };
      }

      const domains = await db.query.nclexDomains.findMany();
      const domainPerformance = this.calculateDomainPerformance(progress, domains);

      return {
        areasForImprovement: domainPerformance
          .filter((d) => d.accuracy < 70)
          .map((d) => d.domain),
        overallProgress: this.calculateOverallProgress(progress),
        lastActive: progress[0].timestamp || new Date(),
      };
    } catch (error) {
      console.error("Error getting user analytics:", error);
      return {
        areasForImprovement: [],
        overallProgress: 0,
        lastActive: new Date(),
      };
    }
  }

  async getDomainPerformance(userId: number) {
    try {
      const progress = await db.query.userProgress.findMany({
        where: eq(userProgress.userId, userId),
        with: {
          question: {
            with: {
              domain: true,
            },
          },
        },
      });

      const domains = await db.query.nclexDomains.findMany();
      return this.calculateDomainPerformance(progress, domains);
    } catch (error) {
      console.error("Error getting domain performance:", error);
      throw new Error("Failed to fetch domain performance data");
    }
  }

  private calculateDomainPerformance(progress: UserProgressType[], domains: NclexDomain[]): any[] {
    const domainStats = new Map<string, { correct: number; total: number; domainName: string }>();

    // Initialize stats for all domains
    domains.forEach((domain) => {
      domainStats.set(domain.id.toString(), {
        correct: 0,
        total: 0,
        domainName: domain.name,
      });
    });

    // Calculate stats from progress
    progress.forEach((p) => {
      const domainId = p.question?.domain?.id.toString();
      if (domainId && domainStats.has(domainId)) {
        const stats = domainStats.get(domainId)!;
        stats.total++;
        if (p.correct) stats.correct++;
        domainStats.set(domainId, stats);
      }
    });

    return Array.from(domainStats.values()).map((stats) => ({
      domain: stats.domainName,
      accuracy: stats.total > 0 ? (stats.correct / stats.total) * 100 : 0,
      totalAttempts: stats.total,
      status: stats.total > 0 && (stats.correct / stats.total) >= 0.7 ? "strong" as const : "needs_improvement" as const,
    }));
  }

  private calculateOverallProgress(progress: UserProgressType[]): number {
    if (!progress.length) return 0;
    return (progress.filter((p) => p.correct).length / progress.length) * 100;
  }

  async identifyKnowledgeGaps(studentId: number) {
    try {
      const results = await db.query.userProgress.findMany({
        where: eq(userProgress.userId, studentId),
        orderBy: [desc(userProgress.timestamp)],
        limit: 10,
      });

      return results.map((result) => ({
        domainId: result.questionId,
        correct: result.correct,
        gapLevel: result.correct ? 0 : 1,
        recommendedActions: this.generateRecommendations(result),
      }));
    } catch (error) {
      log("[AnalyticsService] Error identifying knowledge gaps: " + (error instanceof Error ? error.message : String(error)));
      throw new Error("Failed to identify knowledge gaps");
    }
  }
  async getStudyPatterns(userId: number) {
    try {
      const progress = await db.query.userProgress.findMany({
        where: eq(userProgress.userId, userId),
        orderBy: [desc(userProgress.timestamp)],
      });

      const patterns = {
        accuracy: this.calculateOverallProgress(progress),
        trend: this.calculateLearningTrend(progress),
        lastActive: progress[0]?.timestamp || new Date(),
      };

      return patterns;
    } catch (error) {
      log("[AnalyticsService] Error getting study patterns: " + (error instanceof Error ? error.message : String(error)));
      throw error;
    }
  }
  async getAdvancedAnalytics(userId: number): Promise<AnalyticsData> {
    try {
      const progress = await db.query.userProgress.findMany({
        where: eq(userProgress.userId, userId),
        orderBy: [desc(userProgress.timestamp)],
        limit: 50,
      });

      if (!progress.length) {
        return {
          overallProgress: 0,
          recentPerformance: 0,
          domainPerformance: [],
          learningTrend: "stable",
        };
      }

      const recentProgress = progress.slice(0, 10);
      const totalAnswered = progress.length;
      const correctAnswers = progress.filter(p => p.correct).length;
      const overallProgress = totalAnswered > 0 
        ? (correctAnswers / totalAnswered) * 100
        : 0;

      return {
        overallProgress,
        recentPerformance: this.calculateOverallProgress(recentProgress),
        domainPerformance: [
          {
            domain: "General",
            accuracy: overallProgress,
            totalAttempts: totalAnswered,
            status: overallProgress >= 70 ? "strong" : "needs_improvement"
          }
        ],
        learningTrend: this.calculateLearningTrend(recentProgress),
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      log("[AnalyticsService] Error getting advanced analytics: " + errorMessage);
      throw new Error("Failed to generate advanced analytics");
    }
  }

  private calculateLearningTrend(progress: UserProgressType[]): "improving" | "declining" | "stable" {
    if (progress.length < 2) return "stable";

    const scores = progress.map(p => p.correct ? 1 : 0);
    let trend = 0;

    for (let i = 1; i < scores.length; i++) {
      trend += scores[i] - scores[i - 1];
    }

    return trend > 0 ? "improving" : trend < 0 ? "declining" : "stable";
  }
}

export const analyticsService = new AnalyticsService();