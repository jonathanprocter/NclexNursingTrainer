import { db } from "@db";
import { users } from "@db/schema";
import { eq } from "drizzle-orm";
import { hash, compare } from "bcrypt";
import { DatabaseError } from "./utils";

const SALT_ROUNDS = 10;

interface AuthCredentials {
  username: string;
  password: string;
}

interface User {
  id: number;
  username: string;
}

export class AuthService {
  async register({ username, password }: AuthCredentials): Promise<User> {
    try {
      const existingUser = await db.query.users.findFirst({
        where: eq(users.username, username),
      });

      if (existingUser) {
        throw new Error("Username already exists");
      }

      const hashedPassword = await hash(password, SALT_ROUNDS);

      const [user] = await db
        .insert(users)
        .values({
          username,
          password: hashedPassword,
        })
        .returning();

      return { id: user.id, username: user.username };
    } catch (error) {
      throw new DatabaseError(
        `Registration failed: ${error instanceof Error ? error.message : "Unknown error"}`,
        "register"
      );
    }
  }

  async login({ username, password }: AuthCredentials): Promise<User> {
    try {
      const user = await db.query.users.findFirst({
        where: eq(users.username, username),
      });

      if (!user) {
        throw new Error("Invalid credentials");
      }

      const isValid = await compare(password, user.password);
      if (!isValid) {
        throw new Error("Invalid credentials");
      }

      return { id: user.id, username: user.username };
    } catch (error) {
      throw new DatabaseError(
        `Login failed: ${error instanceof Error ? error.message : "Unknown error"}`,
        "login"
      );
    }
  }
}

export const authService = new AuthService();