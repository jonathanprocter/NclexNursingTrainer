Here's the fixed code:

import { aiLearningService } from "../lib/ai-learning.service";

interface ModuleActivity {
  type: string;
  description: string;
  objectives: string[];
  framework: {
    introduction: string;
    keyPoints: string[];
    clinicalRelevance: string;
  };
  content: {
    introduction: string;
    theory: string;
    sections: Array<{
      title: string;
      content: string;
      keyPoints: string[];
      examples: Array<{
        scenario: string;
        problem: string;
        solution: string;
        explanation: string;
      }>;
      practice: Array<{
        question: string;
        type: "calculation" | "conceptual" | "clinical";
        options?: string[];
        correctAnswer: string | number;
        explanation: string;
        difficulty: "basic" | "intermediate" | "advanced";
      }>;
      aiHelp: {
        enabled: boolean;
        prompts: string[];
        contextualHints: string[];
      };
    }>;
    assessment: {
      quizzes: Array<{
        title: string;
        questions: Array<{
          question: string;
          type: "calculation" | "conceptual" | "clinical";
          options?: string[];
          correctAnswer: string | number;
          explanation: string;
        }>;
      }>;
      practiceScenarios: Array<{
        title: string;
        scenario: string;
        questions: Array<{
          question: string;
          correctAnswer: string;
          rationale: string;
        }>;
      }>;
    };
  };
  adaptiveOptions: {
    difficultyLevels: string[];
    contentTypes: string[];
    aiAssistance: boolean;
    aiHelpPrompts: string[];
  };
}

interface Module {
  name: string;
  introduction: string;
  learningOutcomes: string[];
  activities: ModuleActivity[];
  aiFeatures: {
    adaptiveLearning: boolean;
    personalizedFeedback: boolean;
    contentGeneration: boolean;
    performanceAnalytics: boolean;
  };
}

export const moduleFeatures: Record<string, Module> = {
  drugCalculations: {
    name: "Drug Calculations: A Comprehensive Guide",
    introduction:
      "Welcome to this in-depth module on Drug Calculations! As a nursing student preparing for the NCLEX, developing proficiency in medication math is absolutely essential for safe and effective practice. This module will guide you through the key concepts and strategies needed to confidently tackle drug calculations across a variety of clinical scenarios.",
    learningOutcomes: [
      "Convert between different units of measurement",
      "Calculate medication dosages using dimensional analysis",
      "Determine flow rates and durations for IV infusions",
      "Adjust dosages for special populations",
      "Apply critical thinking to medication calculations",
    ],
    activities: [
      {
        type: "measurement_basics",
        description: "Master fundamental measurement systems and conversions",
        objectives: [
          "Understand the metric system",
          "Convert between measurement units",
          "Work with household measurements",
          "Apply conversion factors",
        ],
        framework: {
          introduction:
            "Before we dive into calculations, let's establish a solid foundation in measurement systems.",
          keyPoints: [
            "The metric system is the standard for medication measurement",
            "Understanding conversion factors is crucial for accuracy",
            "Household measurements require special attention to safety",
          ],
          clinicalRelevance:
            "Accurate measurement conversion is essential for safe medication administration.",
        },
        content: {
          introduction:
            "Before we dive into calculations, let's make sure we have a solid grasp on the fundamental units of measurement used in medication administration.",
          theory: `The metric system is the standard for medication measurement. The key metric units you'll work with are:

Grams (g): Used for measuring medication weights, typically for oral or topical drugs.
Subunits: milligrams (mg), micrograms (mcg)
1 gram = 1,000 milligrams = 1,000,000 micrograms

Liters (L): Used for measuring medication volumes, typically for injectable or IV drugs.
Subunits: milliliters (mL), microliters (μL)
1 liter = 1,000 milliliters = 1,000,000 microliters`,
          sections: [
            {
              title: "Metric System Fundamentals",
              content: `The metric system is the standard for medication measurement. The beauty of the metric system is that it operates on a base-10 scale, just like our standard number system. This means that converting between units is often as simple as moving the decimal point.

For example, to convert from grams to milligrams, you move the decimal point 3 places to the right:
5 g = 5,000 mg

And to convert from liters to milliliters, you also move the decimal point 3 places to the right:
2 L = 2,000 mL`,
              keyPoints: [
                "Metric system operates on base-10",
                "Decimal point movement determines conversion",
                "Accuracy is crucial for patient safety",
              ],
              examples: [
                {
                  scenario: "Converting Weight Units",
                  problem: "Convert 5 grams to milligrams",
                  solution: "5 g × 1000 mg/g = 5000 mg",
                  explanation:
                    "To convert from grams to milligrams, multiply by 1000",
                },
                {
                  scenario: "Converting Volume Units",
                  problem: "Convert 2.5 liters to milliliters",
                  solution: "2.5 L × 1000 mL/L = 2500 mL",
                  explanation:
                    "To convert from liters to milliliters, multiply by 1000",
                },
              ],
              practice: [
                {
                  question: "How many milligrams are in 2.5 grams?",
                  type: "calculation",
                  options: ["250 mg", "2,500 mg", "25 mg", "25,000 mg"],
                  correctAnswer: "2,500 mg",
                  explanation:
                    "To convert grams to milligrams, multiply by 1000: 2.5 × 1000 = 2,500",
                  difficulty: "basic",
                },
              ],
              aiHelp: {
                enabled: true,
                prompts: [
                  "Help me understand metric conversion",
                  "Check my conversion work",
                  "Explain the decimal point movement",
                ],
                contextualHints: [
                  "Remember to move decimal point 3 places right for g to mg",
                  "Think about the relationship between units",
                ],
              },
            },
            {
              title: "Household Measurements",
              content: `While metric units are the gold standard, you'll sometimes encounter medications that use household measurements, especially oral liquids. Common household units include:

Teaspoon (tsp): Approximately 5 mL
Tablespoon (tbsp): Approximately 15 mL
Ounce (oz): Approximately 30 mL
Cup (c): Approximately 240 mL`,
              keyPoints: [
                "Household measurements are less precise",
                "Converting to metric is preferred",
                "Common conversions should be memorized",
              ],
              examples: [
                {
                  scenario: "Converting Household to Metric",
                  problem: "Convert 2 tablespoons to milliliters",
                  solution: "2 tbsp × 15 mL/tbsp = 30 mL",
                  explanation: "Each tablespoon equals 15 mL",
                },
              ],
              practice: [
                {
                  question: "How many milliliters are in 3 teaspoons?",
                  type: "calculation",
                  correctAnswer: 15,
                  explanation: "1 teaspoon = 5 mL, so 3 teaspoons = 15 mL",
                  difficulty: "basic",
                },
              ],
              aiHelp: {
                enabled: true,
                prompts: [
                  "Help me convert household measures",
                  "Explain common conversions",
                  "Check my calculations",
                ],
                contextualHints: [
                  "Remember: 1 tablespoon = 3 teaspoons",
                  "Always verify your conversions",
                ],
              },
            },
          ],
          assessment: {
            quizzes: [
              {
                title: "Metric System Mastery",
                questions: [
                  {
                    question: "Convert 0.5 L to mL",
                    type: "calculation",
                    correctAnswer: 500,
                    explanation: "0.5 L × 1000 mL/L = 500 mL",
                  },
                  {
                    question: "How many milliliters in 4 tablespoons?",
                    type: "calculation",
                    correctAnswer: 60,
                    explanation: "4 tbsp × 15 mL/tbsp = 60 mL",
                  },
                ],
              },
            ],
            practiceScenarios: [
              {
                title: "Emergency Room Calculations",
                scenario:
                  "A patient needs rapid fluid replacement. The order is for 1 liter of normal saline, but the nurse needs to convert this to milliliters for the IV pump.",
                questions: [
                  {
                    question: "Convert 1 L to mL",
                    correctAnswer: "1000 mL",
                    rationale: "1 L = 1000 mL (multiply by 1000)",
                  },
                ],
              },
            ],
          },
        },
        adaptiveOptions: {
          difficultyLevels: ["basic", "intermediate", "advanced"],
          contentTypes: ["text", "interactive", "practice"],
          aiAssistance: true,
          aiHelpPrompts: [
            "Help me with this conversion",
            "Check my calculation",
            "Explain this concept",
          ],
        },
      },
      {
        type: "dimensional_analysis",
        description: "Master systematic drug calculation approaches",
        objectives: [
          "Understanding dimensional analysis principles",
          "Setting up calculation problems",
          "Solving complex medication calculations",
          "Verifying calculation accuracy",
        ],
        framework: {
          introduction:
            "Dimensional analysis provides a structured approach to solving medication calculations.",
          keyPoints: [
            "Units cancel out, leaving only desired units",
            "Set up the problem carefully to avoid errors",
            "Verify your answer makes sense in the clinical context",
          ],
          clinicalRelevance:
            "Dimensional analysis ensures accuracy and minimizes medication errors.",
        },
        content: {
          introduction:
            "Dimensional analysis is a powerful tool for solving medication calculations accurately and efficiently. It involves setting up an equation where units cancel out, leaving you with the desired unit.",
          theory:
            "Dimensional analysis is a systematic approach to solving medication calculations...",
          sections: [
            {
              title: "Dimensional Analysis Techniques",
              content:
                "This section covers the steps involved in setting up and solving dimensional analysis problems...",
              keyPoints: [
                "Identify the desired unit",
                "Set up the equation with appropriate conversion factors",
                "Cancel units to arrive at the solution",
              ],
              examples: [
                {
                  scenario: "Calculating Medication Dosage",
                  problem:
                    "Calculate mL needed for 500 mg amoxicillin (250 mg/5 mL)",
                  solution: "500 mg × (5 mL/250 mg) = 10 mL",
                  explanation:
                    "The mg units cancel, leaving mL as the final unit.",
                },
              ],
              practice: [
                {
                  question:
                    "A patient needs 1 gram of ceftriaxone. The vial contains 2 grams in 80 mL. How many mL should you administer?",
                  type: "calculation",
                  correctAnswer: 40,
                  explanation: "1 g × (80 mL/2 g) = 40 mL",
                  difficulty: "intermediate",
                },
              ],
              aiHelp: {
                enabled: true,
                prompts: [
                  "Help me set up the dimensional analysis equation",
                  "Check my units",
                  "Guide me through the calculation",
                ],
                contextualHints: [
                  "Make sure units cancel correctly",
                  "Double-check your calculations",
                ],
              },
            },
          ],
          assessment: {
            quizzes: [
              {
                title: "Dimensional Analysis Quiz",
                questions: [
                  {
                    question:
                      "Patient ordered 125 mg. Drug supplied as 250 mg/5 mL. Calculate mL to give.",
                    type: "calculation",
                    correctAnswer: 2.5,
                    explanation: "125 mg × (5 mL/250 mg) = 2.5 mL",
                  },
                ],
              },
            ],
            practiceScenarios: [],
          },
        },
        adaptiveOptions: {
          difficultyLevels: ["foundational", "intermediate", "complex"],
          contentTypes: [
            "guided_practice",
            "problem_solving",
            "verification_tools",
          ],
          aiAssistance: true,
          aiHelpPrompts: [
            "Guide me through this calculation",
            "Help me set up dimensional analysis",
            "Verify my solution steps",
          ],
        },
      },
      {
        type: "iv_calculations",
        description: "Master IV medication calculations and flow rates",
        objectives: [
          "Calculating flow rates",
          "Determining infusion times",
          "Working with drop factors",
          "Managing IV medications",
        ],
        framework: {
          introduction:
            "This section focuses on calculating flow rates and infusion times for intravenous medications.",
          keyPoints: [
            "Understanding drop factors is crucial",
            "Accurate calculations prevent medication errors",
            "Always double-check your work",
          ],
          clinicalRelevance:
            "Precise IV calculations are essential for patient safety.",
        },
        content: {
          introduction:
            "Intravenous (IV) medications require precise calculations to ensure the correct dosage is delivered over the specified time. This section will cover the essential formulas and techniques for calculating IV flow rates and infusion times.",
          theory:
            "IV calculations involve determining flow rates and infusion durations...",
          sections: [
            {
              title: "IV Flow Rate Calculations",
              content:
                "This section explains how to calculate IV flow rates...",
              keyPoints: [
                "Formula: Flow rate (gtt/min) = (Volume (mL) / Time (min)) × Drop factor (gtt/mL)",
                "Accurate measurement of volume and time is critical",
                "Drop factor varies depending on the IV tubing used",
              ],
              examples: [
                {
                  scenario: "Calculating Drops per Minute",
                  problem:
                    "Calculate drops/min for 1000 mL over 8 hours with 15 drops/mL",
                  solution:
                    "(1000 mL ÷ 8 hr) × (15 drops/mL ÷ 60 min/hr) = 31.25 ≈ 31 drops/min",
                  explanation:
                    "The calculation considers the total volume, infusion time, and drop factor.",
                },
              ],
              practice: [
                {
                  question:
                    "Calculate infusion time for 100 mL at 20 drops/min (drop factor 15)",
                  type: "calculation",
                  correctAnswer: 75,
                  explanation:
                    "75 minutes (1 hr 15 min) - detailed calculation shown in solution",
                  difficulty: "advanced",
                },
              ],
              aiHelp: {