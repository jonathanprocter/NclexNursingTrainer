import { db } from "@db";
import { flashcardProgress, flashcards } from "@db/schema";
import { eq, and } from "drizzle-orm";

class SpacedRepetitionService {
  // SuperMemo-2 algorithm parameters
  private readonly MIN_INTERVAL = 1; // Minimum interval in days
  private readonly MAX_INTERVAL = 365; // Maximum interval in days
  private readonly MIN_EF = 1.3; // Minimum easiness factor
  private readonly DEFAULT_EF = 2.5; // Initial easiness factor

  async calculateNextReview(
    flashcardId: number,
    isCorrect: boolean,
  ): Promise<Date> {
    // Get current progress
    const progress = await db
      .select()
      .from(flashcardProgress)
      .where(eq(flashcardProgress.flashcardId, flashcardId))
      .limit(1);

    let interval = 1; // Default interval for new cards
    let easeFactor = this.DEFAULT_EF * 100; // Convert to integer storage format

    if (progress.length > 0) {
      const currentProgress = progress[0];
      // Use nullish coalescing for safe access to nullable fields
      const currentInterval = currentProgress.interval ?? 1;
      const currentEaseFactor =
        currentProgress.easeFactor ?? this.DEFAULT_EF * 100;

      if (isCorrect) {
        interval = Math.round(currentInterval * (currentEaseFactor / 100));
        easeFactor = Math.max(
          this.MIN_EF * 100,
          currentEaseFactor + (0.1 - (5 - 5) * (0.08 + (5 - 5) * 0.02)) * 100,
        );
      } else {
        interval = 1;
        easeFactor = Math.max(this.MIN_EF * 100, currentEaseFactor - 20);
      }
    }

    // Cap the interval
    interval = Math.min(
      this.MAX_INTERVAL,
      Math.max(this.MIN_INTERVAL, interval),
    );

    // Calculate next review date
    const nextReview = new Date();
    nextReview.setDate(nextReview.getDate() + interval);

    return nextReview;
  }

  async getReviewStats(userId: number): Promise<{
    totalReviewed: number;
    correctCount: number;
    averageConfidence: number;
  }> {
    const progress = await db
      .select({
        id: flashcardProgress.id,
        correct: flashcardProgress.correct,
        confidence: flashcardProgress.confidence,
      })
      .from(flashcardProgress)
      .where(eq(flashcardProgress.userId, userId));

    const totalReviewed = progress.length;
    const correctCount = progress.filter((p) => p.correct).length;
    const averageConfidence =
      progress.reduce((acc, p) => acc + p.confidence, 0) / (totalReviewed || 1);

    return {
      totalReviewed,
      correctCount,
      averageConfidence,
    };
  }

  private calculateTimeQuality(responseTime: number): number {
    // Convert response time to seconds
    const seconds = responseTime / 1000;

    if (seconds <= 15) return 5; // Perfect response time
    if (seconds <= 30) return 4; // Good response time
    if (seconds <= 60) return 3; // Average response time
    if (seconds <= 120) return 2; // Below average response time
    return 1; // Poor response time
  }

  private calculateClinicalScore(
    isCorrect: boolean,
    responseTime: number,
  ): number {
    const timeScore = Math.max(0, 1 - responseTime / 120000); // 2 minutes max
    return isCorrect ? 0.7 + 0.3 * timeScore : 0.3 * timeScore;
  }

  private calculateCognitiveLoad(
    responseTime: number,
    isCorrect: boolean,
  ): number {
    const normalizedTime = Math.min(1, responseTime / 120000); // 2 minutes max
    const baseLoad = normalizedTime * 0.7 + 0.3;
    return isCorrect ? baseLoad * 0.8 : baseLoad;
  }

  private calculateRetentionRate(
    totalReviews: number,
    correctReviews: number,
  ): number {
    if (totalReviews < 5) return 0;
    const retentionFactor = Math.min(1, totalReviews / 100); // Scale with number of reviews
    return (correctReviews / totalReviews) * retentionFactor * 100;
  }
}

export const spacedRepetitionService = new SpacedRepetitionService();
