Here's the fixed code for the `intelligent-question-recommendation.ts` file:

```typescript
import { db } from "@db";
import { eq, and, desc, sql } from "drizzle-orm";
import {
  questions,
  userProgress,
  nclexDomains,
  learningModules,
  userModuleProgress,
} from "@db/schema";
import { generateAdaptiveRecommendations } from "./adaptive-recommendations";
import { generatePersonalizedLearningPath } from "./learning-path-generator";

interface QuestionRecommendation {
  questionId: number;
  domainId: number;
  difficulty: number;
  priority: number;
  reason: string;
  conceptualLevel: string;
  timeToReview: Date;
}

interface SpacedRepetitionMetrics {
  lastReviewDate: Date;
  nextReviewDate: Date;
  intervalDays: number;
  easeFactor: number;
  consecutiveCorrect: number;
}

export class IntelligentQuestionRecommender {
  private readonly DEFAULT_EASE_FACTOR = 2.5;
  private readonly MIN_INTERVAL_DAYS = 1;
  private readonly MAX_INTERVAL_DAYS = 365;

  async getRecommendedQuestions(
    userId: number,
    count: number = 10,
  ): Promise<QuestionRecommendation[]> {
    try {
      // Get user's current performance metrics and recommendations
      const adaptiveRecommendations =
        await generateAdaptiveRecommendations(userId);
      const learningPath = await generatePersonalizedLearningPath(userId);

      // Get user's progress history
      const progressHistory = await db.query.userProgress.findMany({
        where: eq(userProgress.userId, userId),
        orderBy: [desc(userProgress.timestamp)],
        with: {
          question: {
            with: {
              domain: true,
            },
          },
        },
      });

      // Calculate spaced repetition metrics for each previously attempted question
      const spacedRepetitionData =
        await this.calculateSpacedRepetitionMetrics(progressHistory);

      // Get questions due for review based on spaced repetition
      const dueQuestions = await this.getDueQuestions(
        userId,
        spacedRepetitionData,
      );

      // Combine recommendations from different sources
      const recommendations = await this.combineRecommendations(
        userId,
        adaptiveRecommendations,
        learningPath,
        dueQuestions,
        count,
      );

      return this.prioritizeRecommendations(recommendations, count);
    } catch (error) {
      console.error("Error getting recommended questions:", error);
      throw error;
    }
  }

  private async calculateSpacedRepetitionMetrics(
    progressHistory: any[],
  ): Promise<Map<number, SpacedRepetitionMetrics>> {
    const metrics = new Map<number, SpacedRepetitionMetrics>();

    for (const progress of progressHistory) {
      const questionId = progress.question.id;

      if (!metrics.has(questionId)) {
        const consecutiveCorrect = this.calculateConsecutiveCorrect(
          progressHistory.filter((p) => p.question.id === questionId),
        );

        const easeFactor = this.calculateEaseFactor(
          this.DEFAULT_EASE_FACTOR,
          progress.correct,
          consecutiveCorrect,
        );

        const intervalDays = this.calculateNextInterval(
          consecutiveCorrect,
          easeFactor,
        );

        metrics.set(questionId, {
          lastReviewDate: new Date(progress.timestamp),
          nextReviewDate: this.calculateNextReviewDate(
            new Date(progress.timestamp),
            intervalDays,
          ),
          intervalDays,
          easeFactor,
          consecutiveCorrect,
        });
      }
    }

    return metrics;
  }

  private async getDueQuestions(
    userId: number,
    spacedRepetitionData: Map<number, SpacedRepetitionMetrics>,
  ): Promise<QuestionRecommendation[]> {
    const now = new Date();
    const dueQuestions: QuestionRecommendation[] = [];

    for (const [questionId, metrics] of spacedRepetitionData.entries()) {
      if (metrics.nextReviewDate <= now) {
        const question = await db.query.questions.findFirst({
          where: eq(questions.id, questionId),
          with: {
            domain: true,
          },
        });

        if (question) {
          dueQuestions.push({
            questionId,
            domainId: question.domain?.id || question.domainId,
            difficulty: question.difficulty,
            priority: this.calculateReviewPriority(metrics),
            reason: "Due for review based on spaced repetition",
            conceptualLevel: question.conceptualLevel,
            timeToReview: metrics.nextReviewDate,
          });
        }
      }
    }

    return dueQuestions;
  }

  private async combineRecommendations(
    userId: number,
    adaptiveRecommendations: any[],
    learningPath: any[],
    dueQuestions: QuestionRecommendation[],
    count: number,
  ): Promise<QuestionRecommendation[]> {
    const recommendations: QuestionRecommendation[] = [];

    // Add questions from adaptive recommendations
    for (const rec of adaptiveRecommendations) {
      const questions = await db.query.questions.findMany({
        where: and(
          eq(questions.domainId, rec.domainId),
          eq(questions.conceptualLevel, rec.conceptLevel),
        ),
        limit: Math.ceil(count / 3),
      });

      recommendations.push(
        ...questions.map((q) => ({
          questionId: q.id,
          domainId: q.domainId,
          difficulty: q.difficulty,
          priority: rec.priorityLevel,
          reason: rec.reason,
          conceptualLevel: q.conceptualLevel,
          timeToReview: new Date(),
        })),
      );
    }

    // Add questions from learning path
    for (const pathItem of learningPath) {
      if (pathItem.suggestedModules) {
        for (const module of pathItem.suggestedModules) {
          const questions = await db.query.questions.findMany({
            where: eq(questions.moduleId, module.id),
            limit: Math.ceil(count / 3),
          });

          recommendations.push(
            ...questions.map((q) => ({
              questionId: q.id,
              domainId: q.domainId,
              difficulty: q.difficulty,
              priority: this.calculateModulePriority(module),
              reason: "Aligns with current learning path",
              conceptualLevel: q.conceptualLevel,
              timeToReview: new Date(),
            })),
          );
        }
      }
    }

    // Add due questions from spaced repetition
    recommendations.push(...dueQuestions);

    return recommendations;
  }

  private prioritizeRecommendations(
    recommendations: QuestionRecommendation[],
    count: number,
  ): QuestionRecommendation[] {
    return recommendations
      .sort((a, b) => b.priority - a.priority)
      .slice(0, count);
  }

  private calculateConsecutiveCorrect(progressHistory: any[]): number {
    let consecutive = 0;
    for (const progress of progressHistory) {
      if (progress.correct) {
        consecutive++;
      } else {
        break;
      }
    }
    return consecutive;
  }

  private calculateEaseFactor(
    currentEaseFactor: number,
    correct: boolean,
    consecutiveCorrect: number,
  ): number {
    if (!correct) {
      return Math.max(1.3, currentEaseFactor - 0.3);
    }

    const bonus = consecutiveCorrect * 0.1;
    return Math.min(2.5, currentEaseFactor + 0.1 + bonus);
  }

  private calculateNextInterval(
    consecutiveCorrect: number,
    easeFactor: number,
  ): number {
    if (consecutiveCorrect === 0) return this.MIN_INTERVAL_DAYS;
    if (consecutiveCorrect === 1) return 2;

    const interval = Math.ceil(
      this.MIN_INTERVAL_DAYS * Math.pow(easeFactor, consecutiveCorrect - 1),
    );

    return Math.min(this.MAX_INTERVAL_DAYS, interval);
  }

  private calculateNextReviewDate(
    lastReview: Date,
    intervalDays: number,
  ): Date {
    const nextDate = new Date(lastReview);
    nextDate.setDate(nextDate.getDate() + intervalDays);
    return nextDate;
  }

  private calculateReviewPriority(metrics: SpacedRepetitionMetrics): number {
    const daysOverdue = Math.max(
      0,
      (new Date().getTime() - metrics.nextReviewDate.getTime()) /
        (1000 * 60 * 60 * 24),
    );

    return Math.min(10, 5 + daysOverdue * 0.5);
  }

  private calculateModulePriority(module: any): number {
    // Priority based on module completion status and prerequisites
    return module.priority || 5;
  }
}

export const questionRecommender = new IntelligentQuestionRecommender();
```