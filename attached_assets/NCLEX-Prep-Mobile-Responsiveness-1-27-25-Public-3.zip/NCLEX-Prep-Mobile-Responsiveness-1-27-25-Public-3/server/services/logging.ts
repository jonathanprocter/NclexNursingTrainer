Here's the fixed code:

```typescript
import { mkdir, stat, rename as fsRename } from "fs/promises";
import { createWriteStream } from "fs";
import { join } from "path";
import { format } from "date-fns";
import winston from "winston";

export interface LogEntry {
  timestamp: string;
  level: "INFO" | "WARNING" | "ERROR";
  component: string;
  message: string;
  details?: Record<string, any>;
}

class LoggingService {
  private static instance: LoggingService;
  private logDir: string;
  private currentLogFile: string;
  private writeStream: ReturnType<typeof createWriteStream> | null = null;
  private winstonLogger: winston.Logger;

  private constructor() {
    this.logDir = join(process.cwd(), "logs");
    this.currentLogFile = this.generateLogFileName();
    this.winstonLogger = winston.createLogger({
      level: process.env.NODE_ENV === "development" ? "debug" : "info",
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      ),
      transports: [
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
          ),
        }),
        new winston.transports.File({
          filename: join(this.logDir, "error.log"),
          level: "error",
        }),
        new winston.transports.File({ filename: join(this.logDir, "combined.log") }),
      ],
    });
    this.initializeLogging();
  }

  public static getInstance(): LoggingService {
    if (!LoggingService.instance) {
      LoggingService.instance = new LoggingService();
    }
    return LoggingService.instance;
  }

  private async initializeLogging() {
    try {
      await mkdir(this.logDir, { recursive: true });
      this.writeStream = createWriteStream(
        join(this.logDir, this.currentLogFile),
        { flags: "a" }
      );
      this.info("LoggingService", "Logging service initialized", {
        logDir: this.logDir,
        currentLogFile: this.currentLogFile,
      });
    } catch (error) {
      console.error("Failed to initialize logging:", error);
    }
  }

  private generateLogFileName(): string {
    return `nclex-app-${format(new Date(), "yyyy-MM-dd")}.log`;
  }

  private async rotateLogsIfNeeded() {
    try {
      const logPath = join(this.logDir, this.currentLogFile);
      const stats = await stat(logPath).catch((err: NodeJS.ErrnoException) => {
        if (err.code !== "ENOENT") {
          throw err;
        }
        return null;
      });

      if (stats) {
        const fileSizeInMB = stats.size / (1024 * 1024);

        if (fileSizeInMB > 10) {
          const timestamp = format(new Date(), "HH-mm-ss");
          const newFileName = `nclex-app-${format(new Date(), "yyyy-MM-dd")}-${timestamp}.log`;
          const newPath = join(this.logDir, newFileName);

          if (this.writeStream) {
            this.writeStream.end();
            this.writeStream = null;
          }

          await fsRename(logPath, newPath);

          this.currentLogFile = this.generateLogFileName();
          this.writeStream = createWriteStream(
            join(this.logDir, this.currentLogFile),
            { flags: "a" }
          );
        }
      }
    } catch (error) {
      console.error("Failed to rotate logs:", error);
    }
  }

  private formatLogEntry(entry: LogEntry): string {
    const timestamp = new Date().toISOString();
    const details = entry.details
      ? `\n  Details: ${JSON.stringify(entry.details, null, 2)}`
      : "";

    return `[${timestamp}] ${entry.level} [${entry.component}]: ${entry.message}${details}\n`;
  }

  public async log(entry: LogEntry) {
    try {
      await this.rotateLogsIfNeeded();
      const logMessage = this.formatLogEntry(entry);

      if (this.writeStream) {
        this.writeStream.write(logMessage);
      }

      this.winstonLogger.log({
        level: entry.level.toLowerCase(),
        message: `${entry.component}: ${entry.message}`,
        ...entry.details,
      });
    } catch (error) {
      console.error("Failed to write log:", error);
    }
  }

  public async info(
    component: string,
    message: string,
    details?: Record<string, any>
  ) {
    await this.log({
      timestamp: new Date().toISOString(),
      level: "INFO",
      component,
      message,
      details,
    });
  }

  public async warn(
    component: string,
    message: string,
    details?: Record<string, any>
  ) {
    await this.log({
      timestamp: new Date().toISOString(),
      level: "WARNING",
      component,
      message,
      details,
    });
  }

  public async error(
    component: string,
    message: string,
    details?: Record<string, any>
  ) {
    await this.log({
      timestamp: new Date().toISOString(),
      level: "ERROR",
      component,
      message,
      details,
    });
  }
}

export const logger = LoggingService.getInstance();

export const log = {
  error: (message: string, meta?: any) => logger.error("System", message, meta),
  warn: (message: string, meta?: any) => logger.warn("System", message, meta),
  info: (message: string, meta?: any) => logger.info("System", message, meta),
  debug: (message: string, meta?: any) => logger.info("System", message, meta),
};

export default log;
```