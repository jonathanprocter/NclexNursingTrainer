import { log } from "../vite";

export class DatabaseError extends Error {
  constructor(message: string, cause?: string) {
    super(message);
    this.name = "DatabaseError";
    this.cause = cause;

    // Log database errors for monitoring
    log(`Database Error: ${message}${cause ? ` (Cause: ${cause})` : ""}`);
  }
}

export function isError(error: unknown): error is Error {
  return error instanceof Error;
}

export function getErrorMessage(error: unknown): string {
  if (error instanceof Error) {
    return error.message;
  }
  return String(error);
}
