Here's the fixed code:

```typescript
import { db } from "@db";
import { flashcardProgress } from "@db/schema";
import { aiLearningService } from "./ai-learning.service";
import { z } from "zod";

interface EmotionalState {
  userId: number;
  currentMood: "stressed" | "confident" | "neutral";
  energyLevel: number;
  focusQuality: number;
}

interface EmotionalResponse {
  supportMessage: string;
  studyRecommendation: string;
  adaptivePath?: {
    suggestedTopics: string[];
    difficulty: "easy" | "medium" | "hard";
    timeRecommendation: number;
  };
}

const SUPPORT_MESSAGES = {
  stressed: [
    "Take a deep breath. You're making progress, even if it doesn't feel like it.",
    "It's normal to feel overwhelmed. Let's break this down into smaller steps.",
    "Remember why you started. Every small step counts.",
  ],
  confident: [
    "Your confidence is well-earned! Keep up the great momentum.",
    "You're mastering these concepts beautifully.",
    "Your positive attitude will help you tackle even harder concepts.",
  ],
  neutral: [
    "Steady progress is the key to success.",
    "Let's focus on one concept at a time.",
    "You're building strong foundations for your nursing career.",
  ],
};

const STUDY_RECOMMENDATIONS = {
  stressed: [
    "Start with reviewing concepts you're most comfortable with",
    "Take more frequent breaks between study sessions",
    "Focus on understanding rather than memorization",
  ],
  confident: [
    "Challenge yourself with more complex case studies",
    "Try teaching concepts to others to reinforce learning",
    "Tackle your challenging topics while motivation is high",
  ],
  neutral: [
    "Maintain a balanced study schedule",
    "Mix different learning methods to keep engaged",
    "Focus on connecting related concepts",
  ],
};

export const emotionalStateSchema = z.object({
  currentMood: z.enum(["stressed", "confident", "neutral"]),
  energyLevel: z.number().min(0).max(100),
  focusQuality: z.number().min(0).max(100),
});

class EmotionalIntelligenceService {
  private getRandomMessage(array: string[]): string {
    return array[Math.floor(Math.random() * array.length)];
  }

  async recordState(state: EmotionalState): Promise<EmotionalResponse> {
    try {
      const validatedState = emotionalStateSchema.parse({
        currentMood: state.currentMood,
        energyLevel: state.energyLevel,
        focusQuality: state.focusQuality,
      });

      // Record emotional state in flashcard progress
      const progressEntry = {
        userId: state.userId,
        flashcardId: 0, // Placeholder for emotional state tracking
        correct: true, // Not relevant for emotional state
        confidence: Math.round(validatedState.energyLevel),
        performanceData: {
          confidence:
            validatedState.currentMood === "confident"
              ? 0.8
              : validatedState.currentMood === "stressed"
              ? 0.4
              : 0.6,
          responseTime: 0,
          correct: true,
        },
      };

      await db.insert(flashcardProgress).values(progressEntry);

      let adaptivePath;
      try {
        adaptivePath = await aiLearningService.generateAdaptivePath(
          state.userId
        );
      } catch (error) {
        console.error("Error generating adaptive path:", error);
        // Handle the error appropriately, e.g., log or return a default path
        adaptivePath = null;
      }

      return {
        supportMessage: this.getRandomMessage(
          SUPPORT_MESSAGES[validatedState.currentMood]
        ),
        studyRecommendation: this.getRandomMessage(
          STUDY_RECOMMENDATIONS[validatedState.currentMood]
        ),
        adaptivePath: adaptivePath
          ? {
              suggestedTopics:
                adaptivePath.recommendedPath.currentDomainFocus,
              difficulty: adaptivePath.recommendedPath.suggestedDifficulty,
              timeRecommendation:
                adaptivePath.recommendedPath.estimatedTimeMinutes,
            }
          : undefined,
      };
    } catch (error) {
      console.error("Error in emotional intelligence service:", error);
      throw new Error(
        "Failed to process emotional state: " +
          (error instanceof Error ? error.message : String(error))
      );
    }
  }
}

export const emotionalIntelligenceService = new EmotionalIntelligenceService();
```