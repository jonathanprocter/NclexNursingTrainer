Here's the fixed code:

```typescript
import { db } from "@db";
import { questions, userModuleProgress, learningModules } from "../../db/schema";
import { eq, and, sql } from "drizzle-orm";
import { generateAdaptiveRecommendations } from "./adaptive-recommendations";

interface ModuleWithMaterials {
  id: number;
  title: string;
  description: string;
  content: {
    objectives: string[];
    sections: {
      title: string;
      content: string;
      type: 'text' | 'video' | 'quiz' | 'simulation';
      difficulty: 'easy' | 'medium' | 'hard';
      conceptualLevel: string;
    }[];
  };
  estimatedDuration: number;
  difficulty: 'easy' | 'medium' | 'hard';
  prerequisites: number[];
}

export async function generatePersonalizedLearningPath(userId: number) {
  try {
    // Get adaptive recommendations
    const recommendations = await generateAdaptiveRecommendations(userId);

    // Get user's completed modules
    const completedModules = await db.select()
      .from(userModuleProgress)
      .where(
        and(
          eq(userModuleProgress.userId, userId),
          eq(userModuleProgress.status, 'completed')
        )
      );

    const completedModuleIds = new Set(completedModules.map(m => m.moduleId));

    // Generate learning path based on recommendations
    const learningPath = await Promise.all(
      recommendations.map(async (rec) => {
        // Find suitable modules based on recommendation criteria
        const modules = await db.select()
          .from(learningModules)
          .where(
            and(
              eq(learningModules.domainId, rec.domainId),
              sql`${learningModules.content}->>'conceptualLevel' = ${rec.conceptLevel}`
            )
          );

        // Filter and sort modules based on prerequisites and difficulty
        const eligibleModules = modules
          .filter(module => {
            const prerequisites = module.prerequisites || [];
            return prerequisites.every((preReqId: number) => completedModuleIds.has(preReqId));
          })
          .map(module => ({
            ...module,
            matchScore: calculateModuleMatch(module, rec)
          }))
          .sort((a, b) => b.matchScore - a.matchScore);

        // Get associated practice questions
        const practiceQuestions = await db.select()
          .from(questions)
          .where(
            and(
              eq(questions.domainId, rec.domainId),
              eq(questions.conceptualLevel, rec.conceptLevel as any)
            )
          )
          .limit(5);

        return {
          recommendation: rec,
          suggestedModules: eligibleModules.slice(0, 3),
          practiceQuestions
        };
      })
    );

    return learningPath;
  } catch (error) {
    console.error('Error generating personalized learning path:', error);
    throw error;
  }
}

function calculateModuleMatch(
  module: ModuleWithMaterials,
  recommendation: any
): number {
  let score = 0;

  // Check if module format matches recommended format
  const hasRecommendedFormat = module.content.sections.some(
    section => section.type === recommendation.recommendedFormat
  );
  if (hasRecommendedFormat) score += 0.3;

  // Adjust score based on difficulty progression
  const difficultyScore = {
    'easy': 0.1,
    'medium': 0.2,
    'hard': 0.3
  }[module.difficulty] || 0;
  score += difficultyScore;

  // Consider content variety
  const uniqueContentTypes = new Set(
    module.content.sections.map(section => section.type)
  );
  score += uniqueContentTypes.size * 0.1;

  // Weight by estimated duration (prefer shorter modules for quick wins)
  const durationScore = Math.max(0, 1 - (module.estimatedDuration / 120)); // Normalize to 2 hours
  score += durationScore * 0.2;

  return score;
}

export async function getModulePrerequisites(moduleId: number): Promise<number[]> {
  try {
    const module = await db.query.learningModules.findFirst({
      where: eq(learningModules.id, moduleId)
    });

    return module?.prerequisites || [];
  } catch (error) {
    console.error(`Error fetching prerequisites for module ${moduleId}:`, error);
    throw error;
  }
}

export async function validateLearningPath(userId: number, moduleIds: number[]): Promise<boolean> {
  try {
    for (const moduleId of moduleIds) {
      const prerequisites = await getModulePrerequisites(moduleId);

      if (prerequisites.length > 0) {
        const completedPrereqs = await db.select()
          .from(userModuleProgress)
          .where(
            and(
              eq(userModuleProgress.userId, userId),
              eq(userModuleProgress.status, 'completed'),
              sql`${userModuleProgress.moduleId} = ANY(${prerequisites})`
            )
          );

        if (completedPrereqs.length !== prerequisites.length) {
          return false;
        }
      }
    }

    return true;
  } catch (error) {
    console.error('Error validating learning path:', error);
    throw error;
  }
}
```