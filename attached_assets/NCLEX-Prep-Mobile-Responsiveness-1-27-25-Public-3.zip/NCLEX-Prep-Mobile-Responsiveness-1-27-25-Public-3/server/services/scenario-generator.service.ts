import { db } from "@db";
import { userProgress, type NclexDomain } from "@db/schema";
import { eq } from "drizzle-orm";

interface VitalSigns {
  temperature: number;
  heartRate: number;
  bloodPressure: string;
  respiratoryRate: number;
  oxygenSaturation: number;
}

interface PatientScenario {
  id: number;
  difficulty: "easy" | "medium" | "hard";
  clinicalSetting: string;
  patientDetails: {
    age: number;
    gender: string;
    chiefComplaint: string;
    vitalSigns: VitalSigns;
    history: string[];
  };
  decisions: Array<{
    stage: string;
    options: string[];
    correctOption: string;
    rationale: string;
    followUp?: {
      observation: string;
      additionalFindings: string[];
    };
  }>;
  feedback: {
    clinical: string;
    emotional: string;
    technicalAccuracy: number;
  };
}

// Pre-defined scenarios with enhanced details
const SCENARIOS: PatientScenario[] = [
  {
    id: 1,
    difficulty: "easy",
    clinicalSetting: "Medical-Surgical Unit",
    patientDetails: {
      age: 35,
      gender: "Male",
      chiefComplaint: "Persistent cough and fever",
      vitalSigns: {
        temperature: 38.5,
        heartRate: 88,
        bloodPressure: "120/80",
        respiratoryRate: 20,
        oxygenSaturation: 96,
      },
      history: [
        "No significant medical history",
        "Non-smoker",
        "Recent travel history",
      ],
    },
    decisions: [
      {
        stage: "Initial Assessment",
        options: [
          "Order chest X-ray and basic blood work",
          "Start antibiotics immediately",
          "Send patient home with cough medicine",
          "Perform rapid COVID-19 test",
        ],
        correctOption: "Perform rapid COVID-19 test",
        rationale:
          "Given the presenting symptoms of fever and cough, along with recent travel history, COVID-19 testing is the appropriate first step before proceeding with other interventions.",
      },
    ],
    feedback: {
      clinical:
        "This case demonstrates the importance of appropriate screening and testing in the context of respiratory symptoms.",
      emotional:
        "Good job on maintaining a systematic approach to patient assessment.",
      technicalAccuracy: 90,
    },
  },
  {
    id: 2,
    difficulty: "medium",
    clinicalSetting: "Emergency Department",
    patientDetails: {
      age: 45,
      gender: "Female",
      chiefComplaint: "Severe chest pain radiating to left arm",
      vitalSigns: {
        temperature: 37.2,
        heartRate: 110,
        bloodPressure: "160/95",
        respiratoryRate: 22,
        oxygenSaturation: 95,
      },
      history: [
        "Hypertension",
        "Type 2 Diabetes",
        "Family history of heart disease",
      ],
    },
    decisions: [
      {
        stage: "Initial Assessment",
        options: [
          "Order complete blood count and basic metabolic panel",
          "Obtain 12-lead ECG and cardiac enzymes",
          "Start oxygen therapy via nasal cannula",
          "Administer aspirin and obtain vital signs",
        ],
        correctOption: "Obtain 12-lead ECG and cardiac enzymes",
        rationale:
          "In a patient presenting with chest pain and risk factors for cardiac disease, obtaining an ECG and cardiac enzymes is the priority to rule out acute myocardial infarction. Time is critical in cardiac events, and these diagnostics help determine if immediate interventions are needed.",
        followUp: {
          observation:
            "ECG shows ST-segment elevation in leads V1-V4. Initial troponin is elevated at 0.5 ng/mL.",
          additionalFindings: [
            "Patient reports worsening pain, now 8/10 on pain scale",
            "Diaphoresis noted",
            "Mild shortness of breath",
          ],
        },
      },
      {
        stage: "Treatment Plan",
        options: [
          "Administer morphine for pain relief",
          "Give nitroglycerin and aspirin",
          "Start beta-blockers immediately",
          "Schedule stress test for tomorrow",
        ],
        correctOption: "Give nitroglycerin and aspirin",
        rationale:
          "With confirmed ST-elevation MI (STEMI), immediate administration of nitroglycerin helps dilate coronary arteries and reduce chest pain, while aspirin helps prevent further clot formation. This is standard initial treatment for acute coronary syndrome while preparing for definitive intervention.",
        followUp: {
          observation:
            "After nitroglycerin, patient reports pain decreasing to 4/10. Blood pressure now 145/85.",
          additionalFindings: [
            "Repeat ECG shows persistent ST elevation",
            "Second troponin elevated at 2.0 ng/mL",
            "Cardiology consulted for potential cardiac catheterization",
          ],
        },
      },
      {
        stage: "Definitive Care Decision",
        options: [
          "Transfer to cardiac catheterization lab",
          "Continue medical management and observe",
          "Schedule outpatient follow-up",
          "Discharge with medication adjustments",
        ],
        correctOption: "Transfer to cardiac catheterization lab",
        rationale:
          "With confirmed STEMI and persistent ST elevation despite initial treatment, immediate cardiac catheterization is indicated. The goal is to achieve reperfusion as quickly as possible to minimize myocardial damage.",
      },
    ],
    feedback: {
      clinical:
        "This case demonstrates the importance of rapid recognition and treatment of acute coronary syndrome. The key learning points include prioritizing ECG and cardiac enzymes in suspected cardiac cases, appropriate use of medications, and understanding the importance of timely intervention in STEMI.",
      emotional:
        "Your decision-making showed good clinical judgment in prioritizing time-sensitive interventions. Consider discussing the plan with the patient to address any anxiety and ensure understanding of the urgency of the situation.",
      technicalAccuracy: 95,
    },
  },
  {
    id: 3,
    difficulty: "hard",
    clinicalSetting: "Intensive Care Unit",
    patientDetails: {
      age: 68,
      gender: "Female",
      chiefComplaint: "Acute respiratory distress and altered mental status",
      vitalSigns: {
        temperature: 39.2,
        heartRate: 125,
        bloodPressure: "85/50",
        respiratoryRate: 28,
        oxygenSaturation: 88,
      },
      history: [
        "COPD",
        "Recent pneumonia",
        "Chronic kidney disease",
        "Heart failure",
      ],
    },
    decisions: [
      {
        stage: "Initial Stabilization",
        options: [
          "Start high-flow oxygen therapy only",
          "Initiate mechanical ventilation immediately",
          "Begin BiPAP therapy and reassess",
          "Administer nebulizer treatment",
        ],
        correctOption: "Begin BiPAP therapy and reassess",
        rationale:
          "In acute respiratory distress with altered mental status but maintaining some respiratory drive, BiPAP is the appropriate first step. It provides respiratory support while avoiding immediate intubation, which carries its own risks. This allows time to assess response while preparing for possible escalation of care.",
        followUp: {
          observation:
            "After 1 hour on BiPAP, oxygen saturation improves to 92% but work of breathing remains elevated.",
          additionalFindings: [
            "Patient becoming more agitated",
            "Accessory muscle use still prominent",
            "Arterial blood gas shows respiratory acidosis",
          ],
        },
      },
      {
        stage: "Advanced Management",
        options: [
          "Continue current BiPAP settings",
          "Proceed with intubation and mechanical ventilation",
          "Switch to high-flow nasal cannula",
          "Add inhaled bronchodilators only",
        ],
        correctOption: "Proceed with intubation and mechanical ventilation",
        rationale:
          "Despite initial BiPAP therapy, the patient shows signs of deterioration with persistent respiratory acidosis, increased work of breathing, and agitation. Early intubation in a controlled setting is safer than emergency intubation if the patient further deteriorates.",
        followUp: {
          observation:
            "Patient successfully intubated. Post-intubation chest x-ray shows bilateral infiltrates.",
          additionalFindings: [
            "Initial ventilator settings established using lung-protective strategy",
            "Hemodynamics stabilized with fluid resuscitation",
            "Requiring moderate vasopressor support",
          ],
        },
      },
      {
        stage: "Comprehensive Care",
        options: [
          "Focus only on ventilator management",
          "Initiate empiric antibiotics and sepsis workup",
          "Start steroids without further workup",
          "Observe and wait for culture results",
        ],
        correctOption: "Initiate empiric antibiotics and sepsis workup",
        rationale:
          "Given the elevated temperature, hypotension requiring vasopressors, and respiratory failure, sepsis is likely. Prompt initiation of broad-spectrum antibiotics after obtaining cultures is crucial, following the sepsis bundle guidelines.",
      },
    ],
    feedback: {
      clinical:
        "This complex case highlights the importance of systematic evaluation and timely interventions in critically ill patients. Key learning points include recognition of respiratory failure progression, appropriate use of non-invasive and invasive ventilation, and early recognition and management of sepsis.",
      emotional:
        "Managing critically ill patients requires both clinical expertise and emotional intelligence. Your ability to make difficult decisions while considering the patient's overall condition is crucial for optimal outcomes.",
      technicalAccuracy: 98,
    },
  },
];

class ScenarioGeneratorService {
  async generateScenario(
    difficulty: string,
    domain: string,
  ): Promise<PatientScenario> {
    try {
      console.log(
        `Generating scenario with difficulty: ${difficulty}, domain: ${domain}`,
      );

      const availableScenarios = SCENARIOS.filter(
        (s) => s.difficulty === difficulty,
      );
      if (availableScenarios.length === 0) {
        console.error(`No scenarios available for difficulty: ${difficulty}`);
        throw new Error(
          `No scenarios available for the selected difficulty level: ${difficulty}`,
        );
      }

      const randomIndex = Math.floor(Math.random() * availableScenarios.length);
      const selectedScenario = availableScenarios[randomIndex];
      console.log(`Selected scenario ID: ${selectedScenario.id}`);

      return selectedScenario;
    } catch (error) {
      console.error("Error generating scenario:", error);
      throw error;
    }
  }

  async recordResponse(
    userId: number,
    scenarioId: number,
    response: string,
    isCorrect: boolean,
  ) {
    try {
      console.log(
        `Recording response for user ${userId}, scenario ${scenarioId}`,
      );

      // Record in user progress table instead
      await db.insert(userProgress).values({
        userId,
        questionId: scenarioId, // Using scenarioId as questionId for now
        correct: isCorrect,
        responseTime: 0, // Default value since we don't track this for scenarios
        learningMetrics: {
          confidenceLevel: 0,
          cognitiveLoadIndex: 0,
          timeSpent: 0,
        },
      });

      console.log("Response recorded successfully");
    } catch (error) {
      console.error("Error recording scenario response:", error);
      throw error;
    }
  }
}

export const scenarioGeneratorService = new ScenarioGeneratorService();