import pg from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import { EventEmitter } from 'events';
import * as schema from '@db/schema';
import { log } from "../vite";

const { Pool } = pg;

export class DatabaseManager extends EventEmitter {
  private pool: pg.Pool | null = null;
  private isInitialized = false;
  private isShuttingDown = false;
  private readonly MAX_RETRIES = 3;
  private readonly RETRY_DELAY = 1000;
  private readonly CLEANUP_TIMEOUT = 5000;

  constructor(private readonly config: pg.PoolConfig) {
    super();
    this.validateConfig();
  }

  private validateConfig() {
    if (!this.config.connectionString) {
      throw new Error('[DatabaseManager] DATABASE_URL is required');
    }
  }

  async initialize(): Promise<boolean> {
    if (this.isInitialized) {
      log('[DatabaseManager] Already initialized');
      return true;
    }

    if (this.isShuttingDown) {
      throw new Error('[DatabaseManager] Cannot initialize during shutdown');
    }

    try {
      log('[DatabaseManager] Creating database pool...');
      this.pool = new Pool(this.config);

      // Set up event handlers
      this.pool.on('error', (err: Error) => {
        log(`[DatabaseManager] Pool error: ${err}`);
        this.emit('error', err);
      });

      this.pool.on('connect', () => {
        log('[DatabaseManager] New client connected to pool');
        this.emit('connect');
      });

      // Verify connection with retries
      await this.verifyConnection();

      this.isInitialized = true;
      log('[DatabaseManager] Successfully initialized');
      return true;
    } catch (error) {
      log(`[DatabaseManager] Failed to initialize: ${error}`);
      await this.cleanup();
      return false;
    }
  }

  private async verifyConnection(): Promise<void> {
    for (let attempt = 1; attempt <= this.MAX_RETRIES; attempt++) {
      try {
        const client = await this.pool?.connect();
        if (!client) {
          throw new Error('[DatabaseManager] Failed to get database client');
        }

        await client.query('SELECT 1');
        client.release();
        log('[DatabaseManager] Connection verified successfully');
        return;
      } catch (error) {
        log(`[DatabaseManager] Connection attempt ${attempt}/${this.MAX_RETRIES} failed: ${error}`);

        if (attempt === this.MAX_RETRIES) {
          throw error;
        }

        await new Promise(resolve => setTimeout(resolve, this.RETRY_DELAY * attempt));
      }
    }
  }

  getDrizzle() {
    if (!this.pool || !this.isInitialized) {
      throw new Error('[DatabaseManager] Database not initialized');
    }
    return drizzle(this.pool, { schema });
  }

  async cleanup(): Promise<void> {
    if (this.isShuttingDown) {
      return;
    }

    this.isShuttingDown = true;
    log('[DatabaseManager] Starting cleanup...');

    try {
      if (this.pool) {
        await Promise.race([
          this.pool.end(),
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Pool end timeout')), this.CLEANUP_TIMEOUT)
          )
        ]);
      }

      log('[DatabaseManager] Cleanup completed');
    } catch (error) {
      log(`[DatabaseManager] Error during cleanup: ${error}`);
      throw error;
    } finally {
      this.pool = null;
      this.isInitialized = false;
      this.isShuttingDown = false;
    }
  }

  isConnected(): boolean {
    return this.isInitialized && !this.isShuttingDown;
  }
}

// Create and export the singleton instance
const poolConfig: pg.PoolConfig = {
  connectionString: process.env.DATABASE_URL,
  max: process.env.DATABASE_MAX_CONNECTIONS 
    ? parseInt(process.env.DATABASE_MAX_CONNECTIONS, 10)
    : 20,
  idleTimeoutMillis: process.env.DATABASE_IDLE_TIMEOUT
    ? parseInt(process.env.DATABASE_IDLE_TIMEOUT, 10)
    : 30000,
  connectionTimeoutMillis: process.env.DATABASE_CONNECTION_TIMEOUT
    ? parseInt(process.env.DATABASE_CONNECTION_TIMEOUT, 10)
    : 5000,
  ssl: process.env.NODE_ENV === 'production'
    ? { rejectUnauthorized: false }
    : false,
  keepAlive: true,
  application_name: 'nclex_prep_app',
};

export const dbManager = new DatabaseManager(poolConfig);