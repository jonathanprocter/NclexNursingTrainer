import { OpenAI } from "openai";
import { type Question, type UserProgress } from "@db/schema";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

interface PerformanceMetrics {
  accuracy: number;
  timePerQuestion: number;
  difficultyLevel: string;
  domainPerformance: Record<string, number>;
  weakAreas: string[];
  strongAreas: string[];
}

export class PerformanceAnalyticsService {
  async analyzePerformance(
    userProgress: UserProgress[],
    questions: Question[],
  ): Promise<PerformanceMetrics> {
    // Calculate basic metrics
    const metrics = this.calculateBasicMetrics(userProgress, questions);

    // Enhance analysis with AI recommendations
    const enhancedAnalysis = await this.generateAIRecommendations(metrics);

    return enhancedAnalysis;
  }

  private calculateBasicMetrics(
    userProgress: UserProgress[],
    questions: Question[],
  ): PerformanceMetrics {
    const domainPerformance: Record<
      string,
      { correct: number; total: number }
    > = {};
    let totalCorrect = 0;
    let totalTime = 0;

    userProgress.forEach((progress) => {
      const question = questions.find((q) => q.id === progress.questionId);
      if (!question) return;

      // Track domain performance
      const domain = question.domainId.toString();
      if (!domainPerformance[domain]) {
        domainPerformance[domain] = { correct: 0, total: 0 };
      }
      domainPerformance[domain].total++;
      if (progress.correct) {
        domainPerformance[domain].correct++;
        totalCorrect++;
      }

      totalTime += progress.responseTime;
    });

    // Calculate domain percentages
    const domainPercentages: Record<string, number> = {};
    Object.entries(domainPerformance).forEach(([domain, stats]) => {
      domainPercentages[domain] = (stats.correct / stats.total) * 100;
    });

    // Identify weak and strong areas
    const weakAreas = Object.entries(domainPercentages)
      .filter(([_, percentage]) => percentage < 70)
      .map(([domain]) => domain);

    const strongAreas = Object.entries(domainPercentages)
      .filter(([_, percentage]) => percentage >= 85)
      .map(([domain]) => domain);

    return {
      accuracy: (totalCorrect / userProgress.length) * 100,
      timePerQuestion: totalTime / userProgress.length,
      difficultyLevel: this.calculateOverallDifficulty(userProgress),
      domainPerformance: domainPercentages,
      weakAreas,
      strongAreas,
    };
  }

  private calculateOverallDifficulty(userProgress: UserProgress[]): string {
    const averageScore =
      userProgress.reduce(
        (sum, progress) => sum + (progress.correct ? 1 : 0),
        0,
      ) / userProgress.length;

    if (averageScore >= 0.8) return "hard";
    if (averageScore >= 0.6) return "medium";
    return "easy";
  }

  private async generateAIRecommendations(
    metrics: PerformanceMetrics,
  ): Promise<PerformanceMetrics> {
    try {
      const prompt = `
        Analyze this NCLEX exam performance data and provide specific study recommendations:
        - Overall accuracy: ${metrics.accuracy}%
        - Average time per question: ${metrics.timePerQuestion} seconds
        - Current difficulty level: ${metrics.difficultyLevel}
        - Weak areas: ${metrics.weakAreas.join(", ")}
        - Strong areas: ${metrics.strongAreas.join(", ")}
        
        Provide focused recommendations for improvement.
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content:
              "You are an expert NCLEX tutor providing specific, actionable study recommendations.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
      });

      const aiRecommendations = response.choices[0].message.content;

      return {
        ...metrics,
        weakAreas: [
          ...metrics.weakAreas,
          ...this.extractRecommendations(aiRecommendations),
        ],
      };
    } catch (error) {
      console.error("Error generating AI recommendations:", error);
      return metrics;
    }
  }

  private extractRecommendations(aiResponse: string): string[] {
    // Extract key points from AI response
    return aiResponse
      .split("\n")
      .filter((line) => line.trim().startsWith("-"))
      .map((line) => line.trim().substring(2));
  }
}
