Here's the fixed version of the code:

```typescript
import { db } from "@db";
import { eq, users } from "@db/schema";

interface StudentProgress {
  id: string;
  name: string;
  averageScore: number;
  questionsAttempted: number;
  lastActive: string;
  performanceTrend: number[];
  weakAreas: string[];
  learningProgress: {
    retentionRate: number;
    accuracyTrend: number;
    estimatedMastery: number;
  };
}

interface DomainStats {
  domain: string;
  averageScore: number;
  totalAttempts: number;
  improvement: number;
  distribution: {
    category: string;
    value: number;
  }[];
  trendData: {
    date: string;
    score: number;
  }[];
}

export const instructorDashboardService = {
  async getStudentProgress(): Promise<StudentProgress[]> {
    try {
      // Get non-instructor users
      const students = await db.query.users.findMany({
        where: eq(users.isInstructor, false),
      });

      return students.map((student) => ({
        id: student.id,
        name: student.username,
        averageScore: 85, // Default value for demo
        questionsAttempted: 120,
        lastActive:
          student.lastActive?.toISOString() || new Date().toISOString(),
        performanceTrend: [75, 78, 82, 85],
        weakAreas: ["Pharmacology", "Critical Care"],
        learningProgress: {
          retentionRate: 0.85,
          accuracyTrend: 0.82,
          estimatedMastery: 78,
        },
      }));
    } catch (error) {
      console.error("Error fetching student progress:", error);
      throw new Error("Failed to fetch student progress");
    }
  },

  async getDomainStats(): Promise<DomainStats[]> {
    try {
      const domainStats: DomainStats[] = [
        {
          domain: "Management of Care",
          averageScore: 85,
          totalAttempts: 250,
          improvement: 15,
          distribution: [
            { category: "High", value: 45 },
            { category: "Medium", value: 35 },
            { category: "Low", value: 20 },
          ],
          trendData: Array.from({ length: 7 }, (_, i) => ({
            date: new Date(
              Date.now() - i * 24 * 60 * 60 * 1000
            ).toLocaleDateString(),
            score: 75 + Math.random() * 15,
          })),
        },
        {
          domain: "Safety and Infection Control",
          averageScore: 82,
          totalAttempts: 180,
          improvement: 12,
          distribution: [
            { category: "High", value: 40 },
            { category: "Medium", value: 40 },
            { category: "Low", value: 20 },
          ],
          trendData: Array.from({ length: 7 }, (_, i) => ({
            date: new Date(
              Date.now() - i * 24 * 60 * 60 * 1000
            ).toLocaleDateString(),
            score: 70 + Math.random() * 15,
          })),
        },
        {
          domain: "Health Promotion",
          averageScore: 88,
          totalAttempts: 200,
          improvement: 18,
          distribution: [
            { category: "High", value: 50 },
            { category: "Medium", value: 30 },
            { category: "Low", value: 20 },
          ],
          trendData: Array.from({ length: 7 }, (_, i) => ({
            date: new Date(
              Date.now() - i * 24 * 60 * 60 * 1000
            ).toLocaleDateString(),
            score: 80 + Math.random() * 10,
          })),
        },
        {
          domain: "Psychosocial Integrity",
          averageScore: 80,
          totalAttempts: 150,
          improvement: 10,
          distribution: [
            { category: "High", value: 35 },
            { category: "Medium", value: 45 },
            { category: "Low", value: 20 },
          ],
          trendData: Array.from({ length: 7 }, (_, i) => ({
            date: new Date(
              Date.now() - i * 24 * 60 * 60 * 1000
            ).toLocaleDateString(),
            score: 75 + Math.random() * 12,
          })),
        },
      ];

      return domainStats;
    } catch (error) {
      console.error("Error fetching domain stats:", error);
      throw new Error("Failed to fetch domain statistics");
    }
  },
};
```