import { db } from "@db";
import { questions, userProgress, nclexDomains } from "@db/schema";
import { eq, and, desc, inArray } from "drizzle-orm";
import { aiService } from "../../tmp/extracted/nclex_prep_project_part_5/server/services/ai-service";
import crypto from "crypto";

export interface PracticeExamConfig {
  userId: number;
  questionCount: number;
  timeLimit: number; // in minutes
  adaptiveDifficulty: boolean;
  categories?: string[];
}

export interface PracticeExamSession {
  id: string;
  userId: number;
  startTime: Date;
  endTime: Date;
  timeLimit: number;
  questions: PracticeQuestion[];
  currentQuestionIndex: number;
  completed: boolean;
  score?: number;
}

export interface PracticeQuestion {
  id: number;
  content: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
  category: string;
  difficulty: "easy" | "medium" | "hard";
  timeSpent?: number;
  answered?: boolean;
  userAnswer?: string;
}

class PracticeExamService {
  private activeExams: Map<string, PracticeExamSession> = new Map();

  async createExam(config: PracticeExamConfig): Promise<PracticeExamSession> {
    try {
      // Get questions based on user's performance and selected categories
      const questions = await this.generateQuestionSet(config);

      const session: PracticeExamSession = {
        id: crypto.randomUUID(),
        userId: config.userId,
        startTime: new Date(),
        endTime: new Date(Date.now() + config.timeLimit * 60 * 1000),
        timeLimit: config.timeLimit,
        questions,
        currentQuestionIndex: 0,
        completed: false,
      };

      this.activeExams.set(session.id, session);
      return session;
    } catch (error) {
      console.error("Error creating practice exam:", error);
      throw new Error("Failed to create practice exam");
    }
  }

  async submitAnswer(
    examId: string,
    answer: string,
    timeSpent: number,
  ): Promise<{
    completed: boolean;
    nextQuestion: PracticeQuestion | null;
    timeRemaining: number;
    currentQuestionIndex: number;
  }> {
    if (!examId) {
      throw new Error("Invalid exam ID");
    }

    const session = this.activeExams.get(examId);
    if (!session) {
      throw new Error("Exam not found");
    }

    const question = session.questions[session.currentQuestionIndex];
    if (!question) {
      throw new Error("Invalid question");
    }

    // Record the answer
    question.answered = true;
    question.userAnswer = answer;
    question.timeSpent = timeSpent;

    // Move to next question
    session.currentQuestionIndex++;

    // Check if this was the last question or time is up
    const isComplete = session.currentQuestionIndex >= session.questions.length;
    if (isComplete) {
      session.completed = true;
      return {
        completed: true,
        nextQuestion: null,
        timeRemaining: 0,
        currentQuestionIndex: session.currentQuestionIndex,
      };
    }

    const nextQuestion = session.questions[session.currentQuestionIndex];
    return {
      completed: false,
      nextQuestion,
      timeRemaining: Math.max(0, session.timeLimit * 60 - timeSpent),
      currentQuestionIndex: session.currentQuestionIndex,
    };
  }

  async completeExam(examId: string) {
    const session = this.activeExams.get(examId);
    if (!session) {
      throw new Error("Exam not found");
    }

    const totalTimeSpent = session.questions.reduce(
      (total, q) => total + (q.timeSpent || 0),
      0,
    );

    // Get domain information for all questions
    const domainIds = new Set(session.questions.map((q) => Number(q.category)));
    const domains = await db
      .select()
      .from(nclexDomains)
      .where(inArray(nclexDomains.id, Array.from(domainIds)));

    const domainMap = new Map(domains.map((d) => [d.id, d]));

    // Calculate results by question
    const questionResults = session.questions.map((q) => {
      const domainId = Number(q.category);
      const domain = domainMap.get(domainId);
      return {
        id: q.id,
        question: q.content,
        correctAnswer: q.correctAnswer,
        explanation: q.explanation,
        category: domain?.name || "Uncategorized",
        difficulty: q.difficulty,
        userAnswer: q.userAnswer || "",
        timeSpent: q.timeSpent || 0,
        isCorrect: q.userAnswer === q.correctAnswer,
      };
    });

    // Calculate overall statistics
    const correctAnswers = questionResults.filter((q) => q.isCorrect).length;
    const score = (correctAnswers / session.questions.length) * 100;

    // Calculate performance by category
    const categoryPerformance = questionResults.reduce(
      (acc, q) => {
        if (!acc[q.category]) {
          acc[q.category] = { total: 0, correct: 0, timeSpent: 0 };
        }
        acc[q.category].total++;
        if (q.isCorrect) acc[q.category].correct++;
        acc[q.category].timeSpent += q.timeSpent;
        return acc;
      },
      {} as Record<
        string,
        { total: number; correct: number; timeSpent: number }
      >,
    );

    // Identify areas for improvement
    const areasForImprovement = Object.entries(categoryPerformance)
      .map(([category, data]) => ({
        category,
        accuracy: (data.correct / data.total) * 100,
        averageTime: data.timeSpent / data.total,
      }))
      .sort((a, b) => a.accuracy - b.accuracy)
      .slice(0, 3);

    return {
      score,
      totalQuestions: session.questions.length,
      correctAnswers,
      totalTimeSpent,
      averageTimePerQuestion: totalTimeSpent / session.questions.length,
      questions: questionResults,
      categoryPerformance,
      areasForImprovement,
      timeAnalysis: {
        totalTime: totalTimeSpent,
        averageTimePerQuestion: totalTimeSpent / session.questions.length,
        timeByCategory: categoryPerformance,
      },
    };
  }

  private async generateQuestionSet(
    config: PracticeExamConfig,
  ): Promise<PracticeQuestion[]> {
    try {
      // Join with nclexDomains to get domain information
      const questionsData = await db
        .select({
          id: questions.id,
          scenario: questions.scenario,
          options: questions.options,
          correctAnswer: questions.correctAnswer,
          explanation: questions.explanation,
          difficulty: questions.difficulty,
          domainId: questions.domainId,
          domainName: nclexDomains.name,
        })
        .from(questions)
        .leftJoin(nclexDomains, eq(questions.domainId, nclexDomains.id))
        .limit(config.questionCount);

      return questionsData.map((q) => ({
        id: q.id,
        content: q.scenario,
        options: q.options,
        correctAnswer: q.correctAnswer,
        explanation: q.explanation,
        category: q.domainId.toString(), // Store domain ID for later mapping
        difficulty: q.difficulty as "easy" | "medium" | "hard",
        answered: false,
      }));
    } catch (error) {
      console.error("Error generating question set:", error);
      throw new Error("Failed to generate question set");
    }
  }

  getSession(sessionId: string): PracticeExamSession | undefined {
    return this.activeExams.get(sessionId);
  }
}

export const practiceExamService = new PracticeExamService();
