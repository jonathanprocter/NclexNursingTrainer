import { EventEmitter } from "events";
import { poolManager } from "./pool-manager";
import { queryMonitor } from "./query-monitor";
import { log } from "../vite";

interface HealthMetrics {
  responseTime: number;
  connectionCount: number;
  queryCount: number;
  errorRate: number;
}

class HealthChecker extends EventEmitter {
  private isRunning = false;
  private checkInterval: NodeJS.Timeout | null = null;
  private readonly CHECK_INTERVAL = 30000; // 30 seconds
  private readonly RESPONSE_TIME_THRESHOLD = 1000; // 1 second
  private readonly ERROR_RATE_THRESHOLD = 0.1; // 10%

  async startMonitoring(): Promise<void> {
    if (this.isRunning) return;

    this.isRunning = true;
    await this.runHealthCheck();

    this.checkInterval = setInterval(async () => {
      try {
        await this.runHealthCheck();
      } catch (error) {
        const errorMessage =
          error instanceof Error ? error.message : String(error);
        log(`Health check failed: ${errorMessage}`);
        this.emit("error", error);
      }
    }, this.CHECK_INTERVAL);

    log("Database health monitoring started");
  }

  stop(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
    this.isRunning = false;
    log("Database health monitoring stopped");
  }

  async checkHealth(): Promise<boolean> {
    try {
      const metrics = await this.gatherMetrics();
      const isHealthy = this.evaluateHealth(metrics);

      if (!isHealthy) {
        this.emit("unhealthy", metrics);
        return false;
      }

      return true;
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : String(error);
      log(`Health check error: ${errorMessage}`);
      this.emit("error", error);
      return false;
    }
  }

  private async runHealthCheck(): Promise<void> {
    const isHealthy = await this.checkHealth();
    this.emit("healthCheck", {
      timestamp: new Date(),
      healthy: isHealthy,
    });
  }

  private async gatherMetrics(): Promise<HealthMetrics> {
    const start = Date.now();

    try {
      // Test basic query functionality
      await poolManager.executeQuery(async (client) => {
        const { rows } = await client.query("SELECT 1");
        return rows[0];
      });
      const responseTime = Date.now() - start;

      // Get current connection stats using pg_stat_activity
      const { rows: connectionStats } = await poolManager.executeQuery(
        async (client) => {
          return client.query(`
          SELECT count(*) as count 
          FROM pg_stat_activity 
          WHERE datname = current_database()
        `);
        },
      );

      const connectionCount = parseInt(connectionStats[0]?.count || "0", 10);

      // Get query metrics from the monitor
      const queryMetrics = queryMonitor.getMetrics() as Map<string, any>;
      const queryCount = queryMetrics.size;

      // Calculate error rate from recent queries
      const recentQueries = Array.from(queryMetrics.values()).filter(
        (m) => m.timestamp > new Date(Date.now() - 5 * 60 * 1000),
      ); // Last 5 minutes

      const errorRate =
        recentQueries.length > 0
          ? recentQueries.filter((m) => m.error).length / recentQueries.length
          : 0;

      return {
        responseTime,
        connectionCount,
        queryCount,
        errorRate,
      };
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : String(error);
      log(`Error gathering health metrics: ${errorMessage}`);
      throw error;
    }
  }

  private evaluateHealth(metrics: HealthMetrics): boolean {
    return (
      metrics.responseTime < this.RESPONSE_TIME_THRESHOLD &&
      metrics.errorRate < this.ERROR_RATE_THRESHOLD &&
      metrics.connectionCount > 0
    );
  }
}

export const healthChecker = new HealthChecker();