Here's the fixed code with improvements in code structure, error handling, type safety, and best practices:

```typescript
import { db } from "@db";
import {
  flashcards,
  flashcardProgress,
  type Flashcard,
  type FlashcardProgress,
  type NewFlashcard,
  type NewFlashcardProgress,
} from "@db/schema";
import { sql } from "drizzle-orm";
import { eq, desc, and, lt } from "drizzle-orm";
import { spacedRepetitionService } from "./spaced-repetition.service";

interface ConceptBreakdown {
  keyPoints: string[];
  relatedConcepts: string[];
  clinicalCorrelation: string;
}

interface NCLEXQuestion {
  question: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
  conceptBreakdown?: ConceptBreakdown;
  tags?: string[];
}

interface VoiceOptions {
  enabled: boolean;
  speed?: number;
  pitch?: number;
  voice?: string;
}

const debug = {
  log: (...args: unknown[]): void => console.log("[Flashcard Debug]:", ...args),
  error: (...args: unknown[]): void => console.error("[Flashcard Error]:", ...args),
};

function validateQuestion(question: NCLEXQuestion): boolean {
  return !!(
    question.question &&
    Array.isArray(question.options) &&
    question.options.length >= 2 &&
    question.correctAnswer &&
    question.explanation
  );
}

function createEnhancedExplanation(question: NCLEXQuestion): string {
  if (!question.conceptBreakdown) return question.explanation;

  const breakdown = question.conceptBreakdown;
  return `${question.explanation}\n\nKey Points:\n${breakdown.keyPoints.join("\n")}\n\nClinical Application:\n${breakdown.clinicalCorrelation}\n\nRelated Concepts:\n${breakdown.relatedConcepts.join(", ")}`.trim();
}

export class FlashcardService {
  async createFlashcard(
    question: NCLEXQuestion,
    userId: number,
    domain: string,
  ): Promise<Flashcard> {
    if (!validateQuestion(question)) {
      throw new Error("Invalid question format");
    }

    debug.log("Processing question:", question.question);

    const newFlashcard: NewFlashcard = {
      userId,
      front: question.question,
      back: question.correctAnswer,
      domain,
      difficulty: "medium",
      question: question.question,
      options: question.options,
      correctAnswer: question.correctAnswer,
      explanation: createEnhancedExplanation(question),
      tags: question.tags || [],
      metadata: {
        source: "ai_generated",
        aiGenerated: true,
        confidence: 0.8,
      },
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const [result] = await db
      .insert(flashcards)
      .values(newFlashcard)
      .returning();

    return result;
  }

  async getFlashcards(userId: number): Promise<Flashcard[]> {
    return await db
      .select()
      .from(flashcards)
      .where(eq(flashcards.userId, userId))
      .orderBy(desc(flashcards.createdAt));
  }

  async getDueFlashcards(userId: number, limit = 10): Promise<(Flashcard & { reviewData: FlashcardProgress })[]> {
    const now = new Date();
    const dueCards = await db
      .select()
      .from(flashcardProgress)
      .leftJoin(flashcards, eq(flashcardProgress.flashcardId, flashcards.id))
      .where(
        and(
          eq(flashcardProgress.userId, userId),
          lt(flashcardProgress.nextReview, now),
        ),
      )
      .limit(limit);

    return dueCards.map(({ flashcard_progress, flashcards }) => ({
      ...flashcards,
      reviewData: {
        lastReview: flashcard_progress.lastReview,
        nextReview: flashcard_progress.nextReview,
        correctStreak: flashcard_progress.correctStreak,
        totalReviews: flashcard_progress.timesReviewed,
      },
    }));
  }

  async recordFlashcardReview(
    userId: number,
    flashcardId: number,
    isCorrect: boolean,
    confidence: number,
  ): Promise<{ success: boolean }> {
    const nextReview = await spacedRepetitionService.calculateNextReview(
      flashcardId,
      isCorrect,
    );

    const progressData: NewFlashcardProgress = {
      userId,
      flashcardId,
      correct: isCorrect,
      confidence,
      lastReview: new Date(),
      nextReview,
      timesReviewed: 1,
      performance: {
        confidence,
        timeSpent: 0,
        mistakes: isCorrect ? 0 : 1,
      },
    };

    await db
      .insert(flashcardProgress)
      .values(progressData)
      .onConflictDoUpdate({
        target: [flashcardProgress.userId, flashcardProgress.flashcardId],
        set: {
          lastReview: new Date(),
          nextReview,
          timesReviewed: sql`${flashcardProgress.timesReviewed} + 1`,
          correctStreak: isCorrect
            ? sql`${flashcardProgress.correctStreak} + 1`
            : 0,
        },
      });

    return { success: true };
  }

  async getFlashcardWithVoice(
    flashcardId: number,
    voiceOptions: VoiceOptions = { enabled: false },
  ): Promise<Flashcard & { voiceContent?: Record<string, string | number | boolean> }> {
    const flashcard = await db.query.flashcards.findFirst({
      where: eq(flashcards.id, flashcardId),
    });

    if (!flashcard) {
      throw new Error("Flashcard not found");
    }

    if (voiceOptions.enabled) {
      return {
        ...flashcard,
        voiceContent: {
          front: flashcard.front,
          back: flashcard.back,
          explanation: flashcard.explanation || "",
          options: flashcard.options?.join(". Next option. "),
          speed: voiceOptions.speed || 1,
          pitch: voiceOptions.pitch || 1,
          voice: voiceOptions.voice || "default",
        },
      };
    }

    return flashcard;
  }
}

export const flashcardService = new FlashcardService();
```