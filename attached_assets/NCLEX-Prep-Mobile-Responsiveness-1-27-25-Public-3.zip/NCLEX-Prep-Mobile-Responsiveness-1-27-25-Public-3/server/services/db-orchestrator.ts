Here's the complete fixed code for the `/home/runner/workspace/server/services/db-orchestrator.ts` file:

```typescript
import { EventEmitter } from "events";
import { poolManager } from "./pool-manager";
import { queryMonitor } from "./query-monitor";
import { healthChecker } from "./health-checker";
import { cleanupService } from "./cleanup-service";
import { DatabaseError } from "./utils";
import { log } from "../vite";

interface ServiceStatus {
  poolManager: boolean;
  queryMonitor: boolean;
  healthChecker: boolean;
  cleanupService: boolean;
}

interface HealthMetrics {
  responseTime: number;
  connectionCount: number;
  queryCount: number;
  errorRate: number;
}

export class DatabaseOrchestrator extends EventEmitter {
  private serviceStatus: ServiceStatus = {
    poolManager: false,
    queryMonitor: false,
    healthChecker: false,
    cleanupService: false,
  };

  private recoveryMode = false;
  private readonly recoveryAttempts = new Map<string, number>();
  private readonly MAX_RECOVERY_ATTEMPTS = 3;
  private isShuttingDown = false;
  private initPromise: Promise<boolean> | null = null;
  private initRetryCount = 0;
  private readonly MAX_INIT_RETRIES = 3;
  private readonly INIT_RETRY_DELAY = 1000;

  constructor() {
    super();
    this.setupProcessHandlers();
  }

  private setupProcessHandlers() {
    process.on("SIGTERM", async () => {
      await this.cleanup("SIGTERM received");
    });

    process.on("SIGINT", async () => {
      await this.cleanup("SIGINT received");
    });

    process.on("unhandledRejection", async (error: unknown) => {
      const errorMessage =
        error instanceof Error ? error.message : String(error);
      log(
        `Unhandled Promise Rejection in DatabaseOrchestrator: ${errorMessage}`
      );
      if (!this.isShuttingDown) {
        await this.handleUnhealthyState();
      }
    });
  }

  async initialize(): Promise<boolean> {
    if (this.isShuttingDown) {
      throw new Error("Cannot initialize during shutdown");
    }

    if (this.initPromise) {
      return this.initPromise;
    }

    this.initPromise = this._initialize();
    return this.initPromise;
  }

  private async _initialize(): Promise<boolean> {
    try {
      if (this.initRetryCount >= this.MAX_INIT_RETRIES) {
        throw new Error(
          `Failed to initialize after ${this.MAX_INIT_RETRIES} attempts`
        );
      }

      log("Initializing database services...");

      // Start monitoring with retry logic
      await this.startMonitoringWithRetry();

      // Start cleanup service
      await this.startCleanupService();

      // Setup event listeners
      this.setupEventListeners();

      this.initPromise = null;
      this.initRetryCount = 0;
      log("Database services initialized successfully");
      return true;
    } catch (error: unknown) {
      const errorMessage =
        error instanceof Error ? error.message : String(error);
      log(`Failed to initialize database services: ${errorMessage}`);

      this.initRetryCount++;
      this.initPromise = null;

      if (this.initRetryCount < this.MAX_INIT_RETRIES) {
        log(
          `Retrying initialization (attempt ${this.initRetryCount + 1}/${
            this.MAX_INIT_RETRIES
          })...`
        );
        await new Promise((resolve) =>
          setTimeout(resolve, this.INIT_RETRY_DELAY * this.initRetryCount)
        );
        return this.initialize();
      }

      await this.cleanup("Initialization failure");
      throw error;
    }
  }

  private async startMonitoringWithRetry(retries = 3): Promise<void> {
    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        // Start health checker
        await healthChecker.startMonitoring();
        this.serviceStatus.healthChecker = true;
        log("Health checker initialized");

        // Start query monitor
        queryMonitor.reset();
        queryMonitor.enable();
        this.serviceStatus.queryMonitor = true;
        log("Query monitor initialized");

        // Initialize pool manager with verification
        await poolManager.executeQuery(async (client) => {
          const result = await client.query("SELECT NOW()");
          if (!result.rows || result.rows.length === 0) {
            throw new Error("Database connection test failed");
          }
          return result.rows[0];
        });

        this.serviceStatus.poolManager = true;
        log("Pool manager initialized");

        return;
      } catch (error: unknown) {
        const errorMessage =
          error instanceof Error ? error.message : String(error);
        log(`Initialization attempt ${attempt} failed: ${errorMessage}`);

        if (attempt === retries) {
          throw new DatabaseError(
            "Failed to start monitoring services after all retries",
            errorMessage
          );
        }

        // Wait before retry with exponential backoff
        await new Promise((resolve) =>
          setTimeout(resolve, Math.pow(2, attempt) * 1000)
        );
      }
    }
  }

  private async startCleanupService() {
    try {
      await cleanupService.startScheduledCleanup();
      this.serviceStatus.cleanupService = true;
      log("Cleanup service started");
    } catch (error: unknown) {
      const errorMessage =
        error instanceof Error ? error.message : String(error);
      log(`Failed to start cleanup service (non-critical): ${errorMessage}`);
    }
  }

  private setupEventListeners() {
    // Health check events
    healthChecker.on("unhealthy", async (metrics: HealthMetrics) => {
      if (this.isShuttingDown) return;

      const metricsStr = JSON.stringify(metrics);
      log(`Database health check failed: ${metricsStr}`);
      await this.handleUnhealthyState();
    });

    // Query monitor events
    queryMonitor.on(
      "slowQuery",
      (data: { queryId: string; duration: number }) => {
        if (this.isShuttingDown) return;

        const dataStr = JSON.stringify(data);
        log(`Slow query detected: ${dataStr}`);
      }
    );

    queryMonitor.on(
      "queryError",
      async (data: { queryId: string; error: Error }) => {
        if (this.isShuttingDown) return;

        const errorStr = JSON.stringify({
          queryId: data.queryId,
          error: data.error.message,
        });
        log(`Query error: ${errorStr}`);
        await this.handleQueryError(data.error);
      }
    );

    // Cleanup service events
    cleanupService.on("error", (error: Error) => {
      if (this.isShuttingDown) return;
      log(`Cleanup service error: ${error.message}`);
    });
  }

  private async handleUnhealthyState() {
    if (this.recoveryMode || this.isShuttingDown) return;

    this.recoveryMode = true;
    try {
      log("Attempting to recover database services...");

      // Reset connection pool
      await this.resetConnectionPool();

      // Check if recovery was successful
      const isHealthy = await healthChecker.checkHealth();
      if (!isHealthy) {
        throw new Error("Recovery failed - database still unhealthy");
      }

      log("Database services recovered successfully");
    } catch (error: unknown) {
      const errorMessage =
        error instanceof Error ? error.message : String(error);
      log(`Recovery failed: ${errorMessage}`);
      this.emit("recoveryFailed", error);

      if (!this.isShuttingDown) {
        await this.cleanup("Recovery failure");
      }
    } finally {
      this.recoveryMode = false;
    }
  }

  private async resetConnectionPool() {
    try {
      // Close all existing connections
      await poolManager.cleanup();

      // Attempt to establish new connections
      await poolManager.executeQuery(async (client) => {
        const result = await client.query("SELECT NOW()");
        if (!result.rows || result.rows.length === 0) {
          throw new Error("Connection test failed");
        }
        return result.rows[0];
      });
      log("Connection pool reset successfully");
    } catch (error: unknown) {
      const errorMessage =
        error instanceof Error ? error.message : String(error);
      throw new Error(`Failed to reset connection pool: ${errorMessage}`);
    }
  }

  private async handleQueryError(error: Error) {
    if (this.isShuttingDown) return;

    const errorType = error.name || "UnknownError";
    const attempts = this.recoveryAttempts.get(errorType) || 0;

    if (attempts < this.MAX_RECOVERY_ATTEMPTS) {
      this.recoveryAttempts.set(errorType, attempts + 1);
      await this.handleUnhealthyState();
    } else {
      this.emit("maxRecoveryAttemptsExceeded", {
        errorType,
        attempts,
      });

      if (!this.isShuttingDown) {
        await this.cleanup("Max recovery attempts exceeded");
      }
    }
  }

  getServiceStatus(): ServiceStatus {
    return { ...this.serviceStatus };
  }

  async cleanup(reason = "Unknown"): Promise<void> {
    if (this.isShuttingDown) {
      return;
    }

    this.isShuttingDown = true;
    log(`Starting database services cleanup (Reason: ${reason})...`);

    try {
      // Stop all services in reverse order of initialization
      const cleanupPromises: Promise<void>[] = [];

      if (this.serviceStatus.healthChecker) {
        cleanupPromises.push(
          (async () => {
            healthChecker.stop();
            log("Health checker stopped");
          })()
        );
      }

      if (this.serviceStatus.cleanupService) {
        cleanupPromises.push(
          (async () => {
            cleanupService.stop();
            log("Cleanup service stopped");
          })()
        );
      }

      if (this.serviceStatus.poolManager) {
        cleanupPromises.push(
          (async () => {
            await poolManager.cleanup();
            log("Pool manager cleaned up");
          })()
        );
      }

      if (this.serviceStatus.queryMonitor) {
        cleanupPromises.push(
          (async () => {
            queryMonitor.reset();
            log("Query monitor reset");
          })()
        );
      }

      // Wait for all cleanup operations with timeout
      await Promise.race([
        Promise.all(cleanupPromises),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error("Cleanup timeout")), 5000)
        ),
      ]);

      this.serviceStatus = {
        poolManager: false,
        queryMonitor: false,
        healthChecker: false,
        cleanupService: false,
      };

      log("Database services cleanup completed successfully");
    } catch (error: unknown) {
      const errorMessage =
        error instanceof Error ? error.message : String(error);
      log(`Error during cleanup: ${errorMessage}`);
      throw error;
    } finally {
      this.isShuttingDown = false;
      this.initPromise = null;
      this.initRetryCount = 0;
      this.recoveryAttempts.clear();
    }
  }
}

export const dbOrchestrator = new DatabaseOrchestrator();
```