import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Brain, ThumbsUp, ThumbsDown, Check, X } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ErrorBoundary } from "@/components/error-boundary";
import { Suspense } from "react";
//import { indexedDBService } from "@/lib/indexedDb"; //Removed unnecessary import

interface FlashcardStudyProps {
  category?: string;
  onComplete?: () => void;
}

export function FlashcardStudy({ category, onComplete }: FlashcardStudyProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [confidenceRating, setConfidenceRating] = useState(0);
  const { toast } = useToast();

  const {
    data: flashcards,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["/api/flashcards", category],
    queryFn: async () => {
      const response = await fetch(
        `/api/flashcards?${category ? `category=${category}` : ""}`,
      );
      if (!response.ok) throw new Error("Failed to fetch flashcards");
      return response.json();
    },
  });

  const recordAttempt = useMutation({
    mutationFn: async (data: {
      cardId: number;
      isCorrect: boolean;
      confidence: number;
    }) => {
      const response = await fetch("/api/flashcards/progress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to record attempt");
      return response.json();
    },
  });

  if (error) {
    return <div className="text-red-500">Error loading flashcards</div>;
  }

  if (isLoading || !flashcards) {
    return <div>Loading flashcards...</div>;
  }

  const currentCard = flashcards[currentIndex];
  if (!currentCard) return null;

  const handleAnswer = (answer: string) => {
    if (confidenceRating === 0) {
      toast({
        title: "Confidence Rating Required",
        description: "Please rate your confidence before selecting an answer",
        variant: "destructive",
      });
      return;
    }

    setSelectedAnswer(answer);
    recordAttempt.mutate({
      cardId: currentCard.id,
      isCorrect: answer === currentCard.correctAnswer,
      confidence: confidenceRating / 100,
    });
  };

  const handleNext = () => {
    if (currentIndex < flashcards.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedAnswer(null);
      setConfidenceRating(0);
    } else {
      onComplete?.();
    }
  };

  return (
    <div className="max-w-3xl mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <span>
          Question {currentIndex + 1} of {flashcards.length}
        </span>
        <Progress
          value={((currentIndex + 1) / flashcards.length) * 100}
          className="w-[200px]"
        />
      </div>

      <Card>
        <CardContent className="p-6 space-y-6">
          {/* Question Display */}
          <div className="prose prose-sm">
            <p className="text-lg font-medium">{currentCard.question}</p>
          </div>

          {/* Confidence Rating (before answer selection) */}
          {!selectedAnswer && (
            <div className="space-y-6">
              <div className="bg-muted/50 rounded-lg p-4 space-y-4">
                <h4 className="font-medium text-sm">
                  Rate your confidence first:
                </h4>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Confidence Level</span>
                    <span className="text-sm font-medium">
                      {confidenceRating}%
                    </span>
                  </div>
                  <Slider
                    value={[confidenceRating]}
                    onValueChange={([value]) => setConfidenceRating(value)}
                    max={100}
                    step={10}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Not confident at all</span>
                    <span>Very confident</span>
                  </div>
                </div>
              </div>

              {/* Answer Options */}
              <div className="grid grid-cols-1 gap-3">
                {currentCard.options.map((option: string, index: number) => (
                  <Button
                    key={index}
                    variant="outline"
                    className="w-full justify-start h-auto py-3 px-4"
                    onClick={() => handleAnswer(option)}
                    disabled={confidenceRating === 0}
                  >
                    {option}
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* Answer and Explanation */}
          {selectedAnswer && (
            <div className="space-y-6">
              <Alert>
                <AlertTitle className="flex items-center gap-2">
                  {selectedAnswer === currentCard.correctAnswer ? (
                    <>
                      <ThumbsUp className="h-4 w-4 text-green-500" />
                      <span className="text-green-500">Correct!</span>
                    </>
                  ) : (
                    <>
                      <ThumbsDown className="h-4 w-4 text-red-500" />
                      <span className="text-red-500">Incorrect</span>
                    </>
                  )}
                </AlertTitle>
                <AlertDescription>
                  <div className="mt-2 space-y-2">
                    <p>
                      <strong>Your Answer:</strong> {selectedAnswer}
                    </p>
                    <p>
                      <strong>Correct Answer:</strong>{" "}
                      {currentCard.correctAnswer}
                    </p>
                    <p>
                      <strong>Your Confidence:</strong> {confidenceRating}%
                    </p>
                  </div>
                </AlertDescription>
              </Alert>

              {/* Explanation */}
              <div className="bg-muted/50 rounded-lg p-4">
                <h4 className="font-medium mb-2">Explanation</h4>
                <p className="text-sm">{currentCard.explanation}</p>
              </div>

              {/* Concept Breakdown */}
              <div className="bg-accent/10 rounded-lg p-4 space-y-4">
                <div className="flex items-center gap-2">
                  <Brain className="h-4 w-4" />
                  <h4 className="font-medium">Concept Breakdown</h4>
                </div>

                {/* Key Points */}
                <div>
                  <h5 className="text-sm font-medium mb-2">Key Points</h5>
                  <ul className="list-disc pl-4 space-y-1">
                    {currentCard.metadata?.conceptBreakdown?.keyPoints?.map(
                      (point: string, i: number) => (
                        <li key={i} className="text-sm">
                          {point}
                        </li>
                      ),
                    )}
                  </ul>
                </div>

                {/* Clinical Correlation */}
                {currentCard.metadata?.conceptBreakdown
                  ?.clinicalCorrelation && (
                  <div>
                    <h5 className="text-sm font-medium mb-2">
                      Clinical Correlation
                    </h5>
                    <p className="text-sm">
                      {
                        currentCard.metadata.conceptBreakdown
                          .clinicalCorrelation
                      }
                    </p>
                  </div>
                )}

                {/* Related Topics */}
                {currentCard.metadata?.conceptBreakdown?.relatedConcepts && (
                  <div>
                    <h5 className="text-sm font-medium mb-2">Related Topics</h5>
                    <div className="flex flex-wrap gap-2">
                      {currentCard.metadata.conceptBreakdown.relatedConcepts.map(
                        (concept: string, i: number) => (
                          <Badge key={i} variant="secondary">
                            {concept}
                          </Badge>
                        ),
                      )}
                    </div>
                  </div>
                )}
              </div>

              <Button onClick={handleNext} className="w-full">
                {currentIndex === flashcards.length - 1
                  ? "Complete"
                  : "Next Question"}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export function FlashcardStudyWrapper(props: FlashcardStudyProps) {
  return (
    <ErrorBoundary
      fallback={
        <div className="p-4 text-red-500">Error loading flashcards</div>
      }
    >
      <Suspense fallback={<div>Loading...</div>}>
        <FlashcardStudy {...props} />
      </Suspense>
    </ErrorBoundary>
  );
}
