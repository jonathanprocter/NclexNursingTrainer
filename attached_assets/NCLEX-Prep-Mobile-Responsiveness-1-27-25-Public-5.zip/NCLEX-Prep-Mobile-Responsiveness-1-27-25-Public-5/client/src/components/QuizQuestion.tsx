import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import {
  Clock,
  ArrowRight,
  ArrowLeft,
  Flag,
  Bookmark,
  HelpCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface QuizQuestionProps {
  question: {
    id: string;
    content: string;
    options: string[];
    explanation?: string;
    category: string;
    difficulty: "beginner" | "intermediate" | "advanced";
    answered?: boolean; // Added answered property
  };
  currentIndex: number;
  totalQuestions: number;
  timeLeft?: number;
  onAnswer: (optionIndex: number) => void;
  onNext: () => void;
  onPrevious: () => void;
  onFlag: () => void;
  onBookmark: () => void;
  selectedAnswer?: number;
  correctAnswer?: number;
  showExplanation?: boolean;
}

export function QuizQuestion({
  question,
  currentIndex,
  totalQuestions,
  timeLeft,
  onAnswer,
  onNext,
  onPrevious,
  onFlag,
  onBookmark,
  selectedAnswer,
  correctAnswer,
  showExplanation,
}: QuizQuestionProps) {
  const [selectedOption, setSelectedOption] = useState<number | undefined>(
    selectedAnswer,
  );
  const [isTimerWarning, setIsTimerWarning] = useState(false);
  const progress = ((currentIndex + 1) / totalQuestions) * 100;

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" && currentIndex < totalQuestions - 1) {
        onNext();
      } else if (e.key === "ArrowLeft" && currentIndex > 0) {
        onPrevious();
      } else if (e.key >= "1" && e.key <= "4") {
        const optionIndex = parseInt(e.key) - 1;
        if (
          optionIndex < question.options.length &&
          !selectedAnswer &&
          !question.answered
        ) {
          // Added !question.answered check
          setSelectedOption(optionIndex);
          onAnswer(optionIndex);
        }
      } else if (e.key === "f") {
        onFlag();
      } else if (e.key === "b") {
        onBookmark();
      }
    };

    window.addEventListener("keydown", handleKeyPress);
    return () => window.removeEventListener("keydown", handleKeyPress);
  }, [
    onNext,
    onPrevious,
    onAnswer,
    question.options.length,
    selectedAnswer,
    currentIndex,
    totalQuestions,
    onFlag,
    onBookmark,
    question.answered,
  ]);

  // Timer warning effect
  useEffect(() => {
    if (timeLeft && timeLeft <= 60) {
      setIsTimerWarning(true);
    } else {
      setIsTimerWarning(false);
    }
  }, [timeLeft]);

  const formatTime = (seconds?: number) => {
    if (!seconds) return "--:--";
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner":
        return "bg-green-100 text-green-800";
      case "intermediate":
        return "bg-yellow-100 text-yellow-800";
      case "advanced":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={question.id}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        transition={{ duration: 0.3 }}
        className="max-w-4xl mx-auto"
      >
        <Card>
          <CardHeader className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Badge variant="outline">
                  Question {currentIndex + 1}/{totalQuestions}
                </Badge>
                <Badge variant="secondary">{question.category}</Badge>
                <Badge
                  variant="outline"
                  className={getDifficultyColor(question.difficulty)}
                >
                  {question.difficulty}
                </Badge>
              </div>
              {timeLeft !== undefined && (
                <motion.div
                  animate={{ scale: isTimerWarning ? [1, 1.1, 1] : 1 }}
                  transition={{
                    duration: 0.5,
                    repeat: isTimerWarning ? Infinity : 0,
                  }}
                  className={cn(
                    "flex items-center gap-2",
                    isTimerWarning ? "text-red-500" : "text-muted-foreground",
                  )}
                >
                  <Clock className="h-4 w-4" />
                  <span className="font-mono">{formatTime(timeLeft)}</span>
                </motion.div>
              )}
            </div>
            <Progress value={progress} className="h-2" />
          </CardHeader>

          <CardContent className="space-y-6">
            <div className="text-lg font-medium leading-relaxed">
              {question.content}
            </div>

            <div className="space-y-3">
              {question.options.map((option, index) => (
                <motion.div
                  key={index}
                  whileHover={{
                    scale: selectedAnswer === undefined ? 1.01 : 1,
                  }}
                  whileTap={{ scale: selectedAnswer === undefined ? 0.99 : 1 }}
                >
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left px-4 py-6 h-auto",
                      {
                        "border-primary":
                          selectedOption === index &&
                          correctAnswer === undefined,
                        "bg-green-50 border-green-500":
                          correctAnswer !== undefined &&
                          index === correctAnswer,
                        "bg-red-50 border-red-500":
                          correctAnswer !== undefined &&
                          selectedOption === index &&
                          index !== correctAnswer,
                      },
                    )}
                    onClick={() => {
                      if (selectedAnswer === undefined && !question.answered) {
                        // Added !question.answered check
                        setSelectedOption(index);
                        onAnswer(index);
                      }
                    }}
                    disabled={selectedAnswer !== undefined}
                  >
                    <span className="font-mono mr-4">
                      {String.fromCharCode(65 + index)}.
                    </span>
                    {option}
                  </Button>
                </motion.div>
              ))}
            </div>

            {showExplanation && question.explanation && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                transition={{ duration: 0.3 }}
                className="bg-muted rounded-lg p-4 border"
              >
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <HelpCircle className="h-4 w-4" />
                  Explanation
                </h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {question.explanation}
                </p>
              </motion.div>
            )}
          </CardContent>

          <CardFooter className="flex justify-between">
            <div className="flex gap-2">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={onBookmark}
                      className="text-muted-foreground hover:text-primary"
                    >
                      <Bookmark className="h-4 w-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Bookmark question (B)</p>
                  </TooltipContent>
                </Tooltip>

                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={onFlag}
                      className="text-muted-foreground hover:text-primary"
                    >
                      <Flag className="h-4 w-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Flag for review (F)</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={onPrevious}
                disabled={currentIndex === 0}
                className="gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Previous
              </Button>
              <Button
                onClick={onNext}
                disabled={currentIndex === totalQuestions - 1}
                className="gap-2"
              >
                Next
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </CardFooter>
        </Card>

        {/* Keyboard shortcuts help */}
        <div className="mt-4 text-center text-sm text-muted-foreground space-y-1">
          <p>Keyboard shortcuts:</p>
          <p>
            <kbd className="px-2 py-1 bg-muted rounded text-xs">←</kbd> Previous
            | <kbd className="px-2 py-1 bg-muted rounded text-xs">→</kbd> Next |{" "}
            <kbd className="px-2 py-1 bg-muted rounded text-xs">1-4</kbd> Select
            option | <kbd className="px-2 py-1 bg-muted rounded text-xs">F</kbd>{" "}
            Flag | <kbd className="px-2 py-1 bg-muted rounded text-xs">B</kbd>{" "}
            Bookmark
          </p>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
