import { ProcessedFile, ExtractedFile } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { SearchBar, SearchOptions } from "@/components/ui/search";
import { Button } from "@/components/ui/button";
import {
  Eye,
  Image as ImageIcon,
  FileCode,
  FileJson,
  FileSpreadsheet,
  FileText,
  File,
  FileQuestion,
  BookOpen,
} from "lucide-react";
import React, { useState, useMemo } from "react";
import { PreviewDialog } from "./PreviewDialog";
import { isImageFile, getFileType } from "@/lib/fileUtils";

interface FileViewerProps {
  files: ProcessedFile[];
}

interface SearchResult {
  fileName: string;
  matches: Array<{
    lineNumber: number;
    line: string;
    start: number;
    end: number;
  }>;
}

const getFileIcon = (fileName: string) => {
  if (fileName.toLowerCase().includes("question")) {
    return FileQuestion;
  }
  if (fileName.toLowerCase().includes("nclex")) {
    return BookOpen;
  }

  const extension = fileName.toLowerCase().slice(fileName.lastIndexOf("."));
  switch (extension) {
    case ".jpg":
    case ".jpeg":
    case ".png":
    case ".gif":
    case ".webp":
      return ImageIcon;
    case ".js":
    case ".ts":
    case ".jsx":
    case ".tsx":
      return FileCode;
    case ".json":
      return FileJson;
    case ".csv":
    case ".xlsx":
      return FileSpreadsheet;
    default:
      return FileText;
  }
};

export function FileViewer({ files }: FileViewerProps) {
  const successfulFiles = files.filter((f) => f.status === "success");
  const [searchResults, setSearchResults] = useState<
    Record<string, SearchResult>
  >({});
  const [activeTab, setActiveTab] = useState<string>(
    successfulFiles[0]?.name || "",
  );
  const [previewFile, setPreviewFile] = useState<ExtractedFile | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const categories = useMemo(() => {
    const allCategories = new Set<string>();
    successfulFiles.forEach((file) => {
      if (file.categories) {
        file.categories.forEach((category) => allCategories.add(category));
      }
    });
    return ["all", ...Array.from(allCategories)];
  }, [successfulFiles]);

  if (successfulFiles.length === 0) return null;

  const searchInContent = (
    content: string,
    query: string,
    options: SearchOptions,
  ): Array<{
    lineNumber: number;
    line: string;
    start: number;
    end: number;
  }> => {
    const matches: Array<{
      lineNumber: number;
      line: string;
      start: number;
      end: number;
    }> = [];

    let searchRegex: RegExp;
    try {
      if (options.useRegex) {
        searchRegex = new RegExp(query, options.caseSensitive ? "g" : "gi");
      } else {
        const escapedQuery = query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        searchRegex = new RegExp(
          escapedQuery,
          options.caseSensitive ? "g" : "gi",
        );
      }
    } catch (error) {
      console.error("Invalid regex:", error);
      return [];
    }

    const lines = content.split("\n");
    lines.forEach((line, index) => {
      let match: RegExpExecArray | null;
      while ((match = searchRegex.exec(line)) !== null) {
        matches.push({
          lineNumber: index + 1,
          line,
          start: match.index,
          end: match.index + match[0].length,
        });
      }
    });

    return matches;
  };

  const handleSearch = (query: string, options: SearchOptions) => {
    if (!query.trim()) {
      setSearchResults({});
      return;
    }

    const results: Record<string, SearchResult> = {};
    successfulFiles.forEach((file) => {
      file.extractedFiles?.forEach((extractedFile) => {
        if (
          selectedCategory !== "all" &&
          file.categories &&
          !file.categories.includes(selectedCategory)
        ) {
          return;
        }

        const decodedContent = atob(extractedFile.content);
        const matches = searchInContent(decodedContent, query, options);
        if (matches.length > 0) {
          const key = `${file.name}/${extractedFile.name}`;
          results[key] = {
            fileName: extractedFile.name,
            matches,
          };
        }
      });
    });

    setSearchResults(results);
  };

  const highlightContent = (content: string, fileName: string) => {
    const key = `${activeTab}/${fileName}`;
    const result = searchResults[key];
    if (!result || result.matches.length === 0) {
      return <code>{content}</code>;
    }

    const lines = content.split("\n");
    return (
      <code>
        {lines.map((line, lineIndex) => {
          const lineMatches = result.matches.filter(
            (m) => m.lineNumber === lineIndex + 1,
          );
          if (lineMatches.length === 0) {
            return <div key={lineIndex}>{line}</div>;
          }

          let lastIndex = 0;
          const elements: JSX.Element[] = [];
          lineMatches.forEach((match, matchIndex) => {
            elements.push(
              <span key={`${lineIndex}-${matchIndex}-before`}>
                {line.slice(lastIndex, match.start)}
              </span>,
            );
            elements.push(
              <span
                key={`${lineIndex}-${matchIndex}-match`}
                className="bg-yellow-200 dark:bg-yellow-900"
              >
                {line.slice(match.start, match.end)}
              </span>,
            );
            lastIndex = match.end;
          });
          elements.push(
            <span key={`${lineIndex}-end`}>{line.slice(lastIndex)}</span>,
          );

          return (
            <div key={lineIndex} className="relative group">
              {elements}
              <span className="absolute left-0 -ml-8 text-gray-400 opacity-0 group-hover:opacity-100 text-xs">
                {lineIndex + 1}
              </span>
            </div>
          );
        })}
      </code>
    );
  };

  const renderPreview = (file: ExtractedFile) => {
    const FileIcon = getFileIcon(file.name);

    if (isImageFile(file)) {
      return (
        <div className="relative group overflow-hidden rounded-md border border-border">
          <div className="aspect-video bg-muted flex items-center justify-center">
            <img
              src={`data:image/${file.type};base64,${file.content}`}
              alt={file.name}
              className="max-h-full max-w-full object-contain transition-transform group-hover:scale-105"
            />
          </div>
          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => setPreviewFile(file)}
              className="transform translate-y-4 group-hover:translate-y-0 transition-transform"
            >
              <Eye className="h-4 w-4 mr-2" />
              Preview
            </Button>
          </div>
        </div>
      );
    }

    return (
      <div className="relative group rounded-md border border-border overflow-hidden">
        <div className="absolute top-2 left-2">
          <FileIcon className="h-5 w-5 text-muted-foreground" />
        </div>
        <pre className="bg-muted/50 p-4 pt-10 rounded-md overflow-x-auto">
          {highlightContent(atob(file.content), file.name)}
        </pre>
        <div className="absolute top-2 right-2 transform translate-y-[-8px] opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition">
          <Button
            variant="secondary"
            size="sm"
            onClick={() => setPreviewFile(file)}
          >
            <Eye className="h-4 w-4 mr-2" />
            Preview
          </Button>
        </div>
      </div>
    );
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <File className="h-5 w-5" />
            NCLEX Content Explorer
          </CardTitle>
          <div className="flex flex-col gap-4">
            <div className="flex gap-2 items-center">
              <span className="text-sm font-medium">Category:</span>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors"
              >
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </option>
                ))}
              </select>
            </div>
            <SearchBar onSearch={handleSearch} />
          </div>
        </CardHeader>
        <CardContent>
          <Tabs
            defaultValue={successfulFiles[0]?.name}
            onValueChange={setActiveTab}
          >
            <TabsList className="w-full">
              {successfulFiles.map((file) => (
                <TabsTrigger
                  key={file.name}
                  value={file.name}
                  className="flex items-center gap-2"
                >
                  {React.createElement(getFileIcon(file.name), {
                    className: "w-4 h-4",
                  })}
                  {file.name}
                  {file.questions && (
                    <span className="ml-2 text-xs bg-primary/10 px-2 py-0.5 rounded-full">
                      {file.questions} Q
                    </span>
                  )}
                </TabsTrigger>
              ))}
            </TabsList>
            {successfulFiles.map((file) => (
              <TabsContent key={file.name} value={file.name}>
                <ScrollArea className="h-[600px] w-full rounded-md border p-4">
                  <div className="grid gap-6">
                    {file.extractedFiles?.map((extracted, index) => (
                      <div key={index} className="space-y-2">
                        <h3 className="font-medium flex items-center gap-2">
                          {React.createElement(getFileIcon(extracted.name), {
                            className: "w-4 h-4",
                          })}
                          {extracted.name}
                        </h3>
                        {renderPreview(extracted)}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>
      {previewFile && (
        <PreviewDialog
          file={previewFile}
          isOpen={!!previewFile}
          onClose={() => setPreviewFile(null)}
        />
      )}
    </>
  );
}
