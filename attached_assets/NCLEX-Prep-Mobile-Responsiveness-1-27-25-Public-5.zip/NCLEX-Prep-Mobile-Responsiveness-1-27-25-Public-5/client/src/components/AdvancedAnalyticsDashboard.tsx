import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { AlertCircle } from "lucide-react";

interface AnalyticsData {
  overallProgress: number;
  recentPerformance: number;
  domainPerformance: Array<{
    domain: string;
    accuracy: number;
    totalAttempts: number;
    status: "strong" | "needs_improvement";
  }>;
  learningTrend: "improving" | "declining" | "stable";
}

const defaultData: AnalyticsData = {
  overallProgress: 0,
  recentPerformance: 0,
  domainPerformance: [],
  learningTrend: "stable"
};

export function AdvancedAnalyticsDashboard() {
  const { data, isLoading, error } = useQuery<AnalyticsData>({
    queryKey: ["/api/analytics/advanced"],
    retry: 1,
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-[300px] w-full" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-[400px]">
        <div className="text-center space-y-2">
          <AlertCircle className="h-8 w-8 mx-auto text-destructive" />
          <p className="text-destructive">Failed to load analytics data</p>
          <p className="text-sm text-muted-foreground">
            Please try again later
          </p>
        </div>
      </div>
    );
  }

  const analytics = data || defaultData;

  // Transform domain performance data for the chart
  const performanceData = analytics.domainPerformance.map((domain) => ({
    name: domain.domain,
    accuracy: Math.round(domain.accuracy),
    attempts: domain.totalAttempts,
  }));

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="pt-6">
          <h3 className="text-lg font-semibold mb-4">Domain Performance</h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={performanceData}>
                <defs>
                  <linearGradient
                    id="accuracyGradient"
                    x1="0"
                    y1="0"
                    x2="0"
                    y2="1"
                  >
                    <stop
                      offset="5%"
                      stopColor="hsl(var(--primary))"
                      stopOpacity={0.1}
                    />
                    <stop
                      offset="95%"
                      stopColor="hsl(var(--primary))"
                      stopOpacity={0}
                    />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Area
                  type="monotone"
                  dataKey="accuracy"
                  stroke="hsl(var(--primary))"
                  fill="url(#accuracyGradient)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <h4 className="text-sm font-medium text-muted-foreground">
              Overall Progress
            </h4>
            <p className="text-2xl font-bold">
              {Math.round(analytics.overallProgress)}%
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h4 className="text-sm font-medium text-muted-foreground">
              Recent Performance
            </h4>
            <p className="text-2xl font-bold">
              {Math.round(analytics.recentPerformance)}%
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h4 className="text-sm font-medium text-muted-foreground">
              Learning Trend
            </h4>
            <p className="text-2xl font-bold capitalize">
              {analytics.learningTrend}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h4 className="text-sm font-medium text-muted-foreground">
              Domains Mastered
            </h4>
            <p className="text-2xl font-bold">
              {analytics.domainPerformance.filter(d => d.status === "strong").length}
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}