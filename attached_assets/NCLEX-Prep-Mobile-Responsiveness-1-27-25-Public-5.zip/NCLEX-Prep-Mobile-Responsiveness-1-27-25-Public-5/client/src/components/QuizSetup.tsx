import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  PlayCircle,
  BookOpen,
  Clock,
  Target,
  Brain,
  AlertCircle,
  Save,
  History,
} from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { motion, AnimatePresence } from "framer-motion";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";

interface QuizSetupProps {
  onStart: (settings: QuizSettings) => void;
}

export interface QuizSettings {
  categoryId: string;
  difficulty: number;
  questionCount: number;
  timeLimit?: number;
  focusAreas?: string[];
}

const mockCategories = [
  {
    id: "1",
    name: "Fundamentals of Nursing",
    description: "Core nursing concepts and basic patient care",
    questionCount: 250,
    averageScore: 75,
    recentImprovement: "+5%",
    lastAttempt: "2 days ago",
    completionRate: 65,
    icon: BookOpen,
    color: "bg-blue-100 text-blue-800",
  },
  {
    id: "2",
    name: "Medical-Surgical Nursing",
    description: "Adult health and illness management",
    questionCount: 300,
    averageScore: 68,
    recentImprovement: "+3%",
    lastAttempt: "1 week ago",
    completionRate: 72,
    icon: Brain,
    color: "bg-purple-100 text-purple-800",
  },
  {
    id: "3",
    name: "Pharmacology",
    description: "Drug classifications, administration, and effects",
    questionCount: 200,
    averageScore: 72,
    recentImprovement: "+7%",
    lastAttempt: "3 days ago",
    completionRate: 80,
    icon: Target,
    color: "bg-green-100 text-green-800",
  },
];

const difficultyLevels = [
  {
    value: "1",
    label: "Beginner",
    description: "Fundamental concepts and straightforward scenarios",
    icon: Target,
    color: "bg-green-100 text-green-800",
    recommendedFor: "New students or initial topic review",
  },
  {
    value: "2",
    label: "Intermediate",
    description: "Complex scenarios requiring deeper analysis",
    icon: Target,
    color: "bg-blue-100 text-blue-800",
    recommendedFor: "Students with basic concept mastery",
  },
  {
    value: "3",
    label: "Advanced",
    description: "Critical thinking and multiple concept integration",
    icon: Target,
    color: "bg-purple-100 text-purple-800",
    recommendedFor: "Final exam preparation",
  },
];

export function QuizSetup({ onStart }: QuizSetupProps) {
  const [open, setOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [settings, setSettings] = useState<QuizSettings>({
    categoryId: "",
    difficulty: 1,
    questionCount: 10,
    timeLimit: 30,
  });

  const [showTimeLimit, setShowTimeLimit] = useState(false);
  const [savePreferences, setSavePreferences] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<
    (typeof mockCategories)[0] | null
  >(null);

  const handleCategoryChange = (categoryId: string) => {
    setSettings((prev) => ({ ...prev, categoryId }));
    setSelectedCategory(
      mockCategories.find((c) => c.id === categoryId) || null,
    );
  };

  const handleStart = async () => {
    setIsLoading(true);
    try {
      const finalSettings = showTimeLimit
        ? settings
        : { ...settings, timeLimit: undefined };
      await onStart(finalSettings);
      setOpen(false);
    } finally {
      setIsLoading(false);
    }
  };

  const isValid =
    settings.categoryId &&
    settings.questionCount >= 5 &&
    settings.questionCount <= 75 &&
    (!showTimeLimit || (settings.timeLimit && settings.timeLimit >= 5));

  const getRecommendedTime = () => {
    const baseTimePerQuestion = 1.5; // minutes
    return Math.ceil(settings.questionCount * baseTimePerQuestion);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="lg" className="gap-2 group">
          <PlayCircle className="w-5 h-5 transition-transform group-hover:scale-110" />
          Start New Quiz
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <div className="flex justify-between items-center">
            <DialogTitle>Quiz Settings</DialogTitle>
            <div className="flex items-center gap-4">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <History className="h-4 w-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>View previous quiz settings</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              <div className="flex items-center gap-2">
                <Switch
                  id="save-preferences"
                  checked={savePreferences}
                  onCheckedChange={setSavePreferences}
                />
                <Label htmlFor="save-preferences" className="text-sm">
                  Save preferences
                </Label>
              </div>
            </div>
          </div>
        </DialogHeader>
        <AnimatePresence mode="wait">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
            className="grid gap-6 py-4"
          >
            <div className="space-y-4">
              <Label htmlFor="category">Category</Label>
              <Select
                value={settings.categoryId}
                onValueChange={handleCategoryChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  {mockCategories.map((category) => (
                    <SelectItem
                      key={category.id}
                      value={category.id}
                      className="transition-colors hover:bg-accent"
                    >
                      <motion.div
                        className="flex items-center gap-2"
                        whileHover={{ x: 2 }}
                        transition={{ type: "spring", stiffness: 300 }}
                      >
                        <category.icon className="w-4 h-4" />
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="font-medium">{category.name}</span>
                            <Badge className={`ml-2 ${category.color}`}>
                              {category.averageScore}%
                            </Badge>
                          </div>
                          <Progress
                            value={category.completionRate}
                            className="h-1 mt-1"
                          />
                        </div>
                      </motion.div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {selectedCategory && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <Card className="bg-muted/50">
                    <CardContent className="pt-4">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium">
                            {selectedCategory.name}
                          </h4>
                          <Badge variant="outline" className="gap-1">
                            <Target className="w-3 h-3" />
                            {selectedCategory.averageScore}% avg. score
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {selectedCategory.description}
                        </p>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Completion Progress</span>
                            <span>{selectedCategory.completionRate}%</span>
                          </div>
                          <Progress
                            value={selectedCategory.completionRate}
                            className="h-2"
                          />
                        </div>
                        <div className="flex gap-4 text-sm mt-2">
                          <Badge variant="secondary" className="gap-1">
                            <Brain className="w-3 h-3" />
                            {selectedCategory.questionCount} questions
                          </Badge>
                          <Badge
                            variant="secondary"
                            className={
                              selectedCategory.recentImprovement.startsWith("+")
                                ? "bg-green-100 text-green-800"
                                : "bg-red-100 text-red-800"
                            }
                          >
                            {selectedCategory.recentImprovement} improvement
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            Last attempt: {selectedCategory.lastAttempt}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </div>

            <div className="space-y-4">
              <Label htmlFor="difficulty">Difficulty Level</Label>
              <Select
                value={settings.difficulty.toString()}
                onValueChange={(value) =>
                  setSettings((prev) => ({
                    ...prev,
                    difficulty: parseInt(value),
                  }))
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select difficulty" />
                </SelectTrigger>
                <SelectContent>
                  {difficultyLevels.map((level) => (
                    <SelectItem
                      key={level.value}
                      value={level.value}
                      className="transition-colors hover:bg-accent"
                    >
                      <motion.div
                        className="flex items-center gap-2"
                        whileHover={{ x: 2 }}
                        transition={{ type: "spring", stiffness: 300 }}
                      >
                        <level.icon className="w-4 h-4" />
                        <div>
                          <span className="font-medium">{level.label}</span>
                          <Badge className={`ml-2 ${level.color}`}>
                            {level.label}
                          </Badge>
                          <p className="text-xs text-muted-foreground">
                            {level.recommendedFor}
                          </p>
                        </div>
                      </motion.div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {settings.difficulty && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <Card className="bg-muted/50">
                    <CardContent className="py-3">
                      <p className="text-sm text-muted-foreground">
                        {difficultyLevels[settings.difficulty - 1].description}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </div>

            <div className="space-y-4">
              <Label htmlFor="questionCount">Number of Questions</Label>
              <div className="flex gap-4 items-center">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="flex-1">
                        <Input
                          id="questionCount"
                          type="number"
                          min={5}
                          max={75}
                          value={settings.questionCount}
                          onChange={(e) =>
                            setSettings((prev) => ({
                              ...prev,
                              questionCount: parseInt(e.target.value) || 10,
                            }))
                          }
                          className="w-24"
                        />
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Choose between 5 and 75 questions</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  Estimated time: ~{getRecommendedTime()} minutes
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="timeLimit">Time Limit (minutes)</Label>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowTimeLimit(!showTimeLimit)}
                  className="gap-2 group"
                >
                  <Clock
                    className={`w-4 h-4 transition-transform ${showTimeLimit ? "rotate-180" : ""}`}
                  />
                  {showTimeLimit ? "Remove Time Limit" : "Add Time Limit"}
                </Button>
              </div>
              <AnimatePresence>
                {showTimeLimit && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Card className="bg-muted/50">
                      <CardContent className="py-3">
                        <div className="space-y-3">
                          <div className="flex items-center gap-4">
                            <div className="flex items-center gap-2">
                              <Clock className="w-4 h-4" />
                              <Input
                                id="timeLimit"
                                type="number"
                                min={5}
                                value={settings.timeLimit}
                                onChange={(e) =>
                                  setSettings((prev) => ({
                                    ...prev,
                                    timeLimit: parseInt(e.target.value) || 30,
                                  }))
                                }
                                className="w-24"
                              />
                            </div>
                            <div className="text-sm text-muted-foreground">
                              Recommended: {getRecommendedTime()} minutes
                            </div>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            Minimum 5 minutes recommended for best results
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <AnimatePresence>
              {isValid && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <Card className="bg-primary/5 border-primary/20">
                    <CardContent className="py-3">
                      <div className="space-y-2">
                        <h4 className="font-medium flex items-center gap-2">
                          <Target className="w-4 h-4" />
                          Quiz Summary
                        </h4>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div className="flex items-center gap-2">
                            <BookOpen className="w-4 h-4" />
                            <span>{selectedCategory?.name}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Brain className="w-4 h-4" />
                            <span>
                              {difficultyLevels[settings.difficulty - 1].label}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Target className="w-4 h-4" />
                            <span>{settings.questionCount} questions</span>
                          </div>
                          {showTimeLimit && (
                            <div className="flex items-center gap-2">
                              <Clock className="w-4 h-4" />
                              <span>{settings.timeLimit} minutes</span>
                            </div>
                          )}
                        </div>
                        {savePreferences && (
                          <p className="text-xs text-muted-foreground mt-2">
                            These settings will be saved for your next quiz
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>

            <AnimatePresence>
              {!isValid && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      Please ensure all fields are filled correctly:
                      <ul className="list-disc list-inside mt-2">
                        {!settings.categoryId && <li>Select a category</li>}
                        {(settings.questionCount < 5 ||
                          settings.questionCount > 75) && (
                          <li>Questions must be between 5 and 75</li>
                        )}
                        {showTimeLimit &&
                          (!settings.timeLimit || settings.timeLimit < 5) && (
                            <li>Time limit must be at least 5 minutes</li>
                          )}
                      </ul>
                    </AlertDescription>
                  </Alert>
                </motion.div>
              )}
            </AnimatePresence>

            <Button
              onClick={handleStart}
              disabled={!isValid || isLoading}
              className="w-full relative"
              size="lg"
            >
              {isLoading ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex items-center gap-2"
                >
                  <Skeleton className="h-4 w-4 rounded-full animate-spin" />
                  Setting up quiz...
                </motion.div>
              ) : (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex items-center gap-2"
                >
                  <PlayCircle className="w-5 h-5" />
                  Start Quiz
                </motion.div>
              )}
            </Button>
          </motion.div>
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}
