import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { FileHeart, Users, Target } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export default function VirtualPatient() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Virtual Patient Scenarios</h1>
      <p className="text-muted-foreground">
        Interactive clinical simulations for developing critical thinking and
        decision-making skills.
      </p>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Scenarios Completed
            </CardTitle>
            <FileHeart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12/20</div>
            <p className="text-xs text-muted-foreground">
              Clinical cases completed
            </p>
            <Progress value={60} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Patient Interactions
            </CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">48</div>
            <p className="text-xs text-muted-foreground">Total interactions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">85%</div>
            <p className="text-xs text-muted-foreground">
              Average success rate
            </p>
            <Progress value={85} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Available Scenarios</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-8">
            <div className="space-y-2">
              <h3 className="font-semibold">Medical-Surgical Cases</h3>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="p-4 rounded-lg border">
                  <h4 className="font-medium">Post-operative Care</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    Manage a patient recovering from abdominal surgery
                  </p>
                  <Progress value={100} className="mt-2" />
                  <p className="text-xs text-muted-foreground mt-1">
                    Completed
                  </p>
                </div>
                <div className="p-4 rounded-lg border">
                  <h4 className="font-medium">Diabetic Ketoacidosis</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    Acute care management of DKA
                  </p>
                  <Progress value={75} className="mt-2" />
                  <p className="text-xs text-muted-foreground mt-1">
                    In progress
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold">Critical Care Scenarios</h3>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="p-4 rounded-lg border">
                  <h4 className="font-medium">Sepsis Protocol</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    Early recognition and management of sepsis
                  </p>
                  <Progress value={100} className="mt-2" />
                  <p className="text-xs text-muted-foreground mt-1">
                    Completed
                  </p>
                </div>
                <div className="p-4 rounded-lg border">
                  <h4 className="font-medium">Respiratory Distress</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    Acute respiratory failure management
                  </p>
                  <Progress value={0} className="mt-2" />
                  <p className="text-xs text-muted-foreground mt-1">
                    Not started
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold">Pediatric Cases</h3>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="p-4 rounded-lg border">
                  <h4 className="font-medium">Asthma Exacerbation</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    Pediatric asthma management
                  </p>
                  <Progress value={100} className="mt-2" />
                  <p className="text-xs text-muted-foreground mt-1">
                    Completed
                  </p>
                </div>
                <div className="p-4 rounded-lg border">
                  <h4 className="font-medium">Dehydration Assessment</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    Fluid and electrolyte management in children
                  </p>
                  <Progress value={50} className="mt-2" />
                  <p className="text-xs text-muted-foreground mt-1">
                    In progress
                  </p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
