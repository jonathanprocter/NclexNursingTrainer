import { useState, useEffect, useCallback } from "react";
import { useMutation } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Brain, AlertCircle, Loader2, Clock, Check, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useLocation } from "wouter";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

interface PracticeQuestion {
  id: number;
  scenario: string;
  options: string[];
  correctAnswer: string;
  explanation?: string;
  difficulty: "easy" | "medium" | "hard";
  domainId: number;
}

interface ExamSession {
  id: string;
  timeRemaining: number;
  questions: PracticeQuestion[];
  currentQuestionIndex: number;
  totalQuestions: number;
  completed: boolean;
  mode: "standard" | "cat";
}

interface ExamResults {
  score: number;
  totalQuestions: number;
  correctAnswers: number;
  totalTimeSpent: number;
  averageTimePerQuestion: number;
  questions: Array<{
    question: string;
    correctAnswer: string;
    explanation: string;
    category: string;
    difficulty: string;
    userAnswer: string;
    timeSpent: number;
    isCorrect: boolean;
  }>;
  categoryPerformance: Record<
    string,
    {
      total: number;
      correct: number;
      timeSpent: number;
    }
  >;
  areasForImprovement: Array<{
    category: string;
    accuracy: number;
    averageTime: number;
  }>;
  timeAnalysis: {
    totalTime: number;
    averageTimePerQuestion: number;
    timeByCategory: Record<
      string,
      {
        total: number;
        correct: number;
        timeSpent: number;
      }
    >;
  };
  catAnalytics?: {
    finalAbilityEstimate: number;
    consistencyMetrics: {
      performanceStability: number;
    };
    adaptiveProgress: Array<{
      questionNumber: number;
      difficulty: number;
      correctness: boolean;
      timeSpent: number;
    }>;
  };
}

export default function PracticeExam() {
  const [location] = useLocation();
  const params = new URLSearchParams(location.split("?")[1]);
  const urlMode = params.get("mode");

  const [examSession, setExamSession] = useState<ExamSession | null>(null);
  const [examResults, setExamResults] = useState<ExamResults | null>(null);
  const [timeRemaining, setTimeRemaining] = useState<number>(0);
  const [questionStartTime, setQuestionStartTime] = useState<number>(
    Date.now(),
  );
  const [currentSelection, setCurrentSelection] = useState<{
    questionId: number;
    answer: string;
  } | null>(null);
  const [examMode, setExamMode] = useState<"standard" | "cat">(
    urlMode === "cat" ? "cat" : "standard",
  );
  const { toast } = useToast();

  useEffect(() => {
    setCurrentSelection(null);
    setQuestionStartTime(Date.now());
  }, [examSession?.currentQuestionIndex]);

  const startExamMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/practice-exam/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          duration: examMode === "cat" ? 360 : 180,
          mode: examMode,
        }),
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(error);
      }

      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Exam Started",
        description: "Good luck on your practice exam!",
      });
      const totalQuestions = data.mode === "cat" ? 145 : 75;
      setExamSession({
        id: data.id,
        timeRemaining: data.timeRemaining,
        questions: [
          {
            id: data.currentQuestion.id,
            scenario:
              data.currentQuestion.question || data.currentQuestion.scenario,
            options: data.currentQuestion.options,
            correctAnswer: data.currentQuestion.correctAnswer,
            explanation: data.currentQuestion.explanation,
            difficulty: data.currentQuestion.difficulty,
            domainId: data.currentQuestion.domainId,
          },
        ],
        currentQuestionIndex: 0,
        totalQuestions: totalQuestions,
        completed: false,
        mode: data.mode,
      });
      setTimeRemaining(data.timeRemaining);
      setQuestionStartTime(Date.now());
      setExamResults(null);
    },
    onError: (error) => {
      toast({
        title: "Error Starting Exam",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const submitAnswerMutation = useMutation({
    mutationFn: async (answer: string) => {
      if (!examSession) throw new Error("No active exam");

      const timeSpent = Math.round((Date.now() - questionStartTime) / 1000);
      const response = await fetch("/api/practice-exam/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId: examSession.id,
          selectedAnswer: answer,
          timeSpent,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || "Failed to submit answer");
      }

      return response.json();
    },
    onSuccess: (data) => {
      if (data.completed) {
        setExamResults(data.results);
        setExamSession((prev) => (prev ? { ...prev, completed: true } : null));
      } else {
        setExamSession((prev) => {
          if (!prev) return null;
          return {
            ...prev,
            questions: [
              ...prev.questions,
              {
                id: data.nextQuestion.id,
                scenario:
                  data.nextQuestion.question || data.nextQuestion.scenario,
                options: data.nextQuestion.options,
                correctAnswer: data.nextQuestion.correctAnswer,
                explanation: data.nextQuestion.explanation,
                difficulty: data.nextQuestion.difficulty,
                domainId: data.nextQuestion.domainId,
              },
            ],
            currentQuestionIndex: prev.currentQuestionIndex + 1,
            timeRemaining: data.timeRemaining,
          };
        });
        setTimeRemaining(data.timeRemaining);
        setQuestionStartTime(Date.now());
      }
    },
    onError: (error) => {
      toast({
        title: "Error Submitting Answer",
        description:
          error instanceof Error ? error.message : "Failed to submit answer",
        variant: "destructive",
      });
      setCurrentSelection(null); // Reset selection on error
    },
  });

  const testCATExamMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/practice-exam/test-cat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });

      if (!response.ok) {
        throw new Error("Failed to run CAT test");
      }

      return response.json();
    },
    onSuccess: (data) => {
      setExamResults(data);
      setExamSession((prev) =>
        prev ? { ...prev, completed: true, mode: "cat" } : null,
      );
    },
  });

  useEffect(() => {
    if (!examSession || examSession.completed || timeRemaining <= 0) return;

    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 0) {
          clearInterval(timer);
          submitAnswerMutation.mutate("");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [examSession, timeRemaining, submitAnswerMutation]);

  const formatTime = useCallback((seconds: number): string => {
    if (!seconds || isNaN(seconds)) return "00:00:00";
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`;
  }, []);

  if (examResults) {
    return (
      <div className="container mx-auto py-8 px-4">
        <Card>
          <CardHeader>
            <CardTitle>NCLEX Practice Exam Results</CardTitle>
            <CardDescription>
              Comprehensive analysis of your performance
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              <div className="text-center">
                <h2 className="text-3xl font-bold">
                  Score: {examResults.score.toFixed(1)}%
                </h2>
                <p className="text-muted-foreground">
                  {examResults.correctAnswers} correct out of{" "}
                  {examResults.totalQuestions} questions
                </p>
                {examSession?.mode === "cat" && (
                  <p className="mt-2 text-sm text-muted-foreground">
                    Completed in Computerized Adaptive Testing (CAT) mode
                  </p>
                )}
              </div>

              <div className="space-y-4">
                <h3 className="text-xl font-semibold text-green-600">
                  Areas of Strength
                </h3>
                <div className="grid gap-4 md:grid-cols-2">
                  {Object.entries(examResults.categoryPerformance)
                    .filter(([_, data]) => data.correct / data.total >= 0.7)
                    .map(([category, data]) => (
                      <Card key={category} className="bg-green-50">
                        <CardContent className="pt-6">
                          <h4 className="font-medium flex items-center gap-2">
                            <Check className="h-5 w-5 text-green-600" />
                            {category}
                          </h4>
                          <p className="text-2xl font-bold text-green-700">
                            {Math.round((data.correct / data.total) * 100)}%
                          </p>
                          <p className="text-sm text-green-600">
                            {data.correct} correct out of {data.total} questions
                          </p>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-xl font-semibold text-red-600">
                  Priority Areas for Improvement
                </h3>
                <div className="grid gap-4 md:grid-cols-2">
                  {Object.entries(examResults.categoryPerformance)
                    .filter(([_, data]) => data.correct / data.total < 0.7)
                    .map(([category, data]) => (
                      <Card key={category} className="bg-red-50">
                        <CardContent className="pt-6">
                          <h4 className="font-medium flex items-center gap-2">
                            <X className="h-5 w-5 text-red-600" />
                            {category}
                          </h4>
                          <p className="text-2xl font-bold text-red-700">
                            {Math.round((data.correct / data.total) * 100)}%
                          </p>
                          <p className="text-sm text-red-600">
                            {data.correct} correct out of {data.total} questions
                          </p>
                          <p className="text-sm text-muted-foreground mt-2">
                            Focus on reviewing key concepts in this area
                          </p>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-xl font-semibold">Time Analysis</h3>
                <div className="grid gap-4 md:grid-cols-2">
                  <Card>
                    <CardContent className="pt-6">
                      <h4 className="font-medium">Total Time</h4>
                      <p className="text-2xl font-bold">
                        {formatTime(examResults.totalTimeSpent)}
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <h4 className="font-medium">Average Time per Question</h4>
                      <p className="text-2xl font-bold">
                        {Math.round(examResults.averageTimePerQuestion)} seconds
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {examResults &&
                examSession?.mode === "cat" &&
                examResults.catAnalytics && (
                  <div className="space-y-4">
                    <h3 className="text-xl font-semibold">CAT Analysis</h3>
                    <div className="grid gap-4 md:grid-cols-2">
                      <Card>
                        <CardContent className="pt-6">
                          <h4 className="font-medium">
                            Final Ability Estimate
                          </h4>
                          <p className="text-2xl font-bold">
                            {examResults.catAnalytics.finalAbilityEstimate.toFixed(
                              2,
                            )}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Score range: -3 (Novice) to +3 (Expert)
                          </p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <h4 className="font-medium">Performance Stability</h4>
                          <p className="text-2xl font-bold">
                            {(
                              examResults.catAnalytics.consistencyMetrics
                                .performanceStability * 100
                            ).toFixed(1)}
                            %
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Based on last 5 questions
                          </p>
                        </CardContent>
                      </Card>
                    </div>

                    <Card>
                      <CardHeader>
                        <CardTitle>Adaptive Progress</CardTitle>
                        <CardDescription>
                          Question difficulty progression throughout the exam
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="h-[200px]">
                          <div className="space-y-2">
                            {examResults.catAnalytics.adaptiveProgress.map(
                              (progress, index) => (
                                <div
                                  key={index}
                                  className="flex items-center gap-4"
                                >
                                  <span className="text-sm">
                                    Q{progress.questionNumber}
                                  </span>
                                  <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                                    <div
                                      className={`h-full rounded-full ${
                                        progress.correctness
                                          ? "bg-green-500"
                                          : "bg-red-500"
                                      }`}
                                      style={{
                                        width: `${((progress.difficulty + 3) / 6) * 100}%`,
                                      }}
                                    />
                                  </div>
                                  <span className="text-sm text-muted-foreground">
                                    {progress.timeSpent}s
                                  </span>
                                </div>
                              ),
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}

              <div className="space-y-4">
                <h3 className="text-xl font-semibold">Question Review</h3>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="w-full">Review All Questions</Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-4xl h-[80vh]">
                    <DialogHeader>
                      <DialogTitle>Question Review</DialogTitle>
                    </DialogHeader>
                    <ScrollArea className="h-full pr-4">
                      <div className="space-y-6">
                        {examResults.questions.map((q, index) => (
                          <Card
                            key={index}
                            className={
                              q.isCorrect
                                ? "border-green-200"
                                : "border-red-200"
                            }
                          >
                            <CardContent className="pt-6">
                              <div className="flex items-center gap-2 mb-4">
                                <span className="font-bold">
                                  Question {index + 1}
                                </span>
                                {q.isCorrect ? (
                                  <span className="text-green-600 flex items-center gap-1">
                                    <Check className="h-4 w-4" /> Correct
                                  </span>
                                ) : (
                                  <span className="text-red-600 flex items-center gap-1">
                                    <X className="h-4 w-4" /> Incorrect
                                  </span>
                                )}
                              </div>
                              <p className="font-medium mb-4">{q.question}</p>
                              <div className="space-y-2 mb-4">
                                <p>
                                  Your answer:{" "}
                                  <span
                                    className={
                                      q.isCorrect
                                        ? "text-green-600 font-medium"
                                        : "text-red-600 font-medium"
                                    }
                                  >
                                    {q.userAnswer}
                                  </span>
                                </p>
                                {!q.isCorrect && (
                                  <p className="text-green-600 font-semibold border-l-4 border-green-500 pl-3 py-2 bg-green-50 rounded">
                                    Correct answer: {q.correctAnswer}
                                  </p>
                                )}
                              </div>
                              <div className="bg-muted p-4 rounded-lg">
                                <h4 className="font-medium mb-2">
                                  Explanation
                                </h4>
                                <p className="text-sm text-muted-foreground">
                                  {q.explanation}
                                </p>
                              </div>
                              <div className="mt-4 text-sm text-muted-foreground">
                                <p>Category: {q.category}</p>
                                <p>Time spent: {q.timeSpent} seconds</p>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </ScrollArea>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="flex gap-4">
                <Button
                  className="flex-1"
                  onClick={() => {
                    setExamSession(null);
                    setExamResults(null);
                    startExamMutation.mutate();
                  }}
                >
                  Start New Exam
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!examSession) {
    return (
      <div className="container mx-auto py-8 px-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-6 w-6" />
              NCLEX Practice Exam
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <h3 className="font-medium">Select Exam Mode:</h3>
              <RadioGroup
                value={examMode}
                onValueChange={(value: "standard" | "cat") =>
                  setExamMode(value)
                }
                className="grid grid-cols-1 gap-4 mt-2"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="standard" id="standard" />
                  <Label htmlFor="standard" className="font-medium">
                    Standard Mode
                    <p className="text-sm text-muted-foreground">
                      75 questions with fixed length and mixed difficulty
                    </p>
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="cat" id="cat" />
                  <Label htmlFor="cat" className="font-medium">
                    CAT Mode (Computerized Adaptive Testing)
                    <p className="text-sm text-muted-foreground">
                      Adaptive difficulty, variable length (75-145 questions)
                    </p>
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-2">
              <h3 className="font-medium">Exam Details:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                {examMode === "standard" ? (
                  <>
                    <li>75 questions covering various NCLEX domains</li>
                    <li>3-hour time limit</li>
                    <li>Mixed difficulty levels</li>
                  </>
                ) : (
                  <>
                    <li>Adapts to your performance level</li>
                    <li>75-145 questions based on performance</li>
                    <li>6-hour time limit</li>
                    <li>Mirrors actual NCLEX-RN exam format</li>
                  </>
                )}
                <li>Comprehensive performance analysis</li>
                <li>No returning to previous questions</li>
              </ul>
            </div>

            <Button
              onClick={() => startExamMutation.mutate()}
              disabled={startExamMutation.isPending}
              className="w-full"
            >
              {startExamMutation.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : null}
              Start {examMode === "cat" ? "CAT" : "Standard"} Practice Exam
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const currentQuestion =
    examSession?.questions[examSession.currentQuestionIndex];
  if (!currentQuestion) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-2">
          <AlertCircle className="h-8 w-8 mx-auto text-yellow-500" />
          <p>
            An error occurred loading the question. Please try starting a new
            exam.
          </p>
          <Button
            onClick={() => {
              setExamSession(null);
              startExamMutation.mutate();
            }}
          >
            Start New Exam
          </Button>
        </div>
      </div>
    );
  }

  const handleAnswerSubmit = async (questionId: number, answer: string) => {
    if (submitAnswerMutation.isPending || currentSelection) return;

    try {
      setCurrentSelection({ questionId, answer });
      await submitAnswerMutation.mutate(answer);
    } catch (error) {
      console.error("Error submitting answer:", error);
      setCurrentSelection(null); // Reset selection on error
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="space-y-6">
        <div className="flex items-center justify-between bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-50 p-4 rounded-lg shadow-sm">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">
                Question {examSession.currentQuestionIndex + 1}
                {examSession.mode === "cat"
                  ? ` of max ${examSession.totalQuestions} (CAT Mode)`
                  : ` of ${examSession.totalQuestions}`}
              </span>
              <span className="px-2 py-1 text-xs font-medium rounded-full bg-muted">
                {currentQuestion.difficulty}
              </span>
              {examSession.mode === "cat" && (
                <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                  Adaptive Testing
                </span>
              )}
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="h-5 w-5" />
              <span className="font-mono text-lg">
                {formatTime(timeRemaining)}
              </span>
            </div>
          </div>
        </div>

        <Card className="mb-4">
          <CardHeader>
            <CardTitle className="text-lg font-medium">Question</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-lg leading-relaxed">
              {currentQuestion.scenario}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-medium">
              Select Your Answer
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2">
              {currentQuestion.options.map((option, index) => {
                const isSelected =
                  currentSelection?.questionId === currentQuestion.id &&
                  currentSelection?.answer === option;

                return (
                  <button
                    key={`${currentQuestion.id}-${option}-${index}-${examSession.currentQuestionIndex}`}
                    onClick={() =>
                      handleAnswerSubmit(currentQuestion.id, option)
                    }
                    disabled={
                      submitAnswerMutation.isPending ||
                      currentSelection !== null
                    }
                    className={`
                      w-full text-left px-6 py-4 rounded-md
                      ${isSelected ? "bg-primary text-primary-foreground" : "bg-background hover:bg-accent hover:text-accent-foreground"}
                      disabled:opacity-50 disabled:cursor-not-allowed
                      border border-input
                      focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2
                    `}
                  >
                    <div className="flex items-center">
                      <span className="font-mono mr-4">
                        {String.fromCharCode(65 + index)}.
                      </span>
                      <span>{option}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <div className="flex items-start gap-2 text-sm text-muted-foreground">
          <AlertCircle className="h-4 w-4 mt-0.5" />
          <p>
            You cannot return to previous questions after submitting an answer.
            {examSession?.mode === "cat" &&
              " The exam length will adapt based on your performance."}
          </p>
        </div>
      </div>
    </div>
  );
}
