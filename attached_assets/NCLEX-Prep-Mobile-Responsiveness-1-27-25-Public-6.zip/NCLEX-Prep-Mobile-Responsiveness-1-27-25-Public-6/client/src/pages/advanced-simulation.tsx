import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Brain,
  Target,
  ChartLine,
  Settings,
  PlayCircle,
  RefreshCw,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

interface SimulationSettings {
  duration: number;
  difficulty: string;
  focus: string[];
  adaptiveMode: boolean;
}

interface SimulationState {
  currentQuestion: number;
  totalQuestions: number;
  score: number;
  timeRemaining: number;
  adaptiveLevel: number;
  currentDifficulty: string;
}

export default function AdvancedSimulation() {
  const [isActive, setIsActive] = useState(false);
  const [settings, setSettings] = useState<SimulationSettings>({
    duration: 30,
    difficulty: "medium",
    focus: ["clinical-judgment", "critical-care"],
    adaptiveMode: true,
  });
  const [simulation, setSimulation] = useState<SimulationState>({
    currentQuestion: 0,
    totalQuestions: 75,
    score: 0,
    timeRemaining: 1800,
    adaptiveLevel: 1,
    currentDifficulty: "medium",
  });
  const { toast } = useToast();

  const startSimulation = () => {
    setIsActive(true);
    toast({
      title: "Simulation Started",
      description: "The adaptive testing environment is now active.",
    });
  };

  const updateDifficulty = (newDifficulty: string) => {
    setSettings((prev) => ({
      ...prev,
      difficulty: newDifficulty,
    }));
  };

  const updateDuration = (minutes: number) => {
    setSettings((prev) => ({
      ...prev,
      duration: minutes,
      timeRemaining: minutes * 60,
    }));
  };

  if (!isActive) {
    return (
      <div className="container mx-auto py-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-6 w-6" />
              Advanced NCLEX Simulation
            </CardTitle>
            <CardDescription>
              AI-Powered Adaptive Testing Environment
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-2">
                <label className="text-sm font-medium">Difficulty Level</label>
                <Select
                  value={settings.difficulty}
                  onValueChange={updateDifficulty}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select difficulty" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="easy">Easy</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="hard">Hard</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">
                  Duration (minutes)
                </label>
                <Select
                  value={settings.duration.toString()}
                  onValueChange={(val) => updateDuration(parseInt(val))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select duration" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="60">1 hour</SelectItem>
                    <SelectItem value="120">2 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Alert>
              <Target className="h-4 w-4" />
              <AlertTitle>Adaptive Testing Active</AlertTitle>
              <AlertDescription>
                This simulation uses AI to adjust question difficulty based on
                your performance, providing a personalized testing experience
                similar to the actual NCLEX.
              </AlertDescription>
            </Alert>

            <div className="grid gap-6 md:grid-cols-3">
              <Card>
                <CardContent className="pt-6">
                  <Brain className="h-8 w-8 mb-4 text-primary/60" />
                  <h4 className="font-semibold mb-2">AI-Powered Adaptation</h4>
                  <p className="text-sm text-muted-foreground">
                    Questions adjust in real-time based on your performance and
                    confidence levels.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <ChartLine className="h-8 w-8 mb-4 text-primary/60" />
                  <h4 className="font-semibold mb-2">Performance Analytics</h4>
                  <p className="text-sm text-muted-foreground">
                    Detailed insights into your progress and areas for
                    improvement.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <Settings className="h-8 w-8 mb-4 text-primary/60" />
                  <h4 className="font-semibold mb-2">
                    Customizable Experience
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    Set your focus areas and preferred duration for targeted
                    practice.
                  </p>
                </CardContent>
              </Card>
            </div>

            <Button onClick={startSimulation} className="w-full" size="lg">
              <PlayCircle className="h-4 w-4 mr-2" />
              Start Advanced Simulation
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Advanced NCLEX Simulation</h1>
            <p className="text-muted-foreground">
              Question {simulation.currentQuestion + 1} of{" "}
              {simulation.totalQuestions}
            </p>
          </div>
          <Badge variant="outline">
            Level {simulation.adaptiveLevel} • {simulation.currentDifficulty}
          </Badge>
        </div>

        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div className="space-y-1">
                <CardTitle>Progress Overview</CardTitle>
                <CardDescription>
                  Time Remaining: {Math.floor(simulation.timeRemaining / 60)}:
                  {(simulation.timeRemaining % 60).toString().padStart(2, "0")}
                </CardDescription>
              </div>
              <Button variant="outline" onClick={() => setIsActive(false)}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Reset Simulation
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Overall Progress</span>
                  <span>
                    {Math.round(
                      (simulation.currentQuestion / simulation.totalQuestions) *
                        100,
                    )}
                    %
                  </span>
                </div>
                <Progress
                  value={
                    (simulation.currentQuestion / simulation.totalQuestions) *
                    100
                  }
                />
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                <div className="p-4 rounded-lg bg-muted">
                  <h3 className="font-medium mb-1">Current Score</h3>
                  <p className="text-2xl font-bold">{simulation.score}%</p>
                </div>
                <div className="p-4 rounded-lg bg-muted">
                  <h3 className="font-medium mb-1">Questions Remaining</h3>
                  <p className="text-2xl font-bold">
                    {simulation.totalQuestions - simulation.currentQuestion}
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-muted">
                  <h3 className="font-medium mb-1">Adaptive Level</h3>
                  <p className="text-2xl font-bold">
                    {simulation.adaptiveLevel}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Placeholder for the actual question component */}
        <Card>
          <CardContent className="pt-6">
            <Alert>
              <AlertTitle>Simulation Active</AlertTitle>
              <AlertDescription>
                The question component will be implemented here, following the
                same pattern as our virtual patient scenarios but with adaptive
                difficulty adjustments.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Performance Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible>
              <AccordionItem value="strengths">
                <AccordionTrigger>Current Strengths</AccordionTrigger>
                <AccordionContent>
                  <ul className="list-disc pl-4 space-y-2">
                    <li>Strong performance in clinical judgment questions</li>
                    <li>Consistent accuracy in medication calculations</li>
                    <li>Quick response time in emergency scenarios</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="areas">
                <AccordionTrigger>Areas for Improvement</AccordionTrigger>
                <AccordionContent>
                  <ul className="list-disc pl-4 space-y-2">
                    <li>Review pediatric care protocols</li>
                    <li>
                      Focus on prioritization in multiple-patient scenarios
                    </li>
                    <li>Practice more complex medication interactions</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
