import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Brain, Book, Calculator, Check, MessageSquare } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";

interface Example {
  scenario: string;
  problem: string;
  solution: string;
  explanation: string;
}

interface Practice {
  question: string;
  type: "calculation" | "conceptual" | "clinical";
  options?: string[];
  correctAnswer: string | number;
  explanation: string;
  difficulty: "basic" | "intermediate" | "advanced";
}

interface AIHelp {
  enabled: boolean;
  prompts: string[];
  contextualHints: string[];
}

interface ModuleSection {
  title: string;
  content: string;
  keyPoints: string[];
  examples: Example[];
  practice: Practice[];
  aiHelp: AIHelp;
}

interface ModuleContentProps {
  title: string;
  introduction: string;
  objectives: string[];
  sections: ModuleSection[];
}

export function ModuleContent({
  title,
  introduction,
  objectives,
  sections,
}: ModuleContentProps) {
  const [activeAIHelp, setActiveAIHelp] = useState<Record<string, boolean>>({});
  const [selectedAnswers, setSelectedAnswers] = useState<
    Record<string, string>
  >({});
  const { toast } = useToast();

  const toggleAIHelp = (sectionTitle: string) => {
    setActiveAIHelp((prev) => ({
      ...prev,
      [sectionTitle]: !prev[sectionTitle],
    }));
  };

  const handleAnswerSubmit = (
    question: string,
    answer: string,
    correctAnswer: string | number,
  ) => {
    setSelectedAnswers((prev) => ({
      ...prev,
      [question]: answer,
    }));

    const isCorrect = answer === correctAnswer.toString();
    toast({
      title: isCorrect ? "Correct!" : "Try Again",
      description: isCorrect
        ? "Great job!"
        : "Review the explanation and try again.",
      variant: isCorrect ? "default" : "destructive",
    });
  };

  return (
    <div className="space-y-8">
      {/* Module Header */}
      <div>
        <h1 className="text-3xl font-bold">{title}</h1>
        <p className="mt-4 text-lg text-muted-foreground">{introduction}</p>
      </div>

      {/* Learning Objectives */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Book className="h-5 w-5" />
            Learning Objectives
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-6 space-y-2">
            {objectives.map((objective, index) => (
              <li key={index} className="text-muted-foreground">
                {objective}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Module Sections */}
      <Accordion type="single" collapsible className="space-y-4">
        {sections.map((section, sectionIndex) => (
          <AccordionItem key={sectionIndex} value={`section-${sectionIndex}`}>
            <AccordionTrigger className="text-xl font-semibold hover:no-underline">
              {section.title}
            </AccordionTrigger>
            <AccordionContent className="space-y-6 pt-4">
              {/* Section Content */}
              <div className="prose max-w-none">
                <p>{section.content}</p>
              </div>

              {/* Key Points */}
              <div className="flex flex-wrap gap-2">
                {section.keyPoints.map((point, index) => (
                  <Badge key={index} variant="secondary" className="text-sm">
                    <Check className="h-3 w-3 mr-1" />
                    {point}
                  </Badge>
                ))}
              </div>

              {/* AI Help Section */}
              {section?.aiHelp && section.aiHelp.enabled && (
                <div>
                  <Button
                    variant="outline"
                    onClick={() => toggleAIHelp(section.title)}
                    className="gap-2"
                  >
                    <Brain className="h-4 w-4" />
                    AI Study Assistant
                  </Button>

                  {activeAIHelp[section.title] && (
                    <div className="mt-4 space-y-4">
                      {section.aiHelp.prompts.map((prompt, index) => (
                        <Alert key={index}>
                          <MessageSquare className="h-4 w-4" />
                          <AlertDescription>{prompt}</AlertDescription>
                        </Alert>
                      ))}
                      {section.aiHelp.contextualHints.map((hint, index) => (
                        <div
                          key={index}
                          className="text-sm text-muted-foreground pl-4 border-l-2"
                        >
                          {hint}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Examples */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Examples</h3>
                {section.examples.map((example, index) => (
                  <Card key={index}>
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div>
                          <Badge>Scenario</Badge>
                          <p className="mt-2">{example.scenario}</p>
                        </div>
                        <div>
                          <Badge variant="outline">Problem</Badge>
                          <p className="mt-2">{example.problem}</p>
                        </div>
                        <div>
                          <Badge variant="secondary">Solution</Badge>
                          <p className="mt-2">{example.solution}</p>
                        </div>
                        <div className="bg-muted p-4 rounded-md">
                          <p className="font-medium">Explanation:</p>
                          <p className="mt-2">{example.explanation}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Practice Problems */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Practice Problems</h3>
                {section.practice.map((problem, index) => (
                  <Card key={index}>
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">{problem.type}</Badge>
                          <Badge>{problem.difficulty}</Badge>
                        </div>
                        <p className="font-medium">{problem.question}</p>

                        {problem.options ? (
                          <div className="space-y-2">
                            {problem.options.map((option, optionIndex) => (
                              <Button
                                key={optionIndex}
                                variant={
                                  selectedAnswers[problem.question] === option
                                    ? "default"
                                    : "outline"
                                }
                                className="w-full justify-start"
                                onClick={() =>
                                  handleAnswerSubmit(
                                    problem.question,
                                    option,
                                    problem.correctAnswer,
                                  )
                                }
                              >
                                {option}
                              </Button>
                            ))}
                          </div>
                        ) : (
                          <div className="flex gap-2">
                            <input
                              type="number"
                              className="border p-2 rounded"
                              placeholder="Enter your answer"
                              onChange={(e) =>
                                handleAnswerSubmit(
                                  problem.question,
                                  e.target.value,
                                  problem.correctAnswer,
                                )
                              }
                            />
                            <Button
                              variant="outline"
                              onClick={() => {
                                const answer = (
                                  document.querySelector(
                                    "input",
                                  ) as HTMLInputElement
                                ).value;
                                handleAnswerSubmit(
                                  problem.question,
                                  answer,
                                  problem.correctAnswer,
                                );
                              }}
                            >
                              <Calculator className="h-4 w-4 mr-2" />
                              Check Answer
                            </Button>
                          </div>
                        )}

                        {selectedAnswers[problem.question] && (
                          <div className="bg-muted p-4 rounded-md mt-4">
                            <p className="font-medium">Explanation:</p>
                            <p className="mt-2">{problem.explanation}</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}
