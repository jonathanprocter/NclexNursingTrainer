import { Link, useLocation } from "wouter";
import {
  Target,
  Pill,
  Brain,
  Calculator,
  HeartPulse,
  Stethoscope,
  Menu,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer";
import { useMediaQuery } from "@/hooks/use-media-query";

export function SideNav() {
  const [location] = useLocation();
  const isMobile = useMediaQuery("(max-width: 768px)");

  const moduleLinks = [
    {
      href: "/analyze-cues",
      label: "Analyze Cues",
      icon: Target,
    },
    {
      href: "/pharmacology",
      label: "Pharmacology",
      icon: Pill,
    },
    {
      href: "/clinical-judgment",
      label: "Clinical Judgment",
      icon: Brain,
    },
    {
      href: "/drug-calculations",
      label: "Drug Calculations",
      icon: Calculator,
    },
    {
      href: "/risk-reduction",
      label: "Risk Reduction",
      icon: HeartPulse,
    },
    {
      href: "/advanced-pathophysiology",
      label: "Advanced Pathophysiology",
      icon: Stethoscope,
    },
  ];

  const NavigationContent = () => (
    <div className="flex flex-col h-full">
      <div className="p-6">
        <h2 className="font-semibold text-lg mb-2">Learning Modules</h2>
        <p className="text-sm text-muted-foreground">
          Comprehensive NCLEX preparation modules
        </p>
      </div>
      <nav className="flex-1 px-4 pb-6 overflow-y-auto">
        <div className="space-y-1">
          {moduleLinks.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center py-2 px-3 text-sm rounded-md hover:bg-accent transition-colors",
                location === href
                  ? "bg-accent text-accent-foreground font-medium"
                  : "text-muted-foreground hover:text-primary",
              )}
            >
              <Icon className="mr-2 h-4 w-4" />
              {label}
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );

  if (isMobile) {
    return (
      <Drawer>
        <DrawerTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="fixed top-4 left-4 z-50 md:hidden"
          >
            <Menu className="h-5 w-5" />
          </Button>
        </DrawerTrigger>
        <DrawerContent>
          <DrawerHeader>
            <DrawerTitle>Navigation</DrawerTitle>
          </DrawerHeader>
          <div className="px-4 pb-8">
            <NavigationContent />
          </div>
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <div className="hidden md:block fixed top-14 left-0 h-[calc(100vh-3.5rem)] w-64 border-r bg-card">
      <NavigationContent />
    </div>
  );
}
