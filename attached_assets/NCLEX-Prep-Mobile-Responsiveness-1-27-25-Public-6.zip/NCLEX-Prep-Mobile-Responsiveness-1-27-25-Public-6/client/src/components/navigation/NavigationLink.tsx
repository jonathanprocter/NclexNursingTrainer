import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";
import { memo } from "react";

interface NavigationLinkProps {
  href: string;
  label: string;
  icon: LucideIcon;
  isActive: boolean;
  onClick: () => void;
}

export const NavigationLink = memo(function NavigationLink({
  href,
  label,
  icon: Icon,
  isActive,
  onClick,
}: NavigationLinkProps) {
  return (
    <Button
      key={href}
      variant="ghost"
      className={cn(
        "flex items-center gap-2",
        isActive && "bg-primary text-primary-foreground",
      )}
      onClick={onClick}
    >
      <Icon className="h-4 w-4" />
      <span>{label}</span>
    </Button>
  );
});
