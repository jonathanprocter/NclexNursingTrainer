import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import {
  Brain,
  CheckCircle2,
  XCircle,
  Loader2,
  Target,
  Clock,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
  domain: string;
  difficulty: "easy" | "medium" | "hard";
  clinicalJudgmentLevel: string;
  timeLimit?: number;
}

interface PerformanceMetrics {
  accuracy: number;
  averageResponseTime: number;
  currentStreak: number;
  masteryLevel: number;
}

export function AdaptiveQuestions() {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string>("");
  const [showExplanation, setShowExplanation] = useState(false);
  const [startTime, setStartTime] = useState(Date.now());
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    accuracy: 0,
    averageResponseTime: 0,
    currentStreak: 0,
    masteryLevel: 0,
  });
  const { toast } = useToast();

  const {
    data: questions,
    isLoading: questionsLoading,
    error: questionsError,
  } = useQuery<Question[]>({
    queryKey: ["/api/questions/adaptive"],
    queryFn: async () => {
      const response = await fetch("/api/questions/adaptive", {
        method: "GET",
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) throw new Error("Failed to fetch questions");
      return response.json();
    },
  });

  const {
    data: recommendations,
    isLoading: recommendationsLoading,
    error: recommendationsError,
  } = useQuery({
    queryKey: ["adaptive-recommendations"],
    queryFn: async () => {
      const res = await fetch("/api/adaptive/recommendations");
      if (!res.ok) {
        if (res.status === 401) {
          throw new Error(
            "Unauthorized: Please log in to access recommendations.",
          );
        }
        throw new Error("Failed to fetch recommendations");
      }
      return res.json();
    },
    retry: 2,
    staleTime: 30000,
  });

  const submitAnswerMutation = useMutation({
    mutationFn: async ({
      answer,
      timeSpent,
      difficulty,
    }: {
      answer: string;
      timeSpent: number;
      difficulty: string;
    }) => {
      if (!questions || !questions[currentQuestionIndex]) {
        throw new Error("Invalid question data");
      }

      const response = await fetch("/api/questions/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          questionId: questions[currentQuestionIndex].id,
          answer,
          timeSpent,
          difficulty,
          performanceMetrics: metrics,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to submit answer");
      }

      return response.json();
    },
    onSuccess: (data) => {
      setShowExplanation(true);
      updateMetrics(data.isCorrect, data.timeSpent);
      if (data.isCorrect) {
        toast({
          title: "Correct!",
          description: "Great job! Let's keep going.",
          variant: "default",
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateMetrics = (isCorrect: boolean, timeSpent: number) => {
    setMetrics((prev) => {
      const newAccuracy =
        (prev.accuracy * currentQuestionIndex + (isCorrect ? 1 : 0)) /
        (currentQuestionIndex + 1);
      const newStreak = isCorrect ? prev.currentStreak + 1 : 0;
      const newMastery = calculateMasteryLevel(newAccuracy, newStreak);

      return {
        accuracy: newAccuracy,
        averageResponseTime:
          (prev.averageResponseTime * currentQuestionIndex + timeSpent) /
          (currentQuestionIndex + 1),
        currentStreak: newStreak,
        masteryLevel: newMastery,
      };
    });
  };

  const calculateMasteryLevel = (accuracy: number, streak: number): number => {
    const baseLevel = accuracy * 0.7;
    const streakBonus = Math.min(streak * 0.1, 0.3);
    return Math.min(baseLevel + streakBonus, 1);
  };

  const handleSubmit = () => {
    if (!selectedAnswer) {
      toast({
        title: "Select an Answer",
        description: "Please select an answer before submitting.",
        variant: "default",
      });
      return;
    }

    const timeSpent = (Date.now() - startTime) / 1000;
    const currentQuestion = questions?.[currentQuestionIndex];

    if (currentQuestion) {
      submitAnswerMutation.mutate({
        answer: selectedAnswer,
        timeSpent,
        difficulty: currentQuestion.difficulty,
      });
    }
  };

  const handleNext = () => {
    setSelectedAnswer("");
    setShowExplanation(false);
    setCurrentQuestionIndex((prev) => prev + 1);
    setStartTime(Date.now());
  };

  if (questionsLoading || recommendationsLoading) {
    return (
      <Card className="w-full">
        <CardContent className="pt-6">
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="ml-2">Loading...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (questionsError) {
    return <p>Error loading questions: {questionsError.message}</p>;
  }

  if (recommendationsError) {
    return <p>Error loading recommendations: {recommendationsError.message}</p>;
  }

  if (!questions || questions.length === 0) {
    return (
      <Card className="w-full">
        <CardContent className="pt-6">
          <p className="text-center text-muted-foreground">
            No questions available. Try refreshing the page.
          </p>
        </CardContent>
      </Card>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  return (
    <div className="space-y-6">
      {/* Performance Metrics */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Accuracy</p>
              <p className="text-2xl font-bold">
                {Math.round(metrics.accuracy * 100)}%
              </p>
            </div>
            <Target className="h-8 w-8 text-primary opacity-75" />
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Avg. Time</p>
              <p className="text-2xl font-bold">
                {Math.round(metrics.averageResponseTime)}s
              </p>
            </div>
            <Clock className="h-8 w-8 text-primary opacity-75" />
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Current Streak</p>
              <p className="text-2xl font-bold">{metrics.currentStreak}</p>
            </div>
            <Brain className="h-8 w-8 text-primary opacity-75" />
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Mastery Level</p>
              <Progress value={metrics.masteryLevel * 100} className="w-20" />
            </div>
          </div>
        </Card>
      </div>

      <Card className="w-full">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5" />
              Question {currentQuestionIndex + 1} of {questions.length}
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge variant="outline">{currentQuestion.difficulty}</Badge>
              <Badge variant="secondary">{currentQuestion.domain}</Badge>
            </div>
          </div>
          <Progress value={progress} className="mt-2" />
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <p className="text-lg font-medium">{currentQuestion.question}</p>

            <RadioGroup
              value={selectedAnswer}
              onValueChange={setSelectedAnswer}
              className="space-y-3"
              disabled={showExplanation}
            >
              {currentQuestion.options.map((option, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <RadioGroupItem value={option} id={`option-${index}`} />
                  <Label htmlFor={`option-${index}`}>{option}</Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          <div className="flex justify-between">
            <Button
              onClick={handleSubmit}
              disabled={!selectedAnswer || showExplanation}
            >
              {submitAnswerMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                "Submit Answer"
              )}
            </Button>

            {showExplanation && (
              <Button
                onClick={handleNext}
                disabled={currentQuestionIndex === questions.length - 1}
              >
                Next Question
              </Button>
            )}
          </div>

          <AnimatePresence mode="wait">
            {showExplanation && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className={`p-4 rounded-lg ${
                  selectedAnswer === currentQuestion.correctAnswer
                    ? "bg-green-50"
                    : "bg-red-50"
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  {selectedAnswer === currentQuestion.correctAnswer ? (
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-500" />
                  )}
                  <p
                    className={`font-medium ${
                      selectedAnswer === currentQuestion.correctAnswer
                        ? "text-green-700"
                        : "text-red-700"
                    }`}
                  >
                    {selectedAnswer === currentQuestion.correctAnswer
                      ? "Correct!"
                      : "Incorrect"}
                  </p>
                </div>
                <p className="text-sm mt-2">{currentQuestion.explanation}</p>
                <div className="mt-4 text-sm text-muted-foreground">
                  <p>Domain: {currentQuestion.domain}</p>
                  <p>
                    Clinical Judgment Level:{" "}
                    {currentQuestion.clinicalJudgmentLevel}
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </div>
  );
}