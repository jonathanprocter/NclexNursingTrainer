import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Brain, CheckCircle } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import type { Flashcard } from "@db/schema";

interface FlashcardGeneratorProps {
  topic: string;
  domain?: string;
  onFlashcardsGenerated?: (flashcards: Flashcard[]) => void;
}

export function FlashcardGenerator({
  topic,
  domain = "fundamentals",
  onFlashcardsGenerated,
}: FlashcardGeneratorProps) {
  const [content, setContent] = useState("");
  const { toast } = useToast();

  const generateMutation = useMutation({
    mutationFn: async (text: string) => {
      const response = await fetch("/api/flashcards/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          content: text,
          topic,
          domain,
          count: 5,
          difficulty: "adaptive",
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to generate flashcards");
      }

      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Flashcards Generated!",
        description: `Created ${data.flashcards.length} new flashcards for your study session.`,
      });
      if (onFlashcardsGenerated) {
        onFlashcardsGenerated(data.flashcards);
      }
      setContent("");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description:
          error instanceof Error
            ? error.message
            : "Failed to generate flashcards",
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!content.trim()) {
      toast({
        title: "Input Required",
        description: "Please enter some content to generate flashcards from.",
        variant: "destructive",
      });
      return;
    }

    generateMutation.mutate(content.trim());
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5" />
          AI Flashcard Generator
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Textarea
            placeholder="Enter your study material, notes, or concepts here..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="min-h-[150px] resize-none"
            disabled={generateMutation.isPending}
          />

          <div className="flex flex-col sm:flex-row gap-2">
            <Button
              onClick={handleGenerate}
              disabled={generateMutation.isPending || !content.trim()}
              className="w-full sm:w-auto"
            >
              {generateMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Brain className="h-4 w-4 mr-2" />
                  Generate Flashcards
                </>
              )}
            </Button>

            {generateMutation.isPending && (
              <div className="flex-1 flex items-center gap-2">
                <Progress value={45} className="flex-1" />
                <span className="text-sm text-muted-foreground whitespace-nowrap">
                  Processing...
                </span>
              </div>
            )}
          </div>

          {generateMutation.data && (
            <div className="rounded-lg bg-muted p-4">
              <div className="flex items-center gap-2 text-sm text-green-600">
                <CheckCircle className="h-4 w-4" />
                <span>Successfully generated flashcards!</span>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Your flashcards are ready for review. They've been optimized for
                spaced repetition learning.
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
