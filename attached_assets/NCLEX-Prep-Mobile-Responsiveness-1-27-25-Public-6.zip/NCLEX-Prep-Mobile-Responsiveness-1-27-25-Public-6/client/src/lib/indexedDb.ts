// Constants for the IndexedDB setup
const DB_NAME = "nclexPrepDB";
const DB_VERSION = 1;
const STORES = {
  flashcards: "flashcards",
  userProgress: "userProgress",
} as const;

interface IndexedDBStores {
  flashcards: IDBObjectStore;
  userProgress: IDBObjectStore;
}

// Helper to promisify IndexedDB requests
function promisifyRequest<T = undefined>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

class IndexedDBService {
  private db: IDBDatabase | null = null;

  async init(): Promise<void> {
    if (this.db) return;

    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = () => reject(request.error);

      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // Create stores if they don't exist
        if (!db.objectStoreNames.contains(STORES.flashcards)) {
          db.createObjectStore(STORES.flashcards, { keyPath: "id" });
        }

        if (!db.objectStoreNames.contains(STORES.userProgress)) {
          db.createObjectStore(STORES.userProgress, {
            keyPath: "id",
            autoIncrement: true,
          });
        }
      };
    });
  }

  private getStore(
    storeName: keyof typeof STORES,
    mode: IDBTransactionMode = "readonly",
  ): IDBObjectStore {
    if (!this.db) {
      throw new Error("Database not initialized");
    }
    const transaction = this.db.transaction(storeName, mode);
    return transaction.objectStore(storeName);
  }

  async saveFlashcards(flashcards: any[]): Promise<void> {
    const store = this.getStore(STORES.flashcards, "readwrite");
    await Promise.all(
      flashcards.map((card) => promisifyRequest(store.put(card))),
    );
  }

  async getFlashcards(): Promise<any[]> {
    const store = this.getStore(STORES.flashcards);
    return promisifyRequest<any[]>(store.getAll());
  }

  async saveProgress(progress: any): Promise<void> {
    const store = this.getStore(STORES.userProgress, "readwrite");
    await promisifyRequest(store.put(progress));
  }

  async getProgress(): Promise<any[]> {
    const store = this.getStore(STORES.userProgress);
    return promisifyRequest<any[]>(store.getAll());
  }

  async clearStore(storeName: keyof typeof STORES): Promise<void> {
    const store = this.getStore(storeName, "readwrite");
    await promisifyRequest(store.clear());
  }
}

// Export singleton instance
export const indexedDBService = new IndexedDBService();
