import { useMutation } from "@tanstack/react-query";

interface VoiceCommand {
  command: string;
  studentId: string;
  context: {
    type: string;
    topic?: string;
    focusAreas: string[];
    emotionalState?: "stressed" | "confident" | "neutral";
    tutorPersonality?: "encouraging" | "analytical" | "socratic" | "practical";
  };
}

interface VoiceResponse {
  text: string;
  suggestions?: string[];
  nextTopic?: string;
  confidence: number;
  emotionalSupport?: boolean;
}

export function useVoiceAssistant() {
  const voiceCommandMutation = useMutation({
    mutationFn: async (command: VoiceCommand): Promise<VoiceResponse> => {
      try {
        const response = await fetch("/api/voice-assistant/command", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(command),
          credentials: "same-origin",
        });

        if (!response.ok) {
          const error = await response.text();
          throw new Error(error || `HTTP error! status: ${response.status}`);
        }

        const data = await response.json().catch(() => {
          throw new Error("Failed to parse response as JSON");
        });

        if (!data || typeof data.text !== "string") {
          throw new Error("Invalid response format from server");
        }
        const validatedResponse = {
          text: typeof data.text === "string" ? data.text : "",
          suggestions: Array.isArray(data.suggestions) ? data.suggestions : [],
          confidence:
            typeof data.confidence === "number" ? data.confidence : 1.0,
          emotionalSupport: Boolean(data.emotionalSupport),
          nextTopic: data.nextTopic || null,
        };

        if (!validatedResponse.text) {
          throw new Error("Missing response text from server");
        }

        return validatedResponse;
      } catch (error: any) {
        console.error("Error processing voice command:", error);
        throw error;
      }
    },
  });

  return {
    processCommand: voiceCommandMutation.mutate,
    isProcessing: voiceCommandMutation.isPending,
    response: voiceCommandMutation.data,
    error: voiceCommandMutation.error,
  };
}
