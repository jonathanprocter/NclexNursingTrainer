import { useMutation } from "@tanstack/react-query";
import { queryClient } from "../queryClient";
import { z } from "zod";

const emotionalStateSchema = z.object({
  currentMood: z.enum(["stressed", "confident", "neutral"]),
  energyLevel: z.number().min(0).max(100),
  focusQuality: z.number().min(0).max(100),
});

interface EmotionalState {
  currentMood: "stressed" | "confident" | "neutral";
  energyLevel: number;
  focusQuality: number;
}

interface EmotionalResponse {
  supportMessage: string;
  studyRecommendation: string;
  adaptivePath?: {
    suggestedTopics: string[];
    difficulty: "easy" | "medium" | "hard";
    timeRecommendation: number;
  };
}

export function useEmotionalIntelligence() {
  const recordEmotionalStateMutation = useMutation({
    mutationFn: async (state: EmotionalState): Promise<EmotionalResponse> => {
      try {
        // Validate state before sending
        const validatedState = emotionalStateSchema.parse(state);
        console.log("Sending emotional state to server:", validatedState);

        const response = await fetch("/api/emotional-state", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          body: JSON.stringify({
            currentMood: validatedState.currentMood,
            energyLevel: Math.min(100, Math.max(0, validatedState.energyLevel)),
            focusQuality: Math.min(
              100,
              Math.max(0, validatedState.focusQuality),
            ),
          }),
          credentials: "include",
        });

        if (!response.ok) {
          throw new Error("Failed to record emotional state");
        }

        const contentType = response.headers.get("content-type");
        if (!contentType || !contentType.includes("application/json")) {
          throw new Error("Invalid response format");
        }

        const result = await response.json();
        console.log("Received response from server:", result);
        return result.data;
      } catch (error) {
        console.error("Error in emotional state mutation:", error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/analytics/performance-summary"],
      });
    },
    onError: (error) => {
      console.error("Mutation error:", error);
    },
  });

  return {
    recordEmotionalState: recordEmotionalStateMutation.mutate,
    isRecording: recordEmotionalStateMutation.isPending,
    emotionalResponse: recordEmotionalStateMutation.data,
    error: recordEmotionalStateMutation.error,
  };
}
