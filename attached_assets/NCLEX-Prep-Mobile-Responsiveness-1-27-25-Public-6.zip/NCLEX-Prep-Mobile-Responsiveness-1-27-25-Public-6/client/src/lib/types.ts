export interface FileMetadata {
  lastModified: string;
  createdAt: string;
  mimeType: string;
  encoding: string;
  extension: string;
  path: string;
  compressionMethod?: string;
  compressedSize?: number;
  crc32?: string;
  comment?: string;
}

export interface ExtractedFile {
  name: string;
  content: string;
  type: string;
  metadata: FileMetadata;
}

export interface ProcessedFile {
  name: string;
  size: number;
  status: "success" | "error" | "processing";
  error?: string;
  progress?: number;
  extractedFiles?: ExtractedFile[];
  totalFiles?: number;
  processedAt?: string;
  archiveComment?: string;
  totalCompressedSize?: number;
  totalUncompressedSize?: number;
  questions?: number;
  categories?: string[];
}

export interface UploadResponse {
  message: string;
  file: ProcessedFile;
}
