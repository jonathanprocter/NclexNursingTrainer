import { ExtractedFile } from "./types";

export type FileType = "text" | "image" | "binary" | "unknown";

const TEXT_EXTENSIONS = [
  ".txt",
  ".md",
  ".json",
  ".xml",
  ".csv",
  ".html",
  ".css",
  ".js",
  ".ts",
  ".jsx",
  ".tsx",
  ".yml",
  ".yaml",
  ".conf",
  ".config",
  ".ini",
  ".log",
];

const IMAGE_EXTENSIONS = [
  ".jpg",
  ".jpeg",
  ".png",
  ".gif",
  ".bmp",
  ".webp",
  ".svg",
];

export function getFileType(fileName: string): FileType {
  const extension = fileName.toLowerCase().slice(fileName.lastIndexOf("."));

  if (TEXT_EXTENSIONS.includes(extension)) {
    return "text";
  }

  if (IMAGE_EXTENSIONS.includes(extension)) {
    return "image";
  }

  return "binary";
}

export function isTextFile(file: ExtractedFile): boolean {
  return getFileType(file.name) === "text";
}

export function isImageFile(file: ExtractedFile): boolean {
  return getFileType(file.name) === "image";
}

export function formatFileSize(bytes: number): string {
  const units = ["B", "KB", "MB", "GB"];
  let size = bytes;
  let unitIndex = 0;

  while (size >= 1024 && unitIndex < units.length - 1) {
    size /= 1024;
    unitIndex++;
  }

  return `${size.toFixed(1)} ${units[unitIndex]}`;
}

export function getMimeType(fileName: string): string {
  const extension = fileName.toLowerCase().slice(fileName.lastIndexOf("."));

  const mimeTypes: Record<string, string> = {
    ".txt": "text/plain",
    ".md": "text/markdown",
    ".json": "application/json",
    ".xml": "application/xml",
    ".csv": "text/csv",
    ".html": "text/html",
    ".css": "text/css",
    ".js": "text/javascript",
    ".ts": "text/typescript",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".bmp": "image/bmp",
    ".webp": "image/webp",
    ".svg": "image/svg+xml",
  };

  return mimeTypes[extension] || "application/octet-stream";
}
