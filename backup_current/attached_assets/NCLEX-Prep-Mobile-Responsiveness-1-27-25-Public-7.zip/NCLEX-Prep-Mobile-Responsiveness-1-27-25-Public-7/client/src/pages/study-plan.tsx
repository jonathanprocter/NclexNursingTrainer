import { useState } from "react";
import { Link } from "wouter";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BookOpen,
  Calendar as CalendarIcon,
  CheckCircle2,
  Clock,
  Target,
  Plus,
  Brain,
  BarChart2,
  AlertCircle,
  ArrowRight,
  Filter,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

// Enhanced mock data structure
const mockStudyTopics = [
  {
    id: 1,
    name: "Fundamentals of Nursing",
    progress: 65,
    totalQuestions: 150,
    completedQuestions: 97,
    recommendationReason: "Below average performance in recent quizzes",
    priority: "high",
    estimatedTimeToComplete: "4 hours",
    lastStudied: "2025-01-15",
    upcomingDeadline: "2025-01-20",
    strengthAreas: ["Patient Assessment", "Basic Care"],
    weakAreas: ["Documentation", "Care Planning"],
  },
  {
    id: 2,
    name: "Pharmacology",
    progress: 45,
    totalQuestions: 200,
    completedQuestions: 90,
    recommendationReason: "High-priority NCLEX topic",
    priority: "high",
    estimatedTimeToComplete: "6 hours",
    lastStudied: "2025-01-18",
    upcomingDeadline: "2025-01-25",
    strengthAreas: ["Drug Calculations", "Medication Administration"],
    weakAreas: ["Pharmacokinetics", "Adverse Effects"],
  },
  {
    id: 3,
    name: "Medical-Surgical Nursing",
    progress: 30,
    totalQuestions: 300,
    completedQuestions: 90,
    recommendationReason: "Essential core concept",
    priority: "medium",
    estimatedTimeToComplete: "8 hours",
    lastStudied: "2025-01-10",
    upcomingDeadline: "2025-01-30",
    strengthAreas: ["Cardiac Care", "Respiratory Care"],
    weakAreas: ["Endocrine Disorders", "Gastrointestinal Disorders"],
  },
  {
    id: 4,
    name: "Mental Health Nursing",
    progress: 55,
    totalQuestions: 125,
    completedQuestions: 69,
    recommendationReason: "Scheduled for next week's focus",
    priority: "medium",
    estimatedTimeToComplete: "3 hours",
    lastStudied: "2025-01-12",
    upcomingDeadline: "2025-01-22",
    strengthAreas: ["Anxiety Disorders", "Depression"],
    weakAreas: ["Schizophrenia", "Bipolar Disorder"],
  },
];

const mockStudyGoals = [
  {
    id: 1,
    description: "Complete 50 practice questions in Pharmacology",
    progress: 70,
    dueDate: "2025-01-20",
    type: "practice",
    category: "Pharmacology",
    priority: "high",
    reminder: true,
  },
  {
    id: 2,
    description: "Review all Drug Calculations flashcards",
    progress: 45,
    dueDate: "2025-01-25",
    type: "review",
    category: "Pharmacology",
    priority: "medium",
    reminder: false,
  },
  {
    id: 3,
    description: "Take 2 full practice exams",
    progress: 0,
    dueDate: "2025-02-01",
    type: "exam",
    category: "General",
    priority: "high",
    reminder: true,
  },
  {
    id: 4,
    description: "Complete Med-Surg video lectures",
    progress: 20,
    dueDate: "2025-01-28",
    type: "content",
    category: "Medical-Surgical Nursing",
    priority: "medium",
    reminder: false,
  },
];

const mockDailySchedule = [
  {
    time: "09:00 AM",
    activity: "Review Pharmacology",
    duration: "2 hours",
    completed: true,
    type: "review",
    topic: "Pharmacology",
    resources: ["Video Lectures", "Practice Questions"],
    notes: "Focus on drug classifications and mechanisms of action",
  },
  {
    time: "11:30 AM",
    activity: "Practice Questions",
    duration: "1.5 hours",
    completed: true,
    type: "practice",
    topic: "Med-Surg",
    resources: ["Question Bank", "Review Notes"],
    notes: "Concentrate on cardiac and respiratory systems",
  },
  {
    time: "02:00 PM",
    activity: "Video Lectures",
    duration: "1 hour",
    completed: false,
    type: "content",
    topic: "Mental Health",
    resources: ["Video Series", "Study Guide"],
    notes: "Watch lectures on anxiety disorders",
  },
  {
    time: "04:00 PM",
    activity: "Mock Test",
    duration: "2 hours",
    completed: false,
    type: "exam",
    topic: "Mixed Content",
    resources: ["Practice Exam", "Timer"],
    notes: "Simulate exam conditions",
  },
];

const studyResources = [
  {
    id: 1,
    title: "Practice Questions Bank",
    description: "Access over 2000+ NCLEX-style questions",
    icon: Brain,
    path: "/quiz",
    stats: {
      totalQuestions: 2000,
      completedQuestions: 450,
      averageScore: 75,
    },
  },
  {
    id: 2,
    title: "Performance Analytics",
    description: "Track your progress and identify areas for improvement",
    icon: BarChart2,
    path: "/progress",
    stats: {
      totalQuestions: 1000,
      completedQuestions: 700,
      averageScore: 80,
    },
  },
  {
    id: 3,
    title: "Content Areas Guide",
    description: "Comprehensive review of all NCLEX topics",
    icon: AlertCircle,
    path: "/",
    stats: {
      totalQuestions: 500,
      completedQuestions: 300,
      averageScore: 70,
    },
  },
  {
    id: 4,
    title: "Video Library",
    description: "In-depth video explanations of key concepts",
    icon: BookOpen,
    path: "/",
    stats: {
      totalQuestions: 1500,
      completedQuestions: 900,
      averageScore: 85,
    },
  },
];

export default function StudyPlanPage() {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [showNewGoalDialog, setShowNewGoalDialog] = useState(false);
  const [selectedActivityType, setSelectedActivityType] =
    useState<string>("all");
  const [goalFilter, setGoalFilter] = useState<string>("all");
  const [selectedView, setSelectedView] = useState<"calendar" | "list">(
    "calendar",
  );
  const [selectedPriority, setPriority] = useState<string>("all");
  const [showResourceStats, setShowResourceStats] = useState<boolean>(false);
  const [showStrengthsWeaknesses, setShowStrengthsWeaknesses] =
    useState<boolean>(false);

  const getTotalProgress = () => {
    const totalCompleted = mockStudyTopics.reduce(
      (acc, topic) => acc + topic.completedQuestions,
      0,
    );
    const totalQuestions = mockStudyTopics.reduce(
      (acc, topic) => acc + topic.totalQuestions,
      0,
    );
    return (totalCompleted / totalQuestions) * 100;
  };

  const filteredSchedule =
    selectedActivityType === "all"
      ? mockDailySchedule
      : mockDailySchedule.filter(
          (activity) => activity.type === selectedActivityType,
        );

  const filteredGoals =
    goalFilter === "all"
      ? mockStudyGoals
      : mockStudyGoals.filter((goal) => goal.type === goalFilter);

  const getResourceProgress = (resource: (typeof studyResources)[0]) => {
    return Math.round(
      (resource.stats.completedQuestions / resource.stats.totalQuestions) * 100,
    );
  };

  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case "high":
        return "bg-red-100 text-red-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "low":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="space-y-6">
        {/* Header with action buttons */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Personalized Study Plan</h1>
            <p className="text-muted-foreground mt-2">
              Your customized NCLEX preparation roadmap
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="gap-2">
              <Filter className="w-4 h-4" />
              Customize Plan
            </Button>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Add Study Session
            </Button>
          </div>
        </div>

        {/* Enhanced Overall Progress Card */}
        <Card>
          <CardContent className="py-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-xl font-semibold">Overall Progress</h2>
                <p className="text-muted-foreground">
                  {Math.round(getTotalProgress())}% of study material covered
                </p>
              </div>
              <Button variant="outline" className="gap-2">
                <BarChart2 className="w-4 h-4" />
                View Detailed Analytics
              </Button>
            </div>
            <Progress value={getTotalProgress()} className="h-2" />
            <div className="grid grid-cols-3 gap-4 mt-6">
              <div className="text-center">
                <div className="text-2xl font-bold">
                  {mockStudyTopics.length}
                </div>
                <div className="text-sm text-muted-foreground">
                  Active Topics
                </div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">
                  {mockStudyTopics.reduce(
                    (acc, topic) => acc + topic.completedQuestions,
                    0,
                  )}
                </div>
                <div className="text-sm text-muted-foreground">
                  Questions Completed
                </div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">
                  {
                    mockStudyTopics.filter((topic) => topic.priority === "high")
                      .length
                  }
                </div>
                <div className="text-sm text-muted-foreground">
                  High Priority Topics
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-6 md:grid-cols-2">
          {/* Focus Areas */}
          <Card className="md:row-span-2">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Focus Areas
                </CardTitle>
                <Select value={selectedPriority} onValueChange={setPriority}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Filter by priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Priorities</SelectItem>
                    <SelectItem value="high">High Priority</SelectItem>
                    <SelectItem value="medium">Medium Priority</SelectItem>
                    <SelectItem value="low">Low Priority</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {mockStudyTopics
                  .filter(
                    (topic) =>
                      selectedPriority === "all" ||
                      topic.priority === selectedPriority,
                  )
                  .map((topic) => (
                    <div key={topic.id} className="space-y-2">
                      <div className="flex justify-between">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <h3 className="font-medium">{topic.name}</h3>
                            <span
                              className={`px-2 py-0.5 rounded-full text-xs ${getPriorityColor(topic.priority)}`}
                            >
                              {topic.priority} priority
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {topic.recommendationReason}
                          </p>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              {topic.estimatedTimeToComplete}
                            </span>
                            <span>
                              {topic.completedQuestions}/{topic.totalQuestions}{" "}
                              questions
                            </span>
                            <span className="flex items-center gap-1">
                              <CalendarIcon className="w-4 h-4" />
                              Last studied:{" "}
                              {new Date(topic.lastStudied).toLocaleDateString()}
                            </span>
                          </div>
                          <Button
                            onClick={() =>
                              setShowStrengthsWeaknesses(
                                !showStrengthsWeaknesses,
                              )
                            }
                            className="text-xs"
                          >
                            {showStrengthsWeaknesses ? "Hide" : "Show"}{" "}
                            Strengths/Weaknesses
                          </Button>
                          {showStrengthsWeaknesses && (
                            <>
                              <div>
                                <h4 className="font-medium">Strengths:</h4>
                                <ul>
                                  {topic.strengthAreas.map(
                                    (strength, index) => (
                                      <li key={index}>{strength}</li>
                                    ),
                                  )}
                                </ul>
                              </div>
                              <div>
                                <h4 className="font-medium">Weaknesses:</h4>
                                <ul>
                                  {topic.weakAreas.map((weakness, index) => (
                                    <li key={index}>{weakness}</li>
                                  ))}
                                </ul>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                      <Progress value={topic.progress} className="h-2" />
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>

          {/* Study Calendar */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <CalendarIcon className="h-5 w-5" />
                  Study Calendar
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Button
                    variant={
                      selectedView === "calendar" ? "default" : "outline"
                    }
                    size="sm"
                    onClick={() => setSelectedView("calendar")}
                  >
                    Calendar
                  </Button>
                  <Button
                    variant={selectedView === "list" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedView("list")}
                  >
                    List
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {selectedView === "calendar" ? (
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  className="rounded-md border"
                />
              ) : (
                <div className="space-y-4">
                  {mockDailySchedule.map((item, index) => (
                    <div key={index} className="flex items-start gap-4">
                      <div className="min-w-[80px] text-sm text-muted-foreground">
                        {item.time}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span
                            className={`h-2 w-2 rounded-full ${
                              item.completed ? "bg-green-500" : "bg-yellow-500"
                            }`}
                          />
                          <span className="font-medium">{item.activity}</span>
                          <span
                            className={`px-2 py-0.5 rounded-full text-xs ${
                              item.type === "exam"
                                ? "bg-blue-100 text-blue-800"
                                : item.type === "practice"
                                  ? "bg-green-100 text-green-800"
                                  : "bg-purple-100 text-purple-800"
                            }`}
                          >
                            {item.type}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Topic: {item.topic} • Duration: {item.duration}
                        </p>
                        {item.notes && (
                          <p className="text-sm text-muted-foreground mt-1 italic">
                            Note: {item.notes}
                          </p>
                        )}
                        <div className="flex gap-2 mt-2">
                          {item.resources.map((resource, idx) => (
                            <span
                              key={idx}
                              className="text-xs bg-muted px-2 py-1 rounded-full"
                            >
                              {resource}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Study Goals - Enhanced version */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Study Goals
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Select value={goalFilter} onValueChange={setGoalFilter}>
                    <SelectTrigger className="w-[150px]">
                      <SelectValue placeholder="Filter goals" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Goals</SelectItem>
                      <SelectItem value="practice">Practice</SelectItem>
                      <SelectItem value="review">Review</SelectItem>
                      <SelectItem value="exam">Exam</SelectItem>
                      <SelectItem value="content">Content</SelectItem>
                    </SelectContent>
                  </Select>
                  <Dialog
                    open={showNewGoalDialog}
                    onOpenChange={setShowNewGoalDialog}
                  >
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        <Plus className="h-4 w-4 mr-2" />
                        Add Goal
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Add New Study Goal</DialogTitle>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid gap-2">
                          <Label htmlFor="description">Goal Description</Label>
                          <Input
                            id="description"
                            placeholder="Enter your goal"
                            className="col-span-3"
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="type">Goal Type</Label>
                          <Select>
                            <SelectTrigger>
                              <SelectValue placeholder="Select goal type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="practice">
                                Practice Questions
                              </SelectItem>
                              <SelectItem value="review">
                                Content Review
                              </SelectItem>
                              <SelectItem value="exam">
                                Practice Exam
                              </SelectItem>
                              <SelectItem value="content">
                                Study Content
                              </SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="dueDate">Due Date</Label>
                          <Input id="dueDate" type="date" />
                        </div>
                      </div>
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          onClick={() => setShowNewGoalDialog(false)}
                        >
                          Cancel
                        </Button>
                        <Button onClick={() => setShowNewGoalDialog(false)}>
                          Add Goal
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredGoals.map((goal) => (
                  <div key={goal.id} className="space-y-2">
                    <div className="flex justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <CheckCircle2
                            className={`h-4 w-4 ${
                              goal.progress === 100
                                ? "text-green-500"
                                : "text-muted-foreground"
                            }`}
                          />
                          <span className="font-medium">
                            {goal.description}
                          </span>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            Due {new Date(goal.dueDate).toLocaleDateString()}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded-full text-xs ${
                              goal.type === "exam"
                                ? "bg-blue-100 text-blue-800"
                                : goal.type === "practice"
                                  ? "bg-green-100 text-green-800"
                                  : "bg-purple-100 text-purple-800"
                            }`}
                          >
                            {goal.type}
                          </span>
                        </div>
                      </div>
                      <span className="text-sm font-medium">
                        {goal.progress}%
                      </span>
                    </div>
                    <Progress value={goal.progress} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Study Resources - Enhanced version */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  Study Resources
                </CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowResourceStats(!showResourceStats)}
                >
                  {showResourceStats ? "Hide" : "Show"} Stats
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 sm:grid-cols-2">
                {studyResources.map((resource) => {
                  const Icon = resource.icon;
                  return (
                    <Button
                      key={resource.id}
                      variant="outline"
                      className="w-full h-auto p-4 justify-start"
                      asChild
                    >
                      <Link href={resource.path}>
                        <div className="flex items-start gap-4">
                          <Icon className="h-5 w-5 mt-1 shrink-0" />
                          <div className="text-left space-y-1">
                            <div className="font-medium">{resource.title}</div>
                            <p className="text-sm text-muted-foreground">
                              {resource.description}
                            </p>
                            {showResourceStats && (
                              <div className="space-y-2">
                                <Progress
                                  value={getResourceProgress(resource)}
                                  className="h-1"
                                />
                                <div className="flex gap-2 text-xs text-muted-foreground">
                                  <span>
                                    {resource.stats.completedQuestions}{" "}
                                    completed
                                  </span>
                                  <span>•</span>
                                  <span>
                                    {resource.stats.averageScore}% avg. score
                                  </span>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </Link>
                    </Button>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
