import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function PediatricsPage() {
  return (
    <div className="container mx-auto py-6">
      <Card>
        <CardHeader>
          <CardTitle>Pediatric Nursing</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Comprehensive coverage of pediatric nursing care and child
            development concepts.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
