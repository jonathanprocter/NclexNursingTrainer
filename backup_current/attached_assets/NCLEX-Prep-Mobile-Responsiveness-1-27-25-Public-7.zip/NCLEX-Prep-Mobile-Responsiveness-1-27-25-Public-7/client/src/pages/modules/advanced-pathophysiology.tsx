import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Heart,
  Brain,
  Activity,
  Stethoscope,
  BookOpen,
  CheckCircle2,
  LucideIcon,
} from "lucide-react";

interface SystemCard {
  icon: LucideIcon;
  title: string;
  topics: string[];
}

const bodySystems: SystemCard[] = [
  {
    icon: Heart,
    title: "Cardiovascular System",
    topics: [
      "Coronary artery disease",
      "Heart failure",
      "Arrhythmias",
      "Valvular disorders",
    ],
  },
  {
    icon: Brain,
    title: "Respiratory System",
    topics: [
      "COPD and asthma",
      "Pulmonary embolism",
      "Respiratory failure",
      "Pneumonia",
    ],
  },
  {
    icon: Activity,
    title: "Renal System",
    topics: [
      "Acute kidney injury",
      "Chronic kidney disease",
      "Glomerulonephritis",
      "Electrolyte imbalances",
    ],
  },
];

interface ProgressData {
  overallProgress: number;
  systemProgress: Record<string, number>;
}

export default function AdvancedPathophysiology() {
  const [activeTab, setActiveTab] = useState("overview");

  const { data: progress } = useQuery<ProgressData>({
    queryKey: ["/api/modules/pathophysiology/progress"],
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Advanced Pathophysiology</h1>
          <p className="text-muted-foreground mt-2">
            Deep dive into disease processes and their effects on body systems
          </p>
        </div>
        <Progress
          value={progress?.overallProgress ?? 0}
          className="w-[200px]"
        />
      </div>

      <Tabs
        defaultValue="overview"
        value={activeTab}
        onValueChange={setActiveTab}
      >
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="systems">Body Systems</TabsTrigger>
          <TabsTrigger value="cases">Case Studies</TabsTrigger>
          <TabsTrigger value="assessment">Assessment</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  Disease Processes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Understanding fundamental disease mechanisms and progression
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  System Integration
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  How diseases affect multiple body systems simultaneously
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Stethoscope className="h-5 w-5" />
                  Clinical Applications
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Applying pathophysiology knowledge in clinical settings
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="systems">
          <ScrollArea className="h-[600px]">
            <div className="grid gap-4">
              {bodySystems.map((system, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <system.icon className="h-5 w-5" />
                      {system.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-muted-foreground">Key pathologies:</p>
                      <ul className="list-disc pl-6 space-y-1">
                        {system.topics.map((topic, i) => (
                          <li key={i}>{topic}</li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </ScrollArea>
        </TabsContent>

        <TabsContent value="cases">
          <Card>
            <CardHeader>
              <CardTitle>Clinical Case Studies</CardTitle>
              <CardDescription>
                Apply your knowledge to real-world clinical scenarios
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[1, 2, 3].map((caseNumber) => (
                  <Button
                    key={caseNumber}
                    variant="outline"
                    className="w-full justify-start"
                  >
                    <div className="flex items-center gap-2">
                      <BookOpen className="h-4 w-4" />
                      <span>Case Study {caseNumber}</span>
                      <span className="ml-auto text-muted-foreground">
                        20 minutes
                      </span>
                    </div>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="assessment">
          <Card>
            <CardHeader>
              <CardTitle>Knowledge Assessment</CardTitle>
              <CardDescription>
                Test your understanding of advanced pathophysiology concepts
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Alert>
                <AlertTitle className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4" />
                  Ready to begin?
                </AlertTitle>
                <AlertDescription>
                  This assessment will test your knowledge of disease processes
                  and their effects on body systems.
                </AlertDescription>
              </Alert>
              <Button className="mt-4">Start Assessment</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
