import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Brain,
  Target,
  AlertCircle,
  Scale,
  MessagesSquare,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface ProgressData {
  overallProgress: number;
  accuracyRate: string;
  masteryLevel: string;
  competencyAreas: Array<{
    area: string;
    level: number;
    status: string;
  }>;
}

interface ModuleContent {
  scenarios: Array<{
    title: string;
    description: string;
    presentation: string;
  }>;
}

export default function AnalyzeCues() {
  const [activeTab, setActiveTab] = useState("overview");
  const { toast } = useToast();

  const { data: progress } = useQuery<ProgressData>({
    queryKey: ["/api/modules/analyze-cues/progress"],
  });

  const { data: moduleContent } = useQuery<ModuleContent>({
    queryKey: ["/api/modules/analyze-cues/content"],
  });

  const getAIHelp = async (topic: string) => {
    try {
      const response = await fetch("/api/modules/generate-explanation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic,
          context: "Clinical Reasoning and Cue Analysis",
        }),
      });

      if (!response.ok) throw new Error("Failed to get AI help");

      const data = await response.json();

      toast({
        title: "AI Assistant",
        description: data.content,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to get AI help. Please try again.",
        variant: "destructive",
      });
    }
  };

  const conceptualContent = {
    clinicalReasoning: {
      title: "Clinical Reasoning",
      description:
        "Learn to analyze clinical situations and develop sound nursing hypotheses.",
      points: [
        "Systematic approach to patient assessment",
        "Identifying relevant clinical indicators",
        "Developing and testing nursing hypotheses",
        "Critical thinking in complex scenarios",
      ],
    },
    patternRecognition: {
      title: "Pattern Recognition",
      description:
        "Identify key patterns in patient data and clinical presentations.",
      points: [
        "Common symptom clusters",
        "Disease progression patterns",
        "Risk factor identification",
        "Early warning signs recognition",
      ],
    },
    prioritySetting: {
      title: "Priority Setting",
      description:
        "Learn to prioritize patient needs and nursing interventions.",
      points: [
        "Urgency assessment",
        "Resource allocation",
        "Multiple patient management",
        "Critical situation handling",
      ],
    },
  };

  return (
    <div className="container mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">
            Analyze Cues & Clinical Judgment
          </h1>
          <p className="text-muted-foreground mt-2">
            Master the art of identifying, analyzing, and prioritizing clinical
            indicators
          </p>
        </div>
        <Progress
          value={progress?.overallProgress ?? 0}
          className="w-[200px]"
        />
      </div>

      <Tabs
        defaultValue="overview"
        value={activeTab}
        onValueChange={setActiveTab}
      >
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="learn">Learn</TabsTrigger>
          <TabsTrigger value="practice">Practice</TabsTrigger>
          <TabsTrigger value="progress">Progress</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  {conceptualContent.clinicalReasoning.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  {conceptualContent.clinicalReasoning.description}
                </p>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() =>
                    getAIHelp("Clinical reasoning in nursing practice")
                  }
                >
                  <MessagesSquare className="mr-2 h-4 w-4" />
                  Ask AI to Explain
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  {conceptualContent.patternRecognition.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  {conceptualContent.patternRecognition.description}
                </p>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() =>
                    getAIHelp("Pattern recognition in clinical assessment")
                  }
                >
                  <MessagesSquare className="mr-2 h-4 w-4" />
                  Ask AI to Explain
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Scale className="h-5 w-5" />
                  {conceptualContent.prioritySetting.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  {conceptualContent.prioritySetting.description}
                </p>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => getAIHelp("Priority setting in nursing care")}
                >
                  <MessagesSquare className="mr-2 h-4 w-4" />
                  Ask AI to Explain
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="learn">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Clinical Reasoning Framework</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="prose max-w-none">
                    <h3 className="text-lg font-semibold">
                      Foundational Concepts
                    </h3>
                    <p className="text-muted-foreground">
                      Clinical reasoning is the process by which nurses collect
                      cues, process the information, understand the patient
                      problem or situation, plan and implement interventions,
                      evaluate outcomes, and reflect on and learn from the
                      process.
                    </p>
                    <Button
                      variant="outline"
                      className="mt-4"
                      onClick={() =>
                        getAIHelp("Clinical reasoning process steps")
                      }
                    >
                      <MessagesSquare className="mr-2 h-4 w-4" />
                      Explore with AI
                    </Button>
                  </div>

                  <div className="mt-6">
                    <h3 className="text-lg font-semibold mb-4">
                      Key Learning Points
                    </h3>
                    <ul className="space-y-2">
                      {conceptualContent.clinicalReasoning.points.map(
                        (point, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <span className="flex-shrink-0 mt-1">•</span>
                            <span>{point}</span>
                          </li>
                        ),
                      )}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Pattern Recognition</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="prose max-w-none">
                    <p className="text-muted-foreground">
                      Pattern recognition is a critical skill that allows nurses
                      to quickly identify important clinical cues and make
                      connections between different pieces of patient
                      information.
                    </p>
                    <Button
                      variant="outline"
                      className="mt-4"
                      onClick={() =>
                        getAIHelp("Pattern recognition techniques in nursing")
                      }
                    >
                      <MessagesSquare className="mr-2 h-4 w-4" />
                      Learn More with AI
                    </Button>
                  </div>

                  <div className="mt-6">
                    <h3 className="text-lg font-semibold mb-4">
                      Recognition Skills
                    </h3>
                    <ul className="space-y-2">
                      {conceptualContent.patternRecognition.points.map(
                        (point, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <span className="flex-shrink-0 mt-1">•</span>
                            <span>{point}</span>
                          </li>
                        ),
                      )}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="practice">
          <Card>
            <CardHeader>
              <CardTitle>Practice Scenarios</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {moduleContent?.scenarios?.map((scenario, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <h3 className="text-lg font-semibold mb-2">
                      {scenario.title}
                    </h3>
                    <p className="text-muted-foreground mb-4">
                      {scenario.description}
                    </p>
                    <div className="space-y-4">
                      <h4 className="font-medium">Clinical Presentation</h4>
                      <p>{scenario.presentation}</p>
                      <Button
                        variant="outline"
                        onClick={() =>
                          getAIHelp(
                            `Analysis help for scenario: ${scenario.title}`,
                          )
                        }
                      >
                        <MessagesSquare className="mr-2 h-4 w-4" />
                        Get Analysis Help
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="progress">
          <Card>
            <CardHeader>
              <CardTitle>Your Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span>Overall Progress</span>
                    <span>{progress?.overallProgress ?? 0}%</span>
                  </div>
                  <Progress value={progress?.overallProgress ?? 0} />
                </div>

                {progress?.competencyAreas && (
                  <div className="mt-6 space-y-4">
                    <h3 className="font-semibold">Competency Areas</h3>
                    {progress.competencyAreas.map((area) => (
                      <div key={area.area}>
                        <div className="flex justify-between mb-1">
                          <span>{area.area}</span>
                          <span>{Math.round(area.level * 100)}%</span>
                        </div>
                        <Progress value={area.level * 100} />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
