import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Shield,
  AlertTriangle,
  CheckCircle2,
  Brain,
  ClipboardList,
  Activity,
  HeartPulse,
  Stethoscope,
  Scale,
  ListChecks,
  Loader2,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ExplanationContent {
  content: string;
  keyPoints?: string[];
  examples?: string[];
  relatedConcepts?: string[];
}

export default function RiskReductionModule() {
  const [selectedTab, setSelectedTab] = useState("overview");
  const [selectedTopic, setSelectedTopic] = useState<string>("");
  const [showAIExplanation, setShowAIExplanation] = useState(false);
  const [explanationContent, setExplanationContent] =
    useState<ExplanationContent | null>(null);

  const { toast } = useToast();

  const { data: moduleData, isLoading } = useQuery({
    queryKey: ["/api/modules/risk-reduction"],
  });

  const requestAIExplanation = useMutation({
    mutationFn: async (topic: string) => {
      const response = await fetch("/api/modules/generate-explanation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic,
          context: "risk_reduction",
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to get explanation");
      }

      const data = await response.json();
      if (!data.success) {
        throw new Error(data.error || "Failed to generate explanation");
      }
      return data.data;
    },
    onSuccess: (data) => {
      setExplanationContent({
        content: data.content,
        keyPoints: data.content
          .split("\n")
          .filter((line: string) => line.startsWith("•"))
          .map((line: string) => line.substring(2)),
        examples: data.content
          .split("\n")
          .filter((line: string) => line.includes("Example:")),
        relatedConcepts: data.content
          .split("\n")
          .filter((line: string) => line.includes("Related Concepts:"))
          .flatMap((line: string) =>
            line
              .replace("Related Concepts:", "")
              .split("•")
              .map((concept: string) => concept.trim())
              .filter(Boolean),
          ),
      });
      setShowAIExplanation(true);
      toast({
        title: "AI Explanation Ready",
        description: "Your personalized explanation has been generated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description:
          error instanceof Error
            ? error.message
            : "Failed to get AI explanation",
        variant: "destructive",
      });
      setExplanationContent(null);
    },
  });

  const handleAskAI = (topic: string) => {
    setSelectedTopic(topic);
    requestAIExplanation.mutate(topic);
  };

  const AIHelpButton = ({
    topic,
    className = "",
  }: {
    topic: string;
    className?: string;
  }) => (
    <Button
      variant="outline"
      size="sm"
      className={`flex items-center gap-2 ${className}`}
      onClick={() => handleAskAI(topic)}
      disabled={requestAIExplanation.isPending}
    >
      {requestAIExplanation.isPending && selectedTopic === topic ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <Brain className="h-4 w-4" />
      )}
      <span>Ask AI Assistant</span>
    </Button>
  );

  const formatTopicName = (topic: string) => {
    return topic
      .replace(/([a-z])([A-Z])/g, "$1 $2")
      .replace(/_/g, " ")
      .split(" ")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-pulse">Loading module content...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Reduction of Risk Potential</h1>
          <p className="text-muted-foreground mt-2">
            Master risk assessment and prevention strategies for optimal patient
            outcomes
            <AIHelpButton topic="risk_reduction_overview" className="ml-2" />
          </p>
        </div>
        <Progress value={28} className="w-[200px]" />
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="content">Learning Content</TabsTrigger>
          <TabsTrigger value="practice">Practice</TabsTrigger>
          <TabsTrigger value="assessment">Assessment</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle>Understanding Risk Assessment in Nursing</CardTitle>
              <CardDescription className="flex items-center justify-between">
                Essential concepts and frameworks for identifying and mitigating
                patient risks
                <AIHelpButton topic="risk_assessment_fundamentals" />
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-6 md:grid-cols-3">
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2 mb-4">
                      <Brain className="h-6 w-6 text-primary" />
                      <h3 className="font-semibold">Systematic Approach</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Learn structured methods for identifying and evaluating
                      potential risks in patient care
                      <AIHelpButton
                        topic="systematic_risk_assessment"
                        className="mt-2"
                      />
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2 mb-4">
                      <Shield className="h-6 w-6 text-primary" />
                      <h3 className="font-semibold">Prevention Strategies</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Master evidence-based interventions to prevent
                      complications and adverse events
                      <AIHelpButton
                        topic="prevention_strategies"
                        className="mt-2"
                      />
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2 mb-4">
                      <Activity className="h-6 w-6 text-primary" />
                      <h3 className="font-semibold">Monitoring & Response</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Develop skills in ongoing assessment and rapid response to
                      changing patient conditions
                      <AIHelpButton
                        topic="monitoring_and_response"
                        className="mt-2"
                      />
                    </p>
                  </CardContent>
                </Card>
              </div>

              <Alert>
                <AlertTitle className="flex items-center gap-2">
                  <ListChecks className="h-4 w-4" />
                  Learning Objectives
                  <AIHelpButton
                    topic="learning_objectives"
                    className="ml-auto"
                  />
                </AlertTitle>
                <AlertDescription>
                  <ul className="list-disc pl-6 mt-2 space-y-1">
                    <li>
                      Identify common risk factors across different patient
                      populations
                    </li>
                    <li>
                      Apply systematic risk assessment tools and frameworks
                    </li>
                    <li>Implement evidence-based prevention strategies</li>
                    <li>
                      Document and communicate risk-related findings effectively
                    </li>
                    <li>
                      Respond appropriately to changes in patient condition
                    </li>
                  </ul>
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="content" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  Fundamentals of Risk Assessment
                </div>
                <AIHelpButton topic="risk_assessment_basics" />
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <Accordion type="single" collapsible>
                <AccordionItem value="systematic">
                  <AccordionTrigger>
                    <div className="flex items-center gap-2">
                      <Brain className="h-4 w-4" />
                      Systematic Assessment Approach
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="space-y-4 pt-4">
                    <div className="bg-muted p-4 rounded-lg">
                      <h4 className="font-medium mb-2 flex items-center justify-between">
                        Key Components of Risk Assessment
                        <AIHelpButton topic="risk_assessment_components" />
                      </h4>
                      <ul className="space-y-2">
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 mt-1 text-green-500" />
                          <span>
                            <strong>Initial Assessment:</strong> Comprehensive
                            evaluation of patient's condition, history, and risk
                            factors
                          </span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 mt-1 text-green-500" />
                          <span>
                            <strong>Ongoing Monitoring:</strong> Regular
                            reassessment and documentation of changes
                          </span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 mt-1 text-green-500" />
                          <span>
                            <strong>Risk Stratification:</strong> Categorizing
                            risks by severity and likelihood
                          </span>
                        </li>
                      </ul>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="common-risks">
                  <AccordionTrigger>
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4" />
                      Common Risk Areas
                      <AIHelpButton
                        topic="common_risk_areas"
                        className="ml-auto"
                      />
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="space-y-4 pt-4">
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="p-4 bg-muted rounded-lg">
                        <h4 className="font-medium mb-2 flex items-center gap-2">
                          <HeartPulse className="h-4 w-4" />
                          Vital Signs & Hemodynamics
                          <AIHelpButton
                            topic="vital_signs_hemodynamics"
                            className="ml-auto"
                          />
                        </h4>
                        <ul className="space-y-1 text-sm">
                          <li>Blood pressure variations</li>
                          <li>Heart rate abnormalities</li>
                          <li>Respiratory distress</li>
                          <li>Temperature changes</li>
                        </ul>
                      </div>

                      <div className="p-4 bg-muted rounded-lg">
                        <h4 className="font-medium mb-2 flex items-center gap-2">
                          <Stethoscope className="h-4 w-4" />
                          System-Specific Risks
                          <AIHelpButton
                            topic="system_specific_risks"
                            className="ml-auto"
                          />
                        </h4>
                        <ul className="space-y-1 text-sm">
                          <li>Neurological changes</li>
                          <li>Cardiovascular complications</li>
                          <li>Respiratory compromise</li>
                          <li>GI/GU dysfunction</li>
                        </ul>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="prevention">
                  <AccordionTrigger>
                    <div className="flex items-center gap-2">
                      <Shield className="h-4 w-4" />
                      Prevention Strategies
                      <AIHelpButton
                        topic="prevention_strategies_details"
                        className="ml-auto"
                      />
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="space-y-4 pt-4">
                    <div className="space-y-4">
                      <div className="p-4 bg-muted rounded-lg">
                        <h4 className="font-medium mb-2">
                          Evidence-Based Interventions
                        </h4>
                        <ul className="space-y-2">
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="h-4 w-4 mt-1 text-green-500" />
                            <div>
                              <strong>Standard Precautions:</strong>
                              <p className="text-sm text-muted-foreground">
                                Hand hygiene, PPE, proper disposal of sharps
                              </p>
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="h-4 w-4 mt-1 text-green-500" />
                            <div>
                              <strong>Fall Prevention:</strong>
                              <p className="text-sm text-muted-foreground">
                                Bed alarms, assistance with mobility,
                                environmental safety
                              </p>
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="h-4 w-4 mt-1 text-green-500" />
                            <div>
                              <strong>Pressure Injury Prevention:</strong>
                              <p className="text-sm text-muted-foreground">
                                Regular repositioning, skin assessment, proper
                                support surfaces
                              </p>
                            </div>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="documentation">
                  <AccordionTrigger>
                    <div className="flex items-center gap-2">
                      <ClipboardList className="h-4 w-4" />
                      Documentation & Communication
                      <AIHelpButton
                        topic="documentation_communication"
                        className="ml-auto"
                      />
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="space-y-4 pt-4">
                    <div className="p-4 bg-muted rounded-lg">
                      <h4 className="font-medium mb-2 flex items-center justify-between">
                        Essential Elements of Documentation
                        <AIHelpButton topic="documentation_elements" />
                      </h4>
                      <ul className="space-y-2">
                        <li>Assessment findings and risk scores</li>
                        <li>Implemented interventions and patient response</li>
                        <li>Changes in condition and notifications made</li>
                        <li>Patient/family education provided</li>
                        <li>Follow-up plans and recommendations</li>
                      </ul>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Case Studies in Risk Reduction
                <AIHelpButton topic="case_studies" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Alert className="bg-muted">
                  <AlertTitle>Interactive Learning Cases</AlertTitle>
                  <AlertDescription>
                    Practice applying risk assessment principles through
                    real-world scenarios. Click on each case to explore risk
                    identification, prevention strategies, and outcome
                    evaluation.
                  </AlertDescription>
                </Alert>

                <div className="grid gap-4">
                  <Button variant="outline" className="justify-start">
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary">Case 1</Badge>
                      Post-operative Patient Monitoring
                      <AIHelpButton
                        topic="case_study_post_op"
                        className="ml-auto"
                      />
                    </div>
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary">Case 2</Badge>
                      Managing Multiple Comorbidities
                      <AIHelpButton
                        topic="case_study_comorbidities"
                        className="ml-auto"
                      />
                    </div>
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary">Case 3</Badge>
                      Acute Deterioration Response
                      <AIHelpButton
                        topic="case_study_acute_deterioration"
                        className="ml-auto"
                      />
                    </div>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="practice">
          <Card>
            <CardHeader>
              <CardTitle>Practice Exercises</CardTitle>
              <CardDescription>
                Apply your knowledge through interactive scenarios and
                assessments
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Alert>
                  <AlertTitle>Start Practice Session</AlertTitle>
                  <AlertDescription>
                    Select a practice area below to begin applying risk
                    reduction concepts in simulated clinical scenarios.
                  </AlertDescription>
                </Alert>

                <div className="grid gap-4 md:grid-cols-2">
                  <Button variant="outline" className="h-auto p-4">
                    <div className="text-left">
                      <div className="flex items-center gap-2 mb-2">
                        <Scale className="h-5 w-5" />
                        <span className="font-semibold">
                          Risk Assessment Tools
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Practice using common risk assessment scales and tools
                      </p>
                    </div>
                  </Button>

                  <Button variant="outline" className="h-auto p-4">
                    <div className="text-left">
                      <div className="flex items-center gap-2 mb-2">
                        <Activity className="h-5 w-5" />
                        <span className="font-semibold">Case Scenarios</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Work through complex patient scenarios
                      </p>
                    </div>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="assessment">
          <Card>
            <CardHeader>
              <CardTitle>Knowledge Check</CardTitle>
              <CardDescription>
                Test your understanding of risk reduction concepts
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Alert>
                <AlertTitle>Ready to Test Your Knowledge?</AlertTitle>
                <AlertDescription>
                  Complete this assessment to evaluate your understanding of
                  risk reduction principles and earn your module completion
                  certificate.
                </AlertDescription>
              </Alert>

              <Button className="mt-4">Start Assessment</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={showAIExplanation} onOpenChange={setShowAIExplanation}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5" />
              {selectedTopic
                ? formatTopicName(selectedTopic)
                : "AI Learning Assistant"}
            </DialogTitle>
          </DialogHeader>
          {requestAIExplanation.isPending ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin" />
              <span className="ml-2">Generating explanation...</span>
            </div>
          ) : explanationContent ? (
            <ScrollArea className="h-[60vh]">
              <div className="space-y-6 pr-4">
                <div className="prose prose-sm max-w-none dark:prose-invert">
                  {explanationContent.content.split("\n").map(
                    (paragraph, index) =>
                      paragraph.trim() && (
                        <p key={index} className="mb-4 last:mb-0">
                          {paragraph.trim()}
                        </p>
                      ),
                  )}
                </div>
                {explanationContent.keyPoints &&
                  explanationContent.keyPoints.length > 0 && (
                    <div className="mt-4">
                      <h4 className="font-semibold mb-2">Key Points</h4>
                      <ul className="list-disc pl-4 space-y-1">
                        {explanationContent.keyPoints.map((point, i) => (
                          <li key={i}>{point}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                {explanationContent.examples &&
                  explanationContent.examples.length > 0 && (
                    <div className="mt-4">
                      <h4 className="font-semibold mb-2">Clinical Examples</h4>
                      <ul className="list-disc pl-4 space-y-1">
                        {explanationContent.examples.map((example, i) => (
                          <li key={i}>{example}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                {explanationContent.relatedConcepts &&
                  explanationContent.relatedConcepts.length > 0 && (
                    <div className="mt-4">
                      <h4 className="font-semibold mb-2">Related Concepts</h4>
                      <div className="flex flex-wrap gap-2">
                        {explanationContent.relatedConcepts.map(
                          (concept, i) => (
                            <Badge
                              key={i}
                              variant="secondary"
                              className="cursor-pointer hover:bg-secondary/80"
                              onClick={() => handleAskAI(concept)}
                            >
                              {concept}
                            </Badge>
                          ),
                        )}
                      </div>
                    </div>
                  )}
              </div>
            </ScrollArea>
          ) : null}
        </DialogContent>
      </Dialog>
    </div>
  );
}
