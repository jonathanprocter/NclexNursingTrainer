import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Brain,
  Calculator,
  BookOpen,
  Lightbulb,
  Loader2,
  MessageSquare,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ModuleContent } from "@/components/modules/ModuleContent";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";

interface ExplanationContent {
  content: string;
  keyPoints?: string[];
  examples?: string[];
  relatedConcepts?: string[];
}

const MODULE_CONTENT = {
  title: "Drug Calculations: A Comprehensive Guide",
  introduction:
    "Welcome to this in-depth module on Drug Calculations! As a nursing student preparing for the NCLEX, developing proficiency in medication math is absolutely essential for safe and effective practice.",
  objectives: [
    "Convert between different units of measurement",
    "Calculate medication dosages using dimensional analysis",
    "Determine flow rates and durations for IV infusions",
    "Adjust dosages for special populations",
    "Most importantly, understand the critical thinking process behind medication math",
  ],
  sections: [
    {
      title: "Measurement & Conversion Basics",
      content: `Before we dive into calculations, let's make sure we have a solid grasp on the fundamental units of measurement used in medication administration.

The metric system is the standard for medication measurement. The key metric units you'll work with are:

- Grams (g): Used for measuring medication weights
- Milliliters (mL): Used for measuring medication volumes
- International Units (IU): Used for certain medications`,
      keyPoints: [
        "The metric system is the standard for medication measurement",
        "Converting between units requires careful attention to detail",
        "Accuracy in measurement is critical for patient safety",
      ],
      examples: [
        {
          scenario: "Converting Weight Units",
          problem: "Convert 5 grams to milligrams",
          solution: "5 g × 1000 mg/g = 5000 mg",
          explanation: "To convert from grams to milligrams, multiply by 1000",
        },
      ],
      practice: [
        {
          question: "How many milligrams are in 2.5 grams?",
          type: "calculation" as const,
          options: ["250 mg", "2,500 mg", "25 mg", "25,000 mg"],
          correctAnswer: "2,500 mg",
          explanation:
            "To convert grams to milligrams, multiply by 1000: 2.5 × 1000 = 2,500",
          difficulty: "basic" as const,
        },
      ],
      aiHelp: {
        enabled: true,
        prompts: [
          "Help me understand metric conversion",
          "Check my conversion work",
          "Explain the decimal point movement",
        ],
        contextualHints: [
          "Remember to move decimal point 3 places right for g to mg",
          "Think about the relationship between units",
        ],
      },
    },
    {
      title: "Dimensional Analysis",
      content: `Dimensional analysis is a systematic approach to medication calculations that uses the units to guide the setup and solution...`,
      keyPoints: [
        "Use units to guide problem setup",
        "Cancel out units systematically",
        "Always verify your answer makes sense",
      ],
      examples: [
        {
          scenario: "Calculating Medication Dosage",
          problem: "Calculate mL needed for 500 mg amoxicillin (250 mg/5 mL)",
          solution: "500 mg × (5 mL/250 mg) = 10 mL",
          explanation:
            "Using dimensional analysis, we set up the equation so the mg units cancel out",
        },
      ],
      practice: [
        {
          question:
            "A patient needs 1 gram of ceftriaxone. The vial contains 2 grams in 80 mL. How many mL should you administer?",
          type: "calculation" as const,
          correctAnswer: "40",
          explanation: "1 g × (80 mL/2 g) = 40 mL",
          difficulty: "intermediate" as const,
        },
      ],
      aiHelp: {
        enabled: true,
        prompts: [
          "Help me understand dimensional analysis",
          "Guide me through setting up this problem",
          "Check my calculation setup",
        ],
        contextualHints: [
          "Remember to align your units properly",
          "Make sure units cancel out correctly",
        ],
      },
    },
  ],
};

export default function DrugCalculationsModule() {
  const [showAIExplanation, setShowAIExplanation] = useState(false);
  const [selectedTopic, setSelectedTopic] = useState<string>("");
  const [explanationContent, setExplanationContent] =
    useState<ExplanationContent | null>(null);
  const { toast } = useToast();

  const requestAIExplanation = useMutation({
    mutationFn: async (topic: string) => {
      const response = await fetch("/api/modules/generate-explanation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic,
          context: "drug_calculations",
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to get explanation");
      }

      const data = await response.json();
      if (!data.success) {
        throw new Error(data.error || "Failed to generate explanation");
      }
      return data.data;
    },
    onSuccess: (data) => {
      setExplanationContent({
        content: data.content,
        keyPoints: data.content
          .split("\n")
          .filter((line: string) => line.startsWith("•"))
          .map((line: string) => line.substring(2)),
        examples: data.content
          .split("\n")
          .filter((line: string) => line.includes("Example:")),
        relatedConcepts: data.content
          .split("\n")
          .filter((line: string) => line.includes("Related Concepts:"))
          .flatMap((line: string) =>
            line
              .replace("Related Concepts:", "")
              .split("•")
              .map((concept: string) => concept.trim())
              .filter(Boolean),
          ),
      });
      setShowAIExplanation(true);
      toast({
        title: "AI Explanation Ready",
        description: "Your personalized explanation has been generated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description:
          error instanceof Error
            ? error.message
            : "Failed to get AI explanation",
        variant: "destructive",
      });
      setExplanationContent(null);
    },
  });

  const handleAskAI = (topic: string) => {
    setSelectedTopic(topic);
    requestAIExplanation.mutate(topic);
  };

  const formatTopicName = (topic: string) => {
    return topic
      .replace(/([a-z])([A-Z])/g, "$1 $2")
      .replace(/_/g, " ")
      .split(" ")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  const AIHelpButton = ({
    topic,
    className = "",
  }: {
    topic: string;
    className?: string;
  }) => (
    <Button
      variant="outline"
      size="sm"
      className={`flex items-center gap-2 ${className}`}
      onClick={() => handleAskAI(topic)}
      disabled={requestAIExplanation.isPending}
    >
      {requestAIExplanation.isPending && selectedTopic === topic ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <Brain className="h-4 w-4" />
      )}
      <span>Ask AI Assistant</span>
    </Button>
  );

  return (
    <ScrollArea className="h-[calc(100vh-4rem)]">
      <div className="container mx-auto py-6 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calculator className="h-6 w-6 text-primary" />
            <h1 className="text-3xl font-bold">{MODULE_CONTENT.title}</h1>
          </div>
          <AIHelpButton topic="drug_calculations_overview" className="ml-2" />
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                Learning Objectives
              </CardTitle>
              <Badge variant="outline">Essential Skills</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-6 space-y-2">
              {MODULE_CONTENT.objectives.map((objective, index) => (
                <li key={index} className="text-muted-foreground">
                  {objective}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <ModuleContent
          title={MODULE_CONTENT.title}
          introduction={MODULE_CONTENT.introduction}
          objectives={MODULE_CONTENT.objectives}
          sections={MODULE_CONTENT.sections}
        />

        <Dialog open={showAIExplanation} onOpenChange={setShowAIExplanation}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                {selectedTopic
                  ? formatTopicName(selectedTopic)
                  : "AI Learning Assistant"}
              </DialogTitle>
            </DialogHeader>
            {requestAIExplanation.isPending ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin" />
                <span className="ml-2">Generating explanation...</span>
              </div>
            ) : explanationContent ? (
              <ScrollArea className="h-[60vh]">
                <div className="space-y-6 pr-4">
                  <div className="prose prose-sm max-w-none dark:prose-invert">
                    {explanationContent.content.split("\n").map(
                      (paragraph, index) =>
                        paragraph.trim() && (
                          <p key={index} className="mb-4 last:mb-0">
                            {paragraph.trim()}
                          </p>
                        ),
                    )}
                  </div>
                  {explanationContent.keyPoints &&
                    explanationContent.keyPoints.length > 0 && (
                      <div className="mt-4">
                        <h4 className="font-semibold mb-2">Key Points</h4>
                        <ul className="list-disc pl-4 space-y-1">
                          {explanationContent.keyPoints.map((point, i) => (
                            <li key={i}>{point}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  {explanationContent.examples &&
                    explanationContent.examples.length > 0 && (
                      <div className="mt-4">
                        <h4 className="font-semibold mb-2">
                          Clinical Examples
                        </h4>
                        <ul className="list-disc pl-4 space-y-1">
                          {explanationContent.examples.map((example, i) => (
                            <li key={i}>{example}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  {explanationContent.relatedConcepts &&
                    explanationContent.relatedConcepts.length > 0 && (
                      <div className="mt-4">
                        <h4 className="font-semibold mb-2">Related Concepts</h4>
                        <div className="flex flex-wrap gap-2">
                          {explanationContent.relatedConcepts.map(
                            (concept, i) => (
                              <Badge
                                key={i}
                                variant="secondary"
                                className="cursor-pointer hover:bg-secondary/80"
                                onClick={() => handleAskAI(concept)}
                              >
                                {concept}
                              </Badge>
                            ),
                          )}
                        </div>
                      </div>
                    )}
                </div>
              </ScrollArea>
            ) : null}
          </DialogContent>
        </Dialog>
      </div>
    </ScrollArea>
  );
}
