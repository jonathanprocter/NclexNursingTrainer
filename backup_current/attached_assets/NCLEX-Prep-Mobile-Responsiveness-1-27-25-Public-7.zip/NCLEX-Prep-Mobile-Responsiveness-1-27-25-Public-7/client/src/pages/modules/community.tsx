import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function CommunityHealthPage() {
  return (
    <div className="container mx-auto py-6">
      <Card>
        <CardHeader>
          <CardTitle>Community Health Nursing</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Understanding population health management and community-based
            nursing care.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
