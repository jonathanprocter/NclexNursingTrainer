import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, BookOpen, Brain } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { AdaptiveQuestions } from "@/components/AdaptiveQuestions";

interface RecommendedTopic {
  id: number;
  name: string;
  confidence: number;
  recommended: boolean;
  suggestedQuestions: number;
  priority: "high" | "medium" | "low";
  reason: string;
}

interface PerformanceInsights {
  strengths: string[];
  areasForImprovement: string[];
  overallProgress: number;
}

interface Recommendation {
  currentLevel: string;
  recommendedTopics: RecommendedTopic[];
  suggestedStudyTime: number;
  nextMilestone: string;
  performanceInsights: PerformanceInsights;
}

export default function AdaptiveLearning() {
  const {
    data: recommendations,
    isLoading,
    error,
  } = useQuery<Recommendation>({
    queryKey: ["adaptive-recommendations"],
    queryFn: async () => {
      const res = await fetch("/api/adaptive/recommendations", {
        headers: {
          "Content-Type": "application/json",
          "X-User-Id": "1",
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        credentials: "include",
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Failed to load recommendations");
      }
      return res.json();
    },
    retry: 2,
    retryDelay: 1000,
  });

  if (error) {
    toast({
      variant: "destructive",
      title: "Error loading recommendations",
      description:
        error instanceof Error
          ? error.message
          : "Failed to load recommendations",
    });

    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <div className="text-lg text-red-600">
          Error loading recommendations. Please try again later.
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <Loader2 className="w-6 h-6 animate-spin mr-2" />
        <div className="text-lg">Loading recommendations...</div>
      </div>
    );
  }

  if (!recommendations) {
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <div className="text-lg">
          No recommendations available. Please complete some questions first.
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Adaptive Learning</h1>

      <div className="grid gap-8 lg:grid-cols-2">
        {/* Left Column - Study Progress */}
        <div className="space-y-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-4">
                <Brain className="w-6 h-6 text-primary" />
                <h2 className="text-2xl font-semibold">Study Progress</h2>
              </div>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">
                    Current Level
                  </p>
                  <p className="font-medium capitalize">
                    {recommendations.currentLevel}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">
                    Next Milestone
                  </p>
                  <p className="font-medium">{recommendations.nextMilestone}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">
                    Overall Progress
                  </p>
                  <p className="font-medium">
                    {Math.round(
                      recommendations.performanceInsights.overallProgress * 100,
                    )}
                    %
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">
                    Suggested Study Time
                  </p>
                  <p className="font-medium">
                    {recommendations.suggestedStudyTime} minutes
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <AdaptiveQuestions />
        </div>

        {/* Right Column - Recommendations and Insights */}
        <div className="space-y-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-4">
                <BookOpen className="w-6 h-6 text-primary" />
                <h2 className="text-2xl font-semibold">Recommended Topics</h2>
              </div>

              <div className="space-y-4">
                {recommendations.recommendedTopics.map(
                  (topic: RecommendedTopic) => (
                    <div
                      key={topic.id}
                      className="border-b pb-4 last:border-0 last:pb-0"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-semibold">{topic.name}</h3>
                        <span
                          className={`text-sm px-2 py-1 rounded capitalize
                        ${
                          topic.priority === "high"
                            ? "bg-red-100 text-red-700"
                            : topic.priority === "medium"
                              ? "bg-yellow-100 text-yellow-700"
                              : "bg-green-100 text-green-700"
                        }`}
                        >
                          {topic.priority}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">
                        {topic.reason}
                      </p>
                      <div className="flex justify-between text-sm">
                        <span>
                          Confidence: {Math.round(topic.confidence * 100)}%
                        </span>
                        <span>
                          Suggested Questions: {topic.suggestedQuestions}
                        </span>
                      </div>
                    </div>
                  ),
                )}
              </div>
            </CardContent>
          </Card>

          {/* Performance Insights */}
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">
                Performance Insights
              </h2>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-2">
                    Strengths
                  </h3>
                  <ul className="list-disc list-inside space-y-1">
                    {recommendations.performanceInsights.strengths.map(
                      (strength: string, i: number) => (
                        <li key={i} className="text-sm">
                          {strength}
                        </li>
                      ),
                    )}
                  </ul>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-2">
                    Areas for Improvement
                  </h3>
                  <ul className="list-disc list-inside space-y-1">
                    {recommendations.performanceInsights.areasForImprovement.map(
                      (area: string, i: number) => (
                        <li key={i} className="text-sm">
                          {area}
                        </li>
                      ),
                    )}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
