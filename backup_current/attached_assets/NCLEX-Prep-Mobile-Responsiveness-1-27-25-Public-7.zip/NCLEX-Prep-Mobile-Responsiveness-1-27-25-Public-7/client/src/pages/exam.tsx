import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Bookmark, Clock, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface Question {
  id: number;
  scenario: string;
  options: string[];
  explanation?: string;
  isBookmarked?: boolean;
  difficulty: "easy" | "medium" | "hard";
  domainId: number;
}

interface ExamState {
  id: string;
  currentQuestion: Question | null;
  questionNumber: number;
  timeRemaining: number;
  completed: boolean;
  totalQuestions: number;
}

function Timer({
  timeRemaining,
  isWarning,
}: {
  timeRemaining: number;
  isWarning: boolean;
}) {
  const minutes = Math.floor(timeRemaining / 60);
  const seconds = timeRemaining % 60;

  return (
    <div
      className={`flex items-center gap-2 text-xl font-mono ${isWarning ? "text-red-500" : ""}`}
    >
      <Clock className={`h-5 w-5 ${isWarning ? "animate-pulse" : ""}`} />
      <span>
        {String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
      </span>
    </div>
  );
}

export default function ExamPage() {
  const [examState, setExamState] = useState<ExamState | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<string>("");
  const [showTimeWarning, setShowTimeWarning] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);
  const { toast } = useToast();

  // Start new exam
  const startExam = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/exam/start", {
        method: "POST",
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to start exam");
      return response.json();
    },
    onSuccess: (data) => {
      setExamState({
        ...data,
        questionNumber: 1,
      });
      toast({
        title: "Exam Started",
        description: "Good luck! Answer all questions carefully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error Starting Exam",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Submit answer
  const submitAnswer = useMutation({
    mutationFn: async () => {
      if (!examState?.currentQuestion) return;

      const questionStartTime = localStorage.getItem(
        `question_${examState.currentQuestion.id}_start_time`,
      );
      const timeSpent = questionStartTime
        ? Math.floor((Date.now() - parseInt(questionStartTime)) / 1000)
        : 0;

      const response = await fetch(`/api/exam/${examState.id}/submit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          answer: selectedAnswer,
          timeSpent,
        }),
      });
      if (!response.ok) throw new Error("Failed to submit answer");
      return response.json();
    },
    onSuccess: (data) => {
      if (data.completed) {
        toast({
          title: "Exam Completed",
          description: "Your exam has been submitted successfully.",
        });
        window.location.href = `/exam/${examState?.id}/results`;
      } else {
        setShowExplanation(true);
        // After showing explanation, proceed to next question
        setTimeout(() => {
          setExamState(
            (prev) =>
              prev && {
                ...prev,
                currentQuestion: data.nextQuestion,
                questionNumber: prev.questionNumber + 1,
                timeRemaining: data.timeRemaining,
              },
          );
          setSelectedAnswer("");
          setShowExplanation(false);
          // Set start time for new question
          localStorage.setItem(
            `question_${data.nextQuestion.id}_start_time`,
            Date.now().toString(),
          );
        }, 5000);
      }
    },
    onError: (error) => {
      toast({
        title: "Error Submitting Answer",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Toggle bookmark
  const toggleBookmark = useMutation({
    mutationFn: async () => {
      if (!examState?.currentQuestion) return;
      const response = await fetch(`/api/exam/${examState.id}/bookmark`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          questionIndex: examState.questionNumber - 1,
        }),
      });
      if (!response.ok) throw new Error("Failed to toggle bookmark");
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: data.isBookmarked ? "Question Bookmarked" : "Bookmark Removed",
        duration: 2000,
      });
      setExamState(
        (prev) =>
          prev && {
            ...prev,
            currentQuestion: prev.currentQuestion && {
              ...prev.currentQuestion,
              isBookmarked: data.isBookmarked,
            },
          },
      );
    },
  });

  // Start exam on component mount
  useEffect(() => {
    startExam.mutate();
  }, []);

  // Update timer every second and handle time warnings
  useEffect(() => {
    if (!examState) return;

    // Set initial start time for first question
    if (examState.questionNumber === 1) {
      localStorage.setItem(
        `question_${examState.currentQuestion?.id}_start_time`,
        Date.now().toString(),
      );
    }

    const timer = setInterval(() => {
      setExamState((prev) => {
        if (!prev) return null;
        const newTimeRemaining = prev.timeRemaining - 1;

        // Show warning when 5 minutes remaining
        if (newTimeRemaining === 300 && !showTimeWarning) {
          setShowTimeWarning(true);
          toast({
            title: "Time Warning",
            description: "5 minutes remaining!",
            variant: "destructive",
          });
        }

        if (newTimeRemaining <= 0) {
          clearInterval(timer);
          window.location.href = `/exam/${prev.id}/results`;
          return { ...prev, timeRemaining: 0, completed: true };
        }

        return { ...prev, timeRemaining: newTimeRemaining };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [examState?.id]);

  if (!examState || !examState.currentQuestion) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-pulse">Loading exam...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Timer and Progress */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">NCLEX Practice Exam</h2>
          <div className="flex items-center gap-4">
            <Timer
              timeRemaining={examState.timeRemaining}
              isWarning={examState.timeRemaining <= 300}
            />
            <Badge variant="outline">
              Question {examState.questionNumber}/{examState.totalQuestions}
            </Badge>
          </div>
        </div>
        <Progress
          value={(examState.questionNumber / examState.totalQuestions) * 100}
          className="h-2"
        />
      </div>

      {/* Question Card */}
      <Card className="p-6">
        <CardContent>
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="text-xl font-semibold">
                Question {examState.questionNumber}
              </h3>
              <Badge variant="secondary" className="mt-2">
                Difficulty: {examState.currentQuestion.difficulty}
              </Badge>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => toggleBookmark.mutate()}
            >
              <Bookmark
                className={`h-5 w-5 ${
                  examState.currentQuestion.isBookmarked ? "fill-current" : ""
                }`}
              />
            </Button>
          </div>

          <div className="space-y-6">
            <p className="text-lg">{examState.currentQuestion.scenario}</p>

            <div className="space-y-3">
              {examState.currentQuestion.options.map((option, index) => (
                <Button
                  key={index}
                  variant={selectedAnswer === option ? "default" : "outline"}
                  className="w-full justify-start text-left p-4"
                  onClick={() => setSelectedAnswer(option)}
                >
                  {option}
                </Button>
              ))}
            </div>

            <div className="flex justify-end mt-6">
              <Button
                onClick={() => submitAnswer.mutate()}
                disabled={!selectedAnswer}
                size="lg"
                className="w-32"
              >
                Next Question
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Time Warning Dialog */}
      <AlertDialog open={showTimeWarning} onOpenChange={setShowTimeWarning}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Time Warning</AlertDialogTitle>
            <AlertDialogDescription>
              You have 5 minutes remaining in the exam. Please make sure to
              complete all remaining questions.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction>Continue Exam</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Explanation Dialog */}
      {showExplanation && examState.currentQuestion.explanation && (
        <AlertDialog open={showExplanation} onOpenChange={setShowExplanation}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Question Explanation</AlertDialogTitle>
              <AlertDialogDescription>
                {examState.currentQuestion.explanation}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogAction>Next Question</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
}
