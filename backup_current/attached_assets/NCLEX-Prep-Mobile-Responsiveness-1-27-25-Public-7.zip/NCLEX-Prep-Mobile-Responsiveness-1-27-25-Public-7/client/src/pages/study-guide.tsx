import { StudyGuide } from "@/components/StudyGuide";
import { Card } from "@/components/ui/card";

export default function StudyGuidePage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="p-6">
        <StudyGuide />
      </Card>
    </div>
  );
}