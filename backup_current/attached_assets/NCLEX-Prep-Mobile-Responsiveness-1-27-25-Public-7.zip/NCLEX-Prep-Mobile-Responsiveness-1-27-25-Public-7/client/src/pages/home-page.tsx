import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Brain,
  BookOpen,
  HeartPulse,
  Baby,
  Activity,
  UserCircle,
} from "lucide-react";

const domains = [
  {
    title: "Fundamentals",
    description: "Core nursing concepts and basic patient care",
    icon: Brain,
    href: "/practice/fundamentals",
  },
  {
    title: "Medical-Surgical",
    description: "Adult health and illness management",
    icon: HeartPulse,
    href: "/practice/medical_surgical",
  },
  {
    title: "Pediatric",
    description: "Child health and development",
    icon: Baby,
    href: "/practice/pediatric",
  },
  {
    title: "Mental Health",
    description: "Psychiatric and behavioral health",
    icon: Activity,
    href: "/practice/mental_health",
  },
  {
    title: "Maternal",
    description: "Pregnancy and childbirth care",
    icon: UserCircle,
    href: "/practice/maternal",
  },
  {
    title: "Leadership",
    description: "Management and delegation skills",
    icon: BookOpen,
    href: "/practice/leadership",
  },
];

export default function HomePage() {
  return (
    <div className="container mx-auto py-8">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold mb-4">NCLEX Preparation Platform</h1>
        <p className="text-muted-foreground">
          Choose a domain to begin practicing NCLEX-style questions
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {domains.map((domain) => {
          const Icon = domain.icon;
          return (
            <Card
              key={domain.title}
              className="hover:shadow-lg transition-shadow"
            >
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Icon className="h-5 w-5" />
                  {domain.title}
                </CardTitle>
                <CardDescription>{domain.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <Link href={domain.href}>
                  <Button className="w-full">Start Practice</Button>
                </Link>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
