import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  RadialBarChart,
  RadialBar,
  Legend,
  Area,
  AreaChart,
} from "recharts";
import {
  Activity,
  TrendingUp,
  Clock,
  Target,
  BarChart2,
  Calendar,
  Brain,
  Filter,
  Download,
  ChevronDown,
  ArrowUpRight,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { DetailedPerformanceMetrics } from "@/components/DetailedPerformanceMetrics";
import { AdaptiveQuestions } from "@/components/AdaptiveQuestions";
import { AdvancedAnalyticsDashboard } from "@/components/AdvancedAnalyticsDashboard";
import { StudyAnalytics } from "@/components/StudyAnalytics";
import { useQuery } from "@tanstack/react-query";
import type { DomainProgress } from "@/types/analytics";

interface ProgressMetrics {
  overallProgress: number;
  weeklyProgress: {
    completion: number;
    accuracy: number;
    studyTime: number;
    questionsAttempted: number;
  };
  domainProgress: DomainProgress[];
  studyMetrics: {
    totalTime: number;
    questionsAttempted: number;
    averageAccuracy: number;
    performanceTrend: Array<{
      date: string;
      accuracy: number;
      timeSpent: number;
    }>;
    strengthAreas: string[];
    weakAreas: string[];
    recommendedFocus: string[];
    streakDays: number;
    lastStudySession: string;
  };
}

export default function ProgressPage() {
  const [timeRange, setTimeRange] = useState("week");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [showFilters, setShowFilters] = useState(false);

  const {
    data: metrics,
    isLoading,
    error,
  } = useQuery<ProgressMetrics>({
    queryKey: ["/api/progress/metrics", timeRange, selectedCategory],
    refetchInterval: 300000, // Refetch every 5 minutes
  });

  if (isLoading) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="animate-pulse space-y-8">
          {/* Add loading skeleton UI here */}
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid gap-4 md:grid-cols-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto py-8 px-4">
        <Card className="bg-destructive/10">
          <CardContent className="py-6">
            <p className="text-center text-destructive">
              Failed to load progress metrics. Please try again later.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Progress Analytics</h1>
            <p className="text-muted-foreground mt-2">
              Track your NCLEX preparation journey
            </p>
          </div>
          <div className="flex gap-4">
            <Button
              variant="outline"
              className="gap-2"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter className="w-4 h-4" />
              Filters
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <Download className="w-4 h-4" />
                  Export
                  <ChevronDown className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>Export as PDF</DropdownMenuItem>
                <DropdownMenuItem>Export as CSV</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>Share Progress</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select time range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="week">Past Week</SelectItem>
                <SelectItem value="month">Past Month</SelectItem>
                <SelectItem value="all">All Time</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
            >
              <Card className="bg-muted/50">
                <CardContent className="py-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Select
                      value={selectedCategory}
                      onValueChange={setSelectedCategory}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Filter by category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        {metrics?.domainProgress.map((domain) => (
                          <SelectItem
                            key={domain.id.toString()}
                            value={domain.id.toString()}
                          >
                            {domain.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Advanced Analytics Dashboard */}
        <AdvancedAnalyticsDashboard />

        {/* Study Analytics */}
        {metrics?.studyMetrics && (
          <StudyAnalytics metrics={metrics.studyMetrics} />
        )}

        {/* Detailed Performance Metrics */}
        {metrics?.domainProgress && (
          <DetailedPerformanceMetrics domainProgress={metrics.domainProgress} />
        )}

        {/* Adaptive Questions Section */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5" />
              Practice & Improvement
            </CardTitle>
          </CardHeader>
          <CardContent>
            <AdaptiveQuestions />
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex justify-center gap-4 mt-8">
          <Button variant="outline" className="w-full max-w-xs">
            <Calendar className="w-4 h-4 mr-2" />
            View Study Schedule
          </Button>
          <Button variant="outline" className="w-full max-w-xs">
            <Sparkles className="w-4 h-4 mr-2" />
            Get AI Recommendations
          </Button>
        </div>
      </div>
    </div>
  );
}
