import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Clock,
  CheckCircle,
  AlertCircle,
  BarChart,
  Brain,
  Target,
} from "lucide-react";
import { Progress } from "@/components/ui/progress";

export default function MockExams() {
  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            Mock NCLEX Exams
          </h1>
          <p className="text-muted-foreground">
            Full-length practice exams that simulate the real NCLEX experience
          </p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {/* CAT Exam Card */}
        <Card>
          <CardHeader>
            <CardTitle>CAT Mock Exam</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Adaptive exam that adjusts difficulty based on your performance
            </p>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Duration</span>
                <span className="font-medium">Up to 5 hours</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span>Questions</span>
                <span className="font-medium">75-145 adaptive</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span>Difficulty</span>
                <span className="font-medium">Dynamic</span>
              </div>
            </div>
            <Button className="w-full">Start CAT Exam</Button>
          </CardContent>
        </Card>

        {/* Standard Exam Card */}
        <Card>
          <CardHeader>
            <CardTitle>Standard Mock Exam</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Fixed-length exam with consistent difficulty level
            </p>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Duration</span>
                <span className="font-medium">6 hours</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span>Questions</span>
                <span className="font-medium">145 fixed</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span>Difficulty</span>
                <span className="font-medium">Standard</span>
              </div>
            </div>
            <Button className="w-full">Start Standard Exam</Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your Progress</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span>Exams Completed</span>
              <span className="font-medium">3/5</span>
            </div>
            <Progress value={60} className="h-2" />
            <p className="text-xs text-muted-foreground">
              Complete 2 more exams to receive a comprehensive readiness report
            </p>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="flex items-center justify-between text-sm">
              <span>CAT Average</span>
              <span className="font-medium text-green-600">82%</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span>Standard Average</span>
              <span className="font-medium text-green-600">78%</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Previous Exams</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b pb-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <p className="font-medium">CAT Mock Exam #3</p>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  <span>Completed Jan 20, 2024</span>
                  <Brain className="h-4 w-4 ml-2" />
                  <span>85 questions</span>
                </div>
              </div>
              <div className="text-right">
                <p className="font-medium text-green-600">82%</p>
                <p className="text-sm text-muted-foreground">Passing</p>
              </div>
            </div>

            <div className="flex items-center justify-between border-b pb-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <p className="font-medium">Standard Mock Exam #2</p>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  <span>Completed Jan 15, 2024</span>
                  <Target className="h-4 w-4 ml-2" />
                  <span>145 questions</span>
                </div>
              </div>
              <div className="text-right">
                <p className="font-medium text-green-600">78%</p>
                <p className="text-sm text-muted-foreground">Passing</p>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-yellow-500" />
                  <p className="font-medium">CAT Mock Exam #1</p>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  <span>Completed Jan 10, 2024</span>
                  <Brain className="h-4 w-4 ml-2" />
                  <span>112 questions</span>
                </div>
              </div>
              <div className="text-right">
                <p className="font-medium text-yellow-600">72%</p>
                <p className="text-sm text-muted-foreground">Near passing</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Performance Analysis</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <BarChart className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Critical Thinking</span>
              </div>
              <Progress value={85} className="h-2" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Target className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Decision Making</span>
              </div>
              <Progress value={78} className="h-2" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Brain className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Clinical Judgment</span>
              </div>
              <Progress value={92} className="h-2" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
