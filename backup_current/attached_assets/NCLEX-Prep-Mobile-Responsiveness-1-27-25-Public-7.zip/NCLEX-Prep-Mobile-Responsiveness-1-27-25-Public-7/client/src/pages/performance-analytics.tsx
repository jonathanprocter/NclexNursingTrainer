import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import {
  Activity,
  TrendingUp,
  Target,
  BookOpen,
  Brain,
  CheckCircle,
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";

type TimeRange = "week" | "month" | "all";
type PerformanceData = {
  retentionRate: number;
  estimatedMastery: number;
  averageAccuracy: number;
  performanceTrend: Array<{
    date: string;
    score: number;
    average: number;
  }>;
};

export default function PerformanceAnalytics() {
  const [timeRange, setTimeRange] = useState<TimeRange>("week");

  const { data: performance } = useQuery<PerformanceData>({
    queryKey: ["/api/analytics/performance", timeRange],
  });

  const getPerformanceColor = (value: number) => {
    if (value >= 80) return "text-green-600";
    if (value >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  const handleTimeRangeChange = (value: string) => {
    setTimeRange(value as TimeRange);
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            Performance Analytics
          </h1>
          <p className="text-muted-foreground">
            Track your NCLEX preparation progress and identify areas for
            improvement
          </p>
        </div>
        <Select value={timeRange} onValueChange={handleTimeRangeChange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select time range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="week">Last Week</SelectItem>
            <SelectItem value="month">Last Month</SelectItem>
            <SelectItem value="all">All Time</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Retention Rate
            </CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div>
              <p
                className={`text-2xl font-bold ${getPerformanceColor(performance?.retentionRate ?? 0)}`}
              >
                {Math.round(performance?.retentionRate ?? 0)}%
              </p>
              <p className="text-xs text-muted-foreground">
                Information retention
              </p>
            </div>
            <Progress
              value={performance?.retentionRate ?? 0}
              className="mt-2"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Mastery Level</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div>
              <p
                className={`text-2xl font-bold ${getPerformanceColor(performance?.estimatedMastery ?? 0)}`}
              >
                {Math.round(performance?.estimatedMastery ?? 0)}%
              </p>
              <p className="text-xs text-muted-foreground">Overall mastery</p>
            </div>
            <Progress
              value={performance?.estimatedMastery ?? 0}
              className="mt-2"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Average Accuracy
            </CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div>
              <p
                className={`text-2xl font-bold ${getPerformanceColor(performance?.averageAccuracy ?? 0)}`}
              >
                {Math.round(performance?.averageAccuracy ?? 0)}%
              </p>
              <p className="text-xs text-muted-foreground">Question accuracy</p>
            </div>
            <Progress
              value={performance?.averageAccuracy ?? 0}
              className="mt-2"
            />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Performance Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={performance?.performanceTrend ?? []}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="score"
                  stroke="#2563eb"
                  name="Your Score"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                />
                <Line
                  type="monotone"
                  dataKey="average"
                  stroke="#9ca3af"
                  name="Class Average"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Focus Areas</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              <li className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Target className="h-4 w-4 text-muted-foreground" />
                  <span>Pharmacology & Parenteral</span>
                </div>
                <span className="font-bold text-primary">92%</span>
              </li>
              <li className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Target className="h-4 w-4 text-muted-foreground" />
                  <span>Clinical Judgment</span>
                </div>
                <span className="font-bold text-primary">88%</span>
              </li>
              <li className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Target className="h-4 w-4 text-muted-foreground" />
                  <span>Risk Reduction</span>
                </div>
                <span className="font-bold text-yellow-600">76%</span>
              </li>
              <li className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Target className="h-4 w-4 text-muted-foreground" />
                  <span>Drug Calculations</span>
                </div>
                <span className="font-bold text-red-600">65%</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              <li className="flex items-center space-x-2">
                <BookOpen className="h-4 w-4 text-muted-foreground" />
                <span>Completed Advanced Pathophysiology Module</span>
              </li>
              <li className="flex items-center space-x-2">
                <Brain className="h-4 w-4 text-muted-foreground" />
                <span>Mastered Clinical Judgment Section</span>
              </li>
              <li className="flex items-center space-x-2">
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
                <span>Improved Drug Calculations Score by 15%</span>
              </li>
              <li className="flex items-center space-x-2">
                <Activity className="h-4 w-4 text-muted-foreground" />
                <span>Completed 50 Practice Questions</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
