import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Brain, TrendingUp, Book, AlertTriangle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface AnalyticsData {
  learningMetrics: {
    overallAccuracy: number;
    averageConfidence: number;
    categoriesCovered: number;
    totalReviewed: number;
  };
  categoryPerformance: Array<{
    category: string;
    accuracy: number;
    attempts: number;
    confidence: number;
  }>;
  timestamp: string;
}

interface RecommendationsData {
  recommendations: Array<{
    category: string;
    accuracy: number;
    confidence: number;
    suggestedReviews: number;
    suggestion: string;
  }>;
  timestamp: string;
}

export default function AnalyticsPage() {
  const {
    data: analyticsData,
    isLoading: isLoadingAnalytics,
    error: analyticsError,
  } = useQuery<AnalyticsData>({
    queryKey: ["/api/analytics/stats"],
  });

  const { data: recommendationsData, isLoading: isLoadingRecommendations } =
    useQuery<RecommendationsData>({
      queryKey: ["/api/analytics/recommendations"],
    });

  if (isLoadingAnalytics || isLoadingRecommendations) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <Skeleton className="h-[200px] w-full" />
        <Skeleton className="h-[300px] w-full" />
      </div>
    );
  }

  if (analyticsError) {
    return (
      <div className="container mx-auto p-6">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            Failed to load analytics data. Please try again later.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  const metrics = analyticsData?.learningMetrics || {
    overallAccuracy: 0,
    averageConfidence: 0,
    categoriesCovered: 0,
    totalReviewed: 0,
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Accuracy</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {(metrics.overallAccuracy || 0).toFixed(1)}%
            </div>
            <Progress value={metrics.overallAccuracy || 0} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Confidence</CardTitle>
            <Brain className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {(metrics.averageConfidence || 0).toFixed(1)}/5
            </div>
            <Progress
              value={(metrics.averageConfidence || 0) * 20}
              className="mt-2"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              Topics Covered
            </CardTitle>
            <Book className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {metrics.categoriesCovered || 0}
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Total reviewed: {metrics.totalReviewed || 0}
            </p>
          </CardContent>
        </Card>
      </div>

      {analyticsData?.categoryPerformance && (
        <Card>
          <CardHeader>
            <CardTitle>Category Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {analyticsData.categoryPerformance.map((category) => (
                <div key={category.category} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">{category.category}</span>
                    <span className="text-muted-foreground">
                      {category.attempts} attempts
                    </span>
                  </div>
                  <Progress value={category.accuracy} className="h-2" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Accuracy: {category.accuracy.toFixed(1)}%</span>
                    <span>
                      Confidence: {category.confidence.toFixed(1)}/5
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {recommendationsData?.recommendations && (
        <Card>
          <CardHeader>
            <CardTitle>Study Recommendations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recommendationsData.recommendations.map((rec) => (
                <Alert key={rec.category}>
                  <AlertTitle>{rec.category}</AlertTitle>
                  <AlertDescription className="mt-2">
                    <p>{rec.suggestion}</p>
                    <div className="mt-2 text-sm text-muted-foreground">
                      Current accuracy: {rec.accuracy.toFixed(1)}% •
                      Suggested reviews: {rec.suggestedReviews}
                    </div>
                  </AlertDescription>
                </Alert>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}