import { ContentViewer } from "@/components/ContentViewer";

export default function ContentPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">NCLEX Study Content</h1>
          <p className="text-muted-foreground">
            Browse and study comprehensive NCLEX preparation materials
          </p>
        </div>
      </div>

      <ContentViewer />
    </div>
  );
}
