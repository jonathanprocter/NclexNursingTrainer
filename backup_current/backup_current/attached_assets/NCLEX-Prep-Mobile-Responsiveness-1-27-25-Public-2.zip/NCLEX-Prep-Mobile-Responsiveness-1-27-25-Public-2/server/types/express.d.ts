import { Session } from "express-session";

declare module "express-session" {
  interface Session {
    userId?: number;
    currentStudySessionId?: number;
  }
}

declare module "express" {
  interface Request {
    user?: {
      id: number;
      username: string;
    };
  }
}
