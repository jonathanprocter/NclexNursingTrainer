import { createServer, Server } from "net";

export async function findAvailablePort(startPort: number): Promise<number> {
  const isPortAvailable = (port: number): Promise<boolean> => {
    return new Promise((resolve) => {
      const server: Server = createServer()
        .listen(port, "0.0.0.0")
        .once("error", () => {
          resolve(false);
          server.close();
        })
        .once("listening", () => {
          server.close(() => resolve(true));
        });
    });
  };

  let port = startPort;
  const maxAttempts = 100;
  let attempts = 0;

  while (!(await isPortAvailable(port))) {
    port++;
    attempts++;
    if (attempts >= maxAttempts) {
      throw new Error(
        `No available ports found in range ${startPort}-${startPort + maxAttempts}`,
      );
    }
  }

  return port;
}
