import { EventEmitter } from "events";

interface ServiceStatus {
  isAvailable: boolean;
  activeProvider: "anthropic" | "openai" | null;
  lastCheck: Date;
  errorCount: number;
  consecutiveErrors: number;
  averageResponseTime: number;
  lastError?: Error;
  recoveryAttempts: number;
  totalRequests: number;
}

interface ServiceHealthStatus {
  degraded: boolean;
  availability: boolean;
  activeProvider: "anthropic" | "openai" | null;
  errorRate: number;
  averageResponseTime: number;
}

export class AIServiceMonitor extends EventEmitter {
  private status: ServiceStatus = {
    isAvailable: false,
    activeProvider: null,
    lastCheck: new Date(),
    errorCount: 0,
    consecutiveErrors: 0,
    averageResponseTime: 0,
    recoveryAttempts: 0,
    totalRequests: 0,
  };

  private readonly ERROR_THRESHOLD = 5;
  private readonly MAX_RECOVERY_ATTEMPTS = 3;
  private readonly CHECK_INTERVAL = 15000; // 15 seconds
  private responseTimes: number[] = [];
  private readonly MAX_RESPONSE_TIMES = 100;
  private degradedMode = false;

  constructor() {
    super();
    this.setupHealthCheck();
  }

  private setupHealthCheck(): void {
    setInterval(() => {
      this.checkHealth();
    }, this.CHECK_INTERVAL);
  }

  public updateStatus(provider: "openai" | "anthropic", isAvailable: boolean, responseTime?: number): void {
    this.status.isAvailable = isAvailable;
    this.status.activeProvider = isAvailable ? provider : null;
    this.status.lastCheck = new Date();
    this.status.totalRequests++;

    if (responseTime) {
      this.updateResponseTimes(responseTime);
    }

    if (!isAvailable) {
      this.handleServiceFailure();
    } else {
      this.handleServiceRecovery();
    }

    this.emit("statusUpdate", { ...this.status });
  }

  private handleServiceFailure(): void {
    this.status.consecutiveErrors++;
    this.status.errorCount++;

    if (this.status.consecutiveErrors >= this.ERROR_THRESHOLD) {
      this.enterDegradedMode();
    }

    this.emit("serviceFailure", {
      consecutiveErrors: this.status.consecutiveErrors,
      totalErrors: this.status.errorCount,
    });
  }

  private handleServiceRecovery(): void {
    if (this.status.consecutiveErrors > 0) {
      this.status.consecutiveErrors = 0;
      if (this.degradedMode) {
        this.exitDegradedMode();
      }
    }
  }

  private updateResponseTimes(responseTime: number): void {
    this.responseTimes.push(responseTime);
    if (this.responseTimes.length > this.MAX_RESPONSE_TIMES) {
      this.responseTimes.shift();
    }
    this.status.averageResponseTime = this.calculateAverageResponseTime();
  }

  private calculateAverageResponseTime(): number {
    if (this.responseTimes.length === 0) return 0;
    return this.responseTimes.reduce((a, b) => a + b, 0) / this.responseTimes.length;
  }

  private checkHealth(): void {
    const healthStatus: ServiceHealthStatus = {
      degraded: this.degradedMode,
      availability: this.status.isAvailable,
      activeProvider: this.status.activeProvider,
      errorRate: this.calculateErrorRate(),
      averageResponseTime: this.status.averageResponseTime,
    };

    if (this.shouldEnterDegradedMode(healthStatus)) {
      this.enterDegradedMode();
    } else if (this.shouldExitDegradedMode(healthStatus)) {
      this.exitDegradedMode();
    }

    this.emit("healthCheck", healthStatus);
  }

  private shouldEnterDegradedMode(health: ServiceHealthStatus): boolean {
    return (
      health.errorRate > 0.2 || // Error rate above 20%
      health.averageResponseTime > 5000 || // Response time above 5s
      this.status.consecutiveErrors >= this.ERROR_THRESHOLD
    );
  }

  private shouldExitDegradedMode(health: ServiceHealthStatus): boolean {
    return (
      this.degradedMode &&
      health.errorRate < 0.1 && // Error rate below 10%
      health.averageResponseTime < 3000 && // Response time below 3s
      this.status.consecutiveErrors === 0
    );
  }

  private calculateErrorRate(): number {
    return this.status.totalRequests === 0
      ? 0
      : this.status.errorCount / this.status.totalRequests;
  }

  private enterDegradedMode(): void {
    if (!this.degradedMode) {
      this.degradedMode = true;
      this.emit("degradedMode", true);
    }
  }

  private exitDegradedMode(): void {
    if (this.degradedMode) {
      this.degradedMode = false;
      this.emit("degradedMode", false);
    }
  }

  public getStatus(): Readonly<ServiceStatus> {
    return { ...this.status };
  }

  public isDegraded(): boolean {
    return this.degradedMode;
  }

  public reset(): void {
    this.status = {
      isAvailable: false,
      activeProvider: null,
      lastCheck: new Date(),
      errorCount: 0,
      consecutiveErrors: 0,
      averageResponseTime: 0,
      recoveryAttempts: 0,
      totalRequests: 0,
    };
    this.responseTimes = [];
    this.degradedMode = false;
    this.emit("reset");
  }
}

// Export singleton instance
export const serviceMonitor = new AIServiceMonitor();