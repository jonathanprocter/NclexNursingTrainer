// Import from services directly since we've removed the lib alias
import { serviceMonitor } from "../services/ai-service-monitor";
import { analyticsService } from "../services/analytics";
import OpenAI from "openai";
import Anthropic from "@anthropic-ai/sdk";
import {
  questions,
  userProgress,
  learningPaths,
  questionAnswers,
} from "@db/schema";
import { db } from "@db";
import { eq } from "drizzle-orm";
import { LearningPath, Question } from "../types";

export class AILearningService {
  private openai: OpenAI | null = null;
  private anthropic: Anthropic | null = null;
  private readonly MAX_RETRIES = 3;
  private readonly RETRY_DELAY = 1000;
  private initialized = false;
  private activeProvider: "openai" | "anthropic" | null = null;

  constructor() {
    console.log("[AILearningService] Constructor called");
    this.initialize().catch((error) => {
      console.error("[AILearningService] Failed to initialize:", error);
      serviceMonitor.updateStatus(this.activeProvider || "openai", false);
    });
  }

  private async initialize(): Promise<void> {
    if (this.initialized) {
      return;
    }

    console.log("[AILearningService] Starting initialization...");

    const providers = ["openai", "anthropic"] as const;
    for (const provider of providers) {
      try {
        console.log(`[AILearningService] Attempting to initialize ${provider}...`);

        if (provider === "anthropic" && process.env.ANTHROPIC_API_KEY) {
          const startTime = Date.now();
          this.anthropic = new Anthropic({
            apiKey: process.env.ANTHROPIC_API_KEY,
          });

          // Test the connection
          await this.anthropic.messages.create({
            model: "claude-3-opus-20240229",
            max_tokens: 5,
            messages: [{ role: "user", content: "Test" }]
          });

          const responseTime = Date.now() - startTime;
          console.log("[AILearningService] Anthropic initialized successfully");
          this.activeProvider = "anthropic";
          serviceMonitor.updateStatus("anthropic", true, responseTime);
          break;
        } else if (provider === "openai" && process.env.OPENAI_API_KEY) {
          const startTime = Date.now();
          this.openai = new OpenAI({
            apiKey: process.env.OPENAI_API_KEY,
          });

          // Test the connection
          await this.openai.chat.completions.create({
            model: "gpt-4",
            messages: [{ role: "user", content: "Test" }],
            max_tokens: 5,
          });

          const responseTime = Date.now() - startTime;
          console.log("[AILearningService] OpenAI initialized successfully");
          this.activeProvider = "openai";
          serviceMonitor.updateStatus("openai", true, responseTime);
          break;
        }
      } catch (error) {
        console.error(
          `[AILearningService] Failed to initialize ${provider}:`,
          error
        );
        serviceMonitor.updateStatus(provider, false);

        if (provider === providers[providers.length - 1]) {
          throw new Error("Failed to initialize any AI provider");
        }
      }
    }

    if (!this.activeProvider) {
      throw new Error("No API keys available for any provider");
    }

    this.initialized = true;
    console.log("[AILearningService] Initialization completed successfully");
  }

  async generateQuestion(topic: string, difficulty: string): Promise<string> {
    if (!this.initialized) {
      await this.initialize();
    }

    const startTime = Date.now();
    const prompt = `Generate an NCLEX-style question about ${topic} at ${difficulty} difficulty level.`;

    try {
      let response: string;
      if (this.activeProvider === "anthropic" && this.anthropic) {
        const result = await this.anthropic.messages.create({
          model: "claude-3-opus-20240229",
          messages: [{ role: "user", content: prompt }],
          max_tokens: 1000
        });
        response = result.content[0].text;
      } else if (this.activeProvider === "openai" && this.openai) {
        const result = await this.openai.chat.completions.create({
          model: "gpt-4",
          messages: [{ role: "user", content: prompt }],
          max_tokens: 1000,
        });
        response = result.choices[0].message.content || "Failed to generate question";
      } else {
        throw new Error("No active AI provider available");
      }

      const responseTime = Date.now() - startTime;
      serviceMonitor.updateStatus(this.activeProvider, true, responseTime);
      return response;
    } catch (error) {
      console.error("[AILearningService] Error generating question:", error);
      serviceMonitor.updateStatus(this.activeProvider!, false);
      throw error;
    }
  }

  async createLearningPath(userId: number): Promise<LearningPath> {
    if (!this.initialized) {
      await this.initialize();
    }

    try {
      const recentProgress = await db.query.userProgress.findMany({
        where: eq(userProgress.userId, userId),
        orderBy: (fields, { desc }) => [desc(fields.timestamp)],
        limit: 10,
      });

      // For now, return a basic learning path
      return {
        id: 0,
        userId,
        status: "active",
        createdAt: new Date(),
        updatedAt: new Date(),
      };
    } catch (error) {
      console.error("[AILearningService] Error creating learning path:", error);
      throw error;
    }
  }
}

// Export singleton instance
export const aiLearningService = new AILearningService();