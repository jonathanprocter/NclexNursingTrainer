import { Router } from "express";
import { db } from "@db";
import { users, questions, userProgress } from "@db/schema";
import { eq, sql } from "drizzle-orm";
import type { Request, Response } from "express";

const router = Router();

interface ExamQuestion {
  id: number;
  domain: string;
  scenario: string;
  options: string[];
  difficulty: string;
  metadata: any;
  correct_answer?: string;
  explanation?: string;
}

interface ExamSession {
  id: number;
  questions: Omit<ExamQuestion, "correct_answer" | "explanation">[];
  currentQuestionIndex: number;
}

// Store active exam sessions in memory
const activeSessions = new Map<number, ExamSession>();

// Helper to ensure a test user exists
async function ensureTestUser() {
  let user = await db.query.users.findFirst({
    where: eq(users.id, 1),
  });

  if (!user) {
    // Create test user for development
    const [insertedUser] = await db
      .insert(users)
      .values({
        id: 1,
        email: "test@example.com",
        username: "testuser",
        password: "password123",
        createdAt: new Date(),
      })
      .returning();

    user = insertedUser;
  }

  return user;
}

// Start a new practice exam
router.post("/start", async (req: Request, res: Response) => {
  try {
    console.log("Starting new practice exam:", req.body);
    const { mode = "standard", duration = 180, domains = [] } = req.body;

    // For development, ensure test user exists
    const user = await ensureTestUser();
    if (!user) {
      return res.status(500).json({ error: "Failed to create/find test user" });
    }

    // Get questions for the exam
    const examQuestions = await db
      .select({
        id: questions.id,
        domain: questions.domain,
        scenario: questions.scenario,
        options: questions.options,
        difficulty: questions.difficulty,
        metadata: questions.metadata,
        correct_answer: questions.correct_answer,
        explanation: questions.explanation,
      })
      .from(questions)
      .where(domains.length > 0 ? sql`domain = ANY(${domains})` : sql`true`)
      .orderBy(sql`RANDOM()`)
      .limit(mode === "cat" ? 75 : 60);

    if (examQuestions.length === 0) {
      return res.status(500).json({ error: "No questions available" });
    }

    // Format questions for frontend
    const formattedQuestions: Omit<ExamQuestion, "correct_answer" | "explanation">[] =
      examQuestions.map((q) => ({
        id: q.id,
        scenario: q.scenario,
        options: q.options,
        domain: q.domain,
        difficulty: q.difficulty,
        metadata: q.metadata,
      }));

    // Create session ID
    const sessionId = Date.now();

    // Store exam session data
    activeSessions.set(sessionId, {
      id: sessionId,
      questions: formattedQuestions,
      currentQuestionIndex: 0,
    });

    // Return initial exam data
    res.json({
      id: sessionId,
      currentQuestion: formattedQuestions[0],
      totalQuestions: formattedQuestions.length,
      timeRemaining: duration * 60,
      mode,
    });
  } catch (error) {
    console.error("Error starting practice exam:", error);
    res.status(500).json({
      error: "Failed to start practice exam",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

// Submit answer endpoint
router.post("/submit", async (req: Request, res: Response) => {
  try {
    console.log("Received answer submission:", req.body);

    const { sessionId, selectedAnswer, timeSpent = 0 } = req.body;

    if (!sessionId) {
      return res.status(400).json({
        error: "Session ID is required",
      });
    }

    const parsedSessionId = parseInt(sessionId.toString(), 10);
    if (isNaN(parsedSessionId)) {
      return res.status(400).json({
        error: "Invalid session ID format",
      });
    }

    const examSession = activeSessions.get(parsedSessionId);
    if (!examSession) {
      return res.status(404).json({
        error: "Exam session not found",
      });
    }

    const currentItem = examSession.questions[examSession.currentQuestionIndex];

    // Get the full question details to check correct answer
    const question = await db.query.questions.findFirst({
      where: eq(questions.id, currentItem.id),
    });

    if (!question) {
      return res.status(404).json({
        error: "Question not found",
      });
    }

    const isCorrect = question.correct_answer === selectedAnswer;

    // Ensure test user exists before recording progress
    const user = await ensureTestUser();
    if (!user) {
      return res.status(500).json({ error: "Failed to find/create test user" });
    }

    // Record the user's progress
    await db.insert(userProgress).values({
      userId: user.id,
      questionId: currentItem.id,
      correct: isCorrect,
      responseTime: timeSpent,
      timestamp: new Date(),
      learningMetrics: {
        confidenceLevel: isCorrect ? 1 : 0,
        difficultyRating:
          question.difficulty === "hard"
            ? 3
            : question.difficulty === "medium"
            ? 2
            : 1,
        questionsAttempted: examSession.currentQuestionIndex + 1,
      },
    });

    // Move to next question
    examSession.currentQuestionIndex++;

    // Check if exam is completed
    const nextItem = examSession.questions[examSession.currentQuestionIndex];
    if (!nextItem) {
      activeSessions.delete(parsedSessionId);
      return res.json({
        completed: true,
        feedback: {
          isCorrect,
          explanation: question.explanation || "",
        },
      });
    }

    // Return next question and feedback
    res.json({
      completed: false,
      feedback: {
        isCorrect,
        explanation: question.explanation || "",
      },
      nextItem,
    });
  } catch (error) {
    console.error("Error submitting answer:", error);
    res.status(500).json({
      error: "Failed to submit answer",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

export default router;