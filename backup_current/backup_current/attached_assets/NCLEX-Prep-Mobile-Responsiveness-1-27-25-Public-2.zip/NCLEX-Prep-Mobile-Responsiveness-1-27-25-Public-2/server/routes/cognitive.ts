import { Router } from "express";
import { db } from "@db";
import { userProgress, progressTracking } from "@db/schema";
import { eq, desc } from "drizzle-orm";
import { z } from "zod";
import { analyticsService } from "../services/analytics.service";

const router = Router();

// Schema for response validation
const cognitiveResponseSchema = z.object({
  learningMetrics: z.object({
    confidenceLevel: z.number(),
    difficultyRating: z.number(),
    responseTime: z.number(),
    struggleAreas: z.array(z.string()),
    clinicalJudgmentScore: z.number(),
    predictedPerformance: z.number(),
    cognitiveLoadIndex: z.number(),
  }),
  analyticsState: z.object({
    currentLoad: z.number(),
    attentionLevel: z.number(),
    fatigueIndex: z.number(),
    learningRate: z.number(),
  }),
});

router.get("/", async (req, res) => {
  try {
    // TODO: Replace with actual auth user ID
    const userId = 1;

    const [learningMetrics, analyticsState] = await Promise.all([
      analyticsService.analyzeLearningPatterns(userId),
      analyticsService.getCurrentAnalyticsState(userId),
    ]);

    const response = cognitiveResponseSchema.parse({
      learningMetrics,
      analyticsState,
    });

    res.json(response);
  } catch (error) {
    console.error("Error getting cognitive metrics:", error);
    res.status(500).json({
      error: "Failed to get cognitive metrics",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

export default router;