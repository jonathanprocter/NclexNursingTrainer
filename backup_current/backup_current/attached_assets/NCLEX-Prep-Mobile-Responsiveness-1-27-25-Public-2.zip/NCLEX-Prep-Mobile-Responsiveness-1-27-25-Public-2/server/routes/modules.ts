import { Router } from "express";
import { getConceptExplanation } from "../anthropic";
import { z } from "zod";

const router = Router();

const requestSchema = z.object({
  topic: z.string().min(1, "Topic is required"),
  context: z.string().optional(),
});

interface ModuleData {
  success: boolean;
  data: {
    name: string;
    description: string;
    activities: ActivityData[];
  };
}

interface ActivityData {
  type: string;
  description: string;
  conceptualOverview: string;
  keyPoints: string[];
  commonQuestions: { question: string; answer: string }[];
  caseStudies: CaseStudyData[];
  quiz: QuizData[];
}

interface CaseStudyData {
  title: string;
  scenario: string;
  medications?: string[];
  considerations?: string[];
  steps?: string[];
}

interface QuizData {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface ProgressData {
  success: boolean;
  data: {
    overallProgress: number;
    accuracyRate: string;
    masteryLevel: string;
    competencyAreas: CompetencyAreaData[];
  };
}

interface CompetencyAreaData {
  area: string;
  level: number;
  status: string;
}

interface ExplanationResponse {
  success: boolean;
  data: {
    title: string;
    content: string;
    context: string;
    timestamp: string;
  };
}

// Get module content
router.get("/pharmacology", async (req, res) => {
  try {
    const moduleData: ModuleData = {
      success: true,
      data: {
        name: "Pharmacology & Parenteral Therapies",
        description:
          "Master medication administration, dosage calculations, and IV therapy with AI assistance",
        activities: [
          {
            type: "lesson",
            description: "Fundamentals of Pharmacology",
            conceptualOverview: "Pharmacology is the branch of science that deals with how drugs interact with the body. It's a complex, multifaceted field that draws on principles of chemistry, biology, physiology, and pathology to understand how medications can be used to prevent, diagnose, and treat disease.",
            keyPoints: [
              "Drug classifications and mechanisms of action",
              "Routes of administration and absorption",
              "Medication calculations and safety",
              "IV therapy and fluid management",
              "Monitoring therapeutic effects and adverse reactions",
            ],
            commonQuestions: [
              {
                question: "What are the key considerations when administering medications?",
                answer: "The 'Rights' of medication administration: right patient, right drug, right dose, right route, right time, right documentation, right reason, and right response.",
              },
              {
                question: "How do you calculate medication dosages?",
                answer: "Using dimensional analysis or ratio/proportion methods, always double-checking calculations and following facility protocols.",
              },
            ],
            caseStudies: [
              {
                title: "Medication Reconciliation",
                scenario: "Mr. Johnson, a 78-year-old man with hypertension, diabetes, and chronic back pain, presents with multiple medications.",
                medications: [
                  "Lisinopril 20 mg once daily",
                  "Metformin 1000 mg twice daily",
                  "Glyburide 5 mg once daily",
                ],
                considerations: [
                  "Medication interactions",
                  "Proper dosing schedule",
                  "Pain management strategy",
                ],
              },
            ],
            quiz: [
              {
                question: "A patient is prescribed 500mg of medication X to be given orally twice daily. The medication comes in 250mg tablets. How many tablets should be given per dose?",
                options: ["1 tablet", "2 tablets", "3 tablets", "4 tablets"],
                correctAnswer: 1,
                explanation: "Using dimensional analysis: 500mg ÷ 250mg/tablet = 2 tablets needed to achieve the prescribed dose.",
              },
            ],
          },
        ],
      },
    };

    res.json(moduleData);
  } catch (error) {
    console.error("Error fetching module content:", error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : "Failed to fetch module content",
    });
  }
});

// Get module progress
router.get("/pharmacology/progress", async (req, res) => {
  try {
    const progressData: ProgressData = {
      success: true,
      data: {
        overallProgress: 45,
        accuracyRate: "78%",
        masteryLevel: "Intermediate",
        competencyAreas: [
          {
            area: "Drug Classifications",
            level: 0.65,
            status: "in-progress",
          },
          {
            area: "Medication Calculations",
            level: 0.45,
            status: "in-progress",
          },
        ],
      },
    };

    res.json(progressData);
  } catch (error) {
    console.error("Error fetching progress:", error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : "Failed to fetch progress data",
    });
  }
});

// Generate AI explanation
router.post("/generate-explanation", async (req, res) => {
  try {
    const { topic, context } = requestSchema.parse(req.body);

    const content = await getConceptExplanation(topic, context || "Clinical Judgment");

    const response: ExplanationResponse = {
      success: true,
      data: {
        title: topic,
        content: content,
        context: context || "Clinical Judgment",
        timestamp: new Date().toISOString(),
      },
    };

    res.json(response);
  } catch (error) {
    console.error("Failed to generate explanation:", error);
    res.status(400).json({
      success: false,
      error: error instanceof Error ? error.message : "Failed to generate explanation",
    });
  }
});

export default router;