import { Router } from "express";
import { db } from "@db";
import { userProgress } from "@db/schema";
import { eq, and } from "drizzle-orm";
import { NCLEXAIService } from "../services/ai-service";
import { analyticsService } from "../services/analytics.service";
import crypto from "crypto";

console.log("Initializing quiz router");
const router = Router();
const aiService = new NCLEXAIService();

// Generate quiz questions with AI enhancement
router.get("/generate", async (req, res) => {
  try {
    if (!req.headers["content-type"]?.includes("application/json")) {
      return res.status(400).json({
        success: false,
        message: "Invalid content type",
      });
    }
    const adaptiveQuestions = await aiService.generateQuestions({
      difficulty: (req.query.difficulty as string) || "medium",
      count: Math.min(parseInt(req.query.count as string) || 5, 10),
      topics: ["fundamentals", "medical_surgical", "pharmacology"],
    });

    if (!adaptiveQuestions?.questions) {
      return res.status(400).json({
        success: false,
        message: "No questions generated. Please try again.",
        error: "NO_QUESTIONS",
      });
    }

    if (
      !Array.isArray(adaptiveQuestions.questions) ||
      adaptiveQuestions.questions.length === 0
    ) {
      return res.status(400).json({
        success: false,
        message: "Invalid question format received. Please try again.",
        error: "INVALID_FORMAT",
      });
    }

    const validatedQuestions = adaptiveQuestions.questions.map((q) => {
      if (!q.content || !Array.isArray(q.options) || q.options.length < 2) {
        throw new Error("Invalid question format");
      }

      return {
        id: q.id || crypto.randomUUID(),
        content: q.content,
        options: q.options,
        correctAnswer: q.correctAnswer,
        explanation: q.explanation || "",
        difficulty: q.difficulty || "medium",
        category: q.category || "general",
        domain: q.domain || "general_nursing",
      };
    });

    return res.json({
      success: true,
      questions: validatedQuestions,
      metrics: adaptiveQuestions.metrics || null,
      recommendations: adaptiveQuestions.recommendations || null,
    });
  } catch (error) {
    console.error("Error in quiz generation route:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to generate quiz. Please try again.",
      error: error instanceof Error ? error.message : "Unknown error occurred",
    });
  }
});

// Store quiz results
router.post("/results", async (req, res) => {
  try {
    console.log("Received quiz results:", req.body);
    const { courseId, score, performanceMetrics, questionsData } = req.body;

    if (!courseId || !score || !performanceMetrics || !questionsData) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields in request body",
      });
    }

    await db
      .update(userProgress)
      .set({
        correct: score > 0.7,
        responseTime: performanceMetrics.averageResponseTime || 0,
        learningMetrics: {
          difficultyRating: performanceMetrics.difficulty || 0.5,
          evaluationScore: score,
          analysisScore: performanceMetrics.analysisScore || 0,
          synthesisScore: performanceMetrics.synthesisScore || 0,
          applicationScore: performanceMetrics.applicationScore || 0,
          clinicalJudgmentScore: performanceMetrics.clinicalJudgmentScore || 0,
        },
      })
      .where(
        and(
          eq(userProgress.userId, 1), // TODO: Get from auth context
          eq(userProgress.questionId, courseId),
        ),
      );

    res.json({
      success: true,
      message: "Quiz results stored successfully",
    });
  } catch (error) {
    console.error("Error storing quiz results:", error);
    res.status(500).json({
      success: false,
      message: error instanceof Error ? error.message : "Failed to store quiz results",
    });
  }
});

console.log("Quiz routes registered");
export default router;