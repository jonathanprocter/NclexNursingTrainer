import { Router } from "express";
import { scenarioGeneratorService } from "../services/scenario-generator.service";
import { z } from "zod";

const router = Router();

const scenarioRequestSchema = z.object({
  difficulty: z.enum(["easy", "medium", "hard"]),
  domain: z.string(),
});

const scenarioResponseSchema = z.object({
  scenarioId: z.string(),
  response: z.string(),
  isCorrect: z.boolean(),
});

// Generate a new scenario
router.post("/generate", async (req, res) => {
  try {
    const { difficulty, domain } = scenarioRequestSchema.parse(req.body);
    const scenario = await scenarioGeneratorService.generateScenario(
      difficulty,
      domain,
    );
    res.json({ scenario });
  } catch (error) {
    console.error("Error generating scenario:", error);
    res.status(500).json({
      error: "Failed to generate scenario",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

// Submit scenario response
router.post("/submit", async (req, res) => {
  try {
    const { scenarioId, response, isCorrect } = scenarioResponseSchema.parse(req.body);
    const userId = 1; // TODO: Get from auth session

    await scenarioGeneratorService.recordResponse(
      userId,
      scenarioId,
      response,
      isCorrect,
    );

    res.json({ success: true });
  } catch (error) {
    console.error("Error submitting scenario response:", error);
    res.status(500).json({
      error: "Failed to submit response",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

export default router;