import { Router } from "express";
import { aiLearningService } from "../services/ai-learning.service";
import { z } from "zod";
import { requireAuth } from "../middleware/auth";

const router = Router();

// Validation schema for progress update
const progressSchema = z.object({
  userId: z.string().min(1, "User ID is required"),
  questionId: z.number(),
  correct: z.boolean(),
  timeSpent: z.number(),
  confidence: z.number().min(0).max(1),
});

// Route to fetch adaptive recommendations
router.get("/recommendations", requireAuth, async (req, res) => {
  try {
    // Get user ID from authenticated session
    const userId = (req.user as any).id;
    const recommendations = await aiLearningService.generateAdaptivePath(userId);

    res.json(recommendations);
  } catch (error) {
    console.error("Error getting recommendations:", error);
    res.status(500).json({
      error: "Failed to get recommendations",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

// Route to save progress
router.post("/progress", requireAuth, async (req, res) => {
  try {
    const data = progressSchema.parse(req.body);
    const userId = (req.user as any).id;

    // Save progress and get new adaptive recommendations
    const recommendations = await aiLearningService.generateAdaptivePath(userId);

    res.json({
      success: true,
      recommendations
    });
  } catch (error) {
    console.error("Error saving progress:", error);

    if (error instanceof z.ZodError) {
      return res.status(400).json({
        error: "Invalid request data", 
        details: error.errors,
      });
    }

    res.status(500).json({
      error: "Failed to save progress",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

export default router;
