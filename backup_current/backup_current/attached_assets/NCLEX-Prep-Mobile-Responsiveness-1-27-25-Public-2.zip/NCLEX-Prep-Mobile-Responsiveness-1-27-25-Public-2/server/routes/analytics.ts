import express from "express";
import { analyticsService } from "../services/analytics.service";
import type { Request, Response } from "express";

const router = express.Router();

interface AuthenticatedRequest extends Request {
  user?: { id: number; };
}

// Get study metrics
router.get("/metrics", async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.user?.id || 1;
    const metrics = await analyticsService.getStudyMetrics(userId);
    res.json(metrics);
  } catch (error) {
    console.error("Error getting study metrics:", error);
    res.status(500).json({
      error: "Failed to fetch study metrics",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

// Get domain performance with enhanced error handling
router.get("/domain-performance", async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.user?.id || 1;
    const performance = await analyticsService.getDomainPerformance(userId);
    res.json(performance);
  } catch (error) {
    console.error("Error getting domain performance:", error);
    res.status(500).json({
      error: "Failed to fetch domain performance metrics",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

// Get advanced analytics
router.get("/advanced", async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.user?.id || 1;
    const analytics = await analyticsService.getAdvancedAnalytics(userId);
    res.json(analytics);
  } catch (error) {
    console.error("Error getting advanced analytics:", error);
    res.status(500).json({
      error: "Failed to fetch advanced analytics",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

// Get knowledge gaps
router.get("/knowledge-gaps", async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.user?.id || 1;
    const gaps = await analyticsService.identifyKnowledgeGaps(userId);
    res.json(gaps);
  } catch (error) {
    console.error("Error identifying knowledge gaps:", error);
    res.status(500).json({
      error: "Failed to identify knowledge gaps",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

export default router;