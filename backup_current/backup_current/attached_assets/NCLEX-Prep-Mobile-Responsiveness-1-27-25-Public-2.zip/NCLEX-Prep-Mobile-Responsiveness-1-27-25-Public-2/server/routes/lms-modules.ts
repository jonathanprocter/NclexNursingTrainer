Here's the fixed and improved version of the code:

```typescript
import { Router } from "express";
import { analyticsService } from "../services/analytics-service";
import { getConceptExplanation } from "../anthropic";
import { moduleContentService } from "../services/module-content.service";
import { z } from "zod";

const router = Router();

// Schema definitions
const progressUpdateSchema = z.object({
  questionId: z.number(),
  answer: z.number(),
  correct: z.boolean(),
});

const generateQuestionsSchema = z.object({
  difficulty: z.enum([
    "recall",
    "application",
    "analysis",
    "evaluation",
    "synthesis",
  ]),
  count: z.number().optional().default(5),
});

const bookmarkSchema = z.object({
  moduleId: z.string(),
  contentId: z.string(),
  section: z.string(),
  note: z.string().optional(),
  tags: z.array(z.string()).optional(),
});

const exportSchema = z.object({
  format: z.enum(["pdf", "markdown", "html", "csv"]),
  includeNotes: z.boolean(),
  includeTags: z.boolean(),
});

// Module content routes
router.get("/:moduleId", async (req, res) => {
  try {
    const userId = req.session?.userId || 1;
    const { moduleId } = req.params;

    const moduleData = await moduleContentService.generateModuleContent(
      userId,
      moduleId,
      {
        contentType: moduleId.includes("calculation")
          ? "calculation"
          : "pathophysiology",
        domain: moduleId,
        difficulty: "adaptive",
      },
    );

    res.json({
      success: true,
      data: moduleData,
    });
  } catch (error) {
    console.error("Error fetching module:", error);
    res.status(500).json({
      success: false,
      error:
        error instanceof Error
          ? error.message
          : "Failed to load module content",
    });
  }
});

// AI Help endpoint
router.post("/:moduleId/ai-help", async (req, res) => {
  try {
    const userId = req.session?.userId || 1;
    const { moduleId } = req.params;
    const { section, query } = req.body;

    const help = await moduleContentService.getAIHelp(
      userId,
      moduleId,
      section,
      query,
    );

    res.json({
      success: true,
      data: help,
    });
  } catch (error) {
    console.error("Error getting AI help:", error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : "Failed to get AI help",
    });
  }
});

// Bookmark routes
router.post("/bookmarks", async (req, res) => {
  try {
    const userId = req.session?.userId || 1;
    const result = bookmarkSchema.safeParse(req.body);

    if (!result.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid bookmark data",
        details: result.error.issues,
      });
    }

    const { moduleId, contentId, section, note, tags } = result.data;
    const bookmark = await moduleContentService.saveBookmark(
      userId,
      moduleId,
      contentId,
      section,
      note,
      tags,
    );

    res.json({
      success: true,
      data: bookmark,
    });
  } catch (error) {
    console.error("Error saving bookmark:", error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : "Failed to save bookmark",
    });
  }
});

router.post("/bookmarks/export", async (req, res) => {
  try {
    const userId = req.session?.userId || 1;
    const result = exportSchema.safeParse(req.body);

    if (!result.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid export options",
        details: result.error.issues,
      });
    }

    const exportContent = await moduleContentService.exportBookmarks(
      userId,
      result.data,
    );

    res.json({
      success: true,
      data: exportContent,
    });
  } catch (error) {
    console.error("Error exporting bookmarks:", error);
    res.status(500).json({
      success: false,
      error:
        error instanceof Error ? error.message : "Failed to export bookmarks",
    });
  }
});

// Get module details with AI-enhanced content
router.get("/pharmacology", async (req, res) => {
  try {
    const userId = req.session?.userId || 1;
    const moduleData = {
      name: "Pharmacological and Parenteral Therapies",
      activities: [
        {
          type: "foundations",
          description: "Learn foundational pharmacology concepts",
          objectives: ["Drug classifications", "Common medications"],
          conceptualOverview:
            "Pharmacology is the study of drug action in biological systems. This module covers key concepts in pharmacodynamics, pharmacokinetics, and safe medication administration.",
          keyPoints: [
            "Understanding drug classifications and mechanisms",
            "Pharmacokinetics: Absorption, Distribution, Metabolism, Excretion",
            "Safe medication administration practices",
            "Common drug interactions and contraindications",
            "Dosage calculation principles",
          ],
          commonQuestions: [
            {
              question: "What are the key components of pharmacokinetics?",
              answer:
                "Pharmacokinetics includes: Absorption (how drugs enter the body), Distribution (how drugs spread through the body), Metabolism (how drugs are broken down), and Excretion (how drugs leave the body).",
            },
            {
              question: "Why is drug classification important?",
              answer:
                "Drug classification helps organize medications by their chemical structure, mechanism of action, or therapeutic use, making it easier to understand their effects and potential interactions.",
            },
          ],
          quiz: [
            {
              question:
                "Which of the following best describes the process of drug metabolism?",
              options: [
                "How drugs are absorbed into the bloodstream",
                "How drugs are broken down in the body",
                "How drugs are distributed to tissues",
                "How drugs are eliminated from the body",
              ],
              correctAnswer: 1,
              explanation:
                "Drug metabolism refers to the process by which drugs are chemically altered (broken down) in the body, primarily by the liver.",
            },
          ],
          adaptiveOptions: {
            difficultyLevels: ["beginner", "intermediate", "advanced"],
            contentTypes: ["text", "case_studies", "simulations"],
            aiAssistance: true,
          },
        },
      ],
      aiFeatures: {
        adaptiveLearning: true,
        personalizedFeedback: true,
        contentGeneration: true,
        performanceAnalytics: true,
      },
    };

    res.json({
      success: true,
      data: moduleData,
    });
  } catch (error) {
    console.error("Error fetching module:", error);
    res.status(500).json({
      success: false,
      error:
        error instanceof Error
          ? error.message
          : "Failed to load module content",
    });
  }
});

// Get module progress and competency tracking
router.get("/pharmacology/progress", async (req, res) => {
  try {
    const userId = req.session?.userId || 1;
    const metrics = await analyticsService.getLearningMetrics(userId);

    res.json({
      success: true,
      data: {
        overallProgress: Math.round(metrics.performanceLevel * 100),
        accuracyRate: `${Math.round(metrics.accuracyRate || 0)}%`,
        masteryLevel: "2/4",
        competencyAreas: [
          {
            area: "Drug Classifications",
            level: 0.75,
            status: "in-progress",
          },
          {
            area: "Medication Safety",
            level: 0.6,
            status: "in-progress",
          },
          {
            area: "Dosage Calculations",
            level: 0.85,
            status: "mastered",
          },
        ],
      },
    });
  } catch (error) {
    console.error("Error fetching progress:", error);
    res.status(500).json({
      success: false,
      error:
        error instanceof Error ? error.message : "Failed to load progress data",
    });
  }
});

// Generate more practice questions
router.post("/pharmacology/generate-questions", async (req, res) => {
  try {
    const result = generateQuestionsSchema.safeParse(req.body);

    if (!result.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid input data",
        details: result.error.issues,
      });
    }

    const { difficulty, count } = result.data;

    // Static questions based on difficulty level
    const questions = [
      {
        question:
          "Which phase of drug metabolism typically produces more water-soluble compounds?",
        options: [
          "Phase 0 (Absorption)",
          "Phase 1 (Functionalization)",
          "Phase 2 (Conjugation)",
          "Phase 3 (Excretion)",
        ],
        correctAnswer: 2,
        explanation:
          "Phase 2 metabolism, or conjugation, typically produces more water-soluble compounds by adding polar groups to drug molecules, making them easier to excrete.",
      },
      {
        question:
          "What is the primary site of drug metabolism in the human body?",
        options: ["Kidneys", "Liver", "Small intestine", "Lungs"],
        correctAnswer: 1,
        explanation:
          "The liver is the primary site of drug metabolism in the human body, containing numerous enzymes that transform drugs into more easily excretable compounds.",
      },
      {
        question: "Which of the following factors can affect drug metabolism?",
        options: [
          "Age",
          "Genetic variations",
          "Liver function",
          "All of the above",
        ],
        correctAnswer: 3,
        explanation:
          "Drug metabolism can be affected by multiple factors including age, genetic variations in metabolizing enzymes, and liver function status.",
      },
    ];

    res.json({
      success: true,
      data: {
        questions: questions.slice(0, count),
      },
    });
  } catch (error) {
    console.error("Error generating questions:", error);
    res.status(500).json({
      success: false,
      error:
        error instanceof Error ? error.message : "Failed to generate questions",
    });
  }
});

// AI explanation route
router.post("/pharmacology/explain", async (req, res) => {
  try {
    const { topic } = req.body;

    if (!topic) {
      return res.status(400).json({
        success: false,
        error: "Topic is required",
      });
    }

    const result = await getConceptExplanation(
      topic,
      "Pharmacology and Parenteral Therapies",
    );

    if (!result.success || !result.data) {
      console.error("Failed to generate explanation:", result.error);
      return res.status(500).json({
        success: false,
        error: result.error || "Failed to generate explanation",
      });
    }

    res.json({
      success: true,
      explanation: result.data,
    });
  } catch (error) {
    console.error("Error in explanation route:", error);
    return res.status(500).json({
      success: false,
      error:
        error instanceof Error
          ? error.message
          : "Failed to process explanation request",
    });
  }
});

export default router;
```

Here's a summary of the changes and improvements made:

1. Removed duplicate schema definitions `progressUpdateSchema2` and `generateQuestionsSchema2`.
2. Removed unnecessary console logs.
3. Improved error handling by checking for `result.success` and `result.data` before proceeding with the explanation route.
4. Simplified the code by removing unnecessary variable assignments and checks.
5. Used consistent naming conventions for variables and functions.
6. Ensured proper indentation and formatting for better readability.
7. Utilized the existing `generateQuestionsSchema` in the `/pharmacology/generate-questions` route.

These changes should improve the code structure, error handling, and overall readability of the code. The code now follows best practices and is more maintainable.