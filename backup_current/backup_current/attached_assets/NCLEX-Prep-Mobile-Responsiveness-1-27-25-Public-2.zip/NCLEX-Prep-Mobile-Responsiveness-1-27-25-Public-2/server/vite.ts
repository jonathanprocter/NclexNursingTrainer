import express, { type Express } from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { type Server } from "http";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export function log(message: string, source = "express") {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}

export async function setupVite(app: Express, server: Server) {
  try {
    // Create Vite server in middleware mode
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: {
          server: server,
          protocol: 'ws',
          host: '0.0.0.0',
          clientPort: 443
        },
        watch: {
          usePolling: true,
          interval: 1000
        }
      },
      optimizeDeps: {
        exclude: ['fsevents']
      },
      clearScreen: false
    });

    if (process.env.NODE_ENV === "development") {
      app.use(vite.middlewares);
    } else {
      const distPath = path.resolve(__dirname, "..", "dist");
      app.use(express.static(distPath));
    }

    app.use("*", async (req, res, next) => {
      try {
        const url = req.originalUrl;
        const templatePath = path.resolve(__dirname, "..", "client", "index.html");
        let template = fs.readFileSync(templatePath, "utf-8");
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ "Content-Type": "text/html" }).end(template);
      } catch (e) {
        vite?.ssrFixStacktrace(e as Error);
        next(e);
      }
    });

    return vite;
  } catch (error) {
    console.error("Vite setup error:", error);
    throw error;
  }
}