import { Request, Response, NextFunction } from "express";
import { log } from "../services/logging";

export class AppError extends Error {
  constructor(
    public statusCode: number,
    public message: string,
    public isOperational = true,
  ) {
    super(message);
    Object.setPrototypeOf(this, AppError.prototype);
  }
}

export function errorHandler(
  err: Error | AppError,
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  log.error("Error:", { error: err.message, stack: err.stack });

  // Ensure response hasn't been sent
  if (res.headersSent) {
    log.error("Headers already sent:", err);
    return next(err);
  }

  let statusCode = 500;
  let message = "Internal server error";
  let details: string | undefined;

  if (err instanceof AppError) {
    statusCode = err.statusCode;
    message = err.message;
  } else if (
    err.message?.includes("database") ||
    err.message?.includes("connection")
  ) {
    statusCode = 503;
    message = "Database service unavailable";
  } else if (err.message?.includes("validation")) {
    statusCode = 400;
    message = "Validation failed";
    details = err.message;
  }

  if (process.env.NODE_ENV !== "production") {
    details = err.stack;
  }

  // Log error for monitoring
  log.error(`[${new Date().toISOString()}] Error:`, {
    statusCode,
    message: err.message,
    stack: err.stack,
    path: req.path,
  });

  res.status(statusCode).json({
    status: "error",
    message: message,
    code: statusCode,
    path: req.path,
    timestamp: new Date().toISOString(),
    details: details,
  });
}
