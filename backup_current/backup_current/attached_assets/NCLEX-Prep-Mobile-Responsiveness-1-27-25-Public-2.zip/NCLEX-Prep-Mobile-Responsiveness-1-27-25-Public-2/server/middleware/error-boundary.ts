import { Request, Response, NextFunction } from "express";

interface ErrorDetails {
  error: string;
  stack?: string;
  path: string;
  method: string;
  timestamp: string;
}

export const errorBoundary = (
  err: Error,
  req: Request,
  res: Response,
  next: NextFunction,
): void => {
  const errorDetails: ErrorDetails = {
    error: err.message,
    stack: err.stack,
    path: req.path,
    method: req.method,
    timestamp: new Date().toISOString(),
  };

  console.error("Uncaught error:", errorDetails);

  res.status(500).json({
    error: "An unexpected error occurred",
    requestId: req.id,
  });
};