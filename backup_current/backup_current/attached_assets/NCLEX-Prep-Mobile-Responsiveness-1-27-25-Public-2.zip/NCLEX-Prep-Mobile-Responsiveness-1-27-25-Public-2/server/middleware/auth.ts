import { Request, Response, NextFunction } from "express";
import type { SessionData } from "express-session";

// For development purposes, we'll use a test user ID and instructor password
const TEST_USER_ID = 1;
const INSTRUCTOR_PASSWORD = "5786";

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  // For development, always attach the test user ID and username
  req.user = {
    id: TEST_USER_ID,
    username: "test_user",
  };
  req.session.userId = TEST_USER_ID;
  next();
}

// Extend the session type to include isInstructor
declare module "express-session" {
  interface SessionData {
    isInstructor?: boolean;
    userId?: number;
  }
}

export function requireInstructor(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  const isInstructor = req.session?.isInstructor || false;
  if (!isInstructor) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

export function validateInstructorPassword(password: string): boolean {
  return password === INSTRUCTOR_PASSWORD;
}

// Add types to Express Request
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: number;
        username: string;
      };
    }
  }
}