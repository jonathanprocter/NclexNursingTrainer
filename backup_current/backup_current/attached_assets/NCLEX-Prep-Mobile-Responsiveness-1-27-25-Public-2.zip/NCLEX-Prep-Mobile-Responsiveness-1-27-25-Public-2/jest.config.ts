import type { Config } from "jest";

const config: Config = {
  preset: "ts-jest", // Use ts-jest for TypeScript support
  testEnvironment: "node", // Set the test environment
  rootDir: ".", // Root directory for Jest
  testMatch: ["**/tests/**/*.test.ts"], // Match test files
  collectCoverage: true, // Enable coverage collection
  collectCoverageFrom: [
    "src/**/*.ts", // Include all TypeScript files in the src directory
    "!src/**/*.d.ts", // Exclude TypeScript declaration files
  ],
  coverageDirectory: "coverage", // Directory for coverage reports
  moduleNameMapper: {
    "^@db/(.*)$": "<rootDir>/db/$1", // Map @db imports
    "^@src/(.*)$": "<rootDir>/src/$1", // Map @src imports
  },
};

export default config;
