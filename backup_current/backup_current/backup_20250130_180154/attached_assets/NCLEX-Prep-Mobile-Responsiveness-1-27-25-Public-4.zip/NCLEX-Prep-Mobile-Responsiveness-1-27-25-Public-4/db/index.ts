import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "@db/schema";

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

const poolConfig: pg.PoolConfig = {
  connectionString: process.env.DATABASE_URL,
  max: process.env.DATABASE_MAX_CONNECTIONS
    ? parseInt(process.env.DATABASE_MAX_CONNECTIONS, 10)
    : 20,
  idleTimeoutMillis: process.env.DATABASE_IDLE_TIMEOUT
    ? parseInt(process.env.DATABASE_IDLE_TIMEOUT, 10)
    : 30000,
  connectionTimeoutMillis: process.env.DATABASE_CONNECTION_TIMEOUT
    ? parseInt(process.env.DATABASE_CONNECTION_TIMEOUT, 10)
    : 5000,
  ssl:
    process.env.NODE_ENV === "production"
      ? { rejectUnauthorized: false }
      : false,
  keepAlive: true,
  application_name: "nclex_prep_app",
};

const pool = new pg.Pool(poolConfig);

pool.on("error", (err: Error) => {
  console.error("Unexpected error on idle client:", err);
  process.exit(1);
});

pool.on("connect", (client: pg.PoolClient) => {
  console.log("New client connected to the pool");
});

export async function verifyConnection(retries = 3): Promise<boolean> {
  for (let i = 0; i < retries; i++) {
    try {
      const client = await pool.connect();
      await client.query("SELECT 1");
      client.release();
      console.log("Database connection verified successfully");
      return true;
    } catch (error) {
      console.error(
        `Database connection attempt ${i + 1}/${retries} failed:`,
        error,
      );
      if (i === retries - 1) return false;
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
  }
  return false;
}

export const db = drizzle(pool, { schema });

export { sql } from "drizzle-orm";

let isShuttingDown = false;

async function cleanup(signal?: string): Promise<void> {
  if (isShuttingDown) return;
  isShuttingDown = true;

  console.log(`${signal ? `Received ${signal}. ` : ""}Cleaning up...`);

  try {
    const cleanup = new Promise<void>((resolve) => {
      pool.end(() => {
        console.log("Database pool closed successfully");
        resolve();
      });
    });

    const timeout = new Promise<void>((_, reject) => {
      setTimeout(() => {
        reject(new Error("Cleanup timed out"));
      }, 5000);
    });

    await Promise.race([cleanup, timeout]);
  } catch (error) {
    console.error("Error during cleanup:", error);
  }

  process.exit(0);
}

process.once("SIGINT", () => cleanup("SIGINT"));
process.once("SIGTERM", () => cleanup("SIGTERM"));
process.once("SIGUSR2", () => cleanup("SIGUSR2"));

export { schema };
export default db;