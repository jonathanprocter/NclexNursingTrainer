import { drizzle } from "drizzle-orm/neon-serverless";
import { migrate } from "drizzle-orm/neon-serverless/migrator";
import { Pool, neonConfig } from "@neondatabase/serverless";
import { sql } from "drizzle-orm";
import * as schema from "./schema";
import ws from "ws";

neonConfig.webSocketConstructor = ws;

async function runMigration() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL environment variable is required");
  }

  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const db = drizzle(pool, { schema });

  console.log("Starting migration...");

  try {
    // First safely handle the enum type
    await pool.query(`
      DO $$ 
      BEGIN
        IF EXISTS (
          SELECT 1 FROM pg_type 
          WHERE typname = 'clinical_judgment_level'
        ) THEN
          -- Drop any existing columns using this type first
          ALTER TABLE IF EXISTS flashcards 
            DROP COLUMN IF EXISTS clinical_judgment_level;
          
          -- Then drop the type
          DROP TYPE clinical_judgment_level;
        END IF;

        -- Create the enum type fresh
        CREATE TYPE clinical_judgment_level AS ENUM ('1', '2', '3', '4');
      END $$;
    `);

    // Run the drizzle migrations
    await migrate(db, { migrationsFolder: "./drizzle" });
    console.log("Migration completed successfully");
  } catch (error) {
    console.error("Migration failed:", error);
    throw error;
  } finally {
    await pool.end();
  }
}

runMigration().catch((err) => {
  console.error("Migration script failed:", err);
  process.exit(1);
});
