import {
  pgTable,
  text,
  serial,
  timestamp,
  integer,
  jsonb,
  boolean,
  pgEnum,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";

// Enums
export const difficultyEnum = pgEnum("difficulty", ["easy", "medium", "hard"]);
export const categoryEnum = pgEnum("category", [
  "fundamentals",
  "medical_surgical",
  "pediatric",
  "mental_health",
  "maternal",
  "leadership",
]);

// Table Definitions
const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").unique().notNull(),
  username: text("username").unique().notNull(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  learningStyle: jsonb("learning_style").$type<{
    visual: number;
    auditory: number;
    kinesthetic: number;
    reading: number;
  }>(),
});

const nclexDomains = pgTable("nclex_domains", {
  id: serial("id").primaryKey(),
  name: text("name").unique().notNull(),
  description: text("description"),
  category: categoryEnum("category").notNull(),
  subTopics: text("sub_topics").array(),
  weightage: integer("weightage"),
  performanceScore: integer("performance_score").default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  domainId: integer("domain_id").references(() => nclexDomains.id),
  scenario: text("scenario").notNull(),
  options: text("options").array().notNull(),
  correctAnswer: text("correct_answer").notNull(),
  explanation: text("explanation").notNull(),
  difficulty: difficultyEnum("difficulty").notNull(),
  topic: text("topic").notNull(),
  category: categoryEnum("category").notNull(),
  aiGenerated: boolean("ai_generated").default(false),
  metadata: jsonb("metadata").$type<{
    conceptualLevel: "recall" | "application" | "analysis";
    clinicalJudgmentLevel: "1" | "2" | "3";
    cognitiveComplexity: number;
  }>(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id),
  questionId: integer("question_id")
    .notNull()
    .references(() => questions.id),
  correct: boolean("correct").notNull(),
  responseTime: integer("response_time").notNull(),
  timestamp: timestamp("timestamp", { withTimezone: true }).defaultNow(),
  learningMetrics: jsonb("learning_metrics").$type<{
    confidenceLevel: number;
    cognitiveLoadIndex: number;
    timeSpent: number;
  }>(),
});

const bookmarkFolders = pgTable("bookmark_folders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id),
  name: text("name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

const bookmarks = pgTable("bookmarks", {
  id: serial("id").primaryKey(),
  folderId: integer("folder_id")
    .notNull()
    .references(() => bookmarkFolders.id),
  questionId: integer("question_id")
    .notNull()
    .references(() => questions.id),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

// Relations
const usersRelations = relations(users, ({ many }) => ({
  progress: many(userProgress),
  bookmarkFolders: many(bookmarkFolders),
}));

const bookmarkFoldersRelations = relations(bookmarkFolders, ({ one, many }) => ({
  user: one(users, {
    fields: [bookmarkFolders.userId],
    references: [users.id],
  }),
  bookmarks: many(bookmarks),
}));

const bookmarksRelations = relations(bookmarks, ({ one }) => ({
  folder: one(bookmarkFolders, {
    fields: [bookmarks.folderId],
    references: [bookmarkFolders.id],
  }),
  question: one(questions, {
    fields: [bookmarks.questionId],
    references: [questions.id],
  }),
  user: one(users, {
    fields: [bookmarks.userId],
    references: [users.id],
  }),
}));

const questionsRelations = relations(questions, ({ one, many }) => ({
  domain: one(nclexDomains, {
    fields: [questions.domainId],
    references: [nclexDomains.id],
  }),
  bookmarks: many(bookmarks),
}));

const userProgressRelations = relations(userProgress, ({ one }) => ({
  user: one(users, {
    fields: [userProgress.userId],
    references: [users.id],
  }),
  question: one(questions, {
    fields: [userProgress.questionId],
    references: [questions.id],
  }),
}));

// Types
export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type Question = typeof questions.$inferSelect;
export type NewQuestion = typeof questions.$inferInsert;
export type UserProgress = typeof userProgress.$inferSelect;
export type NewUserProgress = typeof userProgress.$inferInsert;
export type NclexDomain = typeof nclexDomains.$inferSelect;
export type NewNclexDomain = typeof nclexDomains.$inferInsert;
export type BookmarkFolder = typeof bookmarkFolders.$inferSelect;
export type NewBookmarkFolder = typeof bookmarkFolders.$inferInsert;
export type Bookmark = typeof bookmarks.$inferSelect;
export type NewBookmark = typeof bookmarks.$inferInsert;

// Zod schemas
export const insertUserSchema = createInsertSchema(users);
export const selectUserSchema = createSelectSchema(users);
export const insertQuestionSchema = createInsertSchema(questions);
export const selectQuestionSchema = createSelectSchema(questions);
export const insertProgressSchema = createInsertSchema(userProgress);
export const selectProgressSchema = createSelectSchema(userProgress);
export const insertDomainSchema = createInsertSchema(nclexDomains);
export const selectDomainSchema = createSelectSchema(nclexDomains);
export const insertBookmarkFolderSchema = createInsertSchema(bookmarkFolders);
export const selectBookmarkFolderSchema = createSelectSchema(bookmarkFolders);
export const insertBookmarkSchema = createInsertSchema(bookmarks);
export const selectBookmarkSchema = createSelectSchema(bookmarks);

// Export tables and relations
export {
  users,
  questions,
  userProgress,
  nclexDomains,
  bookmarkFolders,
  bookmarks,
  usersRelations,
  questionsRelations,
  userProgressRelations,
  bookmarkFoldersRelations,
  bookmarksRelations,
};