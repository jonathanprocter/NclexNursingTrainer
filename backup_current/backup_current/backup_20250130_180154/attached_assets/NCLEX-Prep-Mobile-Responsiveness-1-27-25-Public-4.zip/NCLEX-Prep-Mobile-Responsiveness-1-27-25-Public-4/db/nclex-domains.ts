import { type categoryEnum } from "@db/schema";

type DomainInfo = {
  category: (typeof categoryEnum.enumValues)[number];
  subTopics: string[];
  weightage: number;
  clinicalJudgmentLevels: ("1" | "2" | "3")[];
};

export const NGN_DOMAINS: Record<string, DomainInfo> = {
  "Safe and Effective Care Environment": {
    category: "fundamentals",
    subTopics: [
      "Management of Care",
      "Safety and Infection Control",
      "Quality Improvement",
      "Ethics and Legal Rights",
      "Leadership and Delegation",
    ],
    weightage: 26,
    clinicalJudgmentLevels: ["2", "3"],
  },
  "Health Promotion and Maintenance": {
    category: "medical_surgical",
    subTopics: [
      "Growth and Development",
      "Prevention and Early Detection",
      "Self-Care",
      "Lifestyle Choices",
      "Health Screening",
    ],
    weightage: 23,
    clinicalJudgmentLevels: ["2", "3"],
  },
  "Psychosocial Integrity": {
    category: "mental_health",
    subTopics: [
      "Mental Health Concepts",
      "Coping Mechanisms",
      "Crisis Intervention",
      "Therapeutic Communication",
      "Cultural Awareness",
    ],
    weightage: 15,
    clinicalJudgmentLevels: ["1", "2"],
  },
  "Physiological Integrity": {
    category: "medical_surgical",
    subTopics: [
      "Basic Care and Comfort",
      "Pharmacological and Parenteral Therapies",
      "Reduction of Risk Potential",
      "Physiological Adaptation",
      "Complex Care Management",
    ],
    weightage: 36,
    clinicalJudgmentLevels: ["2", "3"],
  },
};
