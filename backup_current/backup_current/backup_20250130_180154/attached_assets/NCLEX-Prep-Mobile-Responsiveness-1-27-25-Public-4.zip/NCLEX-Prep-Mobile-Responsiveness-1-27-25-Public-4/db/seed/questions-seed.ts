import { db } from "@db";
import { questions, nclexDomains } from "@db/schema";
import { eq } from "drizzle-orm";
import path from "path";
import fs from "fs/promises";

async function loadSeedData() {
  const seedDataPath = path.join(
    process.cwd(),
    "attached_assets",
    "nclex-seed-data.json",
  );
  const data = JSON.parse(await fs.readFile(seedDataPath, "utf-8"));
  const rawQuestions = data["questions_seed.json"].questions;

  // Process and normalize categories
  return rawQuestions.map((q) => ({
    ...q,
    category: normalizeCategory(q.category),
    difficulty: normalizeDifficulty(q.difficulty),
  }));
}

function normalizeCategory(category: string): string {
  // Map all subcategories to their main NCLEX domains
  const categoryMap = {
    // Safe and Effective Care Environment subcategories
    "Management of Care": "Safe and Effective Care Environment",
    "Safety and Infection Control": "Safe and Effective Care Environment",
    "Patient Safety": "Safe and Effective Care Environment",
    "Infection Control": "Safe and Effective Care Environment",
    "Risk Management": "Safe and Effective Care Environment",
    "Legal Rights": "Safe and Effective Care Environment",
    "Ethical Practice": "Safe and Effective Care Environment",

    // Health Promotion and Maintenance subcategories
    "Health Promotion": "Health Promotion and Maintenance",
    "Disease Prevention": "Health Promotion and Maintenance",
    "Growth and Development": "Health Promotion and Maintenance",
    "Health Screening": "Health Promotion and Maintenance",
    "Lifestyle Choices": "Health Promotion and Maintenance",

    // Psychosocial Integrity subcategories
    "Mental Health": "Psychosocial Integrity",
    "Psychosocial Integrity": "Psychosocial Integrity",
    "Coping Mechanisms": "Psychosocial Integrity",
    "Crisis Intervention": "Psychosocial Integrity",
    "Cultural Awareness": "Psychosocial Integrity",

    // Physiological Integrity subcategories
    "Basic Care & Comfort": "Physiological Integrity",
    "Pharmacological Therapies": "Physiological Integrity",
    "Clinical Assessment": "Physiological Integrity",
    "Medical-Surgical Nursing": "Physiological Integrity",
    "Physiological Adaptation": "Physiological Integrity",
    Pharmacology: "Physiological Integrity",
    "Complex Care": "Physiological Integrity",
  };
  return categoryMap[category] || category;
}

function normalizeDifficulty(difficulty: number | string): string {
  if (typeof difficulty === "number") {
    if (difficulty <= 0.4) return "easy";
    if (difficulty <= 0.7) return "medium";
    return "hard";
  }
  return difficulty.toLowerCase();
}

export async function seedNCLEXQuestions() {
  try {
    console.log("Starting to seed NCLEX questions...");

    // Get domain IDs
    const domains = await db.select().from(nclexDomains);
    const domainMap = new Map(domains.map((d) => [d.name, d.id]));

    // Load and normalize questions
    const seedQuestions = await loadSeedData();

    // Target distribution based on NCLEX blueprint
    const targetDistribution = {
      "Safe and Effective Care Environment": { weight: 0.3, questions: 23 },
      "Health Promotion and Maintenance": { weight: 0.17, questions: 13 },
      "Psychosocial Integrity": { weight: 0.15, questions: 11 },
      "Physiological Integrity": { weight: 0.38, questions: 28 },
    };

    // Process questions by domain
    for (const [domain, distribution] of Object.entries(targetDistribution)) {
      const domainQuestions = seedQuestions.filter(
        (q) => q.category === domain,
      );
      const domainId = domainMap.get(domain);

      if (!domainId) {
        console.warn(`Domain not found: ${domain}`);
        continue;
      }

      // Calculate target number of questions per difficulty
      const targetEasy = Math.floor(distribution.questions * 0.3);
      const targetMedium = Math.floor(distribution.questions * 0.4);
      const targetHard = distribution.questions - targetEasy - targetMedium;

      console.log(`Target question counts for ${domain}:`, {
        easy: targetEasy,
        medium: targetMedium,
        hard: targetHard,
        total: distribution.questions,
      });

      let processedCount = {
        easy: 0,
        medium: 0,
        hard: 0,
      };

      // Process existing questions first
      for (const question of domainQuestions) {
        if (
          processedCount.easy >= targetEasy &&
          processedCount.medium >= targetMedium &&
          processedCount.hard >= targetHard
        ) {
          break;
        }

        const difficulty = question.difficulty || "medium";
        if (
          processedCount[difficulty] >=
          (difficulty === "easy"
            ? targetEasy
            : difficulty === "medium"
              ? targetMedium
              : targetHard)
        ) {
          continue;
        }

        const questionData = {
          domainId,
          scenario: question.question_text,
          options: question.options || [],
          correctAnswer: Array.isArray(question.correct_answers)
            ? question.options[question.correct_answers[0]]
            : question.correct_answer,
          explanation: question.rationale?.correct || "",
          difficulty,
          conceptualLevel:
            question.cognitive_level?.toLowerCase() || "application",
          clinicalJudgmentLevel: question.clinical_judgment ? "3" : "2",
          aiGenerated: false,
          successRate: null,
          attemptCount: 0,
          conceptualBreakdown: {
            mainConcept: question.rationale?.key_points?.[0] || "",
            relatedConcepts: question.rationale?.key_points || [],
            applicationContext: question.category,
          },
          contentData: {
            references: question.references || [],
            clinicalScenario: question.clinical_scenario || null,
            rationale: question.rationale || {},
          },
        };

        // Update or insert question
        const existingQuestion = await db
          .select()
          .from(questions)
          .where(eq(questions.scenario, question.question_text))
          .limit(1);

        if (existingQuestion.length > 0) {
          await db
            .update(questions)
            .set(questionData)
            .where(eq(questions.scenario, question.question_text));
        } else {
          await db.insert(questions).values(questionData);
        }

        processedCount[difficulty]++;
      }

      console.log(`Processed ${domain}: ${JSON.stringify(processedCount)}`);
    }

    console.log("NCLEX questions seeded successfully");
    return { success: true };
  } catch (error) {
    console.error("Error seeding NCLEX questions:", error);
    throw error;
  }
}
