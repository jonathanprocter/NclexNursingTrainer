import { type Question } from "@db/schema";
import { NGN_DOMAINS } from "../nclex-domains";

// Helper function to ensure proper typing
const createQuestion = (
  domainId: number,
  question: Partial<Question>,
): Omit<Question, "id" | "createdAt" | "updatedAt"> => ({
  domainId,
  scenario: "",
  options: [],
  correctAnswer: "",
  explanation: "",
  difficulty: "medium",
  conceptualLevel: "application",
  clinicalJudgmentLevel: "2",
  aiGenerated: false,
  conceptualBreakdown: {
    mainConcept: "",
    relatedConcepts: [],
    applicationContext: "",
  },
  contentData: {
    references: [],
    tags: [],
    resources: [],
  },
  ...question,
});

// Generate questions for each domain with proper distribution
const generateDomainQuestions = () => {
  const questions: Omit<Question, "id" | "createdAt" | "updatedAt">[] = [];

  // Medical-Surgical Nursing (domainId: 1)
  const medSurgQuestions = [
    // Easy questions
    createQuestion(1, {
      scenario:
        "A client's blood glucose reading is 45 mg/dL and they are conscious. Which intervention should the nurse implement first?",
      options: [
        "Administer 15g of fast-acting carbohydrates",
        "Call the healthcare provider",
        "Administer glucagon injection",
        "Check ketone levels",
      ],
      correctAnswer: "Administer 15g of fast-acting carbohydrates",
      explanation:
        "For a conscious client with hypoglycemia, the first intervention is to administer 15g of fast-acting carbohydrates to quickly raise blood glucose levels.",
      difficulty: "easy",
      conceptualLevel: "application",
      clinicalJudgmentLevel: "1",
      conceptualBreakdown: {
        mainConcept: "Hypoglycemia Management",
        relatedConcepts: [
          "Diabetes",
          "Blood Glucose Regulation",
          "Emergency Response",
        ],
        applicationContext: "Medical-Surgical",
      },
    }),
    // Medium questions
    createQuestion(1, {
      scenario:
        "A client with chronic heart failure reports increasing dyspnea. Which assessment finding requires immediate intervention?",
      options: [
        "Oxygen saturation of 88%",
        "Heart rate of 82 bpm",
        "Blood pressure of 132/78 mmHg",
        "Temperature of 37.2°C",
      ],
      correctAnswer: "Oxygen saturation of 88%",
      explanation:
        "An oxygen saturation of 88% indicates significant hypoxemia requiring immediate intervention to prevent complications.",
      difficulty: "medium",
      conceptualLevel: "analysis",
      clinicalJudgmentLevel: "2",
    }),
    // Hard questions
    createQuestion(1, {
      scenario:
        "A post-operative client suddenly develops shortness of breath, chest pain, and anxiety. Which assessment should the nurse perform first?",
      options: [
        "Assess vital signs and oxygen saturation",
        "Check surgical site dressing",
        "Review medication administration record",
        "Perform neurological assessment",
      ],
      correctAnswer: "Assess vital signs and oxygen saturation",
      difficulty: "hard",
      conceptualLevel: "analysis",
      clinicalJudgmentLevel: "3",
    }),
  ];
  questions.push(...medSurgQuestions);

  // Mental Health (domainId: 2)
  const mentalHealthQuestions = [
    // Easy questions
    createQuestion(2, {
      scenario:
        "A client with anxiety disorder is experiencing a panic attack. Which initial nursing action is most appropriate?",
      options: [
        "Stay with the client and speak in a calm voice",
        "Administer PRN anxiolytic immediately",
        "Call the crisis response team",
        "Remove the client from the current environment",
      ],
      correctAnswer: "Stay with the client and speak in a calm voice",
      explanation:
        "The initial nursing action for a client experiencing a panic attack is to provide a calm, reassuring presence.",
      difficulty: "easy",
      conceptualLevel: "application",
      clinicalJudgmentLevel: "1",
    }),
    // Add more mental health questions...
    createQuestion(2, {
      scenario:
        "A client diagnosed with schizophrenia is exhibiting disorganized speech and thought. Which nursing intervention is most important?",
      options: [
        "Encourage the client to participate in group therapy",
        "Administer prescribed antipsychotic medication",
        "Provide a structured and predictable environment",
        "Engage the client in reality-oriented conversations",
      ],
      correctAnswer: "Provide a structured and predictable environment",
      explanation:
        "A structured environment helps reduce anxiety and confusion in clients with schizophrenia.",
      difficulty: "medium",
      conceptualLevel: "application",
      clinicalJudgmentLevel: "2",
    }),
    createQuestion(2, {
      scenario:
        "A client with bipolar disorder is experiencing a manic episode. Which nursing intervention is most important?",
      options: [
        "Encourage the client to engage in quiet activities",
        "Allow the client to express their feelings freely",
        "Set firm limits on behavior",
        "Administer prescribed mood stabilizers",
      ],
      correctAnswer: "Set firm limits on behavior",
      explanation:
        "Setting limits is crucial during manic episodes to prevent escalation and ensure safety.",
      difficulty: "hard",
      conceptualLevel: "analysis",
      clinicalJudgmentLevel: "3",
    }),
  ];
  questions.push(...mentalHealthQuestions);

  // Fundamentals (domainId: 3)
  const fundamentalsQuestions = [
    createQuestion(3, {
      scenario:
        "A nurse is preparing to administer medication to a client. Which action demonstrates safe medication administration practice?",
      options: [
        "Administer the medication without verifying the client's identity",
        "Check the medication's expiration date before administration",
        "Administer the medication based on the client's request",
        "Document the medication administration before giving it",
      ],
      correctAnswer:
        "Check the medication's expiration date before administration",
      explanation:
        "Checking the expiration date is a crucial step in safe medication practice.",
      difficulty: "easy",
      conceptualLevel: "application",
      clinicalJudgmentLevel: "1",
    }),
    createQuestion(3, {
      scenario:
        "A nurse is performing a sterile dressing change. Which action compromises sterile technique?",
      options: [
        "Using sterile gloves and instruments",
        "Touching the inside of the sterile drape",
        "Maintaining a sterile field",
        "Using aseptic technique throughout the procedure",
      ],
      correctAnswer: "Touching the inside of the sterile drape",
      explanation:
        "Touching the inside of a sterile drape contaminates the field.",
      difficulty: "medium",
      conceptualLevel: "application",
      clinicalJudgmentLevel: "2",
    }),
    createQuestion(3, {
      scenario:
        "A nurse is caring for a client who has an intravenous (IV) line. Which action is a priority for preventing infection?",
      options: [
        "Changing the IV site daily",
        "Using aseptic technique during IV insertion and maintenance",
        "Using alcohol-based hand sanitizer before and after handling the IV line",
        "Wearing gloves when handling the IV line",
      ],
      correctAnswer:
        "Using aseptic technique during IV insertion and maintenance",
      explanation:
        "Aseptic technique is fundamental in preventing IV-related infections.",
      difficulty: "hard",
      conceptualLevel: "analysis",
      clinicalJudgmentLevel: "3",
    }),
  ];
  questions.push(...fundamentalsQuestions);

  //Pediatric Nursing (domainId: 4)
  const pediatricQuestions = [
    createQuestion(4, {
      scenario:
        "A 6-month-old infant is brought to the clinic for a well-baby check-up. Which developmental milestone is expected at this age?",
      options: [
        "Sits unsupported",
        "Walks independently",
        "Says a few words",
        "Uses pincer grasp",
      ],
      correctAnswer: "Sits unsupported",
      explanation:
        "Sitting unsupported is a typical developmental milestone for a 6-month-old infant.",
      difficulty: "easy",
      conceptualLevel: "recall",
      clinicalJudgmentLevel: "1",
    }),
    createQuestion(4, {
      scenario:
        "A 2-year-old child is admitted to the hospital with bronchiolitis. Which nursing intervention is a priority?",
      options: [
        "Administer prescribed antibiotics",
        "Restrict fluid intake to prevent dehydration",
        "Provide oxygen therapy as needed",
        "Encourage the child to ambulate frequently",
      ],
      correctAnswer: "Provide oxygen therapy as needed",
      explanation:
        "Oxygen therapy is important for managing respiratory distress in children with bronchiolitis.",
      difficulty: "medium",
      conceptualLevel: "application",
      clinicalJudgmentLevel: "2",
    }),
    createQuestion(4, {
      scenario:
        "A school-age child is admitted to the hospital with a diagnosis of leukemia. Which nursing intervention is most important in addressing the child's psychosocial needs?",
      options: [
        "Encourage the child to engage in academic activities",
        "Allow the child to have frequent visitors",
        "Provide opportunities for play and socialization",
        "Explain the child's diagnosis and prognosis in detail",
      ],
      correctAnswer: "Provide opportunities for play and socialization",
      explanation:
        "Play and socialization are essential for addressing psychosocial needs in hospitalized school-age children, particularly those with chronic illnesses.",
      difficulty: "hard",
      conceptualLevel: "analysis",
      clinicalJudgmentLevel: "3",
    }),
  ];
  questions.push(...pediatricQuestions);

  // Maternity Nursing (domainId: 5)
  const maternityQuestions = [
    createQuestion(5, {
      scenario:
        "A pregnant woman is experiencing contractions every 5 minutes. Which assessment is the priority?",
      options: [
        "Check fetal heart rate",
        "Assess maternal blood pressure",
        "Monitor maternal temperature",
        "Measure cervical dilation",
      ],
      correctAnswer: "Check fetal heart rate",
      explanation:
        "Checking fetal heart rate is a priority during labor to monitor fetal well-being.",
      difficulty: "easy",
      conceptualLevel: "application",
      clinicalJudgmentLevel: "1",
    }),
    createQuestion(5, {
      scenario:
        "A postpartum woman is experiencing excessive vaginal bleeding. Which nursing intervention is most important?",
      options: [
        "Massage the fundus",
        "Administer oxytocin",
        "Check vital signs",
        "Monitor urine output",
      ],
      correctAnswer: "Massage the fundus",
      explanation:
        "Fundal massage helps to contract the uterus and reduce bleeding.",
      difficulty: "medium",
      conceptualLevel: "application",
      clinicalJudgmentLevel: "2",
    }),
    createQuestion(5, {
      scenario:
        "A newborn is exhibiting signs of respiratory distress. Which assessment finding is the most concerning?",
      options: [
        "Grunting respirations",
        "Nasal flaring",
        "Retractions",
        "Acidosis",
      ],
      correctAnswer: "Acidosis",
      explanation:
        "Acidosis is a serious complication of respiratory distress and requires immediate attention.",
      difficulty: "hard",
      conceptualLevel: "analysis",
      clinicalJudgmentLevel: "3",
    }),
  ];
  questions.push(...maternityQuestions);

  //Community Health (domainId: 6)
  const communityHealthQuestions = [
    createQuestion(6, {
      scenario:
        "A community health nurse is conducting a health assessment on a family. Which factor is most indicative of a family's health status?",
      options: [
        "Family income",
        "Family size",
        "Family structure",
        "Family's interaction and coping mechanisms",
      ],
      correctAnswer: "Family's interaction and coping mechanisms",
      explanation:
        "Family interactions and coping strategies significantly impact overall family health.",
      difficulty: "easy",
      conceptualLevel: "application",
      clinicalJudgmentLevel: "1",
    }),
    createQuestion(6, {
      scenario:
        "A community health nurse is developing a health promotion program for a community. Which factor should be considered first?",
      options: [
        "Community demographics",
        "Available resources",
        "Community needs assessment",
        "Funding sources",
      ],
      correctAnswer: "Community needs assessment",
      explanation:
        "A thorough needs assessment is crucial for developing effective health promotion programs.",
      difficulty: "medium",
      conceptualLevel: "analysis",
      clinicalJudgmentLevel: "2",
    }),
    createQuestion(6, {
      scenario:
        "A community health nurse is working with a client who has a chronic illness. Which strategy is most effective in promoting self-management?",
      options: [
        "Providing detailed information on the client's condition",
        "Teaching the client how to administer medication",
        "Empowering the client to make informed decisions about their care",
        "Referring the client to a specialist",
      ],
      correctAnswer:
        "Empowering the client to make informed decisions about their care",
      explanation:
        "Empowerment is crucial for promoting self-management of chronic illness.",
      difficulty: "hard",
      conceptualLevel: "analysis",
      clinicalJudgmentLevel: "3",
    }),
  ];
  questions.push(...communityHealthQuestions);

  return questions;
};

export const NCLEX_QUESTIONS = generateDomainQuestions();

// Utility functions for checking distribution
export const questionsByDomain = NCLEX_QUESTIONS.reduce(
  (acc, question) => {
    const domain = question.domainId;
    if (!acc[domain]) {
      acc[domain] = [];
    }
    acc[domain].push(question);
    return acc;
  },
  {} as Record<number, typeof NCLEX_QUESTIONS>,
);

export const questionsByDifficulty = NCLEX_QUESTIONS.reduce(
  (acc, question) => {
    const difficulty = question.difficulty;
    if (!acc[difficulty]) {
      acc[difficulty] = [];
    }
    acc[difficulty].push(question);
    return acc;
  },
  {} as Record<string, typeof NCLEX_QUESTIONS>,
);

// Verify distribution
const verifyDistribution = () => {
  const difficulties = { easy: 0, medium: 0, hard: 0 };
  NCLEX_QUESTIONS.forEach((q) => {
    difficulties[q.difficulty as keyof typeof difficulties]++;
  });

  console.log("Question distribution:", difficulties);
  console.log("Total questions:", NCLEX_QUESTIONS.length);
};

verifyDistribution();
