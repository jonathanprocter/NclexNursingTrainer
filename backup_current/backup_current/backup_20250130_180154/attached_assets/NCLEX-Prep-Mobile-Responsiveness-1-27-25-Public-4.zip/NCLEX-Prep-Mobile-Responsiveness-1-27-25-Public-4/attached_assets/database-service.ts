import { drizzle } from 'drizzle-orm/node-postgres';
import { dbManager } from './database-manager';
import { log } from '../vite';

export class DatabaseService {
  private db: ReturnType<typeof drizzle> | null = null;
  private initialized = false;
  private shutdownInProgress = false;

  async initialize(): Promise<void> {
    if (this.initialized) {
      log('Database service already initialized');
      return;
    }

    if (this.shutdownInProgress) {
      throw new Error('Cannot initialize during shutdown');
    }

    log('Initializing database service...');
    try {
      // Initialize the database manager
      await dbManager.initialize();
      
      // Get the Drizzle instance
      this.db = dbManager.getDrizzle();
      
      this.initialized = true;
      log('Database service initialized successfully');
    } catch (error) {
      log('Failed to initialize database service:', error);
      await this.cleanup();
      throw error;
    }
  }

  async cleanup(): Promise<void> {
    if (this.shutdownInProgress) {
      return;
    }

    this.shutdownInProgress = true;
    log('Starting database service cleanup...');

    try {
      await dbManager.cleanup();
      log('Database service cleanup completed');
    } catch (error) {
      log('Error during database service cleanup:', error);
      throw error;
    } finally {
      this.db = null;
      this.initialized = false;
      this.shutdownInProgress = false;
    }
  }

  getClient(): ReturnType<typeof drizzle> {
    if (!this.db || !this.initialized) {
      throw new Error('Database client not initialized');
    }
    return this.db;
  }

  isInitialized(): boolean {
    return this.initialized;
  }
}

export const databaseService = new DatabaseService();