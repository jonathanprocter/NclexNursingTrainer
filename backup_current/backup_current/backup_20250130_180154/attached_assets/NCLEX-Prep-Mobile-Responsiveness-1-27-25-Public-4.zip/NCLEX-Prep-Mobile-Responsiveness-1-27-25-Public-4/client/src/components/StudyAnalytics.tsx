import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Brain,
  Target,
  Clock,
  TrendingUp,
  Award,
  Zap,
  AlertTriangle,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

interface StudyMetrics {
  totalTime: number;
  questionsAttempted: number;
  averageAccuracy: number;
  performanceTrend: {
    date: string;
    accuracy: number;
    timeSpent: number;
  }[];
  strengthAreas?: string[];
  weakAreas?: string[];
  recommendedFocus?: string[];
  streakDays?: number;
  lastStudySession?: string;
}

interface Props {
  metrics: StudyMetrics;
  loading?: boolean;
  error?: string; // Added error state
}

export function StudyAnalytics({
  metrics,
  loading = false,
  error = "",
}: Props) {
  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center h-40">
          <div className="text-center space-y-2">
            <Brain className="h-8 w-8 mx-auto text-muted-foreground animate-pulse" />
            <p className="text-sm text-muted-foreground">
              Analyzing study patterns...
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    console.error("StudyAnalytics error:", error);
    return (
      <Card>
        <CardContent className="flex items-center justify-center h-40">
          <div className="text-center space-y-2">
            <AlertTriangle className="h-8 w-8 mx-auto text-red-500" />
            <p className="text-sm text-red-500">
              Unable to load analytics data. Please try again later.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!metrics) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center h-40">
          <div className="text-center space-y-2">
            <Brain className="h-8 w-8 mx-auto text-muted-foreground" />
            <p className="text-sm text-muted-foreground">
              Complete some questions to see your analytics.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getStreakStatus = () => {
    if (!metrics.streakDays)
      return { color: "text-muted-foreground", text: "No active streak" };
    if (metrics.streakDays >= 7)
      return { color: "text-green-500", text: "🔥 On Fire!" };
    if (metrics.streakDays >= 3)
      return { color: "text-yellow-500", text: "⚡ Building Up!" };
    return { color: "text-blue-500", text: "🌱 Getting Started" };
  };

  const streakStatus = getStreakStatus();

  return (
    <div className="space-y-6">
      {/* Performance Overview */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Questions Attempted</p>
                <p className="text-2xl font-bold">
                  {metrics.questionsAttempted}
                </p>
              </div>
              <Brain className="h-8 w-8 text-primary opacity-75" />
            </div>
            {metrics.lastStudySession && (
              <p className="text-xs text-muted-foreground mt-2">
                Last session:{" "}
                {new Date(metrics.lastStudySession).toLocaleDateString()}
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Average Accuracy</p>
                <p className="text-2xl font-bold">
                  {Math.round(metrics.averageAccuracy)}%
                </p>
              </div>
              <Target className="h-8 w-8 text-primary opacity-75" />
            </div>
            {metrics.weakAreas && metrics.weakAreas.length > 0 && (
              <div className="mt-2">
                <p className="text-xs text-red-500 flex items-center">
                  <AlertTriangle className="h-3 w-3 mr-1" />
                  Focus needed: {metrics.weakAreas[0]}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Study Time</p>
                <p className="text-2xl font-bold">
                  {Math.round(metrics.totalTime / 60)}h
                </p>
              </div>
              <Clock className="h-8 w-8 text-primary opacity-75" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Study Streak</p>
                <div className="flex items-center gap-2">
                  {metrics.streakDays ? (
                    <>
                      <Award className="h-4 w-4 text-yellow-500" />
                      <p className="text-sm font-medium">
                        {metrics.streakDays} days
                      </p>
                    </>
                  ) : (
                    <p className="text-sm font-medium">Start your streak!</p>
                  )}
                </div>
              </div>
              <div className={`text-sm ${streakStatus.color}`}>
                {streakStatus.text}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Strength Areas */}
      {metrics.strengthAreas && metrics.strengthAreas.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Strength Areas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {metrics.strengthAreas.map((area, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 text-green-600"
                >
                  <Zap className="h-4 w-4" />
                  <span className="text-sm">{area}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Performance Trend */}
      <Card>
        <CardHeader>
          <CardTitle>Performance Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={metrics.performanceTrend}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis
                  dataKey="date"
                  tickFormatter={(value) =>
                    new Date(value).toLocaleDateString()
                  }
                  className="text-xs"
                />
                <YAxis yAxisId="left" className="text-xs" />
                <YAxis
                  yAxisId="right"
                  orientation="right"
                  className="text-xs"
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--background))",
                    border: "1px solid hsl(var(--border))",
                  }}
                  labelStyle={{ color: "hsl(var(--foreground))" }}
                />
                <Line
                  yAxisId="left"
                  type="monotone"
                  dataKey="accuracy"
                  stroke="hsl(var(--primary))"
                  name="Accuracy (%)"
                  strokeWidth={2}
                />
                <Line
                  yAxisId="right"
                  type="monotone"
                  dataKey="timeSpent"
                  stroke="hsl(var(--secondary))"
                  name="Time Spent (min)"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Recommended Focus Areas */}
      {metrics.recommendedFocus && metrics.recommendedFocus.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Recommended Focus Areas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {metrics.recommendedFocus.map((focus, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 text-muted-foreground"
                >
                  <Target className="h-4 w-4" />
                  <span className="text-sm">{focus}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
