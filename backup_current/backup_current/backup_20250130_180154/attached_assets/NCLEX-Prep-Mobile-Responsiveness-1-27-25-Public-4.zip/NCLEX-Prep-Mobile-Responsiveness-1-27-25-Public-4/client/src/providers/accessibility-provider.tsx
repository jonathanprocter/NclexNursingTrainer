import { createContext, useContext, useState, ReactNode } from "react";

interface AccessibilityContextType {
  fontSize: number;
  contrast: "normal" | "high";
  setFontSize: (size: number) => void;
  setContrast: (contrast: "normal" | "high") => void;
}

const AccessibilityContext = createContext<AccessibilityContextType | null>(
  null,
);

export function useAccessibility() {
  const context = useContext(AccessibilityContext);
  if (!context) {
    throw new Error(
      "useAccessibility must be used within an AccessibilityProvider",
    );
  }
  return context;
}

interface Props {
  children: ReactNode;
}

export function AccessibilityProvider({ children }: Props) {
  const [fontSize, setFontSize] = useState<number>(16);
  const [contrast, setContrast] = useState<"normal" | "high">("normal");

  const value = {
    fontSize,
    contrast,
    setFontSize,
    setContrast,
  };

  return (
    <AccessibilityContext.Provider value={value}>
      {children}
    </AccessibilityContext.Provider>
  );
}
