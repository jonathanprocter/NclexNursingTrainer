import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  BookOpen,
  Search,
  Filter,
  CheckCircle,
  Clock,
  BarChart2,
  Brain,
  Target,
  LayoutGrid,
  List,
  Eye,
  Calendar,
  Timer,
  Bookmark,
  Star,
  History,
  PlayCircle,
  PauseCircle,
  RotateCcw,
  Lightbulb,
  Medal,
  ChevronRight,
  Menu,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";

// Enhanced mock data with more detailed information
const mockCategories = [
  {
    id: "1",
    name: "Fundamentals of Nursing",
    progress: 65,
    contentCount: 120,
    completedCount: 78,
    topicCount: 15,
    lastAccessed: "2025-01-15",
  },
  {
    id: "2",
    name: "Medical-Surgical Nursing",
    progress: 45,
    contentCount: 200,
    completedCount: 90,
    topicCount: 25,
    lastAccessed: "2025-01-14",
  },
  {
    id: "3",
    name: "Pharmacology",
    progress: 30,
    contentCount: 150,
    completedCount: 45,
    topicCount: 18,
    lastAccessed: "2025-01-13",
  },
];

const mockContent = [
  {
    id: "1",
    title: "Patient Assessment Techniques",
    category: "Fundamentals of Nursing",
    type: "lesson",
    status: "completed",
    duration: "45 min",
    lastAccessed: "2025-01-15",
    topics: ["Vital Signs", "Physical Assessment", "Documentation"],
    difficulty: "intermediate",
    estimatedTime: 45,
    completionRate: 85,
  },
  {
    id: "2",
    title: "Medication Administration Principles",
    category: "Pharmacology",
    type: "practice",
    status: "in_progress",
    duration: "30 min",
    lastAccessed: "2025-01-14",
    topics: ["Drug Calculations", "Administration Routes", "Safety"],
    difficulty: "advanced",
    estimatedTime: 30,
    completionRate: 60,
  },
  {
    id: "3",
    title: "Cardiovascular System Review",
    category: "Medical-Surgical Nursing",
    type: "lesson",
    status: "not_started",
    duration: "60 min",
    lastAccessed: null,
    topics: ["Heart Anatomy", "Cardiac Cycle", "Common Disorders"],
    difficulty: "beginner",
    estimatedTime: 60,
    completionRate: 0,
  },
];

// New interface for study session
interface StudySession {
  startTime: Date;
  duration: number;
  category: string;
  completed: number;
  isActive: boolean;
}

export function ContentViewer() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedStatus, setSelectedStatus] = useState<string>("all");
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("all");
  const [sortBy, setSortBy] = useState<
    "title" | "lastAccessed" | "duration" | "progress"
  >("lastAccessed");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [selectedContent, setSelectedContent] = useState<
    (typeof mockContent)[0] | null
  >(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [recentlyViewed, setRecentlyViewed] = useState<typeof mockContent>([]);
  const [studySession, setStudySession] = useState<StudySession | null>(null);
  const [sessionTime, setSessionTime] = useState(0);
  const { toast } = useToast();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);

  const filteredContent = mockContent
    .filter((content) => {
      const matchesSearch =
        content.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        content.topics.some((topic) =>
          topic.toLowerCase().includes(searchQuery.toLowerCase()),
        );
      const matchesCategory =
        selectedCategory === "all" || content.category === selectedCategory;
      const matchesStatus =
        selectedStatus === "all" || content.status === selectedStatus;
      const matchesDifficulty =
        selectedDifficulty === "all" ||
        content.difficulty === selectedDifficulty;
      return (
        matchesSearch && matchesCategory && matchesStatus && matchesDifficulty
      );
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "title":
          return a.title.localeCompare(b.title);
        case "lastAccessed":
          if (!a.lastAccessed) return 1;
          if (!b.lastAccessed) return -1;
          return (
            new Date(b.lastAccessed).getTime() -
            new Date(a.lastAccessed).getTime()
          );
        case "duration":
          return (
            parseInt(b.duration.split(" ")[0]) -
            parseInt(a.duration.split(" ")[0])
          );
        case "progress":
          return b.completionRate - a.completionRate;
        default:
          return 0;
      }
    });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "in_progress":
        return "bg-blue-100 text-blue-800";
      case "not_started":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner":
        return "bg-green-100 text-green-800";
      case "intermediate":
        return "bg-yellow-100 text-yellow-800";
      case "advanced":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const renderContentPreview = (content: (typeof mockContent)[0]) => (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="absolute top-2 right-2">
          <Eye className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>{content.title}</DialogTitle>
        </DialogHeader>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="content">Content</TabsTrigger>
            <TabsTrigger value="progress">Progress</TabsTrigger>
          </TabsList>
          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-3">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">Estimated Time</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Timer className="h-4 w-4" />
                    <span>{content.estimatedTime} minutes</span>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">Last Studied</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    <span>
                      {content.lastAccessed
                        ? new Date(content.lastAccessed).toLocaleDateString()
                        : "Not started"}
                    </span>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">Completion</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>{content.completionRate}%</span>
                    </div>
                    <Progress value={content.completionRate} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            </div>
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-2">Topics Covered</h3>
                    <div className="flex flex-wrap gap-2">
                      {content.topics.map((topic, index) => (
                        <Badge key={index} variant="secondary">
                          {topic}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Learning Objectives</h3>
                    <ul className="list-disc pl-4 space-y-1">
                      <li>Understand key concepts and principles</li>
                      <li>
                        Apply theoretical knowledge to practical scenarios
                      </li>
                      <li>Develop critical thinking skills</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="content">
            {/* Content preview section */}
          </TabsContent>
          <TabsContent value="progress">
            {/* Progress tracking section */}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );

  const renderGridView = () => (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {filteredContent.map((content) => (
        <Card
          key={content.id}
          className="relative hover:shadow-md transition-shadow"
        >
          <CardContent className="pt-6">
            <div className="absolute top-2 left-2">
              <Badge
                variant="outline"
                className={getDifficultyColor(content.difficulty)}
              >
                {content.difficulty}
              </Badge>
            </div>
            {renderContentPreview(content)}
            <div className="space-y-4">
              <div>
                <h3 className="font-medium truncate">{content.title}</h3>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                  <Clock className="h-4 w-4" />
                  <span>{content.duration}</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progress</span>
                  <span>{content.completionRate}%</span>
                </div>
                <Progress value={content.completionRate} className="h-1" />
              </div>
              <div className="flex flex-wrap gap-1">
                {content.topics.slice(0, 2).map((topic, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {topic}
                  </Badge>
                ))}
                {content.topics.length > 2 && (
                  <Badge variant="secondary" className="text-xs">
                    +{content.topics.length - 2} more
                  </Badge>
                )}
              </div>
              <Button className="w-full" variant="outline">
                {content.status === "completed" ? "Review" : "Start Learning"}
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );

  const renderListView = () => (
    <div className="space-y-4">
      {filteredContent.map((content) => (
        <Card key={content.id} className="hover:bg-muted/50 transition-colors">
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <h3 className="font-medium flex items-center gap-2">
                  {content.title}
                  {content.status === "completed" && (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  )}
                </h3>
                <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <BookOpen className="h-4 w-4" />
                    {content.category}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    {content.duration}
                  </span>
                  <span className="flex items-center gap-1">
                    <Brain className="h-4 w-4" />
                    {content.topics.length} topics
                  </span>
                  {content.lastAccessed && (
                    <span className="flex items-center gap-1">
                      <BarChart2 className="h-4 w-4" />
                      Last accessed:{" "}
                      {new Date(content.lastAccessed).toLocaleDateString()}
                    </span>
                  )}
                </div>
                <div className="flex flex-wrap gap-2 mt-2">
                  {content.topics.map((topic, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {topic}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="flex flex-col items-end gap-2">
                <div className="flex items-center gap-2">
                  <Badge className={getStatusColor(content.status)}>
                    {content.status.replace("_", " ")}
                  </Badge>
                  <Badge className={getDifficultyColor(content.difficulty)}>
                    {content.difficulty}
                  </Badge>
                </div>
                <div className="w-32">
                  <div className="flex justify-between text-xs text-muted-foreground mb-1">
                    <span>Progress</span>
                    <span>{content.completionRate}%</span>
                  </div>
                  <Progress value={content.completionRate} className="h-1" />
                </div>
                <Button variant="outline" size="sm">
                  {content.status === "completed" ? "Review" : "Continue"}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );

  // Group content by category
  const contentByCategory = mockContent.reduce(
    (acc, content) => {
      if (!acc[content.category]) {
        acc[content.category] = [];
      }
      acc[content.category].push(content);
      return acc;
    },
    {} as Record<string, typeof mockContent>,
  );

  // Study session timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (studySession?.isActive) {
      timer = setInterval(() => {
        setSessionTime((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [studySession?.isActive]);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`;
  };

  const startStudySession = (category: string) => {
    setStudySession({
      startTime: new Date(),
      duration: 0,
      category,
      completed: 0,
      isActive: true,
    });
    toast({
      title: "Study Session Started",
      description: `Started studying ${category}. Keep up the good work!`,
    });
  };

  const pauseStudySession = () => {
    setStudySession((prev) => (prev ? { ...prev, isActive: false } : null));
    toast({
      title: "Study Session Paused",
      description: "Take a break and resume when you're ready!",
    });
  };

  const resumeStudySession = () => {
    setStudySession((prev) => (prev ? { ...prev, isActive: true } : null));
    toast({
      title: "Study Session Resumed",
      description: "Welcome back! Let's continue learning.",
    });
  };

  const endStudySession = () => {
    if (studySession) {
      toast({
        title: "Study Session Completed",
        description: `You studied for ${formatTime(sessionTime)}. Great job!`,
      });
      setStudySession(null);
      setSessionTime(0);
    }
  };

  return (
    <div className="flex h-[calc(100vh-4rem)]">
      {/* Sidebar */}
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="lg:hidden">
            <Menu className="h-6 w-6" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-[300px] p-0">
          <SidebarContent
            categories={mockCategories}
            contentByCategory={contentByCategory}
            selectedTopic={selectedTopic}
            onSelectTopic={setSelectedTopic}
          />
        </SheetContent>
      </Sheet>

      <div className="hidden lg:block w-[300px] border-r">
        <SidebarContent
          categories={mockCategories}
          contentByCategory={contentByCategory}
          selectedTopic={selectedTopic}
          onSelectTopic={setSelectedTopic}
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="container py-6 space-y-6">
          {/* Study Session Timer */}
          {studySession && (
            <Card className="bg-primary/5">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <h3 className="font-medium">Current Study Session</h3>
                    <p className="text-sm text-muted-foreground">
                      Studying {studySession.category}
                    </p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-2xl font-bold font-mono">
                      {formatTime(sessionTime)}
                    </div>
                    <div className="flex gap-2">
                      {studySession.isActive ? (
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={pauseStudySession}
                        >
                          <PauseCircle className="h-4 w-4" />
                        </Button>
                      ) : (
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={resumeStudySession}
                        >
                          <PlayCircle className="h-4 w-4" />
                        </Button>
                      )}
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={endStudySession}
                      >
                        <RotateCcw className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Quick Stats */}
          <div className="grid gap-4 md:grid-cols-4">
            <QuickStatCard
              title="Study Streak"
              value="7 days"
              icon={<Medal className="h-8 w-8 text-yellow-500" />}
            />
            <QuickStatCard
              title="Today's Progress"
              value="75%"
              subtext="45 questions"
              progress={75}
            />
            <QuickStatCard
              title="Study Time"
              value="2.5h"
              icon={<Clock className="h-8 w-8 text-blue-500" />}
            />
            <QuickStatCard
              title="Mastery Score"
              value="82%"
              icon={<Brain className="h-8 w-8 text-purple-500" />}
            />
          </div>

          {/* Advanced Search and Filters */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Content Library</CardTitle>
                <div className="flex gap-2">
                  <Button
                    variant={viewMode === "grid" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setViewMode("grid")}
                  >
                    <LayoutGrid className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === "list" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setViewMode("list")}
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex flex-wrap gap-4">
                  <div className="flex-1 min-w-[200px]">
                    <div className="relative">
                      <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search content or topics..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-8"
                      />
                    </div>
                  </div>
                  <Select
                    value={selectedCategory}
                    onValueChange={setSelectedCategory}
                  >
                    <SelectTrigger className="w-[200px]">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {mockCategories.map((category) => (
                        <SelectItem key={category.id} value={category.name}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select
                    value={selectedStatus}
                    onValueChange={setSelectedStatus}
                  >
                    <SelectTrigger className="w-[200px]">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="not_started">Not Started</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select
                    value={selectedDifficulty}
                    onValueChange={setSelectedDifficulty}
                  >
                    <SelectTrigger className="w-[200px]">
                      <SelectValue placeholder="Select difficulty" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Difficulties</SelectItem>
                      <SelectItem value="beginner">Beginner</SelectItem>
                      <SelectItem value="intermediate">Intermediate</SelectItem>
                      <SelectItem value="advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select
                    value={sortBy}
                    onValueChange={(value: any) => setSortBy(value)}
                  >
                    <SelectTrigger className="w-[200px]">
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="title">Title</SelectItem>
                      <SelectItem value="lastAccessed">
                        Last Accessed
                      </SelectItem>
                      <SelectItem value="duration">Duration</SelectItem>
                      <SelectItem value="progress">Progress</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <ScrollArea className="h-[500px]">
                  {viewMode === "grid" ? renderGridView() : renderListView()}
                </ScrollArea>
              </div>
            </CardContent>
          </Card>

          {/* Study Tips */}
          <Card className="bg-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="h-5 w-5" />
                Study Tips
              </CardTitle>
              <CardDescription>
                Personalized recommendations based on your learning patterns
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="rounded-full p-2 bg-primary/10">
                    <Target className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="font-medium">Focus on Pharmacology</h4>
                    <p className="text-sm text-muted-foreground">
                      Your performance in drug calculations shows room for
                      improvement. Consider reviewing medication administration
                      principles.
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="rounded-full p-2 bg-primary/10">
                    <Brain className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="font-medium">Review Critical Care</h4>
                    <p className="text-sm text-muted-foreground">
                      You're excelling in basic assessment. Time to challenge
                      yourself with advanced critical care scenarios.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

// New component for sidebar content
function SidebarContent({
  categories,
  contentByCategory,
  selectedTopic,
  onSelectTopic,
}: {
  categories: typeof mockCategories;
  contentByCategory: Record<string, typeof mockContent>;
  selectedTopic: string | null;
  onSelectTopic: (topic: string) => void;
}) {
  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b">
        <h2 className="font-semibold">Study Content</h2>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-4">
          <Accordion type="single" collapsible>
            {categories.map((category) => (
              <AccordionItem key={category.id} value={category.id}>
                <AccordionTrigger>
                  <div className="flex items-center gap-2">
                    <BookOpen className="h-4 w-4" />
                    <span>{category.name}</span>
                    <Badge variant="secondary" className="ml-2">
                      {category.completedCount}/{category.contentCount}
                    </Badge>
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="pl-6 space-y-2">
                    {contentByCategory[category.name]?.map((content) => (
                      <Button
                        key={content.id}
                        variant="ghost"
                        className={`w-full justify-start gap-2 ${
                          selectedTopic === content.id ? "bg-muted" : ""
                        }`}
                        onClick={() => onSelectTopic(content.id)}
                      >
                        <div className="flex items-center gap-2">
                          {content.status === "completed" && (
                            <CheckCircle className="h-4 w-4 text-green-500" />
                          )}
                          <span className="truncate">{content.title}</span>
                        </div>
                      </Button>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </ScrollArea>
    </div>
  );
}

// New component for quick stat cards
function QuickStatCard({
  title,
  value,
  icon,
  subtext,
  progress,
}: {
  title: string;
  value: string;
  icon?: React.ReactNode;
  subtext?: string;
  progress?: number;
}) {
  return (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <p className="text-sm font-medium">{title}</p>
          <p className="text-2xl font-bold">{value}</p>
          {subtext && (
            <p className="text-xs text-muted-foreground">{subtext}</p>
          )}
          {progress !== undefined && (
            <Progress value={progress} className="mt-2" />
          )}
        </div>
        {icon}
      </div>
    </Card>
  );
}
