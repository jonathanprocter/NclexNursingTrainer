import { z } from "zod";

export interface StudyMetrics {
  totalTime: number;
  questionsAttempted: number;
  averageAccuracy: number;
  performanceTrend: Array<{
    date: string;
    accuracy: number;
    timeSpent: number;
  }>;
  strengthAreas?: string[];
  weakAreas?: string[];
  recommendedFocus?: string[];
  streakDays?: number;
  lastStudySession?: string;
  retentionRate: number;
  estimatedMastery: number;
  predictedScore: number;
  cognitiveLoad: number;
}

export interface DomainProgress {
  id: number;
  name: string;
  performanceScore: number;
  trend?: "improving" | "declining" | "stable";
  lastAttempted?: string;
  questionsAnswered?: number;
  accuracy?: number;
  timeSpent?: number;
  recommendations?: string[];
}

export interface PerformanceMetrics {
  accuracy: number;
  responseTime: number;
  confidence: number;
  consistency: number;
}

export interface StudyPattern {
  preferredTimes: string[];
  averageSessionLength: number;
  frequentTopics: string[];
  learningStyle: {
    visual: number;
    reading: number;
    interactive: number;
  };
}

export interface UserMetrics {
  questionsAnswered: number;
  averageScore: number;
  studyTime: number;
  streakDays: number;
  performanceMetrics: PerformanceMetrics;
  studyPatterns?: StudyPattern;
  lastActive?: string;
}

export interface LearningProgress {
  currentLevel: string;
  nextMilestone: string;
  progressToNext: number;
  achievements: string[];
  recommendedActions: string[];
}

// Validation schemas for API responses
export const studyMetricsSchema = z.object({
  totalTime: z.number(),
  questionsAttempted: z.number(),
  averageAccuracy: z.number(),
  performanceTrend: z.array(
    z.object({
      date: z.string(),
      accuracy: z.number(),
      timeSpent: z.number(),
    }),
  ),
  retentionRate: z.number(),
  estimatedMastery: z.number(),
  predictedScore: z.number(),
  cognitiveLoad: z.number(),
  strengthAreas: z.array(z.string()).optional(),
  weakAreas: z.array(z.string()).optional(),
  recommendedFocus: z.array(z.string()).optional(),
  streakDays: z.number().optional(),
  lastStudySession: z.string().optional(),
});
