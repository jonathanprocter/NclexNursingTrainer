// API Response Types
export interface ProgressResponse {
  overallProgress: number;
  accuracyRate: string;
  masteryLevel: string;
  recommendations: string[];
  difficultyAdjustments?: {
    message: string;
    level: number;
  };
}

export interface ModuleData {
  name: string;
  activities: Array<{
    type: string;
    description: string;
    objectives: string[];
    adaptiveOptions?: {
      difficultyLevels: string[];
      contentTypes: string[];
      aiAssistance: boolean;
    };
  }>;
  aiFeatures: {
    adaptiveLearning: boolean;
    personalizedFeedback: boolean;
    contentGeneration: boolean;
    performanceAnalytics: boolean;
  };
}

export interface CaseStudy {
  id: string;
  title: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  patientInfo: {
    age: number;
    gender: string;
    chiefComplaint: string;
    vitalSigns: {
      temperature: string;
      heartRate: string;
      bloodPressure: string;
      respiratoryRate: string;
      oxygenSaturation: string;
    };
    relevantHistory: string[];
  };
  clinicalPresentation: string[];
  labResults?: Array<{
    name: string;
    value: string;
    referenceRange: string;
  }>;
  questions: Array<{
    id: string;
    text: string;
    type: "identification" | "prioritization" | "analysis";
    options: string[];
    correctAnswer: number;
    explanation: string;
    clinicalReasoning: string[];
  }>;
}
