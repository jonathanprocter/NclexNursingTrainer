import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  BookOpen,
  Library,
  Activity,
  Brain,
  FlaskConical,
  Menu,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
  DrawerClose,
} from "@/components/ui/drawer";
import { useMediaQuery } from "@/hooks/use-media-query";

export default function Navigation() {
  const [location, setLocation] = useLocation();
  const isMobile = useMediaQuery("(max-width: 768px)");

  const mainNavItems = [
    {
      label: "Dashboards",
      icon: Activity,
      items: [
        { href: "/analytics-dashboard", label: "Analytics Dashboard" },
        { href: "/performance-analytics", label: "Performance Analytics" },
        { href: "/instructor-dashboard", label: "Instructor Dashboard" },
      ],
    },
    {
      label: "Learning Modules",
      icon: Library,
      items: [
        { href: "/pharmacology", label: "Pharmacology & Parenteral" },
        { href: "/analyze-cues", label: "Analyze Cues & Hypotheses" },
        { href: "/risk-reduction", label: "Risk Reduction" },
        { href: "/clinical-judgment", label: "Clinical Judgment" },
        { href: "/drug-calculations", label: "Drug Calculations" },
        {
          href: "/advanced-pathophysiology",
          label: "Advanced Pathophysiology",
        },
      ],
    },
    {
      label: "Practice & Simulation",
      icon: FlaskConical,
      items: [
        { href: "/practice/quizzes", label: "Practice Quizzes" },
        { href: "/practice/mock-exams", label: "Mock NCLEX Exams" },
        {
          href: "/practice/patient-scenarios",
          label: "Virtual Patient Scenarios",
        },
        { href: "/practice/advanced-simulation", label: "Advanced Simulation" },
      ],
    },
    {
      label: "Study Tools",
      icon: Brain,
      items: [
        { href: "/tools/voice-companion", label: "AI Voice Study Companion" },
        { href: "/tools/spaced-repetition", label: "Spaced Repetition" },
      ],
    },
  ];

  const MobileNavigation = () => (
    <div className="space-y-4 px-2 py-4">
      {mainNavItems.map(({ label, icon: Icon, items }) => (
        <div key={label} className="space-y-3">
          <div className="flex items-center gap-2 px-3">
            <Icon className="h-5 w-5" />
            <span className="font-medium">{label}</span>
          </div>
          <div className="space-y-1 pl-6">
            {items.map((item) => (
              <DrawerClose key={item.href} asChild>
                <Link
                  href={item.href}
                  className={cn(
                    "block rounded-md px-3 py-2 text-sm hover:bg-accent",
                    location === item.href &&
                      "bg-accent text-accent-foreground",
                  )}
                >
                  {item.label}
                </Link>
              </DrawerClose>
            ))}
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="border-b sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="flex h-14 md:h-16 items-center px-4">
        {/* Logo */}
        <Button
          variant="ghost"
          className="mr-6 p-0"
          onClick={() => setLocation("/nclex-manager")}
        >
          <BookOpen className="h-5 w-5 md:h-6 md:w-6" />
          <span className="font-bold text-lg md:text-xl ml-2">NCLEX Prep</span>
        </Button>

        {/* Centered content (Navigation or Mobile Menu) */}
        <div className="flex-1 flex justify-center">
          {isMobile ? (
            <Drawer>
              <DrawerTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="h-5 w-5" />
                </Button>
              </DrawerTrigger>
              <DrawerContent>
                <DrawerHeader>
                  <DrawerTitle>Menu</DrawerTitle>
                </DrawerHeader>
                <MobileNavigation />
              </DrawerContent>
            </Drawer>
          ) : (
            <NavigationMenu>
              <NavigationMenuList>
                {mainNavItems.map(({ label, icon: Icon, items }) => (
                  <NavigationMenuItem key={label}>
                    <NavigationMenuTrigger className="flex items-center gap-2">
                      <Icon className="h-4 w-4" />
                      <span>{label}</span>
                    </NavigationMenuTrigger>
                    <NavigationMenuContent>
                      <ul className="grid w-[400px] gap-3 p-4">
                        {items.map((item) => (
                          <li key={item.href}>
                            <NavigationMenuLink asChild>
                              <Link
                                href={item.href}
                                className={cn(
                                  "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                                  location === item.href &&
                                    "bg-accent text-accent-foreground",
                                )}
                              >
                                <div className="text-sm font-medium leading-none">
                                  {item.label}
                                </div>
                              </Link>
                            </NavigationMenuLink>
                          </li>
                        ))}
                      </ul>
                    </NavigationMenuContent>
                  </NavigationMenuItem>
                ))}
              </NavigationMenuList>
            </NavigationMenu>
          )}
        </div>

        {/* Right side spacer for symmetry */}
        <div className="w-[68px] md:w-[92px]" />
      </div>
    </div>
  );
}
