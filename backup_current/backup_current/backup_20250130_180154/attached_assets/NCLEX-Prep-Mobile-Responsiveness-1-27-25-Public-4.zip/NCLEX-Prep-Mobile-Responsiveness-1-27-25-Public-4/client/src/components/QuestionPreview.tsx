import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Brain,
  Clock,
  Tag,
  BookOpen,
  ArrowRight,
  CheckCircle,
  BarChart2,
  Target,
  Users,
  Star,
  AlertTriangle,
} from "lucide-react";

interface Question {
  id: string;
  text: string;
  options: string[];
  correctOption: number;
  explanation: string;
  category: string;
  topics: string[];
  difficulty: "easy" | "medium" | "hard";
  averageTime: number;
  successRate: number;
  importance?: number;
  warningNotes?: string;
}

interface QuestionPreviewProps {
  question: Question;
  onStartQuiz?: () => void;
}

export function QuestionPreview({
  question,
  onStartQuiz,
}: QuestionPreviewProps) {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy":
        return "bg-green-100 text-green-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "hard":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getImportanceStars = (importance: number = 3) => {
    return Array(5)
      .fill(0)
      .map((_, i) => (
        <Star
          key={i}
          className={`h-4 w-4 ${i < importance ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`}
        />
      ));
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            Question Preview
          </CardTitle>
          <div className="flex gap-2">
            <Badge variant="outline" className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {question.averageTime}s avg
            </Badge>
            <Badge className={getDifficultyColor(question.difficulty)}>
              {question.difficulty}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Question Text */}
        <div className="space-y-4">
          <div className="text-lg font-medium">{question.text}</div>
          <div className="grid gap-2">
            {question.options.map((option, index) => (
              <div
                key={index}
                className={`p-4 rounded-lg border ${
                  index === question.correctOption
                    ? "bg-green-50 border-green-200"
                    : "bg-card hover:bg-accent"
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border">
                    {String.fromCharCode(65 + index)}
                  </div>
                  <div>{option}</div>
                  {index === question.correctOption && (
                    <CheckCircle className="h-5 w-5 text-green-500 ml-auto" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Question Metadata */}
        <div className="grid gap-6 md:grid-cols-2">
          {/* Left Column */}
          <div className="space-y-4">
            {/* Topics */}
            <div className="space-y-2">
              <div className="font-medium flex items-center gap-2">
                <Tag className="h-4 w-4" />
                Topics
              </div>
              <div className="flex flex-wrap gap-2">
                {question.topics.map((topic, index) => (
                  <Badge key={index} variant="secondary">
                    {topic}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Statistics */}
            <div className="space-y-2">
              <div className="font-medium flex items-center gap-2">
                <BarChart2 className="h-4 w-4" />
                Performance Metrics
              </div>
              <div className="grid gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Target className="h-4 w-4 text-blue-500" />
                    <span className="text-sm">Success Rate</span>
                  </div>
                  <span className="font-bold">{question.successRate}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Average Time</span>
                  </div>
                  <span className="font-bold">{question.averageTime}s</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-purple-500" />
                    <span className="text-sm">Attempts</span>
                  </div>
                  <span className="font-bold">324</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-4">
            {/* Importance Level */}
            <div className="space-y-2">
              <div className="font-medium flex items-center gap-2">
                <Star className="h-4 w-4 fill-yellow-500 text-yellow-500" />
                Importance Level
              </div>
              <div className="flex items-center gap-1">
                {getImportanceStars(question.importance)}
              </div>
            </div>

            {/* Warning Notes */}
            {question.warningNotes && (
              <div className="space-y-2">
                <div className="font-medium flex items-center gap-2 text-yellow-600">
                  <AlertTriangle className="h-4 w-4" />
                  Study Notes
                </div>
                <div className="text-sm text-muted-foreground bg-yellow-50 p-3 rounded-lg border border-yellow-200">
                  {question.warningNotes}
                </div>
              </div>
            )}
          </div>
        </div>

        <Separator />

        {/* Explanation */}
        <div className="space-y-2">
          <div className="font-medium flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            Explanation
          </div>
          <ScrollArea className="h-[100px] rounded-md border p-4">
            {question.explanation}
          </ScrollArea>
        </div>

        {/* Action Button */}
        <Button onClick={onStartQuiz} className="w-full gap-2">
          Start Practice Questions
          <ArrowRight className="h-4 w-4" />
        </Button>
      </CardContent>
    </Card>
  );
}
