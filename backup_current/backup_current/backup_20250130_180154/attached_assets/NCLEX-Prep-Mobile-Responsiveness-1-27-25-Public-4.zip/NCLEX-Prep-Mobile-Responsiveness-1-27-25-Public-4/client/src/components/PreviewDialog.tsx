import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Download, X, Clock, FileType, FolderTree } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { ExtractedFile } from "@/lib/types";
import {
  isImageFile,
  isTextFile,
  getMimeType,
  formatFileSize,
} from "@/lib/fileUtils";
import { useState } from "react";

interface PreviewDialogProps {
  file: ExtractedFile;
  isOpen: boolean;
  onClose: () => void;
}

const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleString();
};

export function PreviewDialog({ file, isOpen, onClose }: PreviewDialogProps) {
  const [imageError, setImageError] = useState(false);

  const handleDownload = () => {
    const content = atob(file.content);
    const blob = new Blob([content], { type: getMimeType(file.name) });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = file.name.split("/").pop() || file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const renderMetadata = () => (
    <div className="grid grid-cols-2 gap-2 text-sm mb-4 p-4 rounded-md bg-muted/50">
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-muted-foreground" />
          <span className="text-muted-foreground">Last Modified:</span>
        </div>
        <div className="font-medium">
          {formatDate(file.metadata.lastModified)}
        </div>
      </div>
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-muted-foreground" />
          <span className="text-muted-foreground">Created:</span>
        </div>
        <div className="font-medium">{formatDate(file.metadata.createdAt)}</div>
      </div>
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <FileType className="w-4 h-4 text-muted-foreground" />
          <span className="text-muted-foreground">Type:</span>
        </div>
        <div className="font-medium">{file.metadata.mimeType}</div>
      </div>
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <FolderTree className="w-4 h-4 text-muted-foreground" />
          <span className="text-muted-foreground">Path:</span>
        </div>
        <div className="font-medium">{file.metadata.path || "/"}</div>
      </div>
    </div>
  );

  const renderContent = () => {
    if (isImageFile(file) && !imageError) {
      return (
        <div className="flex items-center justify-center p-4">
          <img
            src={`data:${getMimeType(file.name)};base64,${file.content}`}
            alt={file.name}
            className="max-w-full max-h-[70vh] object-contain"
            onError={() => setImageError(true)}
          />
        </div>
      );
    }

    if (isTextFile(file) || imageError) {
      return (
        <ScrollArea className="h-[70vh] w-full">
          <pre className="p-4 text-sm">
            <code>{atob(file.content)}</code>
          </pre>
        </ScrollArea>
      );
    }

    return (
      <div className="flex items-center justify-center p-4 text-muted-foreground">
        Binary file preview not available
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={() => onClose()}>
      <DialogContent className="max-w-4xl w-full">
        <DialogHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <DialogTitle className="text-xl font-semibold truncate pr-4">
            {file.name}
          </DialogTitle>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={handleDownload}>
              <Download className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>
        {renderMetadata()}
        <Separator className="my-4" />
        {renderContent()}
      </DialogContent>
    </Dialog>
  );
}
