import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  RotateCcw,
  TrendingUp,
  Target,
  Clock,
  Brain,
  BookOpen,
  AlertCircle,
  CheckCircle,
  XCircle,
} from "lucide-react";
import type {
  QuizResultsProps,
  AdaptiveQuestion,
  QuizAnalytics,
} from "@/types/quiz";

export function QuizResults({
  score,
  totalQuestions,
  timeSpent,
  questions,
  analytics,
  onRetake,
}: QuizResultsProps) {
  const percentage = Math.round((score / totalQuestions) * 100);

  const getPerformanceMessage = (percentage: number) => {
    if (percentage >= 90)
      return {
        message: "Excellent! You're well prepared!",
        description:
          "Your understanding of the material is outstanding. Focus on maintaining this level while exploring more challenging concepts.",
        icon: CheckCircle,
      };
    if (percentage >= 80)
      return {
        message: "Great work! Keep it up!",
        description:
          "You're showing strong comprehension. Consider increasing difficulty to push your knowledge further.",
        icon: CheckCircle,
      };
    if (percentage >= 70)
      return {
        message: "Good job! Room for improvement.",
        description:
          "You're on the right track. Review incorrect answers and focus on understanding the rationales.",
        icon: Target,
      };
    return {
      message: "Keep practicing! You'll get there!",
      description:
        "Focus on building your foundational knowledge and take advantage of detailed explanations.",
      icon: AlertCircle,
    };
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`;
  };

  const categoryPerformance = questions.reduce(
    (acc, question) => {
      const category = question.category;
      if (!acc[category]) {
        acc[category] = { total: 0, correct: 0, timeSpent: 0 };
      }
      acc[category].total++;
      // Use the explanation field to determine if the question was answered correctly
      if (question.explanation.includes("Correct")) {
        acc[category].correct++;
      }
      acc[category].timeSpent += question.averageTime || 0;
      return acc;
    },
    {} as Record<string, { total: number; correct: number; timeSpent: number }>,
  );

  const averageTimePerQuestion =
    analytics?.averageTimePerQuestion ??
    Math.round(
      questions.reduce((acc, q) => acc + (q.averageTime || 0), 0) /
        questions.length,
    );

  const performanceData = getPerformanceMessage(percentage);
  const Icon = performanceData.icon;

  const getTimePerformance = (avgTime: number) => {
    if (avgTime <= 45) return "You're answering quickly and efficiently";
    if (avgTime <= 90)
      return "You're taking a good amount of time to consider each question";
    return "Consider practicing to improve your response time";
  };

  return (
    <div className="space-y-6">
      {/* Overall Performance Card */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <div className="p-2 rounded-full bg-primary/10">
              <Icon className="w-8 h-8 text-primary" />
            </div>
            <div className="flex-1 space-y-1">
              <h2 className="text-2xl font-bold">{performanceData.message}</h2>
              <p className="text-muted-foreground">
                {performanceData.description}
              </p>
            </div>
            <div className="text-right">
              <div className="text-4xl font-bold">{percentage}%</div>
              <div className="text-sm text-muted-foreground">
                {score}/{totalQuestions} correct
              </div>
            </div>
          </div>
          <Progress value={percentage} className="h-2 mt-4" />
        </CardContent>
      </Card>

      {/* Performance Metrics Grid */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Time Analysis */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Time Analysis
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-baseline">
              <div>
                <div className="text-2xl font-bold">
                  {averageTimePerQuestion}s
                </div>
                <div className="text-sm text-muted-foreground">
                  per question
                </div>
              </div>
              {timeSpent && (
                <div className="text-right">
                  <div className="text-2xl font-bold">
                    {formatTime(timeSpent)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    total time
                  </div>
                </div>
              )}
            </div>
            <p className="text-sm text-muted-foreground">
              {getTimePerformance(averageTimePerQuestion)}
            </p>
          </CardContent>
        </Card>

        {/* Category Performance */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <BookOpen className="w-5 h-5" />
              Category Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(categoryPerformance).map(([category, data]) => {
                const categoryPercentage = Math.round(
                  (data.correct / data.total) * 100,
                );
                const avgTime = Math.round(data.timeSpent / data.total);
                return (
                  <div key={category} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-medium">{category}</div>
                        <div className="text-sm text-muted-foreground">
                          {categoryPercentage}% correct • {avgTime}s avg
                        </div>
                      </div>
                      <Badge
                        variant={
                          categoryPercentage >= 70 ? "default" : "secondary"
                        }
                      >
                        {data.correct}/{data.total}
                      </Badge>
                    </div>
                    <Progress value={categoryPercentage} className="h-2" />
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="md:col-span-2 flex flex-wrap gap-4">
          <Button onClick={onRetake} className="flex-1 gap-2">
            <RotateCcw className="w-4 h-4" />
            Take Another Quiz
          </Button>
          <Button variant="outline" className="flex-1 gap-2">
            <TrendingUp className="w-4 h-4" />
            View Detailed Analysis
          </Button>
        </div>
      </div>
    </div>
  );
}
