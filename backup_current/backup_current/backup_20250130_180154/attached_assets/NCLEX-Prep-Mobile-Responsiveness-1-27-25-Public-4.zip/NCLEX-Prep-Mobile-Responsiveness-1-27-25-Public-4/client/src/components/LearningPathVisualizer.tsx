import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { Brain, Book, Video, Layout } from "lucide-react";
import type { DomainPerformanceData } from "@/types/recommendations";

interface LearningPathProps {
  domainScores: DomainPerformanceData[];
  recommendedFormats: Array<{
    type: "text" | "video" | "interactive" | "simulation";
    count: number;
  }>;
  loading?: boolean;
}

export function LearningPathVisualizer({
  domainScores,
  recommendedFormats,
  loading = false,
}: LearningPathProps) {
  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Learning Path Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 animate-pulse">
            <div className="h-[200px] bg-gray-200 rounded" />
            <div className="space-y-2">
              <div className="h-4 bg-gray-200 rounded w-3/4" />
              <div className="h-2 bg-gray-200 rounded" />
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getFormatIcon = (type: string) => {
    switch (type) {
      case "video":
        return <Video className="h-5 w-5" />;
      case "interactive":
        return <Layout className="h-5 w-5" />;
      case "simulation":
        return <Brain className="h-5 w-5" />;
      default:
        return <Book className="h-5 w-5" />;
    }
  };

  const chartData = domainScores.map((domain) => ({
    name: domain.name,
    score: domain.score,
    color:
      domain.trend === "improving"
        ? "#22c55e"
        : domain.trend === "declining"
          ? "#ef4444"
          : "#3b82f6",
  }));

  return (
    <Card>
      <CardHeader>
        <CardTitle>Learning Path Analysis</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Domain Performance Chart */}
          <div className="h-[200px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={chartData}
                margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="name"
                  tick={{ fontSize: 12 }}
                  interval={0}
                  angle={-45}
                  textAnchor="end"
                />
                <YAxis domain={[0, 100]} />
                <Tooltip
                  formatter={(value) => [`${value}%`, "Score"]}
                  contentStyle={{
                    backgroundColor: "hsl(var(--popover))",
                    border: "none",
                  }}
                  labelStyle={{ color: "hsl(var(--popover-foreground))" }}
                />
                <Bar
                  dataKey="score"
                  fill="currentColor"
                  className="fill-primary"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Recommended Learning Formats */}
          <div className="space-y-4">
            <h3 className="font-medium text-sm">
              Recommended Learning Formats
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {recommendedFormats.map((format, index) => (
                <Card key={index} className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    {getFormatIcon(format.type)}
                    <span className="capitalize text-sm font-medium">
                      {format.type}
                    </span>
                  </div>
                  <Progress
                    value={format.count}
                    max={Math.max(...recommendedFormats.map((f) => f.count))}
                    className="h-2"
                  />
                  <span className="text-xs text-muted-foreground mt-1 block">
                    {format.count} modules
                  </span>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
