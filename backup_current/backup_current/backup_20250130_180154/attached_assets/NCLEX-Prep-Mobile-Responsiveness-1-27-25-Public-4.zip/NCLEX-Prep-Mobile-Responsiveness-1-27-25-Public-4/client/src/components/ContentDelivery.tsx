import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Video, Book, Layout, Brain } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

interface ContentDeliveryProps {
  moduleId: number;
  title: string;
  content: {
    type: "video" | "text" | "interactive" | "simulation";
    data: string;
    description: string;
  }[];
  learningStyle: {
    visual: number;
    auditory: number;
    kinesthetic: number;
    reading: number;
  };
}

export function ContentDelivery({
  moduleId,
  title,
  content,
  learningStyle,
}: ContentDeliveryProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const currentContent = content[currentIndex];

  const getContentIcon = (type: string) => {
    switch (type) {
      case "video":
        return <Video className="h-5 w-5" />;
      case "interactive":
        return <Layout className="h-5 w-5" />;
      case "simulation":
        return <Brain className="h-5 w-5" />;
      default:
        return <Book className="h-5 w-5" />;
    }
  };

  // Calculate content effectiveness based on learning style
  const getEffectivenessScore = (type: string) => {
    switch (type) {
      case "video":
        return learningStyle.visual;
      case "interactive":
        return learningStyle.auditory;
      case "simulation":
        return learningStyle.kinesthetic;
      case "text":
        return learningStyle.reading;
      default:
        return 0.5;
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {getContentIcon(currentContent.type)}
          <span>{title}</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Content Display */}
          <div className="min-h-[300px] p-4 bg-muted rounded-lg">
            {currentContent.data}
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              disabled={currentIndex === 0}
              onClick={() => setCurrentIndex((prev) => prev - 1)}
            >
              Previous
            </Button>
            <div className="flex-1 mx-4">
              <Progress
                value={((currentIndex + 1) / content.length) * 100}
                className="h-2"
              />
              <p className="text-xs text-muted-foreground text-center mt-1">
                {currentIndex + 1} of {content.length}
              </p>
            </div>
            <Button
              variant="outline"
              disabled={currentIndex === content.length - 1}
              onClick={() => setCurrentIndex((prev) => prev + 1)}
            >
              Next
            </Button>
          </div>

          {/* Learning Style Match */}
          <div className="mt-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Learning Style Match</span>
              <span className="text-sm">
                {Math.round(getEffectivenessScore(currentContent.type) * 100)}%
              </span>
            </div>
            <Progress
              value={getEffectivenessScore(currentContent.type) * 100}
              className="h-2"
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
