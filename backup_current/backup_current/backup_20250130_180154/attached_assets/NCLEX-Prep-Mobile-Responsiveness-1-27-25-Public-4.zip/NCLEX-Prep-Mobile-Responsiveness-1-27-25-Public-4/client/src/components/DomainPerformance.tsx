import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Brain, Target, TrendingUp, AlertTriangle } from "lucide-react";
import { type DomainPerformanceData } from "@/types/recommendations";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { cn } from "@/lib/utils";

interface Props {
  domains: DomainPerformanceData[];
  loading?: boolean;
  error?: string;
}

export function DomainPerformance({ domains, loading = false, error }: Props) {
  if (error) {
    return (
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Domain Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 animate-pulse">
            {[1, 2, 3].map((i) => (
              <div key={i} className="space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4" />
                <div className="h-2 bg-gray-200 rounded" />
                <div className="h-2 bg-gray-200 rounded w-1/2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Sort domains by performance score in descending order
  const sortedDomains = [...domains].sort((a, b) => b.score - a.score);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-xl font-bold">Domain Performance</CardTitle>
        <Target className="h-5 w-5 text-muted-foreground" />
      </CardHeader>
      <CardContent className="space-y-4 pt-4">
        {sortedDomains.map((domain, index) => (
          <div key={index} className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="font-medium">{domain.name}</span>
                {domain.trend && (
                  <span className={`text-sm ${getTrendColor(domain.trend)}`}>
                    {domain.trend === "improving" && (
                      <div className="flex items-center gap-1">
                        <TrendingUp className="h-4 w-4 inline" />
                        <span className="text-xs">Improving</span>
                      </div>
                    )}
                    {domain.trend === "declining" && (
                      <div className="flex items-center gap-1">
                        <TrendingUp className="h-4 w-4 inline rotate-180" />
                        <span className="text-xs">Needs Focus</span>
                      </div>
                    )}
                    {domain.trend === "stable" && (
                      <div className="flex items-center gap-1">
                        <Brain className="h-4 w-4 inline" />
                        <span className="text-xs">Stable</span>
                      </div>
                    )}
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`text-sm font-medium ${getScoreColor(domain.score)}`}
                >
                  {Math.round(domain.score)}%
                </span>
              </div>
            </div>
            <Progress
              value={domain.score}
              className={cn("h-2", getProgressColor(domain.score))}
            />
            {domain.recommendations && domain.recommendations.length > 0 && (
              <div className="text-sm text-muted-foreground mt-1 bg-muted/50 p-2 rounded-md">
                <ul className="list-disc list-inside space-y-1">
                  {domain.recommendations.map((rec, idx) => (
                    <li key={idx} className="text-xs">
                      {rec}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ))}
        {sortedDomains.length === 0 && (
          <div className="text-center text-muted-foreground py-4">
            No domain performance data available yet. Complete more questions to
            see your progress.
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function getTrendColor(trend: "improving" | "declining" | "stable"): string {
  switch (trend) {
    case "improving":
      return "text-green-500";
    case "declining":
      return "text-red-500";
    case "stable":
      return "text-blue-500";
    default:
      return "";
  }
}

function getScoreColor(score: number): string {
  if (score >= 80) return "text-green-600";
  if (score >= 60) return "text-yellow-600";
  return "text-red-600";
}

function getProgressColor(score: number): string {
  if (score >= 80) return "bg-green-600";
  if (score >= 60) return "bg-yellow-600";
  return "bg-red-600";
}
