import { useState, useEffect, useRef } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Brain, Volume2, VolumeX, Check, X, Plus } from "lucide-react";
import type { Flashcard } from "@db/schema";

interface VoiceFlashcardReviewProps {
  initialFlashcards?: Flashcard[];
  onComplete?: (results: { correct: number; total: number }) => void;
}

export function VoiceFlashcardReview({
  initialFlashcards,
  onComplete,
}: VoiceFlashcardReviewProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [topic, setTopic] = useState("");
  const [correctAnswers, setCorrectAnswers] = useState<Record<number, boolean>>(
    {},
  );
  const speechSynthesisRef = useRef<SpeechSynthesisUtterance>();
  const { toast } = useToast();

  // Fetch due flashcards if not provided
  const {
    data: fetchedFlashcards,
    isLoading: isLoadingFlashcards,
    refetch,
  } = useQuery<Flashcard[]>({
    queryKey: ["/api/flashcards/due"],
    enabled: !initialFlashcards,
  });

  // Generate new flashcards
  const generateMutation = useMutation({
    mutationFn: async (topic: string) => {
      const response = await fetch("/api/flashcards/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic }),
      });

      if (!response.ok) {
        throw new Error("Failed to generate flashcards");
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "New flashcards generated! Refreshing list...",
      });
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description:
          error instanceof Error
            ? error.message
            : "Failed to generate flashcards",
        variant: "destructive",
      });
    },
  });

  const flashcards = initialFlashcards || fetchedFlashcards || [];

  // Update flashcard progress
  const updateProgress = useMutation({
    mutationFn: async (data: {
      flashcardId: number;
      isCorrect: boolean;
      confidence: number;
    }) => {
      const response = await fetch("/api/flashcards/progress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error("Failed to update progress");
      }

      return response.json();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to update progress",
        variant: "destructive",
      });
    },
  });

  // Speech synthesis setup
  useEffect(() => {
    speechSynthesisRef.current = new SpeechSynthesisUtterance();
    return () => {
      if (speechSynthesisRef.current) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const speakText = (text: string) => {
    if (!voiceEnabled || !speechSynthesisRef.current) return;

    window.speechSynthesis.cancel();
    speechSynthesisRef.current.text = text;
    speechSynthesisRef.current.rate = 1;
    speechSynthesisRef.current.pitch = 1;
    speechSynthesisRef.current.onstart = () => setIsPlaying(true);
    speechSynthesisRef.current.onend = () => setIsPlaying(false);
    window.speechSynthesis.speak(speechSynthesisRef.current);
  };

  const toggleVoice = () => {
    setVoiceEnabled(!voiceEnabled);
    if (voiceEnabled) {
      window.speechSynthesis.cancel();
    }
  };

  const handleResponse = (isCorrect: boolean) => {
    const currentCard = flashcards[currentIndex];
    setCorrectAnswers((prev) => ({ ...prev, [currentIndex]: isCorrect }));

    updateProgress.mutate({
      flashcardId: currentCard.id,
      isCorrect,
      confidence: isCorrect ? 5 : 1,
    });

    window.speechSynthesis.cancel();

    if (currentIndex === flashcards.length - 1) {
      const results = {
        correct: Object.values(correctAnswers).filter(Boolean).length,
        total: flashcards.length,
      };
      onComplete?.(results);
    } else {
      setCurrentIndex((prev) => prev + 1);
      setShowAnswer(false);
    }
  };

  const currentCard = flashcards[currentIndex];
  const progressPercentage = ((currentIndex + 1) / flashcards.length) * 100;

  if (isLoadingFlashcards) {
    return (
      <Card className="w-full">
        <CardContent className="pt-6 flex justify-center">
          <Loader2 className="h-6 w-6 animate-spin" />
        </CardContent>
      </Card>
    );
  }

  if (!currentCard || flashcards.length === 0) {
    return (
      <Card className="w-full">
        <CardContent className="pt-6">
          <div className="text-center space-y-4">
            <p className="font-medium">No flashcards available</p>
            <div className="flex flex-col gap-4 max-w-sm mx-auto">
              <input
                type="text"
                placeholder="Enter topic for new flashcards..."
                className="border rounded px-3 py-2"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
              />
              <Button
                onClick={() => generateMutation.mutate(topic)}
                disabled={!topic || generateMutation.isPending}
              >
                <Plus className="h-4 w-4 mr-2" />
                Generate New Flashcards
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            Voice-Enabled Flashcard Review
          </span>
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleVoice}
            className={voiceEnabled ? "text-primary" : "text-muted-foreground"}
          >
            {voiceEnabled ? (
              <Volume2 className="h-5 w-5" />
            ) : (
              <VolumeX className="h-5 w-5" />
            )}
          </Button>
        </CardTitle>
        <Progress value={progressPercentage} className="w-full" />
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div
            className="min-h-[200px] p-6 bg-muted rounded-lg flex items-center justify-center text-center cursor-pointer"
            onClick={() => {
              if (!showAnswer) {
                speakText(currentCard.front);
              }
            }}
          >
            <div className="space-y-4">
              <div className="text-lg">
                {showAnswer ? currentCard.back : currentCard.front}
              </div>
              {isPlaying && (
                <div className="mt-2">
                  <Loader2 className="h-4 w-4 animate-spin inline-block" />
                </div>
              )}
            </div>
          </div>

          <div className="space-y-4">
            {!showAnswer ? (
              <Button
                className="w-full"
                onClick={() => {
                  setShowAnswer(true);
                  if (voiceEnabled) {
                    speakText(currentCard.back);
                  }
                }}
                disabled={updateProgress.isPending}
              >
                Show Answer
              </Button>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => handleResponse(false)}
                  disabled={updateProgress.isPending}
                >
                  <X className="h-4 w-4 mr-2" />
                  Incorrect
                </Button>
                <Button
                  className="w-full"
                  onClick={() => handleResponse(true)}
                  disabled={updateProgress.isPending}
                >
                  <Check className="h-4 w-4 mr-2" />
                  Correct
                </Button>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
