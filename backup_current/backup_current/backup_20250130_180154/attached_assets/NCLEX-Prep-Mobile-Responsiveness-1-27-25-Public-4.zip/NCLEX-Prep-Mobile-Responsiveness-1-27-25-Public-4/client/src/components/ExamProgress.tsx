import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Brain, Clock, Target } from "lucide-react";

interface ExamProgressProps {
  currentQuestion: number;
  totalQuestions: number;
  timeRemaining: number;
  difficulty: string;
  category: string;
}

export function ExamProgress({
  currentQuestion,
  totalQuestions,
  timeRemaining,
  difficulty,
  category,
}: ExamProgressProps) {
  const progress = (currentQuestion / totalQuestions) * 100;

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    return `${hours}:${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`;
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case "easy":
        return "bg-green-500/10 text-green-500";
      case "medium":
        return "bg-yellow-500/10 text-yellow-500";
      case "hard":
        return "bg-red-500/10 text-red-500";
      default:
        return "bg-gray-500/10 text-gray-500";
    }
  };

  return (
    <Card className="mb-6">
      <CardContent className="pt-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-4">
            <div className="p-2 rounded-full bg-primary/10">
              <Brain className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold">
                Question {currentQuestion} of {totalQuestions}
              </h3>
              <div className="flex gap-2 mt-1">
                <Badge
                  variant="secondary"
                  className={getDifficultyColor(difficulty)}
                >
                  {difficulty}
                </Badge>
                <Badge variant="outline">{category}</Badge>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-muted-foreground" />
            <span className="font-mono text-lg">
              {formatTime(timeRemaining)}
            </span>
          </div>
        </div>
        <Progress value={progress} className="h-2" />
        <div className="flex justify-between text-sm text-muted-foreground mt-2">
          <span>{progress.toFixed(0)}% Complete</span>
          <span>{totalQuestions - currentQuestion} Questions Remaining</span>
        </div>
      </CardContent>
    </Card>
  );
}
