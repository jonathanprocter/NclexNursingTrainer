import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import {
  BookOpen,
  Search,
  Filter,
  CheckCircle,
  AlertCircle,
  Clock,
  Bookmark,
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface ContentBrowserProps {
  onSelectQuestion?: (questionId: string) => void;
}

// Mock data - will be replaced with actual API data
const mockCategories = [
  {
    id: "1",
    name: "Fundamentals of Nursing",
    questionCount: 150,
    completed: 45,
  },
  {
    id: "2",
    name: "Medical-Surgical Nursing",
    questionCount: 200,
    completed: 80,
  },
  { id: "3", name: "Pharmacology", questionCount: 175, completed: 30 },
];

const mockQuestions = [
  {
    id: "q1",
    category: "1",
    question:
      "A client with type 2 diabetes mellitus has a blood glucose level of 180 mg/dL before lunch. Which nursing intervention is most appropriate?",
    difficulty: "medium",
    completed: true,
    lastAttempted: "2024-01-15",
  },
  {
    id: "q2",
    category: "1",
    question:
      "The nurse is caring for a client who has just returned from surgery. Which assessment finding requires immediate intervention?",
    difficulty: "hard",
    completed: false,
    lastAttempted: null,
  },
];

export function ContentBrowser({ onSelectQuestion }: ContentBrowserProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");
  const [difficultyFilter, setDifficultyFilter] = useState<string>("");

  const filteredQuestions = mockQuestions.filter((q) => {
    if (selectedCategory && q.category !== selectedCategory) return false;
    if (
      searchQuery &&
      !q.question.toLowerCase().includes(searchQuery.toLowerCase())
    )
      return false;
    if (difficultyFilter && q.difficulty !== difficultyFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <div className="grid gap-4 md:grid-cols-3">
        <div className="relative">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search questions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8"
          />
        </div>
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger>
            <SelectValue placeholder="Select category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Categories</SelectItem>
            {mockCategories.map((category) => (
              <SelectItem key={category.id} value={category.id}>
                {category.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
          <SelectTrigger>
            <SelectValue placeholder="Difficulty" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Difficulties</SelectItem>
            <SelectItem value="easy">Easy</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="hard">Hard</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Categories Overview */}
      <div className="grid gap-4 md:grid-cols-3">
        {mockCategories.map((category) => (
          <Card key={category.id} className="relative overflow-hidden">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                {category.name}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Progress</span>
                  <span>
                    {category.completed}/{category.questionCount}
                  </span>
                </div>
                <Progress
                  value={(category.completed / category.questionCount) * 100}
                />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Questions List */}
      <div className="space-y-4">
        {filteredQuestions.map((question) => (
          <Card
            key={question.id}
            className="relative overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
            onClick={() => onSelectQuestion?.(question.id)}
          >
            <CardContent className="pt-6">
              <div className="absolute top-2 right-2 flex gap-2">
                {question.completed ? (
                  <Badge variant="default" className="flex items-center gap-1">
                    <CheckCircle className="h-3 w-3" />
                    Completed
                  </Badge>
                ) : (
                  <Badge
                    variant="secondary"
                    className="flex items-center gap-1"
                  >
                    <AlertCircle className="h-3 w-3" />
                    Not Attempted
                  </Badge>
                )}
                <Badge variant="outline" className="flex items-center gap-1">
                  <Filter className="h-3 w-3" />
                  {question.difficulty}
                </Badge>
              </div>
              <p className="text-sm">{question.question}</p>
              <div className="mt-4 flex items-center gap-4 text-sm text-muted-foreground">
                {question.lastAttempted && (
                  <span className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    Last attempted:{" "}
                    {new Date(question.lastAttempted).toLocaleDateString()}
                  </span>
                )}
                <Button variant="ghost" size="sm" className="ml-auto">
                  <Bookmark className="h-4 w-4" />
                  Save for Later
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
