import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import { Brain, Book, Target, TrendingUp } from "lucide-react";
import { type Recommendation } from "@/types/recommendations";

interface Props {
  recommendations: Recommendation[];
  onStartModule: (moduleId: number) => void;
  loading?: boolean;
}

export function AdaptiveRecommendations({
  recommendations,
  onStartModule,
  loading = false,
}: Props) {
  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Personalized Recommendations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 animate-pulse">
            {[1, 2].map((i) => (
              <div key={i} className="space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4" />
                <div className="h-2 bg-gray-200 rounded" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Sort recommendations by priority (highest first)
  const sortedRecommendations = [...recommendations].sort(
    (a, b) => b.priority - a.priority,
  );

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-xl font-bold">
          Personalized Recommendations
        </CardTitle>
        <Brain className="h-5 w-5 text-muted-foreground" />
      </CardHeader>
      <CardContent className="space-y-4 pt-4">
        {sortedRecommendations.map((rec, index) => (
          <Card key={index} className="p-4 border-l-4 border-l-primary">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-lg">{rec.title}</h3>
                {rec.priority > 2 && (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                    High Priority
                  </span>
                )}
              </div>
              <p className="text-sm text-muted-foreground">{rec.description}</p>
              <div className="text-sm text-muted-foreground italic">
                Reason: {rec.reason}
              </div>
              {rec.progress !== undefined && (
                <div className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span>Progress</span>
                    <span>{Math.round(rec.progress)}%</span>
                  </div>
                  <Progress value={rec.progress} className="h-1" />
                </div>
              )}
              <Button
                onClick={() => onStartModule(rec.moduleId)}
                disabled={rec.status === "completed"}
                className="w-full mt-2"
                variant={rec.status === "completed" ? "outline" : "default"}
              >
                {rec.status === "completed" ? (
                  <>
                    <Book className="mr-2 h-4 w-4" />
                    Completed
                  </>
                ) : rec.status === "in_progress" ? (
                  <>
                    <TrendingUp className="mr-2 h-4 w-4" />
                    Continue
                  </>
                ) : (
                  <>
                    <Target className="mr-2 h-4 w-4" />
                    Start Module
                  </>
                )}
              </Button>
            </div>
          </Card>
        ))}
        {sortedRecommendations.length === 0 && (
          <div className="text-center text-muted-foreground py-4">
            No recommendations available at this time. Complete more modules to
            receive personalized suggestions.
          </div>
        )}
      </CardContent>
    </Card>
  );
}
