import { useQuery } from "@tanstack/react-query";
import { Card } from "../components/ui/card";
import { Progress } from "../components/ui/progress";
import { Badge } from "../components/ui/badge";
import { Brain, LineChart, AlertCircle, CheckCircle } from "lucide-react";

interface LearningMetrics {
  currentScore: number;
  confidenceLevel: number;
  clinicalJudgmentScore: number;
  learningStyle: {
    visual: number;
    practical: number;
    theoretical: number;
  };
  retentionMetrics: {
    shortTerm: number;
    longTerm: number;
    applicationRate: number;
  };
}

interface PredictionMetrics {
  readinessScore: number;
  predictedPerformance: number;
  confidenceInterval: {
    lower: number;
    upper: number;
  };
  recommendations: string[];
  riskFactors: string[];
  strengthIndicators: string[];
}

interface AnalyticsData {
  metrics: LearningMetrics;
  predictions: PredictionMetrics;
  struggleAreas: string[];
}

export function PredictiveAnalytics() {
  const { data, isLoading, error } = useQuery<AnalyticsData>({
    queryKey: ["/api/analytics/realtime"],
    retry: 2,
    refetchInterval: 300000, // Refresh every 5 minutes
  });

  // Handle loading state
  if (isLoading) {
    return (
      <Card className="p-6">
        <div className="space-y-4">
          <div className="h-4 bg-gray-200 animate-pulse rounded" />
          <div className="h-8 bg-gray-200 animate-pulse rounded" />
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-4 bg-gray-200 animate-pulse rounded" />
            ))}
          </div>
        </div>
      </Card>
    );
  }

  // Handle error states
  if (error) {
    return (
      <Card className="p-6">
        <div className="text-center text-gray-500">
          <AlertCircle className="mx-auto h-8 w-8 mb-2 text-red-500" />
          <p>Unable to load analytics data. Please try again later.</p>
          <p className="text-sm mt-2 text-red-400">
            {error instanceof Error ? error.message : "An error occurred"}
          </p>
        </div>
      </Card>
    );
  }

  // Show initial state when no data is available
  const defaultData: AnalyticsData = {
    metrics: {
      currentScore: 0,
      confidenceLevel: 0,
      clinicalJudgmentScore: 0,
      learningStyle: {
        visual: 0,
        practical: 0,
        theoretical: 0,
      },
      retentionMetrics: {
        shortTerm: 0,
        longTerm: 0,
        applicationRate: 0,
      },
    },
    predictions: {
      readinessScore: 0,
      predictedPerformance: 0,
      confidenceInterval: { lower: 0, upper: 0 },
      recommendations: ["Complete practice questions to see predictions"],
      riskFactors: [],
      strengthIndicators: [],
    },
    struggleAreas: [],
  };

  const analytics = data || defaultData;

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="p-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">
              Personalized Recommendations
            </h3>
            <Brain className="h-5 w-5 text-muted-foreground" />
          </div>
          <div className="space-y-2">
            {analytics.predictions.recommendations.map((rec, i) => (
              <p key={i} className="text-sm text-muted-foreground">
                {rec}
              </p>
            ))}
          </div>
          <div className="mt-4">
            <h4 className="font-medium mb-2">Detailed Performance Analysis</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              {analytics.predictions.strengthIndicators.map((strength, i) => (
                <li key={`strength-${i}`} className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  {strength}
                </li>
              ))}
              {analytics.predictions.riskFactors.map((risk, i) => (
                <li key={`risk-${i}`} className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-yellow-500" />
                  {risk}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Card>
      <Card className="p-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Learning Progress</h3>
            <LineChart className="h-5 w-5 text-muted-foreground" />
          </div>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-1">
                <span>Clinical Judgment</span>
                <span>
                  {Math.round(analytics.metrics.clinicalJudgmentScore * 100)}%
                </span>
              </div>
              <Progress value={analytics.metrics.clinicalJudgmentScore * 100} />
            </div>
            <div>
              <div className="flex justify-between mb-1">
                <span>Overall Confidence</span>
                <span>
                  {Math.round(analytics.metrics.confidenceLevel * 100)}%
                </span>
              </div>
              <Progress value={analytics.metrics.confidenceLevel * 100} />
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
